import { resolve } from 'path';
import { fileURLToPath } from 'url';
import type { BuildOptions } from 'esbuild';
import { readFileSync } from 'fs';
import jsonSchemaPlugin from './jsonSchemaPlugin.js';
import type { PackageOptions } from '../.build/common.js';
import { jisonPlugin } from './jisonPlugin.js';

const __dirname = fileURLToPath(new URL('.', import.meta.url));

// For e2e coverage we serve an uninstrumented bundle and collect native V8
// coverage in the browser (see e2e/helpers/coverage.ts). monocart maps the V8
// data back to source via the bundle's source map, which must be inline for it
// to resolve — so the coverage build emits inline maps instead of external ones.
const coverageBuild = process.env.MERMAID_COVERAGE === 'true';

export interface MermaidBuildOptions extends BuildOptions {
  minify: boolean;
  core: boolean;
  metafile: boolean;
  format: 'esm' | 'iife';
  options: PackageOptions;
  includeLargeFeatures: boolean;
  /** Compile the render profiler into the bundle (dev/profiling builds only). */
  profiling: boolean;
}

export const defaultOptions: Omit<MermaidBuildOptions, 'entryName' | 'options'> = {
  minify: false,
  metafile: false,
  core: false,
  format: 'esm',
  includeLargeFeatures: true,
  profiling: false,
} as const;

const buildOptions = (override: BuildOptions): BuildOptions => {
  return {
    bundle: true,
    minify: true,
    keepNames: true,
    platform: 'browser',
    tsconfig: 'tsconfig.json',
    resolveExtensions: ['.ts', '.js', '.json', '.jison', '.yaml'],
    external: ['require', 'fs', 'path'],
    outdir: 'dist',
    plugins: [jisonPlugin, jsonSchemaPlugin],
    sourcemap: coverageBuild ? 'inline' : 'external',
    ...override,
  };
};

const getFileName = (
  fileName: string,
  { core, format, minify, includeLargeFeatures }: MermaidBuildOptions
) => {
  if (core) {
    fileName += '.core';
  } else if (format === 'esm') {
    fileName += '.esm';
  }
  if (!includeLargeFeatures) {
    fileName += '.tiny';
  }
  if (minify) {
    fileName += '.min';
  }
  return fileName;
};

export const getBuildConfig = (options: MermaidBuildOptions): BuildOptions => {
  const {
    core,
    format,
    options: { name, file, packageName },
    globalName = 'mermaid',
    includeLargeFeatures,
    profiling,
    ...rest
  } = options;

  const external: string[] = ['require', 'fs', 'path'];
  const outFileName = getFileName(name, options);
  const { dependencies, peerDependencies, version } = JSON.parse(
    readFileSync(resolve(__dirname, `../packages/${packageName}/package.json`), 'utf-8')
  );
  const output: BuildOptions = buildOptions({
    ...rest,
    absWorkingDir: resolve(__dirname, `../packages/${packageName}`),
    entryPoints: {
      [outFileName]: `src/${file}`,
    },
    globalName,
    logLevel: 'info',
    chunkNames: `chunks/${outFileName}/[name]-[hash]`,
    define: {
      // This needs to be stringified for esbuild
      'injected.includeLargeFeatures': `${includeLargeFeatures}`,
      'injected.profiling': `${profiling}`,
      'injected.version': `'${version}'`,
      'import.meta.vitest': 'undefined',
    },
  });

  if (core) {
    // Core build is used to generate file without bundled dependencies.
    // This is used by downstream projects to bundle dependencies themselves.
    // Ignore dependencies and any dependencies of dependencies
    //
    // peerDependencies must be external too. The consumer is the one that
    // supplies them, so inlining one ships a second copy of that package —
    // with its own module-level singletons — inside this bundle. For the
    // layout plugins that peer dep is mermaid itself: a runtime (non-type)
    // import of it resolves through `exports` to dist/mermaid.core.mjs and
    // esbuild would inline the whole thing, so the plugin would run against
    // its own stale mermaid rather than the host's.
    external.push(...Object.keys(dependencies ?? {}), ...Object.keys(peerDependencies ?? {}));
    output.external = external;
  }

  if (format === 'iife') {
    output.format = 'iife';
    output.splitting = false;
    const originalGlobalName = output.globalName ?? 'mermaid';
    output.globalName = `__esbuild_esm_mermaid_nm[${JSON.stringify(originalGlobalName)}]`;
    // Workaround for removing the .default access in esbuild IIFE.
    // https://github.com/mermaid-js/mermaid/pull/4109#discussion_r1292317396
    output.footer = {
      js: `globalThis[${JSON.stringify(originalGlobalName)}] = globalThis.${output.globalName}.default;`,
    };
    output.outExtension = { '.js': '.js' };
  } else {
    output.format = 'esm';
    output.splitting = true;
    output.outExtension = { '.js': '.mjs' };
  }

  return output;
};
