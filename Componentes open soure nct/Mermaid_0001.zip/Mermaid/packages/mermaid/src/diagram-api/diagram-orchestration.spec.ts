import { it, describe, expect } from 'vitest';
import { detectType } from './detectType.js';
import { addDiagrams } from './diagram-orchestration.js';

describe('diagram-orchestration', () => {
  it('should register diagrams', () => {
    expect(() => detectType('graph TD; A-->B')).toThrow();
    addDiagrams();
    expect(detectType('graph TD; A-->B')).toBe('flowchart');
  });

  describe('proper diagram types should be detected', () => {
    beforeAll(() => {
      addDiagrams();
    });

    it.each([
      { text: 'graph TD;', expected: 'flowchart' },
      { text: 'flowchart TD;', expected: 'flowchart-v2' },
      { text: 'flowchart-v2 TD;', expected: 'flowchart-v2' },
      { text: 'flowchart-elk TD;', expected: 'flowchart-elk' },
      { text: 'swimlane-beta TD;', expected: 'swimlane' },
      { text: 'error', expected: 'error' },
      { text: 'C4Context;', expected: 'c4' },
      { text: 'classDiagram', expected: 'class' },
      { text: 'classDiagram-v2', expected: 'classDiagram' },
      { text: 'erDiagram', expected: 'er' },
      { text: 'journey', expected: 'journey' },
      { text: 'gantt', expected: 'gantt' },
      { text: 'pie', expected: 'pie' },
      { text: 'requirementDiagram', expected: 'requirement' },
      { text: 'info', expected: 'info' },
      { text: 'sequenceDiagram', expected: 'sequence' },
      { text: 'mindmap', expected: 'mindmap' },
      { text: 'timeline', expected: 'timeline' },
      { text: 'gitGraph', expected: 'gitGraph' },
      { text: 'stateDiagram', expected: 'state' },
      { text: 'stateDiagram-v2', expected: 'stateDiagram' },
    ])(
      'should $text be detected as $expected',
      ({ text, expected }: { text: string; expected: string }) => {
        expect(detectType(text)).toBe(expected);
      }
    );

    it('should detect proper flowchart type based on config', () => {
      // graph & dagre-d3 => flowchart
      expect(detectType('graph TD; A-->B')).toBe('flowchart');
      // graph & dagre-d3 => flowchart
      expect(detectType('graph TD; A-->B', { flowchart: { defaultRenderer: 'dagre-d3' } })).toBe(
        'flowchart'
      );
      // flowchart & dagre-d3 => error
      expect(() =>
        detectType('flowchart TD; A-->B', { flowchart: { defaultRenderer: 'dagre-d3' } })
      ).toThrowErrorMatchingInlineSnapshot(
        `[UnknownDiagramError: No diagram type detected matching given configuration for text: flowchart TD; A-->B]`
      );

      // graph & dagre-wrapper => flowchart-v2
      expect(
        detectType('graph TD; A-->B', { flowchart: { defaultRenderer: 'dagre-wrapper' } })
      ).toBe('flowchart-v2');
      // flowchart ==> flowchart-v2
      expect(detectType('flowchart TD; A-->B')).toBe('flowchart-v2');
      // flowchart && dagre-wrapper ==> flowchart-v2
      expect(
        detectType('flowchart TD; A-->B', { flowchart: { defaultRenderer: 'dagre-wrapper' } })
      ).toBe('flowchart-v2');
      // flowchart && elk ==> flowchart-elk
      expect(detectType('flowchart TD; A-->B', { flowchart: { defaultRenderer: 'elk' } })).toBe(
        'flowchart-elk'
      );
      expect(detectType('swimlane-beta TD; A-->B', { flowchart: { defaultRenderer: 'elk' } })).toBe(
        'swimlane'
      );
    });

    it('should detect class diagram v2 when dagre-wrapper is the class renderer', () => {
      expect(detectType('classDiagram', { class: { defaultRenderer: 'dagre-wrapper' } })).toBe(
        'classDiagram'
      );
    });

    it('should not detect flowchart if pie contains flowchart', () => {
      expect(
        detectType(`pie title: "flowchart"
      flowchart: 1 "pie" pie: 2 "pie"`)
      ).toBe('pie');
    });

    it('should detect proper diagram when defaultRenderer is elk for flowchart', () => {
      expect(
        detectType('mindmap\n  root\n    Photograph\n      Waterfall', {
          flowchart: { defaultRenderer: 'elk' },
        })
      ).toBe('mindmap');
      expect(
        detectType(
          `
          classDiagram
            class Person {
              +String name
              -Int id
              #double age
              +Text demographicProfile
            }
          `,
          { flowchart: { defaultRenderer: 'elk' } }
        )
      ).toBe('class');
      expect(
        detectType(
          `
          erDiagram
            p[Photograph] {
              varchar(12) jobId
              date dateCreated
            }
          `,
          {
            flowchart: { defaultRenderer: 'elk' },
          }
        )
      ).toBe('er');
    });
  });
});
