import { getConfig } from '../../../diagram-api/diagramAPI.js';
import { getEffectiveHtmlLabels } from '../../../config.js';
import type { D3Selection, Bounds, Point } from '../../../types.js';
import type { Node } from '../../types.js';
import { labelHelper, updateNodeBounds, getNodeClasses } from './util.js';
import intersect from '../intersect/index.js';
import { createRoundedRectPathD } from './roundedRectPath.js';
import { userNodeOverrides, styles2String } from './handDrawnShapeStyles.js';
import rough from 'roughjs';
import { handleUndefinedAttr } from '../../../utils.js';
import { stampColorSlot } from '../../../diagrams/common/colorThemeGate.js';

/** Height reserved for the ellipsis indicator row below the title */
const INDICATOR_ROW_HEIGHT = 20;
/** Vertical gap between the title and the indicator row */
const SEPARATOR_GAP = 8;
/** Minimum width for the collapsed group shape */
const MIN_WIDTH = 80;
/** Corner radius matching the expanded subgraph (cluster rect) */
const RADIUS = 8;

interface CollapsedStyle {
  rx: number;
  fill: string;
  stroke: string;
  /** Omitted for the default look, which inherits the stylesheet's stroke width. */
  strokeWidth?: number;
  cssClass: string;
}

/**
 * Visual styling for a collapsed container.
 *
 * The default branch reproduces the plain flowchart `@{ view: collapsed }` look.
 * Agentflow tags its containers with `metadata.containerType` so that a collapsed
 * node keeps the visual identity of its expanded cluster (see clusters.js).
 */
function getCollapsedStyle(containerType: string | undefined): CollapsedStyle {
  const { themeVariables } = getConfig();
  const clusterBkg = themeVariables.clusterBkg;
  const clusterBorder = themeVariables.clusterBorder;

  switch (containerType) {
    // Agentflow's grammar has a single container kind (`flow`); a collapsed
    // flow keeps the visual identity of its expanded cluster (see clusters.js).
    case 'flow':
      return {
        rx: 10,
        fill: 'none',
        stroke: themeVariables.flowContainerStroke || themeVariables.secondaryBorderColor,
        strokeWidth: 0.75,
        cssClass: 'flow-collapsed',
      };
    default:
      return {
        rx: RADIUS,
        fill: clusterBkg,
        stroke: clusterBorder,
        cssClass: 'collapsed-group',
      };
  }
}

/**
 * Collapsed subgraph shape (flowchart `@{ view: collapsed }`).
 *
 * Renders a two-row layout that keeps the subgraph's visual identity while
 * signalling that it hides further content:
 *
 *   ┌─────────────────┐
 *   │   Title Text    │
 *   │─ ─ ─ ─ ─ ─ ─ ─ ─│  (separator line)
 *   │      • • •      │  (ellipsis indicator)
 *   └─────────────────┘
 */
export async function collapsedGroup<T extends SVGGraphicsElement>(
  parent: D3Selection<T>,
  node: Node
) {
  const style = getCollapsedStyle(node.metadata?.containerType as string | undefined);
  const { fill, stroke } = style;

  const { nodeStyles } = styles2String(node);

  const { shapeSvg, bbox } = await labelHelper(parent, node, getNodeClasses(node));

  // A collapsed subgraph is still a container, so it takes the same palette slot its
  // expanded form would. Without this it renders uncoloured beside tinted siblings, and
  // the seam shows up exactly when someone uses the collapse feature.
  const { theme, themeVariables } = getConfig();
  stampColorSlot(shapeSvg, node.colorIndex, theme, themeVariables.borderColorArray);

  const padding = node.padding ?? 8;
  const titleHeight = bbox.height;
  const totalWidth = Math.max(bbox.width + padding * 2, MIN_WIDTH, node?.width ?? 0);
  const totalHeight = Math.max(
    titleHeight + SEPARATOR_GAP + INDICATOR_ROW_HEIGHT + padding * 2,
    node?.height ?? 0
  );
  const x = -totalWidth / 2;
  const y = -totalHeight / 2;

  // labelHelper centers the label at (0,0). Shift it up into the title area so
  // there is room for the separator and the ellipsis indicator below it.
  const labelShiftY = -(SEPARATOR_GAP + INDICATOR_ROW_HEIGHT) / 2;
  const labelEl = shapeSvg.select('.label');
  if (labelEl) {
    const useHtmlLabels = node.useHtmlLabels ?? getEffectiveHtmlLabels(getConfig());
    if (useHtmlLabels) {
      labelEl.attr('transform', `translate(${-bbox.width / 2}, ${-bbox.height / 2 + labelShiftY})`);
    } else {
      labelEl.attr('transform', `translate(0, ${-bbox.height / 2 + labelShiftY})`);
    }
  }

  let rect;
  if (node.look === 'handDrawn') {
    // @ts-ignore TODO: Fix rough typings
    const rc = rough.svg(shapeSvg);
    const roughOpts = userNodeOverrides(node, {
      fill,
      stroke,
      ...(style.strokeWidth === undefined ? {} : { strokeWidth: style.strokeWidth }),
      ...(fill === 'none' ? { fillWeight: 0 } : { fillStyle: 'solid' }),
    });
    const roughNode = rc.path(
      createRoundedRectPathD(x, y, totalWidth, totalHeight, style.rx),
      roughOpts
    );
    rect = shapeSvg.insert(() => roughNode, ':first-child');
    rect
      .attr('class', 'basic label-container ' + style.cssClass)
      .attr('style', handleUndefinedAttr(node.cssStyles));
  } else {
    rect = shapeSvg.insert('rect', ':first-child');
    rect
      .attr('class', 'basic label-container ' + style.cssClass)
      .attr('style', nodeStyles)
      .attr('rx', style.rx)
      .attr('ry', style.rx)
      .attr('x', x)
      .attr('y', y)
      .attr('width', totalWidth)
      .attr('height', totalHeight)
      .attr('fill', fill)
      .attr('stroke', stroke);

    if (style.strokeWidth !== undefined) {
      rect.attr('stroke-width', style.strokeWidth + 'px');
    }
  }

  // -- Separator line between the title and the indicator row --
  const separatorY = y + padding + titleHeight + SEPARATOR_GAP;
  shapeSvg
    .append('line')
    .attr('class', 'collapsed-separator')
    .attr('x1', x + 8)
    .attr('y1', separatorY)
    .attr('x2', x + totalWidth - 8)
    .attr('y2', separatorY)
    .attr('stroke', stroke)
    .attr('stroke-dasharray', '3, 3');

  // -- Ellipsis dots (• • •) centered in the indicator row --
  const dotY = separatorY + INDICATOR_ROW_HEIGHT / 2;
  const dotRadius = 2.5;
  const dotSpacing = 10;
  for (let i = -1; i <= 1; i++) {
    shapeSvg
      .append('circle')
      .attr('class', 'collapsed-indicator')
      .attr('cx', i * dotSpacing)
      .attr('cy', dotY)
      .attr('r', dotRadius)
      .attr('fill', stroke);
  }

  updateNodeBounds(node, rect);

  node.calcIntersect = function (bounds: Bounds, point: Point) {
    return intersect.rect(bounds, point);
  };

  node.intersect = function (point) {
    return intersect.rect(node, point);
  };

  return shapeSvg;
}
