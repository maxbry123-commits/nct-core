import type { LangiumParser, ParseResult } from 'langium';

import type {
  Info,
  Packet,
  Pie,
  Architecture,
  GitGraph,
  EventModel,
  Radar,
  Railroad,
  RailroadEbnf,
  RailroadAbnf,
  RailroadPeg,
  Treemap,
  TreeView,
  Wardley,
  Cynefin,
} from './language/index.js';

export type DiagramAST =
  | Info
  | Packet
  | Pie
  | Architecture
  | GitGraph
  | EventModel
  | Radar
  | Railroad
  | RailroadEbnf
  | RailroadAbnf
  | RailroadPeg
  | Treemap
  | TreeView
  | Wardley
  | Cynefin;

const parsers: Record<string, LangiumParser> = {};
const initializers = {
  info: async () => {
    const { createInfoServices } = await import('./language/info/index.js');
    const parser = createInfoServices().Info.parser.LangiumParser;
    parsers.info = parser;
  },
  packet: async () => {
    const { createPacketServices } = await import('./language/packet/index.js');
    const parser = createPacketServices().Packet.parser.LangiumParser;
    parsers.packet = parser;
  },
  pie: async () => {
    const { createPieServices } = await import('./language/pie/index.js');
    const parser = createPieServices().Pie.parser.LangiumParser;
    parsers.pie = parser;
  },
  treeView: async () => {
    const { createTreeViewServices } = await import('./language/treeView/index.js');
    const parser = createTreeViewServices().TreeView.parser.LangiumParser;
    parsers.treeView = parser;
  },
  architecture: async () => {
    const { createArchitectureServices } = await import('./language/architecture/index.js');
    const parser = createArchitectureServices().Architecture.parser.LangiumParser;
    parsers.architecture = parser;
  },
  gitGraph: async () => {
    const { createGitGraphServices } = await import('./language/gitGraph/index.js');
    const parser = createGitGraphServices().GitGraph.parser.LangiumParser;
    parsers.gitGraph = parser;
  },
  eventmodeling: async () => {
    const { createEventModelingServices } = await import('./language/eventmodeling/index.js');
    const parser = createEventModelingServices().EventModel.parser.LangiumParser;
    parsers.eventmodeling = parser;
  },
  radar: async () => {
    const { createRadarServices } = await import('./language/radar/index.js');
    const parser = createRadarServices().Radar.parser.LangiumParser;
    parsers.radar = parser;
  },
  railroad: async () => {
    const { createRailroadServices } = await import('./language/railroad/index.js');
    const parser = createRailroadServices().Railroad.parser.LangiumParser;
    parsers.railroad = parser;
  },
  railroadEbnf: async () => {
    const { createRailroadEbnfServices } = await import('./language/railroad-ebnf/index.js');
    const parser = createRailroadEbnfServices().RailroadEbnf.parser.LangiumParser;
    parsers.railroadEbnf = parser;
  },
  railroadAbnf: async () => {
    const { createRailroadAbnfServices } = await import('./language/railroad-abnf/index.js');
    const parser = createRailroadAbnfServices().RailroadAbnf.parser.LangiumParser;
    parsers.railroadAbnf = parser;
  },
  railroadPeg: async () => {
    const { createRailroadPegServices } = await import('./language/railroad-peg/index.js');
    const parser = createRailroadPegServices().RailroadPeg.parser.LangiumParser;
    parsers.railroadPeg = parser;
  },
  treemap: async () => {
    const { createTreemapServices } = await import('./language/treemap/index.js');
    const parser = createTreemapServices().Treemap.parser.LangiumParser;
    parsers.treemap = parser;
  },
  wardley: async () => {
    const { createWardleyServices } = await import('./language/wardley/index.js');
    const parser = createWardleyServices().Wardley.parser.LangiumParser;
    parsers.wardley = parser;
  },
  cynefin: async () => {
    const { createCynefinServices } = await import('./language/cynefin/index.js');
    const parser = createCynefinServices().Cynefin.parser.LangiumParser;
    parsers.cynefin = parser;
  },
} as const;

export async function parse(diagramType: 'info', text: string): Promise<Info>;
export async function parse(diagramType: 'packet', text: string): Promise<Packet>;
export async function parse(diagramType: 'pie', text: string): Promise<Pie>;
export async function parse(diagramType: 'treeView', text: string): Promise<TreeView>;
export async function parse(diagramType: 'architecture', text: string): Promise<Architecture>;
export async function parse(diagramType: 'gitGraph', text: string): Promise<GitGraph>;
export async function parse(diagramType: 'eventmodeling', text: string): Promise<EventModel>;
export async function parse(diagramType: 'radar', text: string): Promise<Radar>;
export async function parse(diagramType: 'railroad', text: string): Promise<Railroad>;
export async function parse(diagramType: 'railroadEbnf', text: string): Promise<RailroadEbnf>;
export async function parse(diagramType: 'railroadAbnf', text: string): Promise<RailroadAbnf>;
export async function parse(diagramType: 'railroadPeg', text: string): Promise<RailroadPeg>;
export async function parse(diagramType: 'treemap', text: string): Promise<Treemap>;
export async function parse(diagramType: 'wardley', text: string): Promise<Wardley>;
export async function parse(diagramType: 'cynefin', text: string): Promise<Cynefin>;

export async function parse<T extends DiagramAST>(
  diagramType: keyof typeof initializers,
  text: string
): Promise<T> {
  const initializer = initializers[diagramType];
  if (!initializer) {
    throw new Error(`Unknown diagram type: ${diagramType}`);
  }
  if (!parsers[diagramType]) {
    await initializer();
  }
  const parser: LangiumParser = parsers[diagramType];
  const result: ParseResult<T> = parser.parse<T>(text);
  if (result.lexerErrors.length > 0 || result.parserErrors.length > 0) {
    throw new MermaidParseError(result);
  }
  return result.value;
}

export class MermaidParseError extends Error {
  constructor(public result: ParseResult<DiagramAST>) {
    const lexerErrors: string = result.lexerErrors
      .map((err) => {
        const line = err.line !== undefined && !isNaN(err.line) ? err.line : '?';
        const column = err.column !== undefined && !isNaN(err.column) ? err.column : '?';
        return `Lexer error on line ${line}, column ${column}: ${err.message}`;
      })
      .join('\n');
    const parserErrors: string = result.parserErrors
      .map((err) => {
        const line =
          err.token.startLine !== undefined && !isNaN(err.token.startLine)
            ? err.token.startLine
            : '?';
        const column =
          err.token.startColumn !== undefined && !isNaN(err.token.startColumn)
            ? err.token.startColumn
            : '?';
        return `Parse error on line ${line}, column ${column}: ${err.message}`;
      })
      .join('\n');
    super(`Parsing failed: ${lexerErrors} ${parserErrors}`);
  }
}
