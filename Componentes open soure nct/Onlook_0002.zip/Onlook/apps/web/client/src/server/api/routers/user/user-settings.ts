import { createDefaultUserSettings, fromDbUserSettings, userSettings, userSettingsUpdateSchema } from '@onlook/db';
import { eq } from 'drizzle-orm';
import { createTRPCRouter, protectedProcedure } from '../../trpc';

export const userSettingsRouter = createTRPCRouter({
    get: protectedProcedure.query(async ({ ctx }) => {
        const user = ctx.user;
        const settings = await ctx.db.query.userSettings.findFirst({
            where: eq(userSettings.userId, user.id),
        });
        return fromDbUserSettings(settings ?? createDefaultUserSettings(user.id));
    }),
    upsert: protectedProcedure.input(userSettingsUpdateSchema).mutation(async ({ ctx, input }) => {
        const user = ctx.user

        const existingSettings = await ctx.db.query.userSettings.findFirst({
            where: eq(userSettings.userId, user.id),
        });

        if (!existingSettings) {
            // Force the row's userId to the session user — `input` comes from
            // `userSettingsUpdateSchema`, which includes `userId`, so a supplied
            // value must not be able to create settings for another user.
            const newSettings = { ...createDefaultUserSettings(user.id), ...input, userId: user.id };
            const [insertedSettings] = await ctx.db.insert(userSettings).values(newSettings).returning();
            return fromDbUserSettings(insertedSettings ?? newSettings);
        }
        const [updatedSettings] = await ctx.db.update(userSettings).set({ ...input, userId: user.id }).where(eq(userSettings.userId, user.id)).returning();

        if (!updatedSettings) {
            throw new Error('Failed to update user settings');
        }

        return fromDbUserSettings(updatedSettings);
    }),
});
