import { source } from '@/lib/source';
import { getMDXComponents } from '@/mdx-components';
import { createRelativeLink } from 'fumadocs-ui/mdx';
import {
    DocsBody,
    DocsPage
} from 'fumadocs-ui/page';
import { notFound } from 'next/navigation';
import { EditGitHub } from './edit-gh';

export default async function Page(props: {
    params: Promise<{ slug?: string[] }>;
}) {
    const params = await props.params;
    const page = source.getPage(params.slug);
    if (!page) notFound();

    const MDXContent = page.data.body;

    const filePath = params.slug ? `${params.slug.join('/')}.mdx` : 'index.mdx';

    return (
        <DocsPage toc={page.data.toc} full={page.data.full}>
            <DocsBody>
                <MDXContent
                    components={getMDXComponents({
                        // this allows you to link to other pages with relative file paths
                        a: createRelativeLink(source, page),
                    })}
                />
            </DocsBody>
            <EditGitHub filePath={filePath} />
        </DocsPage>
    );
}

export async function generateStaticParams() {
    return source.generateParams();
}

export async function generateMetadata(props: {
    params: Promise<{ slug?: string[] }>;
}) {
    const params = await props.params;
    const page = source.getPage(params.slug);
    if (!page) notFound();

    // Compute OG image URL at /docs-og/…/image.png
    const image = ['/docs-og', ...(params.slug ?? []), 'image.png'].join('/');

    return {
        title: page.data.title,
        description: page.data.description,
        openGraph: {
            images: image,
        },
        twitter: {
            card: 'summary_large_image',
            images: image,
        },
    };
}
