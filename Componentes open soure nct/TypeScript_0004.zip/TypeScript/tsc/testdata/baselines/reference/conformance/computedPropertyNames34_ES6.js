//// [tests/cases/conformance/es6/computedProperties/computedPropertyNames34_ES6.ts] ////

//// [computedPropertyNames34_ES6.ts]
function foo<T>() { return '' }
class C<T> {
    static bar() {
        var obj = {
            [foo<T>()]() { }
        };
        return 0;
    }
}

//// [computedPropertyNames34_ES6.js]
"use strict";
function foo() { return ''; }
class C {
    static bar() {
        var obj = {
            [foo()]() { }
        };
        return 0;
    }
}
