//// [tests/cases/conformance/jsdoc/declarations/jsDeclarationsFunctionKeywordProp.ts] ////

//// [source.js]
function foo() {}
foo.null = true;

function bar() {}
bar.async = true;
bar.normal = false;

function baz() {}
baz.class = true;
baz.normal = false;

//// [source.js]
"use strict";
function foo() { }
foo.null = true;
function bar() { }
bar.async = true;
bar.normal = false;
function baz() { }
baz.class = true;
baz.normal = false;


//// [source.d.ts]
declare function foo(): void;
declare namespace foo {
    var _a: boolean;
    export { _a as null };
}
declare function bar(): void;
declare namespace bar {
    var async: boolean;
    var normal: boolean;
}
declare function baz(): void;
declare namespace baz {
    var _b: boolean;
    export { _b as class };
    export var normal: boolean;
}
