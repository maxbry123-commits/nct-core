//// [tests/cases/conformance/jsdoc/declarations/jsDeclarationsPackageJson.ts] ////

//// [index.js]
const j = require("./package.json");
module.exports = j;
//// [package.json]
{
    "name": "pkg",
    "version": "0.1.0",
    "description": "A package",
    "main": "./dist/index.js",
    "bin": {
      "cli": "./bin/cli.js",
    },
    "engines": {
      "node": ">=0"
    },
    "scripts": {
      "scriptname": "run && run again",
    },
    "devDependencies": {
      "@ns/dep": "0.1.2",
    },
    "dependencies": {
      "dep": "1.2.3",
    },
    "repository": "microsoft/TypeScript",
    "keywords": [
      "kw"
    ],
    "author": "Auth",
    "license": "See Licensce",
    "homepage": "https://site",
    "config": {
      "o": ["a"]
    }
}
  

//// [package.json]
{
    "name": "pkg",
    "version": "0.1.0",
    "description": "A package",
    "main": "./dist/index.js",
    "bin": {
        "cli": "./bin/cli.js"
    },
    "engines": {
        "node": ">=0"
    },
    "scripts": {
        "scriptname": "run && run again"
    },
    "devDependencies": {
        "@ns/dep": "0.1.2"
    },
    "dependencies": {
        "dep": "1.2.3"
    },
    "repository": "microsoft/TypeScript",
    "keywords": [
        "kw"
    ],
    "author": "Auth",
    "license": "See Licensce",
    "homepage": "https://site",
    "config": {
        "o": ["a"]
    }
}
//// [index.js]
"use strict";
const j = require("./package.json");
module.exports = j;


//// [index.d.ts]
export = j;
import j = require("./package.json");


//// [DtsFileErrors]


out/index.d.ts(2,20): error TS2307: Cannot find module './package.json' or its corresponding type declarations.


==== out/index.d.ts (1 errors) ====
    export = j;
    import j = require("./package.json");
                       ~~~~~~~~~~~~~~~~
!!! error TS2307: Cannot find module './package.json' or its corresponding type declarations.
    
==== package.json (0 errors) ====
    {
        "name": "pkg",
        "version": "0.1.0",
        "description": "A package",
        "main": "./dist/index.js",
        "bin": {
          "cli": "./bin/cli.js",
        },
        "engines": {
          "node": ">=0"
        },
        "scripts": {
          "scriptname": "run && run again",
        },
        "devDependencies": {
          "@ns/dep": "0.1.2",
        },
        "dependencies": {
          "dep": "1.2.3",
        },
        "repository": "microsoft/TypeScript",
        "keywords": [
          "kw"
        ],
        "author": "Auth",
        "license": "See Licensce",
        "homepage": "https://site",
        "config": {
          "o": ["a"]
        }
    }
      