//// [tests/cases/conformance/types/rest/objectRestNegative.ts] ////

//// [objectRestNegative.ts]
let o = { a: 1, b: 'no' };
var { ...mustBeLast, a } = o;

var b: string;
let notAssignable: { a: string };
({ b, ...notAssignable } = o);


function stillMustBeLast({ ...mustBeLast, a }: { a: number, b: string }): void {
}
function generic<T extends { x, y }>(t: T) {
    let { x, ...rest } = t;
    return rest;
}

let rest: { b: string } = { b: "" };
({a, ...rest.b + rest.b} = o);


//// [objectRestNegative.js]
"use strict";
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
let o = { a: 1, b: 'no' };
var { a } = o;
var b;
let notAssignable;
({ b } = o, notAssignable = __rest(o, ["b"]));
function stillMustBeLast(_a) {
    var { a } = _a;
}
function generic(t) {
    let { x } = t, rest = __rest(t, ["x"]);
    return rest;
}
let rest = { b: "" };
({ a } = o, rest.b + rest.b = __rest(o, ["a"]));
