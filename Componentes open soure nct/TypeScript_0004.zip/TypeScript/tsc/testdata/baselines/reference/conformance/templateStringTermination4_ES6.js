//// [tests/cases/conformance/es6/templates/templateStringTermination4_ES6.ts] ////

//// [templateStringTermination4_ES6.ts]
`\\\\`

//// [templateStringTermination4_ES6.js]
"use strict";
`\\\\`;
