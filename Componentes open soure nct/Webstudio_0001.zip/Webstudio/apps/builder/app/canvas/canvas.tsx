import {
  useMemo,
  useEffect,
  useState,
  useLayoutEffect,
  useRef,
  type ReactNode,
} from "react";
import { ErrorBoundary, type FallbackProps } from "react-error-boundary";
import { useStore } from "@nanostores/react";
import { type Instances } from "@webstudio-is/sdk";
import type { Components } from "@webstudio-is/react-sdk";
import { wsImageLoader, wsVideoLoader } from "@webstudio-is/image";
import { ReactSdkContext } from "@webstudio-is/react-sdk/runtime";
import { canvasComponentLibraries } from "@webstudio-is/sdk-components-registry/canvas";
import { ErrorMessage } from "~/shared/error";
import { $publisher, publish } from "~/shared/pubsub";
import {
  registerContainers,
  serverSyncStore,
  useCanvasStore,
} from "~/shared/sync/sync-stores";
import {
  GlobalStyles,
  subscribeStyles,
  mountStyles,
  manageDesignModeStyles,
  manageContentEditModeStyles,
} from "./shared/styles";
import {
  WebstudioComponentCanvas,
  WebstudioComponentPreview,
} from "./features/webstudio-component";
import {
  registerComponentLibrary,
  $registeredComponents,
  subscribeComponentHooks,
  $isPreviewMode,
  $isDesignMode,
  $isContentMode,
  subscribeModifierKeys,
  assetBaseUrl,
} from "~/shared/nano-states";
import { $assets } from "~/shared/sync/data-stores";
import { $pages, $instances, $breakpoints } from "~/shared/sync/data-stores";
import { useDragAndDrop } from "./shared/use-drag-drop";
import {
  initCopyPaste,
  initCopyPasteForContentEditMode,
} from "~/shared/copy-paste/copy-paste";
import { inflateInstance, subscribeInflator } from "./inflator";
import { useWindowResizeDebounced } from "~/shared/dom-hooks";
import { subscribeInstanceSelection } from "./instance-selection-events";
import { subscribeInstanceHovering } from "./instance-hovering";
import { useHashLinkSync } from "~/shared/pages";
import { useMount } from "~/shared/hook-utils/use-mount";
import { subscribeInterceptedEvents } from "./interceptor";
import { subscribeCommands } from "~/canvas/shared/commands";
import { updateCollaborativeInstanceRect } from "./collaborative-instance";
import { initCanvasApi } from "~/shared/canvas-api";
import { subscribeFontLoadingDone } from "./shared/font-weight-support";
import { subscribeSelected } from "./selected-instance-effects";
import { subscribeGridGuidesOnSelected } from "./grid-guide-utils";
import { subscribeScrollNewInstanceIntoView } from "./shared/scroll-new-instance-into-view";
import { $selectedPage } from "~/shared/nano-states";
import { createInstanceElement } from "./elements";
import { subscribeScrollbarSize } from "./scrollbar-width";
import { compareMedia } from "@webstudio-is/css-engine";
import { builderApi } from "~/shared/builder-api";
import { useDebounceEffect } from "@webstudio-is/design-system";
import { subscribeInstanceContextMenu } from "./instance-context-menu";
import { startPointerTracking } from "~/shared/awareness";

registerContainers();

const FallbackComponent = ({ error, resetErrorBoundary }: FallbackProps) => {
  // try to recover from error when webstudio data is changed again
  useEffect(() => {
    return serverSyncStore.subscribe(resetErrorBoundary);
  }, [resetErrorBoundary]);
  return (
    // body is required to prevent breaking collapsed instances logic
    <body>
      <ErrorMessage
        error={{
          message: error instanceof Error ? error.message : "Unknown error",
          status: 500,
        }}
      />
    </body>
  );
};

const handleError = (error: unknown) => {
  if (error instanceof Error) {
    builderApi.toast.error(error.message);
    return;
  }

  builderApi.toast.error(`Unknown error: ${String(error)}`);
  console.error(error);
};

const useElementsTree = (components: Components, instances: Instances) => {
  const isSafeMode = builderApi.isSafeMode();
  const page = useStore($selectedPage);
  const isPreviewMode = useStore($isPreviewMode);
  const breakpointsMap = useStore($breakpoints);
  const rootInstanceId = page?.rootInstanceId ?? "";

  if (typeof window === "undefined") {
    // @todo remove after https://github.com/webstudio-is/webstudio/issues/1313 now its needed to be sure that no leaks exists

    console.info({
      $assets: $assets.get().size,
      $pages: $pages.get()?.pages.size ?? 0,
      $instances: $instances.get().size,
    });
  }

  const breakpoints = useMemo(
    () => [...breakpointsMap.values()].sort(compareMedia),
    [breakpointsMap]
  );

  return useMemo(() => {
    return (
      <ReactSdkContext.Provider
        value={{
          renderer: isPreviewMode ? "preview" : "canvas",
          isSafeMode,
          assetBaseUrl,
          imageLoader: wsImageLoader,
          videoLoader: wsVideoLoader,
          resources: {},
          breakpoints,
          // error reporting
          onError: handleError,
        }}
      >
        {createInstanceElement({
          instances,
          instanceId: rootInstanceId,
          instanceSelector: [rootInstanceId],
          Component: isPreviewMode
            ? WebstudioComponentPreview
            : WebstudioComponentCanvas,
          components,
        })}
      </ReactSdkContext.Provider>
    );
  }, [
    instances,
    rootInstanceId,
    components,
    isPreviewMode,
    breakpoints,
    isSafeMode,
  ]);
};

const DesignMode = () => {
  const debounceEffect = useDebounceEffect();
  const ref = useRef<undefined | Instances>(undefined);

  useDragAndDrop();

  useEffect(() => {
    const abortController = new AbortController();
    subscribeScrollNewInstanceIntoView(
      debounceEffect,
      ref,
      abortController.signal
    );
    const unsubscribeSelected = subscribeSelected(debounceEffect);
    const unsubscribeGridGuides = subscribeGridGuidesOnSelected();
    return () => {
      unsubscribeSelected();
      unsubscribeGridGuides();
      abortController.abort();
    };
  }, [debounceEffect]);

  useEffect(() => {
    const abortController = new AbortController();
    const options = { signal: abortController.signal };
    // We need to initialize this in both canvas and builder,
    // because the events will fire in either one, depending on where the focus is
    // @todo we need to forward the events from canvas to builder and avoid importing this
    // in both places
    initCopyPaste(options);
    manageDesignModeStyles(options);
    subscribeScrollbarSize(options);
    updateCollaborativeInstanceRect(options);
    subscribeInstanceSelection(options);
    subscribeInstanceHovering(options);
    subscribeFontLoadingDone(options);
    subscribeModifierKeys(options);
    return () => {
      abortController.abort();
    };
  }, []);
  return null;
};

const ContentEditMode = (): ReactNode => {
  const debounceEffect = useDebounceEffect();
  const ref = useRef<undefined | Instances>(undefined);

  useEffect(() => {
    const abortController = new AbortController();
    subscribeScrollNewInstanceIntoView(
      debounceEffect,
      ref,
      abortController.signal
    );
    const unsubscribeSelected = subscribeSelected(debounceEffect);
    const unsubscribeGridGuides = subscribeGridGuidesOnSelected();
    return () => {
      unsubscribeSelected();
      unsubscribeGridGuides();
      abortController.abort();
    };
  }, [debounceEffect]);

  useEffect(() => {
    const abortController = new AbortController();
    const options = { signal: abortController.signal };
    manageContentEditModeStyles(options);
    subscribeScrollbarSize(options);
    subscribeInstanceSelection(options);
    subscribeInstanceHovering(options);
    subscribeFontLoadingDone(options);
    initCopyPasteForContentEditMode(options);
    subscribeModifierKeys(options);
    // E2E tests wait for this after opening content mode before editing canvas text.
    document.body.dataset.wsContentEditMode = "ready";
    return () => {
      delete document.body.dataset.wsContentEditMode;
      abortController.abort();
    };
  }, []);
  return;
};

export const Canvas = () => {
  useCanvasStore();
  const isDesignMode = useStore($isDesignMode);
  const isContentMode = useStore($isContentMode);

  useMount(() => {
    for (const library of canvasComponentLibraries) {
      registerComponentLibrary(library);
    }
  });

  useMount(initCanvasApi);

  useLayoutEffect(() => {
    mountStyles();
  }, []);

  useEffect(subscribeStyles, []);

  useEffect(subscribeComponentHooks, []);

  useEffect(subscribeCommands, []);

  useEffect(() => {
    $publisher.set({ publish });
  }, []);

  const selectedPage = useStore($selectedPage);
  const rootInstanceId = selectedPage?.rootInstanceId;

  useEffect(() => {
    if (rootInstanceId !== undefined) {
      inflateInstance(rootInstanceId);
    }
  }, [rootInstanceId]);

  useWindowResizeDebounced(() => {
    if (rootInstanceId !== undefined) {
      inflateInstance(rootInstanceId);
    }
  });

  useEffect(subscribeInflator, []);

  useEffect(() => startPointerTracking(), []);

  useHashLinkSync();

  useEffect(subscribeInterceptedEvents, []);

  useEffect(subscribeInstanceContextMenu, []);

  const components = useStore($registeredComponents);
  const instances = useStore($instances);
  const elements = useElementsTree(components, instances);

  const [isInitialized, setInitialized] = useState(false);
  useEffect(() => {
    setInitialized(true);
  }, []);

  if (components.size === 0 || instances.size === 0) {
    return;
  }

  return (
    <>
      <GlobalStyles />
      {/* catch all errors in rendered components */}
      <ErrorBoundary FallbackComponent={FallbackComponent}>
        {elements}
      </ErrorBoundary>
      {
        // Call hooks after render to ensure effects are last.
        // Helps improve outline calculations as all styles are then applied.
      }
      {isDesignMode && isInitialized && <DesignMode />}
      {isContentMode && isInitialized && <ContentEditMode />}
    </>
  );
};
