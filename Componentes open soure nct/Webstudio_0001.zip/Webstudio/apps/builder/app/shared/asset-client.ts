import * as path from "node:path";
import { maxSize } from "@webstudio-is/asset-uploader";
import {
  createFsAssetObjectStore,
  createS3AssetObjectStore,
} from "@webstudio-is/asset-uploader/server";
import env from "~/env/env.server";

export const fileUploadPath = "public/cgi/asset";

export const getMaxAssetUploadSize = () => maxSize.parse(env.MAX_UPLOAD_SIZE);

export const createAssetClient = () => {
  const maxUploadSize = getMaxAssetUploadSize();
  if (
    env.S3_ENDPOINT !== undefined &&
    env.S3_REGION !== undefined &&
    env.S3_ACCESS_KEY_ID !== undefined &&
    env.S3_SECRET_ACCESS_KEY !== undefined &&
    env.S3_BUCKET !== undefined
  ) {
    return createS3AssetObjectStore({
      endpoint: env.S3_ENDPOINT,
      region: env.S3_REGION,
      accessKeyId: env.S3_ACCESS_KEY_ID,
      secretAccessKey: env.S3_SECRET_ACCESS_KEY,
      bucket: env.S3_BUCKET,
      acl: env.S3_ACL,
      maxUploadSize,
    });
  } else {
    return createFsAssetObjectStore({
      maxUploadSize,
      fileDirectory: path.join(process.cwd(), fileUploadPath),
    });
  }
};
