import { describe, expect, test } from "vitest";
import type { BuilderPatchChange } from "@webstudio-is/project-build/contracts";
import { elementComponent, type Instance, type Prop } from "@webstudio-is/sdk";
import {
  isExternalContentInstance,
  isExternalContentMutation,
} from "./external-content-mutations";

const instance = (
  id: string,
  children: Instance["children"] = []
): Instance => ({
  type: "instance",
  id,
  component: elementComponent,
  tag: "div",
  children,
});

const state = {
  instances: new Map([
    ["block", instance("block", [{ type: "id", value: "external" }])],
    ["external", instance("external")],
    ["ordinary", instance("ordinary")],
  ]),
  props: new Map<string, Prop>([
    [
      "external-prop",
      {
        id: "external-prop",
        instanceId: "external",
        name: "title",
        type: "string",
        value: "Before",
      },
    ],
  ]),
};

const change = (
  namespace: BuilderPatchChange["namespace"],
  patches: BuilderPatchChange["patches"]
): BuilderPatchChange => ({ namespace, patches });

describe("external content mutation detection", () => {
  const roots = new Map([
    [
      "scope",
      {
        blockInstanceId: "block",
        instanceIds: new Set(["external"]),
        ownership: {
          instances: new Set(["external"]),
          props: new Set(["external-prop"]),
          styles: new Set(["external:base:color"]),
        },
        mutationRevision: 0,
      },
    ],
  ]);

  test("detects edits to existing external instances and props", () => {
    expect(
      isExternalContentMutation({
        state,
        roots,
        payload: [
          change("instances", [
            {
              op: "replace",
              path: ["external", "children"],
              value: [{ type: "text", value: "After" }],
            },
          ]),
        ],
      })
    ).toBe(true);
    expect(
      isExternalContentMutation({
        state,
        roots,
        payload: [
          change("props", [
            {
              op: "replace",
              path: ["external-prop", "value"],
              value: "After",
            },
          ]),
        ],
      })
    ).toBe(true);
  });

  test("detects insertion into an empty connected block", () => {
    expect(
      isExternalContentMutation({
        state,
        roots,
        payload: [
          change("instances", [
            {
              op: "replace",
              path: ["block", "children"],
              value: [{ type: "id", value: "inserted" }],
            },
            {
              op: "add",
              path: ["inserted"],
              value: instance("inserted"),
            },
          ]),
        ],
      })
    ).toBe(true);
  });

  test("detects edits to every registered external namespace", () => {
    expect(
      isExternalContentMutation({
        state,
        roots,
        payload: [
          change("styles", [
            {
              op: "replace",
              path: ["external:base:color", "value"],
              value: { type: "keyword", value: "red" },
            },
          ]),
        ],
      })
    ).toBe(true);
  });

  test("does not reroute unrelated project mutations", () => {
    expect(
      isExternalContentMutation({
        state,
        roots,
        payload: [
          change("instances", [
            {
              op: "replace",
              path: ["ordinary", "children"],
              value: [{ type: "text", value: "After" }],
            },
          ]),
        ],
      })
    ).toBe(false);
  });
});

test("identifies only instances authored by external content", () => {
  const roots = new Map([
    [
      "scope",
      {
        blockInstanceId: "block",
        instanceIds: new Set(["external"]),
        mutationRevision: 0,
      },
    ],
  ]);

  expect(isExternalContentInstance(roots, "external")).toBe(true);
  expect(isExternalContentInstance(roots, "block")).toBe(false);
  expect(isExternalContentInstance(roots, "ordinary")).toBe(false);
});
