import path from 'path'
import { devices } from '@playwright/test'
import type { PlaywrightTestConfig } from '@playwright/test'
import { config as _config } from 'dotenv'
/**
 * Read environment variables from file.
 * https://github.com/motdotla/dotenv
 */
_config()

const __dirname = path.dirname(new URL(import.meta.url).pathname)

/**
 * See https://playwright.dev/docs/test-configuration.
 */
const config: PlaywrightTestConfig = {
	globalSetup: './global-setup.ts',
	globalTeardown: './global-teardown.ts',
	/* Maximum time one test can run for. */
	timeout: 30 * 1000,
	expect: {
		/**
		 * Maximum time expect() should wait for the condition to be met.
		 * For example in `await expect(locator).toHaveText();`
		 */
		timeout: 2000,
		toHaveScreenshot: {
			maxDiffPixelRatio: 0.0001,
			threshold: 0.01,
		},
	},
	// Run tests fully in parallel for faster execution.
	// Clipboard tests are already skipped due to flakiness.
	fullyParallel: true,
	/* Fail the build on CI if you accidentally left test.only in the source code. */
	forbidOnly: false, // !!process.env.CI,
	/* Retry on CI only */
	retries: process.env.CI ? 1 : 0,
	/* Reporter to use. See https://playwright.dev/docs/test-reporters */
	reporter: process.env.CI ? [['list'], ['github'], ['html', { open: 'never' }]] : 'list',
	/* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
	use: {
		/* Maximum time each action such as `click()` can take. Defaults to 0 (no limit). */
		actionTimeout: 0,
		/* Base URL to use in actions like `await page.goto('/')`. */
		// baseURL: 'http://localhost:5420',

		/* Collect trace when retrying the failed test. See https://playwright.dev/docs/trace-viewer */
		trace: 'on-first-retry',
		headless: true, // !process.env.CI,
		video: 'retain-on-failure',
		screenshot: 'only-on-failure',
	},

	/* Configure projects for major browsers */
	projects: [
		{
			name: 'chromium',
			use: {
				...devices['Desktop Chrome'],
			},
		},

		// {
		// 	name: 'webkit',
		// 	use: {
		// 		...devices['Desktop Safari'],
		// 	},
		// },

		// /* Test against mobile viewports. */
		{
			name: 'Mobile Chrome',
			use: {
				...devices['Pixel 5'],
			},
		},
		// {
		// 	name: 'Mobile Safari',
		// 	use: {
		// 		...devices['iPhone 12'],
		// 	},
		// },

		/* Test against branded browsers. */
		// {
		//   name: 'Microsoft Edge',
		//   use: {
		//     channel: 'msedge',
		//   },
		// },
		// {
		//   name: 'Google Chrome',
		//   use: {
		//     channel: 'chrome',
		//   },
		// },
	],

	/* Folder for test artifacts such as screenshots, videos, traces, etc. */
	outputDir: './test-results',

	/* Run your local dev server before starting the tests */
	webServer: [
		{
			command: process.env.CI ? 'yarn preview' : 'yarn preview-examples',
			port: 5420,
			reuseExistingServer: !process.env.CI,
			cwd: process.env.CI ? path.join(__dirname, '..') : path.join(__dirname, '../../..'),
			timeout: process.env.CI ? 30_000 : 300_000,
		},
		{
			command: 'yarn dev',
			port: 8989,
			reuseExistingServer: !process.env.CI,
			cwd: path.join(__dirname, '../../../apps/bemo-worker'),
			timeout: 60_000,
		},
	],
}

export default config
