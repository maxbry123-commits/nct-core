from typing import Dict, Any, Literal, Optional
from datetime import datetime
from pydantic import BaseModel

class DjangoConfig(BaseModel):
    project_name: str
    app_name: str
    containerization: bool = False

class SQLConfig(BaseModel):
    dialect: Literal["sqlite", "postgresql", "mysql", "mssql", "mariadb"] = "sqlite"

class SQLAlchemyConfig(BaseModel):
    dbms: Literal["sqlite", "postgresql", "mysql", "mssql", "mariadb"] = "sqlite"


class DiagramInput(BaseModel):
    id: Optional[str] = None
    title: str
    model: Dict[str, Any]
    lastUpdate: Optional[datetime] = None
    generator: Optional[str] = None
    config: Optional[dict] = None
    configYaml: Optional[str] = None
    referenceDiagramData: Optional[Dict[str, Any]] = None
    references: Optional[Dict[str, str]] = None  # Per-diagram cross-references by ID (e.g. {"ClassDiagram": "uuid-..."})


class FeedbackSubmission(BaseModel):
    """Model for user feedback submissions."""
    satisfaction: Literal["happy", "neutral", "sad"]
    category: str = ""
    feedback: str
    email: Optional[str] = None
    timestamp: str
    user_agent: str
