export const Foo = null;
