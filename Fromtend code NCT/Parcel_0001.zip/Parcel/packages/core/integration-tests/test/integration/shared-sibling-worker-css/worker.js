import "./a.js";
