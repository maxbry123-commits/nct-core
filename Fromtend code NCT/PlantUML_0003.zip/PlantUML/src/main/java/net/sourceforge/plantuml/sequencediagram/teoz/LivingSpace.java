/* ========================================================================
 * PlantUML : a free UML diagram generator
 * ========================================================================
 *
 * (C) Copyright 2009-2024, Arnaud Roques
 *
 * Project Info:  https://plantuml.com
 * 
 * If you like this project or if you find it useful, you can support us at:
 * 
 * https://plantuml.com/patreon (only 1$ per month!)
 * https://plantuml.com/paypal
 * 
 * This file is part of PlantUML.
 *
 * PlantUML is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * PlantUML distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301,
 * USA.
 *
 *
 * Original Author:  Arnaud Roques
 * 
 *
 */
package net.sourceforge.plantuml.sequencediagram.teoz;

import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import net.sourceforge.plantuml.klimt.UTranslate;
import net.sourceforge.plantuml.klimt.drawing.UGraphic;
import net.sourceforge.plantuml.klimt.font.StringBounder;
import net.sourceforge.plantuml.klimt.geom.HorizontalAlignment;
import net.sourceforge.plantuml.klimt.geom.VerticalAlignment;
import net.sourceforge.plantuml.klimt.geom.XDimension2D;
import net.sourceforge.plantuml.real.Real;
import net.sourceforge.plantuml.real.RealUtils;
import net.sourceforge.plantuml.sequencediagram.Event;
import net.sourceforge.plantuml.sequencediagram.Participant;
import net.sourceforge.plantuml.sequencediagram.ParticipantEnglober;
import net.sourceforge.plantuml.sequencediagram.ParticipantType;
import net.sourceforge.plantuml.skin.Area;
import net.sourceforge.plantuml.skin.Component;
import net.sourceforge.plantuml.skin.ComponentType;
import net.sourceforge.plantuml.skin.Context2D;
import net.sourceforge.plantuml.skin.rose.Rose;
import net.sourceforge.plantuml.style.ISkinParam;
import net.sourceforge.plantuml.url.Url;

public class LivingSpace {

	private final Participant p;
	private final ISkinParam skinParam;
	private final ComponentType headType;
	private final ComponentType tailType;
	private final MutingLine mutingLine;
	private final Rose rose = new Rose();
	private final LiveBoxes liveboxes;

	// private final Rose skin;
	// private final boolean useContinueLineBecauseOfDelay;
	// private final LivingSpaceImpl previous;
	// private LivingSpace next;

	private final Real posB;
	private Real posC;
	private Real posD;

	private boolean create = false;
	// Life segments: y -> true for a create, false for a destroy. A TreeMap is
	// used so that the repeated layout passes do not duplicate entries.
	private final SortedMap<Double, Boolean> aliveChanges = new TreeMap<Double, Boolean>();

	private final ParticipantEnglober englober;

	public int getLevelAt(Tile tile, EventsHistoryMode mode) {
		// assert mode == EventsHistoryMode.IGNORE_FUTURE_DEACTIVATE;
		return liveboxes.getLevelAt(tile.getEvent(), mode);
	}

	public void addStepForLivebox(Event event, double y) {
		liveboxes.addStep(event, y);
	}

	@Override
	public String toString() {
		return p.getCode() + " B=" + posB.getCurrentValue() + "/C=" + currentValue(posC) + "/D=" + currentValue(posD);
	}

	private static String currentValue(Real pos) {
		if (pos == null) {
			return null;
		}
		return "" + pos.getCurrentValue();
	}

	public LivingSpace(Participant p, ParticipantEnglober englober, Rose skin, ISkinParam skinParam, Real position,
			List<Event> events) {
		this.p = p;
		// this.skin = skin;
		this.skinParam = skinParam;
		this.englober = englober;
		this.posB = position;
		if (p.getType() == ParticipantType.PARTICIPANT) {
			headType = ComponentType.PARTICIPANT_HEAD;
			tailType = ComponentType.PARTICIPANT_TAIL;
		} else if (p.getType() == ParticipantType.ACTOR) {
			headType = ComponentType.ACTOR_HEAD;
			tailType = ComponentType.ACTOR_TAIL;
		} else if (p.getType() == ParticipantType.BOUNDARY) {
			headType = ComponentType.BOUNDARY_HEAD;
			tailType = ComponentType.BOUNDARY_TAIL;
		} else if (p.getType() == ParticipantType.CONTROL) {
			headType = ComponentType.CONTROL_HEAD;
			tailType = ComponentType.CONTROL_TAIL;
		} else if (p.getType() == ParticipantType.ENTITY) {
			headType = ComponentType.ENTITY_HEAD;
			tailType = ComponentType.ENTITY_TAIL;
		} else if (p.getType() == ParticipantType.QUEUE) {
			headType = ComponentType.QUEUE_HEAD;
			tailType = ComponentType.QUEUE_TAIL;
		} else if (p.getType() == ParticipantType.DATABASE) {
			headType = ComponentType.DATABASE_HEAD;
			tailType = ComponentType.DATABASE_TAIL;
		} else if (p.getType() == ParticipantType.COLLECTIONS) {
			headType = ComponentType.COLLECTIONS_HEAD;
			tailType = ComponentType.COLLECTIONS_TAIL;
		} else {
			throw new IllegalArgumentException();
		}
		// this.stairs2.addStep2(0, p.getInitialLife());
		// this.stairs2.addStep2(0, 0);
		// this.useContinueLineBecauseOfDelay = useContinueLineBecauseOfDelay(events);
		this.mutingLine = new MutingLine(skin, skinParam, events, p);
		this.liveboxes = new LiveBoxes(p, events, skin, skinParam);
	}

	public void drawLineAndLiveboxes(UGraphic ug, double height, Context2D context) {
		// The line is drawn only over the alive segments: a participant may be
		// created and destroyed several times
		boolean alive = create == false;
		double aliveSince = 0;
		for (Map.Entry<Double, Boolean> ent : aliveChanges.entrySet()) {
			if (alive == false && ent.getValue())
				aliveSince = ent.getKey();
			else if (alive && ent.getValue() == false)
				mutingLine.drawLine(ug, context, aliveSince, ent.getKey());

			alive = ent.getValue();
		}
		if (alive)
			mutingLine.drawLine(ug, context, aliveSince, height);

		liveboxes.drawBoxes(ug, context, getFirstCreateY(), height);
	}

	private double getFirstCreateY() {
		for (Map.Entry<Double, Boolean> ent : aliveChanges.entrySet())
			if (ent.getValue())
				return ent.getKey();

		return 0;
	}

	// public void addDelayTile(DelayTile tile) {
	// System.err.println("addDelayTile " + this + " " + tile);
	// }

	public void drawHead(UGraphic ug, Context2D context, VerticalAlignment verticalAlignment,
			HorizontalAlignment horizontalAlignment) {
		drawHeadOrTail(ug, context, verticalAlignment, horizontalAlignment, headType);
	}

	public void drawTail(UGraphic ug, Context2D context, VerticalAlignment verticalAlignment,
			HorizontalAlignment horizontalAlignment) {
		drawHeadOrTail(ug, context, verticalAlignment, horizontalAlignment, tailType);
	}

	private void drawHeadOrTail(UGraphic ug, Context2D context, VerticalAlignment verticalAlignment,
			HorizontalAlignment horizontalAlignment, ComponentType type) {
		if (create && verticalAlignment == VerticalAlignment.BOTTOM) {
			return;
		}
		final Component comp = rose.createComponentParticipant(p, type, null, skinParam,
				p.getDisplay(skinParam.forceSequenceParticipantUnderlined()));
		final XDimension2D dim = comp.getPreferredDimension(ug.getStringBounder());
		if (horizontalAlignment == HorizontalAlignment.RIGHT) {
			ug = ug.apply(UTranslate.dx(-dim.getWidth()));
		}
		if (verticalAlignment == VerticalAlignment.CENTER) {
			ug = ug.apply(UTranslate.dy(-dim.getHeight() / 2));
		}
		final Area area = new Area(dim);
		final Url url = getParticipant().getUrl();
		if (url != null) {
			ug.startUrl(url);
		}
		comp.drawU(ug, area, context);
		if (url != null) {
			ug.closeUrl();
		}
	}

	public XDimension2D getHeadPreferredDimension(StringBounder stringBounder) {
		final Component comp = rose.createComponentParticipant(p, headType, null, skinParam,
				p.getDisplay(skinParam.forceSequenceParticipantUnderlined()));
		final XDimension2D dim = comp.getPreferredDimension(stringBounder);
		return dim;
	}

	private double getPreferredWidth(StringBounder stringBounder) {
		return getHeadPreferredDimension(stringBounder).getWidth();
	}

	public Real getPosC(StringBounder stringBounder) {
		if (posC == null) {
			this.posC = posB.addFixed(this.getPreferredWidth(stringBounder) / 2);
		}
		return posC;
	}

	public Real getPosC2(StringBounder stringBounder) {
		final double delta = liveboxes.getMaxPosition(stringBounder);
		return getPosC(stringBounder).addFixed(delta);
	}

	public Real getPosD(StringBounder stringBounder) {
		if (posD == null) {
			this.posD = posB.addFixed(this.getPreferredWidth(stringBounder));
		}
		// System.err.println("LivingSpace::getPosD "+posD.getCurrentValue());
		return posD;
	}

	public Real getPosB(StringBounder stringBounder) {
		return posB;
	}

	public Participant getParticipant() {
		return p;
	}

	public void goCreate(double y) {
		this.aliveChanges.put(y, Boolean.TRUE);
		this.create = true;
	}

	public void goCreate() {
		this.create = true;
	}

	public void goDestroy(double y) {
		this.aliveChanges.put(y, Boolean.FALSE);
	}

	public void delayOn(double y, double height) {
		mutingLine.delayOn(y, height);
		liveboxes.delayOn(y, height);
	}

	public ParticipantEnglober getEnglober() {
		return englober;
	}

	private double marginBefore;
	private double marginAfter;

	public void ensureMarginBefore(double margin) {
		if (margin < 0)
			throw new IllegalArgumentException();
		this.marginBefore = Math.max(marginBefore, margin);
	}

	public void ensureMarginAfter(double margin) {
		if (margin < 0)
			throw new IllegalArgumentException();
		this.marginAfter = Math.max(marginAfter, margin);
	}

	public Real getPosA(StringBounder stringBounder) {
		return getPosB(stringBounder).addFixed(-marginBefore);
	}

	public Real getPosE(StringBounder stringBounder) {
		return getPosD(stringBounder).addFixed(marginAfter);
	}

	// Live counterparts of getPosA()/getPosE() above, for the one caller that
	// actually needs them: Doll's neighbour-clearing checks (issue #2791).
	//
	// getPosA()/getPosE() bake the CURRENT value of the mutable
	// marginBefore/marginAfter field as a plain Java literal into the
	// returned Real, at the moment they are CALLED -- not a live reference
	// to the field. That is fine for every caller that already runs late
	// enough to see the final margin (Doll.drawMe(), which draws the box
	// from a fresh call right before painting), or that has always run
	// early and is unaffected by this fix's scope (LivingSpaces.
	// addConstraints()'s plain participant spacing, Doll.getMinX()/getMaxX()
	// feeding PlayingSpace's own canvas-size capture, GroupingTile's frame-
	// clearing check) -- changing THEIR timing or values is outside what
	// #2791 was ever about, and doing so anyway ballooned an unrelated set
	// of existing references across the whole test suite the first time
	// this was tried.
	//
	// Doll's neighbour-clearing checks are different: they must see the
	// FINAL margin (grown by mainTile.addConstraints() from a self-message
	// loop or box-edge note) to constrain the actually-drawn edge, but they
	// also need to run early -- registered in the very same
	// Dolls.addConstraints() pass as everything else -- because running
	// them in a separate later pass (see the removed
	// Dolls.addLateConstraints()) perturbs the shared RealLine's
	// PositiveForce evaluation order and can trigger a premature,
	// permanently-wrong read of an unrelated RealMin/RealMax elsewhere in
	// the graph (GroupingTile's own frame bounds), visible as a misplaced
	// loop/box frame whenever a box is combined with a parallel (&)
	// construct.
	//
	// getPosALive()/getPosELive() resolve that: unlike addFixed(), they
	// read the margin lazily, at getCurrentValue() time. Every
	// getCurrentValue() call anywhere in this codebase happens only
	// during/after RealLine.compile() (see AbstractReal/RealImpl), which
	// itself only runs once, strictly AFTER every ensureMarginBefore()/
	// ensureMarginAfter() call has already executed -- so by construction
	// the margin they read is always the final one, regardless of when
	// they were called or when their constraint was registered. Confined
	// to just this one call site, that keeps every other Real in the graph
	// -- and every other existing reference -- exactly as it already was.
	public Real getPosALive(StringBounder stringBounder) {
		return RealUtils.withLiveOffset(getPosB(stringBounder), () -> -marginBefore);
	}

	public Real getPosELive(StringBounder stringBounder) {
		return RealUtils.withLiveOffset(getPosD(stringBounder), () -> marginAfter);
	}

	// ---------------------------------------------------------------------
	// ASCII rendering positions.
	//
	// Exact character-grid counterparts of posB/C/D/A/E above, expressed as
	// Real on a dedicated ASCII RealLine (created in
	// SequenceDiagramFileMakerTeoz.getAsciiBlock(), separate from the pixel
	// xorigin) with the convention 1.0 = 1 character. The derivation formulas
	// mirror the pixel ones, but every delta is an integer number of cells,
	// so the values resolved by asciiXOrigin.compileNow() are exact integers
	// (no quantization).
	//
	// asciiPosB is the box's left column; the box width is code.length()+2
	// (see Participant.asciiDimension()); the lifeline runs through the
	// middle. Widths come from the participant, never from a Rose Component.
	// ---------------------------------------------------------------------
	private Real asciiPosB;
	private Real asciiPosC;
	private Real asciiPosD;

	private int asciiWidth() {
		return p.asciiDimension().getWidth();
	}

	public void setAsciiPosB(Real asciiPosB) {
		this.asciiPosB = asciiPosB;
	}

	public Real getAsciiPosB() {
		return asciiPosB;
	}

	public Real getAsciiPosC() {
		if (asciiPosC == null)
			this.asciiPosC = asciiPosB.addFixed(asciiWidth() / 2);

		return asciiPosC;
	}

	public Real getAsciiPosD() {
		if (asciiPosD == null)
			this.asciiPosD = asciiPosB.addFixed(asciiWidth());

		return asciiPosD;
	}

	private int asciiMarginBefore;
	private int asciiMarginAfter;

	public void ensureAsciiMarginBefore(int margin) {
		if (margin < 0)
			throw new IllegalArgumentException();
		this.asciiMarginBefore = Math.max(asciiMarginBefore, margin);
	}

	public void ensureAsciiMarginAfter(int margin) {
		if (margin < 0)
			throw new IllegalArgumentException();
		this.asciiMarginAfter = Math.max(asciiMarginAfter, margin);
	}

	public Real getAsciiPosA() {
		return getAsciiPosB().addFixed(-asciiMarginBefore);
	}

	public Real getAsciiPosE() {
		return getAsciiPosD().addFixed(asciiMarginAfter);
	}

	public Real getAsciiLifeColumn() {
		return getAsciiPosC();
	}

	public Real getAsciiLeftColumn() {
		return getAsciiPosB();
	}

}
