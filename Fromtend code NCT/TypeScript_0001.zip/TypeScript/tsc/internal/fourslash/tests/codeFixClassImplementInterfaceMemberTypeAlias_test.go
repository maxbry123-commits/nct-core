package fourslash_test

import (
	"testing"

	"github.com/microsoft/TypeScript/tsc/internal/fourslash"
	"github.com/microsoft/TypeScript/tsc/internal/testutil"
)

func TestCodeFixClassImplementInterfaceMemberTypeAlias(t *testing.T) {
	t.Parallel()
	defer testutil.RecoverAndFail(t, "Panic on fourslash test")
	const content = `type MyType = [string, number];
interface I { x: MyType; test(a: MyType): void; }
class C implements I {}`
	f, done := fourslash.NewFourslash(t, nil /*capabilities*/, content)
	defer done()
	f.VerifyCodeFix(t, fourslash.VerifyCodeFixOptions{
		Description: "Implement interface 'I'",
		NewFileContent: `type MyType = [string, number];
interface I { x: MyType; test(a: MyType): void; }
class C implements I {
    x: MyType;
    test(a: MyType): void {
        throw new Error("Method not implemented.");
    }
}`,
		Index: 0,
	})
}
