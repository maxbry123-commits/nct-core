package fourslash_test

import (
	"testing"

	"github.com/microsoft/TypeScript/tsc/internal/fourslash"
	"github.com/microsoft/TypeScript/tsc/internal/testutil"
)

func TestDocCommentTemplateClassDeclProperty01(t *testing.T) {
	t.Parallel()
	defer testutil.RecoverAndFail(t, "Panic on fourslash test")
	const content = `class C {
    /** /*0*/  */
    foo = (p0) => {
        return p0;
    };
    /*1*/
    bar = (p1) => {
        return p1;
    }
    /*2*/
    baz = function (p2, p3) {
        return p2;
    }
}`
	capabilities := fourslash.GetDefaultCapabilities()
	capabilities.TextDocument.Completion.CompletionItem.SnippetSupport = new(false)
	f, done := fourslash.NewFourslash(t, capabilities, content)
	defer done()
	f.VerifyJSDocCompletion(t, "0", 11, `/**
     * 
     * @param p0
     * @returns
     */`, nil)
	f.VerifyJSDocCompletion(t, "1", 11, `/**
     * 
     * @param p1
     * @returns
     */`, nil)
	f.VerifyJSDocCompletion(t, "2", 11, `/**
     * 
     * @param p2
     * @param p3
     * @returns
     */`, nil)
}
