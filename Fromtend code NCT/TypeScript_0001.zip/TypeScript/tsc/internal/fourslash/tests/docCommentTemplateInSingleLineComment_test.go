package fourslash_test

import (
	"testing"

	"github.com/microsoft/TypeScript/tsc/internal/fourslash"
	"github.com/microsoft/TypeScript/tsc/internal/testutil"
)

func TestDocCommentTemplateInSingleLineComment(t *testing.T) {
	t.Parallel()
	defer testutil.RecoverAndFail(t, "Panic on fourslash test")
	const content = `// @Filename: justAComment.ts
// We want to check off-by-one errors in assessing the end of the comment, so we check twice,
// first with a trailing space and then without.
// /*0*/ 
// /*1*/
// We also want to check EOF handling at the end of a comment
// /*2*/`
	capabilities := fourslash.GetDefaultCapabilities()
	capabilities.TextDocument.Completion.CompletionItem.SnippetSupport = new(false)
	f, done := fourslash.NewFourslash(t, capabilities, content)
	defer done()
	for _, marker := range f.Markers() {
		f.VerifyNoJSDocCompletion(t, marker)
	}
}
