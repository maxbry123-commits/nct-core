package fourslash_test

import (
	"testing"

	"github.com/microsoft/TypeScript/tsc/internal/fourslash"
	"github.com/microsoft/TypeScript/tsc/internal/ls/lsutil"
	"github.com/microsoft/TypeScript/tsc/internal/testutil"
)

func TestImportNameCodeFixNewImportBaseUrl2(t *testing.T) {
	t.Skip("Known failing fourslash test")
	t.Parallel()
	defer testutil.RecoverAndFail(t, "Panic on fourslash test")
	const content = `// @Filename: /tsconfig.json
{
    "compilerOptions": {
        "baseUrl": "./a"
    }
}
// @Filename: /a/b/x.ts
export function f1() { };
// @Filename: /a/c/y.ts
[|f1/*0*/();|]`
	f, done := fourslash.NewFourslash(t, nil /*capabilities*/, content)
	defer done()
	f.GoToFile(t, "/a/c/y.ts")
	f.VerifyImportFixAtPosition(t, []string{
		`import { f1 } from "b/x";

f1();`,
	}, nil /*preferences*/)
	f.VerifyImportFixAtPosition(t, []string{
		`import { f1 } from "../b/x";

f1();`,
	}, &lsutil.UserPreferences{ImportModuleSpecifierPreference: "relative"})
}
