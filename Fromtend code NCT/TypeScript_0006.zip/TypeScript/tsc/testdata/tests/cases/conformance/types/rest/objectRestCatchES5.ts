// @target: es2015
// @strict: false

let a = 1, b = 2;
try {} catch ({ a, ...b }) {}