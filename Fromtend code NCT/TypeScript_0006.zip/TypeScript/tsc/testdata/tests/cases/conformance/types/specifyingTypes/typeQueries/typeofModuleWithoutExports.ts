// @target: es2015
namespace M {
    var x = 1;
    class C {
        foo: number;
    }
}

var r: typeof M;