// @target: es2015
// some complex cases of assignment compat of generic signatures that stress contextual signature instantiation

var f: <S extends { p: string }[]>(x: S) => void
var g: <T extends { p: string }>(x: T[]) => void

f = g; // ok
g = f; // ok