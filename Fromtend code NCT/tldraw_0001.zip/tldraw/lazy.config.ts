import { LazyConfig } from 'lazyrepo'

const config = {
	baseCacheConfig: {
		include: [
			'<rootDir>/package.json',
			'<rootDir>/yarn.lock',
			'<rootDir>/lazy.config.ts',
			'<rootDir>/internal/config/**/*',
			'<rootDir>/internal/scripts/**/*',
			'package.json',
		],
		exclude: [
			'<allWorkspaceDirs>/coverage/**/*',
			'<allWorkspaceDirs>/dist*/**/*',
			'<allWorkspaceDirs>/.next*/**/*',
			'**/*.tsbuildinfo',
			'<rootDir>/docs/gen/**/*',
		],
	},
	scripts: {
		build: {
			baseCommand: 'exit 0',
			runsAfter: {
				prebuild: {},
				'refresh-assets': {},
				'build-i18n': {},
			},
			workspaceOverrides: {
				'apps/vscode/*': { runsAfter: { 'refresh-assets': {} } },
				'packages/*': {
					runsAfter: { 'build-api': { in: 'self-only' }, prebuild: { in: 'self-only' } },
					cache: {
						inputs: ['api/**/*', 'src/**/*'],
					},
				},
				'apps/docs': {
					runsAfter: { 'build-api': { in: 'all-packages' } },
					cache: {
						inputs: [
							'app/**/*',
							'api/**/*',
							'components/**/*',
							'public/**/*',
							'scrips/**/*',
							'styles/**/*',
							'types/**/*',
							'utils/**/*',
						],
					},
				},
			},
		},
		dev: {
			execution: 'independent',
			runsAfter: { predev: {}, 'refresh-assets': {}, 'build-i18n': {} },
			cache: 'none',
			workspaceOverrides: {
				'apps/vscode/*': { runsAfter: { build: { in: 'self-only' } } },
			},
		},
		// predev/prebuild are the css-copy scripts. They write generated, gitignored files
		// (tldraw.css, commenting.css, ...) that lazy doesn't track as outputs, so a cache hit
		// would skip regenerating a file that's missing on disk and vite would fail to resolve it.
		// They're a few file copies, so just always run them.
		predev: {
			cache: 'none',
		},
		prebuild: {
			cache: 'none',
		},
		e2e: {
			cache: 'none',
		},
		'e2e-x10': {
			cache: 'none',
		},
		context: {
			execution: 'independent',
			cache: 'none',
		},
		'pack-tarball': {
			parallel: false,
		},
		'refresh-assets': {
			execution: 'top-level',
			baseCommand: `tsx <rootDir>/internal/scripts/refresh-assets.ts`,
			cache: {
				inputs: [
					'package.json',
					`<rootDir>/internal/scripts/refresh-assets.ts`,
					`<rootDir>/assets/**/*`,
					`<rootDir>/apps/dotcom/client/assets/**/*`,
					`<rootDir>/packages/*/package.json`,
				],
			},
		},
		'build-types': {
			execution: 'top-level',
			baseCommand: `tsx <rootDir>/internal/scripts/typecheck.ts`,
			cache: {
				inputs: {
					include: ['<allWorkspaceDirs>/**/*.{ts,tsx}', '<allWorkspaceDirs>/tsconfig.json'],
					exclude: ['<allWorkspaceDirs>/dist*/**/*', '<allWorkspaceDirs>/api/**/*'],
				},
				outputs: ['<allWorkspaceDirs>/*.tsbuildinfo', '<allWorkspaceDirs>/.tsbuild/**/*'],
			},
			runsAfter: {
				'refresh-assets': {},
				'maybe-clean-tsbuildinfo': {},
			},
		},
		'build-api': {
			execution: 'independent',
			cache: {
				inputs: ['.tsbuild/**/*.d.ts', 'tsconfig.json'],
				outputs: ['api/**/*'],
			},
			runsAfter: {
				'build-types': {
					// Because build-types is top level, if usesOutput were set to true every
					// build-api task would depend on all the .tsbuild files in the whole
					// repo. So we set this to false and configure it to use only the
					// local .tsbuild files
					usesOutput: false,
				},
			},
		},
		'build-i18n': {
			execution: 'independent',
			cache: {
				inputs: ['<rootDir>/apps/dotcom/client/public/tla/locales/*.json'],
				outputs: ['<rootDir>/apps/dotcom/client/public/tla/locales-compiled/*.json'],
			},
		},
		'api-check': {
			execution: 'top-level',
			baseCommand: `tsx <rootDir>/internal/scripts/api-check.ts`,
			runsAfter: { 'build-api': {} },
			cache: {
				inputs: [`<rootDir>/packages/*/api/public.d.ts`],
			},
		},
	},
} satisfies LazyConfig

export default config
