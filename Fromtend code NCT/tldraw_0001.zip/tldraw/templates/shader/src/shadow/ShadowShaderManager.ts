import { Atom, Box, Editor, Group2d, react, TLShape, Vec } from 'tldraw'
import { WebGLManager } from '../WebGLManager'
import { ShaderManagerConfig } from './config'
import FRAGMENT_SHADER from './fragment.glsl?raw'
import VERTEX_SHADER from './vertex.glsl?raw'

export type Geometry = Array<{ start: Vec; end: Vec }>

export class ShadowShaderManager extends WebGLManager<ShaderManagerConfig> {
	private program: WebGLProgram | null = null
	private positionBuffer: WebGLBuffer | null = null
	private vao: WebGLVertexArrayObject | null = null

	private u_resolution: WebGLUniformLocation | null = null
	private u_darkMode: WebGLUniformLocation | null = null
	private u_quality: WebGLUniformLocation | null = null
	private u_zoom: WebGLUniformLocation | null = null
	private u_segments: WebGLUniformLocation | null = null
	private u_segmentCount: WebGLUniformLocation | null = null
	private u_lightPos: WebGLUniformLocation | null = null
	private u_shadowContrast: WebGLUniformLocation | null = null

	private geometries: Geometry[] = []
	private maxSegments: number = 2000

	private pointer: Vec = new Vec(0.5, 0.5)

	constructor(
		editor: Editor,
		canvas: HTMLCanvasElement,
		config: Atom<ShaderManagerConfig, unknown>
	) {
		super(editor, canvas, config)
		this.initialize()
	}

	onInitialize = (): void => {
		this.maxSegments = Math.floor(Math.min(512, 2000 / this.getConfig().quality))

		if (!this.gl) {
			console.error('No WebGL context available')
			return
		}

		if (this.gl.isContextLost()) {
			console.error('WebGL context is lost, cannot initialize')
			return
		}

		const maxTextureSize = this.gl.getParameter(this.gl.MAX_TEXTURE_SIZE)

		if (!maxTextureSize) {
			console.error('WebGL context appears invalid (max texture size is null)')
			return
		}

		const gl = this.gl
		const compileShader = (type: number, source: string): WebGLShader | null => {
			const shader = gl.createShader(type)
			if (!shader) {
				console.error('Failed to create shader - createShader returned null')
				return null
			}

			gl.shaderSource(shader, source)
			gl.compileShader(shader)

			if (gl.getShaderParameter(shader, gl.COMPILE_STATUS) !== true) {
				const shaderType = type === gl.VERTEX_SHADER ? 'VERTEX' : 'FRAGMENT'
				const log = gl.getShaderInfoLog(shader)
				console.error(`${shaderType} shader compile error:`, log || 'No error log available')
				console.error('Shader source:', source)
				gl.deleteShader(shader)
				return null
			}

			return shader
		}

		const vertexShader = compileShader(this.gl.VERTEX_SHADER, VERTEX_SHADER)
		if (!vertexShader) {
			console.error('Failed to compile vertex shader, aborting initialization')
			return
		}

		const fragmentShader = compileShader(this.gl.FRAGMENT_SHADER, FRAGMENT_SHADER)
		if (!fragmentShader) {
			console.error('Failed to compile fragment shader, aborting initialization')
			this.gl.deleteShader(vertexShader)
			return
		}

		this.program = this.gl.createProgram()

		if (!this.program) {
			console.error('Failed to create program')
			return
		}

		this.gl.attachShader(this.program, vertexShader)
		this.gl.attachShader(this.program, fragmentShader)
		this.gl.linkProgram(this.program)

		if (!this.gl.getProgramParameter(this.program, this.gl.LINK_STATUS)) {
			console.error('Program link error:', this.gl.getProgramInfoLog(this.program))
			return
		}

		this.u_resolution = this.gl.getUniformLocation(this.program, 'u_resolution')
		this.u_darkMode = this.gl.getUniformLocation(this.program, 'u_darkMode')
		this.u_quality = this.gl.getUniformLocation(this.program, 'u_quality')
		this.u_zoom = this.gl.getUniformLocation(this.program, 'u_zoom')
		this.u_segments = this.gl.getUniformLocation(this.program, 'u_segments')
		this.u_segmentCount = this.gl.getUniformLocation(this.program, 'u_segmentCount')
		this.u_lightPos = this.gl.getUniformLocation(this.program, 'u_lightPos')
		this.u_shadowContrast = this.gl.getUniformLocation(this.program, 'u_shadowContrast')

		this.positionBuffer = this.gl.createBuffer()

		this.vao = this.gl.createVertexArray()
		this.gl.bindVertexArray(this.vao)

		this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.positionBuffer)
		const positions = new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1])
		this.gl.bufferData(this.gl.ARRAY_BUFFER, positions, this.gl.STATIC_DRAW)

		const a_position = this.gl.getAttribLocation(this.program, 'a_position')
		this.gl.enableVertexAttribArray(a_position)
		this.gl.vertexAttribPointer(a_position, 2, this.gl.FLOAT, false, 0, 0)

		this.gl.bindVertexArray(null)

		this.disposables.add(react('dependencies', this.tick))

		this.tick()
	}

	onUpdate = (): void => {
		const { editor } = this
		const vsb = editor.getViewportScreenBounds()
		const camera = editor.getCamera()
		this.geometries = []

		for (const shape of editor.getCurrentPageShapes()) {
			try {
				const geometry = this.extractGeometry(shape, camera, vsb)
				if (geometry) {
					this.geometries.push(geometry)
				}
			} catch (e) {
				console.log(`Error extracting geometry for shape: ${shape.type}`, e)
			}
		}
	}

	onFirstRender = (): void => {
		if (!this.gl || !this.program) return

		this.gl.clearColor(0, 0, 0, 0)
		this.gl.enable(this.gl.BLEND)
		this.gl.blendFunc(this.gl.SRC_ALPHA, this.gl.ONE_MINUS_SRC_ALPHA)
		this.gl.useProgram(this.program)
	}

	onRender = (_deltaTime: number, _currentTime: number): void => {
		if (!this.gl || !this.program) return

		// Clear the canvas each frame to prevent flickering
		this.gl.clear(this.gl.COLOR_BUFFER_BIT)

		const isDarkMode = this.editor.user.getIsDarkMode()

		const { quality, shadowContrast } = this.getConfig()

		if (this.u_resolution) {
			this.gl.uniform2f(this.u_resolution, this.canvas.width, this.canvas.height)
		}
		if (this.u_darkMode) {
			this.gl.uniform1f(this.u_darkMode, isDarkMode ? 1.0 : 0.0)
		}
		if (this.u_quality) {
			this.gl.uniform1f(this.u_quality, quality)
		}
		if (this.u_zoom) {
			this.gl.uniform1f(this.u_zoom, this.editor.getZoomLevel())
		}

		if (this.u_lightPos) {
			this.gl.uniform2f(this.u_lightPos, this.pointer.x, this.pointer.y)
		}
		if (this.u_shadowContrast) {
			this.gl.uniform1f(this.u_shadowContrast, shadowContrast)
		}

		const allSegments: number[] = []

		for (const geometry of this.geometries) {
			for (const segment of geometry) {
				if (allSegments.length < this.maxSegments * 4) {
					allSegments.push(segment.start.x, segment.start.y, segment.end.x, segment.end.y)
				}
			}
		}

		const farAway = 999999
		while (allSegments.length < this.maxSegments * 4)
			allSegments.push(farAway, farAway, farAway, farAway)

		if (this.u_segments) {
			this.gl.uniform4fv(this.u_segments, allSegments)
		}
		if (this.u_segmentCount) {
			this.gl.uniform1f(this.u_segmentCount, Math.min(allSegments.length / 4, this.maxSegments))
		}

		this.gl.bindVertexArray(this.vao)
		this.gl.drawArrays(this.gl.TRIANGLE_STRIP, 0, 4)
		this.gl.bindVertexArray(null)
	}

	onDispose = (): void => {
		if (this.gl) {
			if (this.vao) {
				this.gl.deleteVertexArray(this.vao)
				this.vao = null
			}
			if (this.positionBuffer) {
				this.gl.deleteBuffer(this.positionBuffer)
				this.positionBuffer = null
			}
			if (this.program) {
				this.gl.deleteProgram(this.program)
				this.program = null
			}
		}
	}

	pointerMove = (x: number, y: number): void => {
		const vsb = this.editor.getViewportScreenBounds()
		this.pointer.x = (x - vsb.x) / vsb.width
		this.pointer.y = 1.0 - (y - vsb.y) / vsb.height
		this.tick()
	}

	private pageToCanvas = (
		point: Vec,
		camera: { x: number; y: number; z: number },
		viewportScreenBounds: Box
	): Vec => {
		const canvasX = ((point.x + camera.x) * camera.z) / viewportScreenBounds.width
		const canvasY = 1.0 - ((point.y + camera.y) * camera.z) / viewportScreenBounds.height
		return new Vec(canvasX, canvasY)
	}

	private extractGeometry = (
		shape: TLShape,
		camera: { x: number; y: number; z: number },
		viewportScreenBounds: Box
	): Geometry | null => {
		const geometry = this.editor.getShapeGeometry(shape)
		const transform = this.editor.getShapePageTransform(shape)
		if (!transform) return null

		const canvasPoints = geometry.vertices.map((c) =>
			this.pageToCanvas(transform.applyToPoint(c), camera, viewportScreenBounds)
		)

		const segments: Geometry = []

		for (let i = 0; i < canvasPoints.length - 1; i++) {
			segments.push({ start: canvasPoints[i], end: canvasPoints[i + 1] })
		}

		const isClosed =
			geometry instanceof Group2d
				? (geometry.children[0]?.isClosed ?? true)
				: 'isClosed' in geometry
					? geometry.isClosed
					: true

		if (isClosed && canvasPoints.length > 0) {
			segments.push({
				start: canvasPoints[canvasPoints.length - 1],
				end: canvasPoints[0],
			})
		}

		return segments
	}
}
