import * as React from 'react';
import { Image } from '../src/blocks/Image';
import * as reactTestRenderer from 'react-test-renderer';
import { block } from './functions/render-block';
import { BuilderPage } from '../src/builder-react';

describe('Image', () => {
  it('Builder image url', () => {
    const tree = reactTestRenderer
      .create(
        <Image image="https://cdn.builder.io/api/v1/image/assets%2FYJIGb4i01jvw0SRdL5Bt%2F755c131471fb49ab91dc0bdc45bc85b5?width=1003" />
      )
      .toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('Builder image url with width', () => {
    const tree = reactTestRenderer
      .create(
        <Image image="https://cdn.builder.io/api/v1/image/assets%2FYJIGb4i01jvw0SRdL5Bt%2F755c131471fb49ab91dc0bdc45bc85b5?width=1003" />
      )
      .toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('renders an empty alt attribute when alt text is missing', () => {
    const tree = reactTestRenderer
      .create(
        <Image image="https://cdn.builder.io/api/v1/image/assets%2FYJIGb4i01jvw0SRdL5Bt%2F755c131471fb49ab91dc0bdc45bc85b5?width=1003" />
      )
      .toJSON() as any;
    const image = tree.children.find((child: any) => child.type === 'img');

    expect(image.props.alt).toBe('');
  });

  it('Shopify image url', () => {
    const tree = reactTestRenderer
      .create(
        <Image image="https://cdn.shopify.com/s/files/1/0374/6457/2041/products/valerie-elash-o1Ic6JdypmA-unsplash.jpg?v=1592506853" />
      )
      .toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('Amp image', () => {
    const imageBlock = block(
      'Image',
      {
        image:
          'https://cdn.shopify.com/s/files/1/0374/6457/2041/products/valerie-elash-o1Ic6JdypmA-unsplash.jpg?v=1592506853',
      },
      {
        responsiveStyles: {
          large: {
            width: '345px',
          },
          medium: {
            width: '100%',
          },
        },
      },
      1234
    );

    const renderedBlock = reactTestRenderer
      .create(
        <BuilderPage
          model="page"
          ampMode
          content={{
            data: {
              blocks: [imageBlock],
            },
          }}
        />
      )
      .toJSON();

    expect(renderedBlock).toMatchSnapshot();
  });

  it('Lazy load', () => {
    const tree = reactTestRenderer
      .create(
        <Image
          image="https://cdn.builder.io/api/v1/image/assets%2FYJIGb4i01jvw0SRdL5Bt%2F755c131471fb49ab91dc0bdc45bc85b5?width=1003"
          lazy
        />
      )
      .toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('with sizes, srcset, and alt', () => {
    const tree = reactTestRenderer
      .create(
        <Image
          sizes="(max-width: 600px) 67vw, 92vw"
          srcset="nosrcset"
          altText="this great image"
          image="https://cdn.builder.io/api/v1/image/assets%2FYJIGb4i01jvw0SRdL5Bt%2F755c131471fb49ab91dc0bdc45bc85b5?width=1003"
          amp="true"
        />
      )
      .toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('with responsive styles', () => {
    const imageBlock = block(
      'Image',
      {
        image:
          'https://cdn.shopify.com/s/files/1/0374/6457/2041/products/valerie-elash-o1Ic6JdypmA-unsplash.jpg?v=1592506853',
      },
      {
        responsiveStyles: {
          large: {
            width: '345px',
          },
          medium: {
            width: '100%',
          },
        },
      },
      1234
    );

    const renderedBlock = reactTestRenderer
      .create(
        <BuilderPage
          model="page"
          content={{
            data: {
              blocks: [imageBlock],
            },
          }}
        />
      )
      .toJSON();

    expect(renderedBlock).toMatchSnapshot();
  });

  it('prepends auto to sizes for lazy-loaded images', () => {
    const tree = reactTestRenderer
      .create(
        <Image
          image="https://cdn.builder.io/api/v1/image/assets%2Fabc%2F123?width=500"
          builderBlock={{
            id: 'test-block',
            responsiveStyles: { large: { width: '50%' } },
          }}
        />
      )
      .toJSON();

    const picture = tree as any;
    const img = picture.children.find((c: any) => c.type === 'img');
    // sizes should start with "auto," since no explicit sizes and not eager
    expect(img.props.sizes).toMatch(/^auto,/);
    expect(img.props.sizes).toContain('50vw');
  });

  it('does not prepend auto when highPriority (eager) is set', () => {
    const tree = reactTestRenderer
      .create(
        <Image
          image="https://cdn.builder.io/api/v1/image/assets%2Fabc%2F123?width=500"
          highPriority
          builderBlock={{
            id: 'test-block',
            responsiveStyles: { large: { width: '50%' } },
          }}
        />
      )
      .toJSON();

    const picture = tree as any;
    const img = picture.children.find((c: any) => c.type === 'img');
    // highPriority loads eagerly, so no "auto" prefix
    expect(img.props.sizes).not.toMatch(/^auto/);
    expect(img.props.sizes).toBe('50vw');
  });

  it('passes sizes to the webp source tag', () => {
    const tree = reactTestRenderer
      .create(
        <Image
          image="https://cdn.builder.io/api/v1/image/assets%2Fabc%2F123?width=500"
          builderBlock={{
            id: 'test-block',
            responsiveStyles: { large: { width: '50%' } },
          }}
        />
      )
      .toJSON();

    const picture = tree as any;
    const source = picture.children.find((c: any) => c.type === 'source');
    // source tag should have sizes matching the img tag
    expect(source).toBeTruthy();
    expect(source.props.sizes).toBeDefined();
    expect(source.props.sizes).toContain('50vw');
  });
});
