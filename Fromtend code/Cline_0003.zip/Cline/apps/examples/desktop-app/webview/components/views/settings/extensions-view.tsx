"use client";

import {
	Bot,
	Code,
	Copy,
	FileText,
	MoreVertical,
	Play,
	Puzzle,
	RefreshCw,
	Server,
	Trash2,
	TriangleAlert,
	Wrench,
	Zap,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuItem,
	DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Spinner } from "@/components/ui/spinner";
import { Switch } from "@/components/ui/switch";
import { desktopClient } from "@/lib/desktop-client";
import type { MarketplacePrimitiveType } from "@/lib/marketplace";
import { cn } from "@/lib/utils";
import {
	MarketplaceEntrySetupDetails,
	type MarketplaceLocalInstalledItem,
	type MarketplaceLocalInstalledItemRenderContext,
	MarketplaceView,
} from "../marketplace-view";
import { CommandBadge, PageFrame, PageHeader } from "../page-layout";

export type CustomizationSection =
	| "Rules"
	| "Hooks"
	| "MCP"
	| "Skills"
	| "Agents"
	| "Plugins"
	| "Tools";

const sectionDescriptions: Record<CustomizationSection, string> = {
	Rules: "Review project and global rule files that shape Cline behavior.",
	Hooks: "Inspect hook configuration and recent execution status.",
	MCP: "Manage installed MCP servers and add new servers from the marketplace.",
	Skills: "Manage installed skills and add new skills from the marketplace.",
	Agents: "Review configured agents discovered from local settings.",
	Plugins: "Manage installed plugins and add new plugins from the marketplace.",
	Tools: "Inspect built-in tools and tools contributed by plugins.",
};

const sectionCommands: Record<CustomizationSection, string> = {
	Rules: "cline config rules",
	Hooks: "cline config hooks",
	MCP: "cline mcp install",
	Skills: "cline skill",
	Agents: "cline config agents",
	Plugins: "cline plugin",
	Tools: "cline config tools",
};

type RuleItem = {
	name: string;
	instructions: string;
	path: string;
};

type WorkflowItem = {
	id: string;
	name: string;
	instructions: string;
	path: string;
};

type SkillItem = {
	name: string;
	description?: string;
	instructions: string;
	path: string;
};

type CommandItem = {
	id: string;
	type: "workflow" | "skill";
	name: string;
	description?: string;
	instructions: string;
	path: string;
	scope: ItemScope;
};

type ItemScope = "Global" | "Project";

type AgentItem = {
	name: string;
	path: string;
};

type PluginItem = {
	name: string;
	path: string;
	enabled: boolean;
	contributions?: PluginContributions;
};

type PluginContributions = {
	inspectionStatus?: "available" | "disabled" | "failed";
	capabilities: string[];
	tools: string[];
	skills: string[];
	rules: string[];
	hooks: string[];
	commands: string[];
	mcpServers: string[];
	providers: string[];
};

type ToolItem = {
	id: string;
	name: string;
	description?: string;
	enabled: boolean;
	source: string;
	path?: string;
	pluginName?: string;
	headlessToolNames?: string[];
};

type HookItem = {
	fileName: string;
	hookEventName?: string;
	path: string;
};

type SessionHookEvent = {
	ts: string;
	hookEventName: string;
};

type CliDiscoveredSession = {
	sessionId: string;
	startedAt: string;
};

type HookExecutionSummary = {
	count: number;
	lastTs: string | null;
};

type McpServer = {
	name: string;
	transportType: "stdio" | "sse" | "streamableHttp";
	disabled: boolean;
	command?: string;
	args?: string[];
	cwd?: string;
	env?: Record<string, string>;
	url?: string;
	headers?: Record<string, string>;
	metadata?: unknown;
};

type McpServersResponse = {
	settingsPath: string;
	hasSettingsFile: boolean;
	servers: McpServer[];
};

type LocalUninstallType = "mcp" | "skill" | "workflow" | "plugin";

type LocalUninstallTarget = {
	key: string;
	type: LocalUninstallType;
	id?: string;
	name?: string;
	path?: string;
};

type UserInstructionListsResponse = {
	workspaceRoot: string;
	rules: RuleItem[];
	workflows: WorkflowItem[];
	skills: SkillItem[];
	agents: AgentItem[];
	plugins: PluginItem[];
	tools: ToolItem[];
	hooks: HookItem[];
	mcp: McpServersResponse;
	warnings: string[];
};

const EMPTY_MCP_RESPONSE: McpServersResponse = {
	settingsPath: "",
	hasSettingsFile: false,
	servers: [],
};

function asArray<T>(value: T[] | null | undefined): T[] {
	return Array.isArray(value) ? value : [];
}

function normalizeInstructionListsResponse(
	response: Partial<UserInstructionListsResponse> | null | undefined,
): UserInstructionListsResponse {
	return {
		workspaceRoot:
			typeof response?.workspaceRoot === "string" ? response.workspaceRoot : "",
		rules: asArray(response?.rules),
		workflows: asArray(response?.workflows),
		skills: asArray(response?.skills),
		agents: asArray(response?.agents),
		plugins: asArray(response?.plugins),
		tools: asArray(response?.tools),
		hooks: asArray(response?.hooks),
		mcp:
			response?.mcp && typeof response.mcp === "object"
				? {
						settingsPath:
							typeof response.mcp.settingsPath === "string"
								? response.mcp.settingsPath
								: "",
						hasSettingsFile: Boolean(response.mcp.hasSettingsFile),
						servers: asArray(response.mcp.servers),
					}
				: {
						...EMPTY_MCP_RESPONSE,
					},
		warnings: asArray(response?.warnings),
	};
}

const EXTENSION_LISTS_CACHE_TTL_MS = 60_000;
const EXTENSION_HOOK_STATS_CACHE_TTL_MS = 30_000;

let extensionListsCache:
	| (UserInstructionListsResponse & {
			fetchedAt: number;
	  })
	| null = null;

let extensionHookStatsCache: {
	hookExecutionByEvent: Record<string, HookExecutionSummary>;
	hookExecutionSessionId: string | null;
	fetchedAt: number;
} | null = null;

const extensionInventoryInvalidationListeners = new Set<() => void>();

/**
 * Drops the module-level inventory cache and notifies mounted inventory views
 * so they refetch immediately. Used by the Marketplace page after
 * installs/uninstalls that happen outside these views — including ones that
 * complete after the user has already navigated back to the Plugins hub.
 */
export function invalidateExtensionInventoryCache() {
	extensionListsCache = null;
	for (const listener of extensionInventoryInvalidationListeners) {
		listener();
	}
}

/** Subscribe to inventory invalidations; returns an unsubscribe function. */
export function subscribeToExtensionInventoryInvalidation(
	listener: () => void,
): () => void {
	extensionInventoryInvalidationListeners.add(listener);
	return () => {
		extensionInventoryInvalidationListeners.delete(listener);
	};
}

function hasFreshExtensionsListsCache(
	cache: typeof extensionListsCache,
	now: number,
): cache is NonNullable<typeof extensionListsCache> {
	return Boolean(
		cache &&
			now - cache.fetchedAt < EXTENSION_LISTS_CACHE_TTL_MS &&
			Array.isArray(cache.tools) &&
			cache.tools.length > 0,
	);
}

function previewText(input: string, maxLength = 150): string {
	const compact = input.replace(/\s+/g, " ").trim();
	if (compact.length <= maxLength) {
		return compact;
	}
	return `${compact.slice(0, maxLength).trimEnd()}...`;
}

function normalizePath(path: string): string {
	return path.replaceAll("\\", "/");
}

function getPathScope(path: string, workspaceRoot: string): ItemScope {
	const normalizedRoot = normalizePath(workspaceRoot);
	const normalized = normalizePath(path);
	return normalizedRoot && normalized.startsWith(`${normalizedRoot}/`)
		? "Project"
		: "Global";
}

function ScopeBadge({ scope }: { scope: ItemScope }) {
	return (
		<Badge variant="outline" className="shrink-0 text-muted-foreground">
			{scope}
		</Badge>
	);
}

function getLocalMarketplaceMatchValues(
	...values: Array<string | undefined>
): string[] {
	const matchValues = new Set<string>();
	for (const value of values) {
		const normalized = value?.trim().replaceAll("\\", "/");
		if (!normalized) {
			continue;
		}
		matchValues.add(normalized);
		const segments = normalized.split("/").filter(Boolean);
		for (const segment of segments) {
			matchValues.add(segment.replace(/\.[^.]+$/, ""));
		}
		for (let index = 0; index < segments.length - 1; index += 1) {
			matchValues.add(`${segments[index]}/${segments[index + 1]}`);
		}
	}
	return [...matchValues];
}

async function fetchUserInstructionLists(): Promise<UserInstructionListsResponse> {
	const response = await desktopClient.invoke<
		Partial<UserInstructionListsResponse>
	>("list_user_instruction_configs");
	return normalizeInstructionListsResponse(response);
}

function isUnsupportedDesktopCommand(error: unknown, command: string): boolean {
	const message = error instanceof Error ? error.message : String(error);
	return message.includes(`unsupported desktop command: ${command}`);
}

export function CustomizationSectionView({
	catalogPrimitive,
	chrome = "page",
	marketplaceVariant = "full",
	onInventoryChanged,
	section = "Rules",
	showTabs = false,
}: {
	catalogPrimitive?: MarketplacePrimitiveType;
	/** "embedded" renders without the page frame/header for use inside the Plugins hub. */
	chrome?: "page" | "embedded";
	/** Which marketplace sections the embedded MarketplaceView shows. */
	marketplaceVariant?: "full" | "installed";
	/** Invoked after a forced inventory refresh (installs, uninstalls). */
	onInventoryChanged?: () => void;
	section?: CustomizationSection;
	showTabs?: boolean;
}) {
	const [activeTab, setActiveTab] = useState<CustomizationSection>(section);
	const [isLoading, setIsLoading] = useState(
		() => !hasFreshExtensionsListsCache(extensionListsCache, Date.now()),
	);
	const [errorMessage, setErrorMessage] = useState<string | null>(null);
	const [workspaceRoot, setWorkspaceRoot] = useState(
		() => extensionListsCache?.workspaceRoot ?? "",
	);
	const [rules, setRules] = useState<RuleItem[]>(
		() => extensionListsCache?.rules ?? [],
	);
	const [workflows, setWorkflows] = useState<WorkflowItem[]>(
		() => extensionListsCache?.workflows ?? [],
	);
	const [skills, setSkills] = useState<SkillItem[]>(
		() => extensionListsCache?.skills ?? [],
	);
	const [agents, setAgents] = useState<AgentItem[]>(
		() => extensionListsCache?.agents ?? [],
	);
	const [plugins, setPlugins] = useState<PluginItem[]>(
		() => extensionListsCache?.plugins ?? [],
	);
	const [tools, setTools] = useState<ToolItem[]>(
		() => extensionListsCache?.tools ?? [],
	);
	const [hooks, setHooks] = useState<HookItem[]>(
		() => extensionListsCache?.hooks ?? [],
	);
	const [mcp, setMcp] = useState<McpServersResponse>(
		() => extensionListsCache?.mcp ?? EMPTY_MCP_RESPONSE,
	);
	const [warnings, setWarnings] = useState<string[]>(
		() => extensionListsCache?.warnings ?? [],
	);
	const [hookExecutionByEvent, setHookExecutionByEvent] = useState<
		Record<string, HookExecutionSummary>
	>(() => extensionHookStatsCache?.hookExecutionByEvent ?? {});
	const [hookExecutionSessionId, setHookExecutionSessionId] = useState<
		string | null
	>(() => extensionHookStatsCache?.hookExecutionSessionId ?? null);
	const [hookExecutionLoading, setHookExecutionLoading] = useState(false);
	const [togglingToolIds, setTogglingToolIds] = useState<Set<string>>(
		() => new Set(),
	);
	const [togglingPluginPaths, setTogglingPluginPaths] = useState<Set<string>>(
		() => new Set(),
	);
	const [localUninstallingKeys, setLocalUninstallingKeys] = useState<
		Set<string>
	>(() => new Set());
	const [localActionMessages, setLocalActionMessages] = useState<
		Map<string, { status: "success" | "failed"; message: string }>
	>(() => new Map());

	useEffect(() => {
		setActiveTab(section);
	}, [section]);

	const refresh = useCallback(
		async (force = false) => {
			const now = Date.now();
			if (!force && hasFreshExtensionsListsCache(extensionListsCache, now)) {
				setWorkspaceRoot(extensionListsCache.workspaceRoot);
				setRules(extensionListsCache.rules);
				setWorkflows(extensionListsCache.workflows);
				setSkills(extensionListsCache.skills);
				setAgents(extensionListsCache.agents);
				setPlugins(extensionListsCache.plugins);
				setTools(extensionListsCache.tools);
				setHooks(extensionListsCache.hooks);
				setMcp(extensionListsCache.mcp);
				setWarnings(extensionListsCache.warnings);
				setErrorMessage(null);
				setIsLoading(false);
				return;
			}

			setIsLoading(true);
			setErrorMessage(null);
			try {
				const response = await fetchUserInstructionLists();
				setWorkspaceRoot(response.workspaceRoot);
				setRules(response.rules);
				setWorkflows(response.workflows);
				setSkills(response.skills);
				setAgents(response.agents);
				setPlugins(response.plugins);
				setTools(response.tools);
				setHooks(response.hooks);
				setMcp(response.mcp);
				setWarnings(response.warnings);
				extensionListsCache = {
					...response,
					fetchedAt: Date.now(),
				};
				if (force) {
					onInventoryChanged?.();
				}
			} catch (error) {
				const message = error instanceof Error ? error.message : String(error);
				setErrorMessage(message);
			} finally {
				setIsLoading(false);
			}
		},
		[onInventoryChanged],
	);

	const loadHookExecutionStats = useCallback(async (force = false) => {
		const now = Date.now();
		if (
			!force &&
			extensionHookStatsCache &&
			now - extensionHookStatsCache.fetchedAt <
				EXTENSION_HOOK_STATS_CACHE_TTL_MS
		) {
			setHookExecutionByEvent(extensionHookStatsCache.hookExecutionByEvent);
			setHookExecutionSessionId(extensionHookStatsCache.hookExecutionSessionId);
			return;
		}

		setHookExecutionLoading(true);
		try {
			const sessions = await desktopClient.invoke<CliDiscoveredSession[]>(
				"list_cli_sessions",
				{
					limit: 300,
				},
			);
			const latestSession = (sessions ?? [])
				.filter(
					(session) =>
						typeof session.sessionId === "string" &&
						session.sessionId.trim().length > 0,
				)
				.sort((left, right) =>
					(right.startedAt ?? "").localeCompare(left.startedAt ?? ""),
				)[0];
			if (!latestSession?.sessionId) {
				setHookExecutionByEvent({});
				setHookExecutionSessionId(null);
				extensionHookStatsCache = {
					hookExecutionByEvent: {},
					hookExecutionSessionId: null,
					fetchedAt: Date.now(),
				};
				return;
			}

			const events = await desktopClient.invoke<SessionHookEvent[]>(
				"read_session_hooks",
				{
					sessionId: latestSession.sessionId,
					limit: 5000,
				},
			);
			const next: Record<string, HookExecutionSummary> = {};
			for (const event of events ?? []) {
				const hookName = event.hookEventName?.trim();
				if (!hookName) {
					continue;
				}
				const current = next[hookName] ?? {
					count: 0,
					lastTs: null,
				};
				current.count += 1;
				if (event.ts && (!current.lastTs || event.ts > current.lastTs)) {
					current.lastTs = event.ts;
				}
				next[hookName] = current;
			}
			setHookExecutionByEvent(next);
			setHookExecutionSessionId(latestSession.sessionId);
			extensionHookStatsCache = {
				hookExecutionByEvent: next,
				hookExecutionSessionId: latestSession.sessionId,
				fetchedAt: Date.now(),
			};
		} catch {
			// Keep existing execution status when lookup fails.
		} finally {
			setHookExecutionLoading(false);
		}
	}, []);

	const applyResponse = useCallback(
		(response: Partial<UserInstructionListsResponse>) => {
			const normalizedResponse = normalizeInstructionListsResponse(response);
			setWorkspaceRoot(normalizedResponse.workspaceRoot);
			setRules(normalizedResponse.rules);
			setWorkflows(normalizedResponse.workflows);
			setSkills(normalizedResponse.skills);
			setAgents(normalizedResponse.agents);
			setPlugins(normalizedResponse.plugins);
			setTools(normalizedResponse.tools);
			setHooks(normalizedResponse.hooks);
			setMcp(normalizedResponse.mcp);
			setWarnings(normalizedResponse.warnings);
			extensionListsCache = {
				...normalizedResponse,
				fetchedAt: Date.now(),
			};
		},
		[],
	);

	const setToolEnabled = useCallback(
		async (tool: ToolItem) => {
			setTogglingToolIds((current) => new Set(current).add(tool.id));
			setErrorMessage(null);
			try {
				const names = [tool.name, ...(tool.headlessToolNames ?? [])].filter(
					Boolean,
				);
				if (names.length === 0) {
					throw new Error("tool name is required");
				}
				let response: UserInstructionListsResponse | undefined;
				try {
					response = await desktopClient.invoke<UserInstructionListsResponse>(
						"set_tool_disabled",
						{
							names,
							disabled: tool.enabled,
						},
					);
				} catch (error) {
					if (!isUnsupportedDesktopCommand(error, "set_tool_disabled")) {
						throw error;
					}
					for (const name of names) {
						response = await desktopClient.invoke<UserInstructionListsResponse>(
							"toggle_disabled_plugin_tool",
							{ name },
						);
					}
				}
				if (!response) {
					throw new Error(
						"tool toggle did not return an updated extension list",
					);
				}
				applyResponse(response);
			} catch (error) {
				const message = error instanceof Error ? error.message : String(error);
				setErrorMessage(message);
			} finally {
				setTogglingToolIds((current) => {
					const next = new Set(current);
					next.delete(tool.id);
					return next;
				});
			}
		},
		[applyResponse],
	);

	const setPluginEnabled = useCallback(
		async (plugin: PluginItem) => {
			setTogglingPluginPaths((current) => new Set(current).add(plugin.path));
			setErrorMessage(null);
			try {
				const response =
					await desktopClient.invoke<UserInstructionListsResponse>(
						"set_plugin_disabled",
						{
							path: plugin.path,
							disabled: plugin.enabled,
						},
					);
				applyResponse(response);
			} catch (error) {
				const message = error instanceof Error ? error.message : String(error);
				setErrorMessage(message);
			} finally {
				setTogglingPluginPaths((current) => {
					const next = new Set(current);
					next.delete(plugin.path);
					return next;
				});
			}
		},
		[applyResponse],
	);

	const uninstallLocalPrimitive = useCallback(
		async (target: LocalUninstallTarget) => {
			if (localUninstallingKeys.has(target.key)) {
				return;
			}
			setLocalUninstallingKeys((current) => new Set(current).add(target.key));
			setLocalActionMessages((current) => {
				const next = new Map(current);
				next.delete(target.key);
				return next;
			});
			setErrorMessage(null);
			try {
				const result = await desktopClient.invoke<{ message?: string }>(
					"uninstall_local_primitive",
					{
						type: target.type,
						id: target.id,
						name: target.name,
						path: target.path,
					},
				);
				setLocalActionMessages((current) => {
					const next = new Map(current);
					next.set(target.key, {
						status: "success",
						message:
							result.message ??
							`Uninstalled ${target.name ?? target.id ?? target.path}.`,
					});
					return next;
				});
				await refresh(true);
			} catch (error) {
				const message = error instanceof Error ? error.message : String(error);
				setLocalActionMessages((current) => {
					const next = new Map(current);
					next.set(target.key, { status: "failed", message });
					return next;
				});
				setErrorMessage(message);
			} finally {
				setLocalUninstallingKeys((current) => {
					const next = new Set(current);
					next.delete(target.key);
					return next;
				});
			}
		},
		[localUninstallingKeys, refresh],
	);

	const formatExecutionTs = useCallback((value: string | null): string => {
		if (!value) {
			return "never";
		}
		const asNumber = Number(value);
		const date = Number.isFinite(asNumber)
			? new Date(asNumber)
			: new Date(value);
		if (Number.isNaN(date.getTime())) {
			return value;
		}
		return date.toLocaleString();
	}, []);

	useEffect(() => {
		const timeoutId = window.setTimeout(() => {
			void refresh(false);
		}, 0);
		return () => window.clearTimeout(timeoutId);
	}, [refresh]);

	// Marketplace installs/uninstalls can complete after this view mounted
	// (e.g. the user navigated back to Plugins mid-install); refetch when the
	// shared inventory cache is invalidated so the list is never stale.
	useEffect(
		() =>
			subscribeToExtensionInventoryInvalidation(() => {
				void refresh(true);
			}),
		[refresh],
	);

	useEffect(() => {
		if (activeTab !== "Hooks") {
			return;
		}
		const timeoutId = window.setTimeout(() => {
			void loadHookExecutionStats(false);
		}, 0);
		return () => window.clearTimeout(timeoutId);
	}, [activeTab, loadHookExecutionStats]);

	const tabs: CustomizationSection[] = [
		"Rules",
		"Hooks",
		"Skills",
		"Agents",
		"Plugins",
		"Tools",
	];

	const commandItems = useMemo<CommandItem[]>(() => {
		const workflowItems: CommandItem[] = workflows.map((workflow) => ({
			id: workflow.id,
			type: "workflow",
			name: workflow.name,
			instructions: workflow.instructions,
			path: workflow.path,
			scope: getPathScope(workflow.path, workspaceRoot),
		}));
		const skillItems: CommandItem[] = skills.map((skill) => ({
			id: normalizePath(skill.path).toLowerCase(),
			type: "skill",
			name: skill.name,
			description: skill.description,
			instructions: skill.instructions,
			path: skill.path,
			scope: getPathScope(skill.path, workspaceRoot),
		}));
		return [...workflowItems, ...skillItems].sort((a, b) =>
			a.name.localeCompare(b.name),
		);
	}, [skills, workflows, workspaceRoot]);

	const { projectRules, globalRules } = useMemo(() => {
		const normalizedRoot = normalizePath(workspaceRoot);
		const project: RuleItem[] = [];
		const global: RuleItem[] = [];
		for (const rule of rules) {
			const normalized = normalizePath(rule.path);
			if (
				normalizedRoot &&
				normalized.startsWith(`${normalizedRoot}/`) &&
				normalized.includes("/.clinerules/")
			) {
				project.push(rule);
			} else {
				global.push(rule);
			}
		}
		return { projectRules: project, globalRules: global };
	}, [rules, workspaceRoot]);

	const { projectHooks, globalHooks } = useMemo(() => {
		const normalizedRoot = normalizePath(workspaceRoot);
		const project: HookItem[] = [];
		const global: HookItem[] = [];
		for (const hook of hooks) {
			const normalized = normalizePath(hook.path);
			if (
				normalizedRoot &&
				normalized.startsWith(`${normalizedRoot}/`) &&
				normalized.includes("/.clinerules/hooks")
			) {
				project.push(hook);
			} else {
				global.push(hook);
			}
		}
		return { projectHooks: project, globalHooks: global };
	}, [hooks, workspaceRoot]);

	const { projectPlugins, globalPlugins } = useMemo(() => {
		const normalizedRoot = normalizePath(workspaceRoot);
		const project: PluginItem[] = [];
		const global: PluginItem[] = [];
		for (const plugin of plugins) {
			const normalized = normalizePath(plugin.path);
			if (
				normalizedRoot &&
				normalized.startsWith(`${normalizedRoot}/`) &&
				normalized.includes("/.cline/plugins")
			) {
				project.push(plugin);
			} else {
				global.push(plugin);
			}
		}
		return { projectPlugins: project, globalPlugins: global };
	}, [plugins, workspaceRoot]);

	const builtinTools = useMemo(
		() => tools.filter((tool) => tool.source === "builtin"),
		[tools],
	);
	const pluginTools = useMemo(
		() => tools.filter((tool) => tool.source !== "builtin"),
		[tools],
	);
	const pluginToolsByPluginKey = useMemo(() => {
		const grouped = new Map<string, ToolItem[]>();
		for (const tool of pluginTools) {
			const key = tool.path ?? "";
			const existing = grouped.get(key) ?? [];
			existing.push(tool);
			grouped.set(key, existing);
		}
		for (const items of grouped.values()) {
			items.sort((left, right) => left.name.localeCompare(right.name));
		}
		return grouped;
	}, [pluginTools]);

	const scopedPlugins = useMemo(
		() => [
			...globalPlugins.map((plugin) => ({
				plugin,
				scope: "Global" as ItemScope,
			})),
			...projectPlugins.map((plugin) => ({
				plugin,
				scope: "Project" as ItemScope,
			})),
		],
		[globalPlugins, projectPlugins],
	);

	const scopedRules = useMemo(
		() => [
			...globalRules.map((rule) => ({ rule, scope: "Global" as ItemScope })),
			...projectRules.map((rule) => ({ rule, scope: "Project" as ItemScope })),
		],
		[globalRules, projectRules],
	);

	const scopedHooks = useMemo(
		() => [
			...globalHooks.map((hook) => ({ hook, scope: "Global" as ItemScope })),
			...projectHooks.map((hook) => ({ hook, scope: "Project" as ItemScope })),
		],
		[globalHooks, projectHooks],
	);

	const renderLocalActionMessage = (key: string) => {
		const message = localActionMessages.get(key);
		if (!message) {
			return null;
		}
		return (
			<output
				className={cn(
					"text-xs",
					message.status === "failed"
						? "text-destructive"
						: "text-muted-foreground",
				)}
			>
				{message.message}
			</output>
		);
	};

	// Sized and styled to match the Install/Uninstall button on marketplace
	// entry cards so installed rows and browse rows read as one list.
	const renderLocalActionButton = (target: LocalUninstallTarget) => {
		const uninstalling = localUninstallingKeys.has(target.key);
		return (
			<Button
				disabled={uninstalling}
				onClick={() => {
					void uninstallLocalPrimitive(target);
				}}
				size="xs"
				type="button"
				variant="destructive"
			>
				{uninstalling ? <Spinner /> : <Trash2 className="size-4" />}
				{uninstalling ? "Uninstalling..." : "Uninstall"}
			</Button>
		);
	};

	const renderPluginMenu = (target: LocalUninstallTarget) => {
		const uninstalling = localUninstallingKeys.has(target.key);
		return (
			<DropdownMenu>
				<DropdownMenuTrigger asChild>
					<Button
						aria-label={`More actions for ${target.name ?? "plugin"}`}
						className="m-0 size-auto shrink-0 p-0 text-muted-foreground"
						onClick={(event) => event.stopPropagation()}
						size="icon"
						type="button"
						variant="ghost"
					>
						<MoreVertical className="size-4" />
					</Button>
				</DropdownMenuTrigger>
				<DropdownMenuContent align="end">
					<DropdownMenuItem
						onClick={() =>
							void navigator.clipboard.writeText(target.path ?? "")
						}
					>
						<Copy className="size-4" />
						Copy path
					</DropdownMenuItem>
					<DropdownMenuItem
						className="text-destructive focus:text-destructive"
						disabled={uninstalling}
						onClick={() => void uninstallLocalPrimitive(target)}
					>
						{uninstalling ? <Spinner /> : <Trash2 className="size-4" />}
						{uninstalling ? "Uninstalling..." : "Uninstall"}
					</DropdownMenuItem>
				</DropdownMenuContent>
			</DropdownMenu>
		);
	};

	const renderSkillCard = (
		item: CommandItem,
		context?: MarketplaceLocalInstalledItemRenderContext,
	) => {
		const key = `${item.type}:${item.path}`;
		return (
			<div
				key={key}
				className="relative grid min-w-0 gap-2 rounded-lg border bg-card p-4"
			>
				<div className="absolute top-4 right-4">
					{renderLocalActionButton({
						key,
						type: item.type,
						id: item.id,
						name: item.name,
						path: item.path,
					})}
				</div>
				<div className="flex min-w-0 items-center gap-2 pr-28">
					{item.type === "workflow" ? (
						<Play className="h-4 w-4 shrink-0 text-primary" />
					) : (
						<Zap className="h-4 w-4 shrink-0 text-primary" />
					)}
					<h3 className="min-w-0 truncate text-sm font-semibold text-foreground">
						{item.name}
					</h3>
					<ScopeBadge scope={item.scope} />
					<Badge variant="outline" className="shrink-0 text-muted-foreground">
						{item.type}
					</Badge>
					{context?.matchedEntries?.length ? (
						<Badge variant="outline" className="shrink-0 text-muted-foreground">
							Marketplace
						</Badge>
					) : null}
				</div>
				<p className="line-clamp-2 text-xs leading-5 text-muted-foreground">
					{item.description?.trim() || previewText(item.instructions)}
				</p>
				<p className="truncate text-xs font-mono text-muted-foreground">
					{item.path}
				</p>
				{context?.matchedEntries?.length ? (
					<MarketplaceEntrySetupDetails entries={context.matchedEntries} />
				) : null}
				{renderLocalActionMessage(key)}
			</div>
		);
	};

	const renderPluginCard = (
		{
			plugin,
			scope,
		}: {
			plugin: PluginItem;
			scope: ItemScope;
		},
		context?: MarketplaceLocalInstalledItemRenderContext,
	) => {
		const key = plugin.path;
		const contributionGroups = [
			{
				label: "Tools",
				items:
					plugin.contributions?.tools ??
					(pluginToolsByPluginKey.get(plugin.path) ?? []).map(
						(tool) => tool.name,
					),
			},
			{ label: "Skills", items: plugin.contributions?.skills ?? [] },
			{ label: "Rules", items: plugin.contributions?.rules ?? [] },
			{ label: "Hooks", items: plugin.contributions?.hooks ?? [] },
			{ label: "Commands", items: plugin.contributions?.commands ?? [] },
			{ label: "MCP servers", items: plugin.contributions?.mcpServers ?? [] },
			{ label: "Providers", items: plugin.contributions?.providers ?? [] },
			{
				label: "Capabilities",
				items: plugin.contributions?.capabilities ?? [],
			},
		].filter((group) => group.items.length > 0);
		return (
			<details key={plugin.path} className="rounded-lg border bg-card p-4">
				<summary className="flex cursor-pointer list-none items-center gap-2">
					<Puzzle className="h-4 w-4 shrink-0 text-primary" />
					<h3 className="min-w-0 flex-1 truncate text-sm font-semibold text-foreground">
						{plugin.name}
					</h3>
					<ScopeBadge scope={scope} />
					{context?.matchedEntries?.length ? (
						<Badge variant="outline" className="shrink-0 text-muted-foreground">
							Marketplace
						</Badge>
					) : null}
					<span className="text-xs text-muted-foreground">
						{plugin.enabled ? "Enabled" : "Disabled"}
					</span>
					<Switch
						checked={plugin.enabled}
						onCheckedChange={() => {
							void setPluginEnabled(plugin);
						}}
						onClick={(event) => event.stopPropagation()}
						disabled={togglingPluginPaths.has(plugin.path)}
						aria-label={`Toggle ${plugin.name}`}
					/>
					{renderPluginMenu({
						key,
						type: "plugin",
						id: plugin.name,
						name: plugin.name,
						path: plugin.path,
					})}
				</summary>
				<div className="mt-3">
					{plugin.contributions?.inspectionStatus === "disabled" ? (
						<p className="mb-2 text-xs text-muted-foreground">
							Enable this plugin to inspect its dynamic contributions.
						</p>
					) : null}
					{contributionGroups.length > 0 ? (
						<div>
							<div className="flex flex-wrap items-center gap-2 py-2 text-xs font-medium text-foreground">
								<span className="mr-1">Contributions</span>
								{contributionGroups.map((group) => (
									<Badge key={group.label} variant="outline">
										{group.label} {group.items.length}
									</Badge>
								))}
							</div>
							<div className="grid max-h-56 gap-3 overflow-y-auto pt-2 sm:grid-cols-2">
								{contributionGroups.map((group) => (
									<div key={group.label} className="min-w-0">
										<p className="mb-1 text-xs font-medium text-muted-foreground">
											{group.label}
										</p>
										<div className="flex flex-wrap gap-1">
											{group.items.map((item) => (
												<Badge key={item} variant="secondary">
													{item}
												</Badge>
											))}
										</div>
									</div>
								))}
							</div>
						</div>
					) : (
						<p className="text-xs text-muted-foreground">
							No plugin contributions found.
						</p>
					)}
				</div>
				{context?.matchedEntries?.length ? (
					<div className="mt-2">
						<MarketplaceEntrySetupDetails entries={context.matchedEntries} />
					</div>
				) : null}
				{renderLocalActionMessage(key) ? (
					<div className="mt-3">{renderLocalActionMessage(key)}</div>
				) : null}
			</details>
		);
	};

	const renderMcpServerCard = (
		server: McpServer,
		context?: MarketplaceLocalInstalledItemRenderContext,
	) => {
		const key = server.name;
		return (
			<div
				key={server.name}
				className="relative grid min-w-0 gap-2 rounded-lg border bg-card p-4"
			>
				<div className="absolute top-4 right-4">
					{renderLocalActionButton({
						key,
						type: "mcp",
						id: server.name,
						name: server.name,
					})}
				</div>
				<div className="flex min-w-0 items-center gap-2 pr-28">
					<Server className="h-4 w-4 shrink-0 text-primary" />
					<h3 className="min-w-0 truncate text-sm font-semibold text-foreground">
						{server.name}
					</h3>
					<ScopeBadge scope="Global" />
					<Badge variant="outline" className="shrink-0 text-muted-foreground">
						{server.transportType}
					</Badge>
					{context?.matchedEntries?.length ? (
						<Badge variant="outline" className="shrink-0 text-muted-foreground">
							Marketplace
						</Badge>
					) : null}
					{server.disabled ? (
						<Badge variant="outline" className="shrink-0 text-muted-foreground">
							Disabled
						</Badge>
					) : null}
				</div>
				<p className="line-clamp-2 text-xs leading-5 text-muted-foreground">
					{server.url ??
						([server.command, ...(server.args ?? [])]
							.filter(Boolean)
							.join(" ") ||
							"No launch command configured.")}
				</p>
				{mcp.settingsPath ? (
					<p className="truncate text-xs font-mono text-muted-foreground">
						{mcp.settingsPath}
					</p>
				) : null}
				{context?.matchedEntries?.length ? (
					<MarketplaceEntrySetupDetails entries={context.matchedEntries} />
				) : null}
				{renderLocalActionMessage(key)}
			</div>
		);
	};

	const installedCatalogLocalItems =
		catalogPrimitive === "skill"
			? commandItems.map(
					(item): MarketplaceLocalInstalledItem => ({
						key: `${item.type}:${item.path}`,
						matchValues: getLocalMarketplaceMatchValues(
							item.id,
							item.name,
							item.path,
						),
						render: (context) => renderSkillCard(item, context),
					}),
				)
			: catalogPrimitive === "plugin"
				? scopedPlugins.map(
						(item): MarketplaceLocalInstalledItem => ({
							key: item.plugin.path,
							matchValues: getLocalMarketplaceMatchValues(
								item.plugin.name,
								item.plugin.path,
							),
							render: (context) => renderPluginCard(item, context),
						}),
					)
				: catalogPrimitive === "mcp"
					? mcp.servers.map(
							(server): MarketplaceLocalInstalledItem => ({
								key: server.name,
								matchValues: getLocalMarketplaceMatchValues(server.name),
								render: (context) => renderMcpServerCard(server, context),
							}),
						)
					: null;
	const refreshButton = (
		<Button
			variant="outline"
			size="sm"
			onClick={() => {
				void refresh(true);
				if (activeTab === "Hooks") {
					void loadHookExecutionStats(true);
				}
			}}
			disabled={isLoading}
		>
			<RefreshCw className={cn("h-4 w-4", isLoading && "animate-spin")} />
		</Button>
	);

	const content = (
		<>
			{chrome === "page" ? (
				<PageHeader
					description={sectionDescriptions[activeTab]}
					title={activeTab}
					meta={<CommandBadge>{sectionCommands[activeTab]}</CommandBadge>}
					actions={refreshButton}
				/>
			) : (
				<div className="mb-4 flex items-center justify-between gap-3">
					<p className="text-sm text-muted-foreground">
						{sectionDescriptions[activeTab]}
					</p>
					{refreshButton}
				</div>
			)}

			{showTabs ? (
				<div className="mb-6 flex items-center gap-0 border-b border-border">
					{tabs.map((tab) => (
						<Button
							key={tab}
							variant="ghost"
							onClick={() => setActiveTab(tab)}
							className={cn(
								"relative px-4 py-2.5 text-sm font-medium transition-colors",
								activeTab === tab
									? "text-foreground"
									: "text-muted-foreground hover:text-foreground",
							)}
						>
							{tab}
							{activeTab === tab && (
								<span className="absolute inset-x-0 -bottom-px h-0.5 bg-foreground" />
							)}
						</Button>
					))}
				</div>
			) : null}

			{errorMessage && (
				<div className="mb-4 rounded-lg border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive">
					Failed to load configuration lists: {errorMessage}
				</div>
			)}

			{warnings.length > 0 && (
				<div className="mb-4 rounded-lg border border-yellow-500/40 bg-yellow-500/10 px-4 py-3 text-sm text-yellow-700 dark:text-yellow-300">
					<div className="mb-2 flex items-center gap-2 font-medium">
						<TriangleAlert className="h-4 w-4" />
						Partial results
					</div>
					<ul className="list-disc space-y-1 pl-5">
						{warnings.map((warning) => (
							<li key={warning}>{warning}</li>
						))}
					</ul>
				</div>
			)}

			{catalogPrimitive ? (
				<MarketplaceView
					chrome="embedded"
					installedItems={installedCatalogLocalItems ?? undefined}
					onInstalledItemsChanged={() => refresh(true)}
					primitive={catalogPrimitive}
					variant={marketplaceVariant}
				/>
			) : null}

			{activeTab === "Rules" && (
				<div>
					<div className="grid gap-3">
						<div className="flex items-center justify-between gap-3">
							<h3 className="text-base font-semibold text-foreground">
								Installed
							</h3>
							<span className="text-sm text-muted-foreground">
								{scopedRules.length}
							</span>
						</div>
						<div className="flex flex-col gap-2">
							{scopedRules.map(({ rule, scope }) => (
								<div
									key={rule.path}
									className="grid min-w-0 gap-2 rounded-lg border bg-card p-4"
								>
									<div className="flex min-w-0 items-center gap-2">
										<FileText className="h-4 w-4 shrink-0 text-primary" />
										<span className="min-w-0 truncate text-sm font-semibold text-foreground">
											{rule.name}
										</span>
										<ScopeBadge scope={scope} />
									</div>
									<p className="line-clamp-2 text-xs leading-5 text-muted-foreground">
										{previewText(rule.instructions)}
									</p>
									<p className="truncate text-xs font-mono text-muted-foreground">
										{rule.path}
									</p>
								</div>
							))}
							{scopedRules.length === 0 && (
								<p className="rounded-lg border border-dashed border-border px-4 py-3 text-sm text-muted-foreground">
									No rules found.
								</p>
							)}
						</div>
					</div>
				</div>
			)}

			{activeTab === "Hooks" && (
				<div>
					{hookExecutionLoading && hookExecutionSessionId && (
						<p className="mb-4 text-xs text-muted-foreground">
							Execution status is based on hook events in session{" "}
							<span className="font-mono">{hookExecutionSessionId}</span>.
						</p>
					)}

					<div className="grid gap-3">
						<div className="flex items-center justify-between gap-3">
							<h3 className="text-base font-semibold text-foreground">
								Installed
							</h3>
							<span className="text-sm text-muted-foreground">
								{scopedHooks.length}
							</span>
						</div>
						<div className="flex flex-col gap-2">
							{scopedHooks.map(({ hook, scope }) => (
								<div
									key={hook.path}
									className="grid min-w-0 gap-2 rounded-lg border bg-card p-4"
								>
									<div className="flex min-w-0 items-center gap-2">
										<Code className="h-4 w-4 shrink-0 text-primary" />
										<span className="min-w-0 truncate text-sm font-semibold text-foreground">
											{hook.fileName}
										</span>
										<ScopeBadge scope={scope} />
										{hook.hookEventName && (
											<>
												<Badge
													variant="outline"
													className="shrink-0 text-muted-foreground"
												>
													{hook.hookEventName}
												</Badge>
												{(() => {
													const stats =
														hookExecutionByEvent[hook.hookEventName];
													const executed = (stats?.count ?? 0) > 0;
													return (
														<Badge
															variant="outline"
															className={cn(
																"shrink-0",
																executed
																	? "border-emerald-400/50 text-emerald-600 dark:text-emerald-400"
																	: "text-muted-foreground",
															)}
														>
															{executed
																? `${stats?.count ?? 0} executed`
																: "never executed"}
														</Badge>
													);
												})()}
											</>
										)}
									</div>
									{hook.hookEventName ? (
										<p className="text-xs leading-5 text-muted-foreground">
											Last run:{" "}
											{formatExecutionTs(
												hookExecutionByEvent[hook.hookEventName]?.lastTs ??
													null,
											)}
										</p>
									) : null}
									<p className="truncate text-xs font-mono text-muted-foreground">
										{hook.path}
									</p>
								</div>
							))}
							{scopedHooks.length === 0 && (
								<p className="rounded-lg border border-dashed border-border px-4 py-3 text-sm text-muted-foreground">
									No hooks found.
								</p>
							)}
						</div>
					</div>
				</div>
			)}

			{activeTab === "Skills" && !catalogPrimitive && (
				<div>
					<p className="mb-6 text-sm leading-relaxed text-muted-foreground">
						Skills can be invoked in chat with{" "}
						<code className="rounded bg-secondary px-1.5 py-0.5 text-xs font-mono text-foreground">
							/SKILL
						</code>
						.
					</p>

					<div className="flex flex-col gap-3">
						{commandItems.map((item) => (
							<div
								key={`${item.type}:${item.path}`}
								className="rounded-lg border border-border px-5 py-4"
							>
								<div className="flex items-center gap-3">
									{item.type === "workflow" ? (
										<Play className="h-4 w-4 shrink-0 text-primary" />
									) : (
										<Zap className="h-4 w-4 shrink-0 text-primary" />
									)}
									<h3 className="text-sm font-semibold text-foreground">
										{item.name}
									</h3>
									<span className="rounded border border-border px-2 py-0.5 text-xs text-muted-foreground">
										{item.type}
									</span>
								</div>
								<p className="mt-2 ml-7 text-xs text-muted-foreground">
									{item.description?.trim() || previewText(item.instructions)}
								</p>
								<p className="mt-1 ml-7 text-xs font-mono text-muted-foreground">
									{item.path}
								</p>
							</div>
						))}
						{commandItems.length === 0 && (
							<p className="rounded-lg border border-dashed border-border px-4 py-3 text-sm text-muted-foreground">
								No enabled skills or workflows found.
							</p>
						)}
					</div>
				</div>
			)}

			{activeTab === "Agents" && (
				<div>
					<p className="mb-6 text-sm leading-relaxed text-muted-foreground">
						Configured agents discovered from Documents and settings
						directories.
					</p>

					<div className="flex flex-col gap-3">
						{agents.map((agent) => (
							<div
								key={agent.path}
								className="rounded-lg border border-border px-5 py-4"
							>
								<div className="flex items-center gap-3">
									<Bot className="h-4 w-4 shrink-0 text-primary" />
									<h3 className="text-sm font-semibold text-foreground">
										{agent.name}
									</h3>
								</div>
								<p className="mt-1 ml-7 text-xs font-mono text-muted-foreground">
									{agent.path}
								</p>
							</div>
						))}
						{agents.length === 0 && (
							<p className="rounded-lg border border-dashed border-border px-4 py-3 text-sm text-muted-foreground">
								No configured agents found.
							</p>
						)}
					</div>
				</div>
			)}

			{activeTab === "Plugins" && !catalogPrimitive && (
				<div>
					<p className="mb-6 text-sm leading-relaxed text-muted-foreground">
						Plugins discovered from workspace and global plugin directories.
					</p>

					<div className="mb-6">
						<h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
							Global Plugins
						</h3>
						<div className="flex flex-col gap-3">
							{globalPlugins.map((plugin) => (
								<div
									key={plugin.path}
									className="rounded-lg border border-border px-5 py-4"
								>
									<div className="flex items-center gap-3">
										<h3 className="min-w-0 flex-1 text-sm font-semibold text-foreground">
											{plugin.name}
										</h3>
										<span className="text-xs text-muted-foreground">
											{plugin.enabled ? "Enabled" : "Disabled"}
										</span>
										<Switch
											checked={plugin.enabled}
											onCheckedChange={() => {
												void setPluginEnabled(plugin);
											}}
											disabled={togglingPluginPaths.has(plugin.path)}
											aria-label={`Toggle ${plugin.name}`}
										/>
									</div>
									<div className="mt-3 ml-7 flex max-h-56 flex-col gap-2 overflow-y-auto">
										{(pluginToolsByPluginKey.get(plugin.path) ?? []).map(
											(tool) => {
												return (
													<div
														key={tool.id}
														className="flex items-center justify-between gap-4 rounded-md border border-border/70 px-3 py-2"
													>
														<div className="min-w-0">
															<p className="text-xs font-medium text-foreground">
																{tool.name}
															</p>
															<p className="text-xs text-muted-foreground">
																{tool.description?.trim() ||
																	"No description available."}
															</p>
														</div>
													</div>
												);
											},
										)}
										{(pluginToolsByPluginKey.get(plugin.path)?.length ?? 0) ===
											0 && (
											<p className="text-xs text-muted-foreground">
												No plugin tools found.
											</p>
										)}
									</div>
								</div>
							))}
							{globalPlugins.length === 0 && (
								<p className="rounded-lg border border-dashed border-border px-4 py-3 text-sm text-muted-foreground">
									No global plugins found.
								</p>
							)}
						</div>
					</div>

					<div>
						<h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
							Project Plugins
						</h3>
						<div className="flex flex-col gap-3">
							{projectPlugins.map((plugin) => (
								<div
									key={plugin.path}
									className="rounded-lg border border-border px-5 py-4"
								>
									<div className="flex items-center gap-3">
										<h3 className="min-w-0 flex-1 text-sm font-semibold text-foreground">
											{plugin.name}
										</h3>
										<span className="text-xs text-muted-foreground">
											{plugin.enabled ? "Enabled" : "Disabled"}
										</span>
										<Switch
											checked={plugin.enabled}
											onCheckedChange={() => {
												void setPluginEnabled(plugin);
											}}
											disabled={togglingPluginPaths.has(plugin.path)}
											aria-label={`Toggle ${plugin.name}`}
										/>
									</div>
									<div className="mt-3 ml-7 flex max-h-56 flex-col gap-2 overflow-y-auto">
										{(pluginToolsByPluginKey.get(plugin.path) ?? []).map(
											(tool) => {
												return (
													<div
														key={tool.id}
														className="flex items-center justify-between gap-4 rounded-md border border-border/70 px-3 py-2"
													>
														<div className="min-w-0">
															<p className="text-xs font-medium text-foreground">
																{tool.name}
															</p>
															<p className="text-xs text-muted-foreground">
																{tool.description?.trim() ||
																	"No description available."}
															</p>
														</div>
													</div>
												);
											},
										)}
										{(pluginToolsByPluginKey.get(plugin.path)?.length ?? 0) ===
											0 && (
											<p className="text-xs text-muted-foreground">
												No plugin tools found.
											</p>
										)}
									</div>
								</div>
							))}
							{projectPlugins.length === 0 && (
								<p className="rounded-lg border border-dashed border-border px-4 py-3 text-sm text-muted-foreground">
									No project plugins found.
								</p>
							)}
						</div>
					</div>
				</div>
			)}

			{activeTab === "Tools" && (
				<div>
					<div className="mb-6 grid gap-3">
						<div className="flex items-center justify-between gap-3">
							<h3 className="text-base font-semibold text-foreground">
								Builtin Tools
							</h3>
							<span className="text-sm text-muted-foreground">
								{builtinTools.length}
							</span>
						</div>
						<div className="flex flex-col gap-2">
							{builtinTools.map((tool) =>
								(() => {
									const isToggling = togglingToolIds.has(tool.id);
									return (
										<div
											key={tool.id}
											className="grid min-w-0 gap-2 rounded-lg border bg-card p-4"
										>
											<div className="flex min-w-0 items-center gap-2">
												<Wrench className="h-4 w-4 shrink-0 text-primary" />
												<h3 className="min-w-0 flex-1 truncate text-sm font-semibold text-foreground">
													{tool.name}
												</h3>
												<span className="text-xs text-muted-foreground">
													{tool.enabled ? "Enabled" : "Disabled"}
												</span>
												<Switch
													checked={tool.enabled}
													onCheckedChange={() => {
														void setToolEnabled(tool);
													}}
													disabled={isToggling}
													aria-label={`Toggle ${tool.name}`}
												/>
											</div>
											<p className="line-clamp-2 text-xs leading-5 text-muted-foreground">
												{tool.description?.trim() ||
													"No description available."}
											</p>
											{!!tool.headlessToolNames?.length && (
												<p className="truncate text-xs font-mono text-muted-foreground">
													{tool.headlessToolNames.join(", ")}
												</p>
											)}
										</div>
									);
								})(),
							)}
							{builtinTools.length === 0 && (
								<p className="rounded-lg border border-dashed border-border px-4 py-3 text-sm text-muted-foreground">
									No builtin tools found.
								</p>
							)}
						</div>
					</div>

					<div className="grid gap-3">
						<div className="flex items-center justify-between gap-3">
							<h3 className="text-base font-semibold text-foreground">
								Plugin Tools
							</h3>
							<span className="text-sm text-muted-foreground">
								{pluginTools.length}
							</span>
						</div>
						<div className="flex flex-col gap-2">
							{pluginTools.map((tool) =>
								(() => {
									const isToggling = togglingToolIds.has(tool.id);
									return (
										<div
											key={tool.id}
											className="grid min-w-0 gap-2 rounded-lg border bg-card p-4"
										>
											<div className="flex min-w-0 items-center gap-2">
												<Wrench className="h-4 w-4 shrink-0 text-primary" />
												<h3 className="min-w-0 flex-1 truncate text-sm font-semibold text-foreground">
													{tool.name}
												</h3>
												{tool.pluginName && (
													<Badge
														variant="outline"
														className="shrink-0 text-muted-foreground"
													>
														{tool.pluginName}
													</Badge>
												)}
												<span className="text-xs text-muted-foreground">
													{tool.enabled ? "Enabled" : "Disabled"}
												</span>
												<Switch
													checked={tool.enabled}
													onCheckedChange={() => {
														void setToolEnabled(tool);
													}}
													disabled={isToggling}
													aria-label={`Toggle ${tool.name}`}
												/>
											</div>
											<p className="line-clamp-2 text-xs leading-5 text-muted-foreground">
												{tool.description?.trim() ||
													"No description available."}
											</p>
											{tool.path && (
												<p className="truncate text-xs font-mono text-muted-foreground">
													{tool.path}
												</p>
											)}
										</div>
									);
								})(),
							)}
							{pluginTools.length === 0 && (
								<p className="rounded-lg border border-dashed border-border px-4 py-3 text-sm text-muted-foreground">
									No plugin tools found.
								</p>
							)}
						</div>
					</div>
				</div>
			)}
		</>
	);

	return chrome === "embedded" ? (
		<div>{content}</div>
	) : (
		<PageFrame>{content}</PageFrame>
	);
}

export function RulesView() {
	return <CustomizationSectionView showTabs />;
}
