export * from './normalizeSlate';
