<template>
	<span class="flex w-[88px] min-w-16 items-center truncate text-xs leading-5 text-ink-gray-6">
		<span class="truncate"><slot /></span>
		<Popover trigger="hover" v-if="description" placement="top">
			<template #target>
				<span class="lucide-info ml-1 h-[12px] w-[12px] text-gray-500" aria-hidden="true" />
			</template>
			<template #body>
				<slot name="body">
					<div
						class="my-4 w-fit max-w-52 rounded bg-gray-800 p-2 text-center text-p-xs text-white shadow-xl"
						v-html="description"></div>
				</slot>
			</template>
		</Popover>
	</span>
</template>
<script lang="ts" setup>
import { Popover } from "frappe-ui";
const props = withDefaults(
	defineProps<{
		description?: string;
	}>(),
	{
		description: "",
	},
);
</script>
