<template>
	<Dialog class="overscroll-none" v-model="showModel" :title="__('Used in following pages')" size="xl">
		<template #default>
			<div class="max-h-[80vh] overflow-y-auto">
				<div v-for="page in pages">
					<router-link
						target="_blank"
						:to="{
							name: 'builder',
							params: {
								pageId: page.name,
							},
						}">
						<div class="flex items-start space-x-4 rounded p-2 hover:bg-surface-gray-2">
							<img
								:src="page.preview"
								:alt="page.page_title"
								class="h-16 w-26 rounded-lg border border-outline-gray-1" />
							<div>
								<div class="font-bold text-ink-gray-8">{{ page.page_title }}</div>
								<div class="text-sm text-gray-500">{{ page.route }}</div>
							</div>
						</div>
					</router-link>
				</div>
			</div>
		</template>
	</Dialog>
</template>
<script setup lang="ts">
import Dialog from "@/components/Controls/Dialog.vue";
import { BuilderPage } from "@/types/doctypes";
import { ref } from "vue";
const showModel = ref(true);
defineProps<{
	pages: BuilderPage[];
}>();
</script>
