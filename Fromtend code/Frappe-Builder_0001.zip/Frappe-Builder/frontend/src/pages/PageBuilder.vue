<template>
	<div v-show="isSmallScreen" class="grid h-screen w-screen place-content-center gap-4 text-ink-gray-9">
		<img src="/builder_logo.png" alt="logo" class="h-10" />
		<div class="flex flex-col">
			<h1 class="text-p-3xl-semibold">{{ __("Screen too small") }}</h1>
			<p class="text-p-base">{{ __("Please switch to a larger screen to edit") }}</p>
		</div>
	</div>
	<div v-show="!isSmallScreen" class="page-builder relative h-screen overflow-hidden bg-surface-gray-1">
		<!-- Canvas layer (bottom) - comes first in DOM -->
		<BuilderCanvas
			ref="fragmentCanvas"
			:key="canvasStore.fragmentData.block?.blockId"
			v-if="canvasStore.editingMode === 'fragment' && canvasStore.fragmentData.block"
			:block-data="canvasStore.fragmentData.block"
			:canvas-styles="{
				width: (canvasStore.fragmentData.block.getStyle('width') + '').endsWith('px') ? '!fit-content' : null,
				padding: '40px',
			}"
			:style="{
				top: 'var(--toolbar-height)',
				left: `${
					builderStore.showLeftPanel
						? builderStore.builderLayout.leftPanelWidth + builderStore.builderLayout.optionsPanelWidth
						: 0
				}px`,
				right: `${builderStore.showRightPanel ? builderStore.builderLayout.rightPanelWidth : 0}px`,
			}"
			class="canvas-container absolute bottom-0 flex justify-center overflow-hidden bg-surface-gray-2 p-10">
			<template v-slot:header>
				<div class="flex items-center justify-between bg-surface-base p-2 text-sm text-ink-gray-8 shadow-sm">
					<div class="flex items-center gap-1 pl-2 text-xs">
						<a @click="canvasStore.exitFragmentMode" class="cursor-pointer">{{ __("Page") }}</a>
						<span class="lucide-chevron-right h-3 w-3" aria-hidden="true" />
						<span class="flex items-center gap-2">
							{{ canvasStore.fragmentData.fragmentName }}
							<a
								@click="pageListDialog = true"
								class="cursor-pointer text-ink-gray-4 underline"
								v-if="canvasStore.fragmentData.showUsageCount">
								{{ usageMessage }}
							</a>
						</span>
					</div>
					<Button variant="solid" class="text-xs" @click="saveAndExitFragmentMode">
						{{ canvasStore.fragmentData.saveActionLabel || __("Save") }}
					</Button>
				</div>
			</template>
		</BuilderCanvas>
		<BuilderCanvas
			v-show="canvasStore.editingMode === 'page'"
			ref="pageCanvas"
			v-if="pageStore.pageBlocks[0]"
			:block-data="pageStore.pageBlocks[0]"
			:canvas-styles="{
				minHeight: '1000px',
			}"
			:style="{
				top: 'var(--toolbar-height)',
				left: `${
					builderStore.showLeftPanel
						? builderStore.builderLayout.leftPanelWidth + builderStore.builderLayout.optionsPanelWidth
						: 0
				}px`,
				right: `${builderStore.showRightPanel ? builderStore.builderLayout.rightPanelWidth : 0}px`,
			}"
			class="canvas-container absolute bottom-0 flex justify-center overflow-hidden bg-surface-gray-1 p-10"></BuilderCanvas>

		<!-- Panels layer (middle) - comes after canvas in DOM -->
		<BuilderLeftPanel
			v-show="builderStore.showLeftPanel"
			class="absolute bottom-0 left-0 top-[var(--toolbar-height)] w-fit border-r-[1px] border-outline-gray-2 bg-surface-base dark:border-outline-gray-1"></BuilderLeftPanel>
		<BuilderRightPanel
			v-show="builderStore.showRightPanel"
			class="no-scrollbar absolute bottom-0 right-0 top-[var(--toolbar-height)] overflow-auto border-l-[1px] border-outline-gray-2 bg-surface-base dark:border-outline-gray-1"></BuilderRightPanel>

		<!-- Toolbar layer (top) - comes last in DOM -->
		<BuilderToolbar class="absolute left-0 right-0 top-0"></BuilderToolbar>
	</div>
	<PageListModal v-model="pageListDialog" :pages="componentUsedInPages"></PageListModal>
	<Dialog
		v-model="canvasStore.showEditorDialog"
		class="overscroll-none"
		:isDirty="expandedEditor?.isDirty"
		title="HTML"
		size="7xl">
		<template #default>
			<CodeEditor
				:modelValue="getExpandedEditorContent()"
				ref="expandedEditor"
				:type="expandedEditorOptions.type"
				height="68vh"
				:label="expandedEditorOptions.label"
				:showLineNumbers="true"
				:showSaveButton="true"
				@save="saveExpandedEditorContent"
				required />
		</template>
	</Dialog>
	<BlockContextMenu ref="blockContextMenu"></BlockContextMenu>
	<BuilderCommandPalette ref="commandPalette" />
	<KeyboardShortcutsModal v-model:open="builderStore.shortcutsModalOpen" />
	<TemplatesDialog />
</template>

<script setup lang="ts">
import { __ } from "@/translation";
import BlockContextMenu from "@/components/BlockContextMenu.vue";
import BuilderCanvas from "@/components/BuilderCanvas.vue";
import BuilderCommandPalette from "@/components/BuilderCommandPalette.vue";
import BuilderLeftPanel from "@/components/BuilderLeftPanel.vue";
import BuilderRightPanel from "@/components/BuilderRightPanel.vue";
import BuilderToolbar from "@/components/BuilderToolbar.vue";
import Dialog from "@/components/Controls/Dialog.vue";
import PageListModal from "@/components/Modals/PageListModal.vue";
import TemplatesDialog from "@/components/Templates/TemplatesDialog.vue";
import { webPages } from "@/data/webPage";
import { sessionUser } from "@/router";
import useBuilderStore from "@/stores/builderStore";
import useCanvasStore from "@/stores/canvasStore";
import usePageStore from "@/stores/pageStore";
import { BuilderPage } from "@/types/doctypes";
import { getUsersInfo } from "@/usersInfo";
import blockController from "@/utils/blockController";
import { offerPendingAssetImport } from "@/utils/builderBlockCopyPaste";
import componentController from "@/utils/componentController.js";
import { getPageUsageMessage, getRootBlockTemplate } from "@/utils/helpers";
import { useBuilderEvents } from "@/utils/useBuilderEvents";
import { breakpointsTailwind, useBreakpoints, useDebounceFn, useEventListener } from "@vueuse/core";
import { createResource, KeyboardShortcutsModal, useShortcut } from "frappe-ui";
import { computed, onActivated, onDeactivated, onMounted, provide, ref, watch, watchEffect } from "vue";
import { useRoute, useRouter } from "vue-router";
import CodeEditor from "../components/Controls/CodeEditor.vue";
import { prefetchBuilderSettings } from "@/utils/prefetch";

const expandedEditor = ref<null | InstanceType<typeof CodeEditor>>(null);

const breakpoints = useBreakpoints(breakpointsTailwind);
const isSmallScreen = breakpoints.smaller("lg");

const route = useRoute();
const router = useRouter();
const builderStore = useBuilderStore();
const pageStore = usePageStore();
const canvasStore = useCanvasStore();
const usageCount = ref(0);
const componentUsedInPages = ref<BuilderPage[]>([]);
const pageListDialog = ref(false);
const blockContextMenu = ref<InstanceType<typeof BlockContextMenu> | null>(null);

watch(
	[
		() => canvasStore.editableBlock,
		() => pageStore.activePage?.is_standard,
		() => pageStore.activePage?.is_template,
		() => canvasStore.versionPreviewBlock,
		() => builderStore.isSiteInReadOnlyMode,
	],
	() => {
		const previewing = Boolean(canvasStore.versionPreviewBlock);
		const isProtected =
			(Boolean(pageStore.activePage?.is_standard) ||
				Boolean(pageStore.activePage?.is_template && pageStore.activePage?.template_group)) &&
			!window.is_developer_mode;
		builderStore.toggleReadOnlyMode(
			builderStore.isSiteInReadOnlyMode ||
				(canvasStore.editingMode === "page" && (previewing || isProtected)),
		);
	},
	{ immediate: true },
);

declare global {
	interface Window {
		blockController: typeof blockController;
	}
}

window.blockController = blockController;

const pageCanvas = ref<InstanceType<typeof BuilderCanvas> | null>(null);
const fragmentCanvas = ref<InstanceType<typeof BuilderCanvas> | null>(null);

provide("pageCanvas", pageCanvas);
provide("fragmentCanvas", fragmentCanvas);
useBuilderEvents(pageCanvas, fragmentCanvas, saveAndExitFragmentMode, route, router);

useShortcut([
	{
		key: " ",
		description: __("Hold for move mode"),
		group: __("Tools"),
		handler: () => {
			if (!canvasStore.editableBlock) {
				builderStore.mode = "move";
			}
		},
		preventDefault: true,
	},
]);

// When space is released, revert back to last mode
useEventListener(document, "keyup", (e) => {
	if (e.key === " " && builderStore.mode === "move") {
		builderStore.mode = builderStore.lastMode !== "move" ? builderStore.lastMode : "select";
	}
});

async function saveAndExitFragmentMode(e: Event) {
	if (canvasStore.fragmentData.fragmentType === "component") {
		componentController.applyComponentDoc();
	}
	await canvasStore.fragmentData.saveAction?.(fragmentCanvas.value?.getRootBlock());
	fragmentCanvas.value?.toggleDirty(false);
	canvasStore.exitFragmentMode(e);
}

let expandedEditorOptions = computed(() => {
	let title, label;
	let type: "HTML" | "JavaScript" | "CSS" = "HTML";
	if (canvasStore.editingContentType === "html") {
		title = __("HTML");
		label = __("Edit HTML");
	} else if (canvasStore.editingContentType === "js") {
		title = __("Block Client Script");
		label = __("Edit Block Client Script");
		type = "JavaScript";
	} else if (canvasStore.editingContentType === "css") {
		title = __("CSS");
		label = __("Edit CSS");
		type = "CSS";
	}
	return { title, label, type };
});

function getExpandedEditorContent() {
	if (canvasStore.editingContentType === "html") {
		return canvasStore.editableBlock?.getInnerHTML();
	}
}

async function saveExpandedEditorContent(val: string) {
	if (canvasStore.editingContentType === "html") {
		canvasStore.editableBlock?.setInnerHTML(val);
	}
	canvasStore.showEditorDialog = false;
}

onActivated(async () => {
	builderStore.realtime.on("doc_viewers", async (data: { users: [] }) => {
		builderStore.viewers = await getUsersInfo(
			data.users.filter((user: string) => user !== sessionUser.value),
		);
	});
	builderStore.realtime.doc_subscribe("Builder Page", route.params.pageId as string);
	builderStore.realtime.doc_open("Builder Page", route.params.pageId as string);
	if (route.params.pageId === pageStore.selectedPage) {
		return;
	}
	if (!webPages.data) {
		await webPages.fetchOne.submit(route.params.pageId as string);
	}
	if (route.params.pageId && route.params.pageId !== "new") {
		await pageStore.setPage(route.params.pageId as string, true, route.query);
		offerPendingAssetImport(route.params.pageId as string);
	}
});

// In-editor navigation to ANOTHER page (the build pill's "View"/"Go back" links):
// the component is reused, so onActivated never refires — swap the page here or
// the URL changes while the canvas keeps showing the previous page.
watch(
	() => route.params.pageId,
	(pageId, oldPageId) => {
		if (!pageId || pageId === "new" || pageId === pageStore.selectedPage) return;
		if (oldPageId && oldPageId !== "new") {
			builderStore.realtime.doc_close("Builder Page", oldPageId as string);
		}
		builderStore.realtime.doc_subscribe("Builder Page", pageId as string);
		builderStore.realtime.doc_open("Builder Page", pageId as string);
		pageStore.setPage(pageId as string, true, route.query);
	},
);

watch(
	route,
	(to, from) => {
		if (to.name === "builder" && to.params.pageId === "new") {
			const pageInfo = {
				page_title: "My Page",
				draft_blocks: [getRootBlockTemplate()],
			} as BuilderPage;
			if (builderStore.activeFolder) {
				pageInfo["project_folder"] = builderStore.activeFolder;
			}
			webPages.insert.submit(pageInfo).then((data: BuilderPage) => {
				router.push({ name: "builder", params: { pageId: data.name }, force: true });
				pageStore.setPage(data.name);
			});
		}
	},
	{ immediate: true },
);

onDeactivated(() => {
	builderStore.realtime.doc_close("Builder Page", pageStore.activePage?.name as string);
	builderStore.realtime.off("doc_viewers", () => {});
	builderStore.viewers = [];
});

onMounted(() => {
	builderStore.blockContextMenu = blockContextMenu.value;
	prefetchBuilderSettings();
});

watchEffect(() => {
	if (fragmentCanvas.value) {
		canvasStore.activeCanvas = fragmentCanvas.value;
	} else {
		canvasStore.activeCanvas = pageCanvas.value;
	}
});

const debouncedPageSave = useDebounceFn(pageStore.savePage, 300);

const usageMessage = computed(() => getPageUsageMessage(usageCount.value));

watch(
	() => pageCanvas.value?.block,
	() => {
		if (
			pageStore.selectedPage &&
			!pageStore.settingPage &&
			canvasStore.editingMode === "page" &&
			!builderStore.readOnlyMode &&
			!builderStore.aiBuildingCanvas &&
			!pageCanvas.value?.canvasProps?.settingCanvas
		) {
			pageStore.savingPage = true;
			debouncedPageSave();
		}
	},
	{
		deep: true,
	},
);

watch(
	() => canvasStore.showEditorDialog,
	(value) => {
		if (!value) {
			canvasStore.editableBlock = null;
		}
	},
);

watch(
	() => fragmentCanvas.value,
	(value) => {
		if (value && canvasStore.fragmentData.fragmentId && canvasStore.fragmentData.showUsageCount) {
			const usageCountResource = createResource({
				method: "POST",
				url: "builder.builder.doctype.builder_settings.builder_settings.get_component_usage_count",
				params: {
					component_id: canvasStore.fragmentData.fragmentId,
				},
				auto: true,
			});
			usageCountResource.promise?.then((res: { count: number; pages: BuilderPage[] }) => {
				usageCount.value = res.count;
				componentUsedInPages.value = res.pages;
			});
		}
	},
);
</script>

<style>
.page-builder {
	--toolbar-height: 3rem;
}
</style>
