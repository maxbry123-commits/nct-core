import CanvasModule from '../../canvas';
import { Model, ObjectAny } from '../../common';
import Editor from '../../editor';
import EditorModel from '../../editor/model/Editor';
import CommandsEvents, { type CommandCallEventData, type CommandEventData } from '../types';

interface ICommand<TRunOptions = any, TStopOptions = TRunOptions, TRunResult = any, TStopResult = any> {
  run?: CommandAbstract<TRunOptions, TStopOptions, TRunResult, TStopResult>['run'];
  stop?: CommandAbstract<TRunOptions, TStopOptions, TRunResult, TStopResult>['stop'];
  id?: string;
  noStop?: boolean;
  initialize?: unknown;
  [key: string]: unknown;
}

export type CommandFunction<TRunOptions = any, TRunResult = any> = CommandAbstract<
  TRunOptions,
  any,
  TRunResult,
  any
>['run'];

export interface CommandConstructor<
  TRunOptions = any,
  TStopOptions = TRunOptions,
  TRunResult = any,
  TStopResult = any,
> {
  new (o: any): CommandAbstract<TRunOptions, TStopOptions, TRunResult, TStopResult>;
  prototype: CommandAbstract<TRunOptions, TStopOptions, TRunResult, TStopResult>;
}

export type Command = CommandObject<any, ObjectAny, any, any, any> | CommandFunction | CommandConstructor;
export type CommandStored = CommandConstructor | CommandAbstract;

export type CommandOptions = Record<string, any>;

export type CommandObject<
  TRunOptions = any,
  T extends ObjectAny = {},
  TStopOptions = TRunOptions,
  TRunResult = any,
  TStopResult = any,
> = ICommand<TRunOptions, TStopOptions, TRunResult, TStopResult> &
  T &
  ThisType<T & CommandAbstract<TRunOptions, TStopOptions, TRunResult, TStopResult>>;

export function defineCommand<
  TRunOptions = any,
  T extends ObjectAny = {},
  TStopOptions = TRunOptions,
  TRunResult = any,
  TStopResult = any,
>(def: CommandObject<TRunOptions, T, TStopOptions, TRunResult, TStopResult>) {
  return def;
}

export default class CommandAbstract<
  TRunOptions = any,
  TStopOptions = TRunOptions,
  TRunResult = any,
  TStopResult = any,
> extends Model {
  config: any;
  em: EditorModel;
  pfx: string;
  ppfx: string;
  hoverClass: string;
  badgeClass: string;
  plhClass: string;
  freezClass: string;
  canvas: CanvasModule;
  noStop?: boolean;

  constructor(o: any) {
    super(0);
    this.config = o || {};
    this.em = this.config.em || {};
    const pfx = this.config.stylePrefix;
    this.pfx = pfx;
    this.ppfx = this.config.pStylePrefix;
    this.hoverClass = `${pfx}hover`;
    this.badgeClass = `${pfx}badge`;
    this.plhClass = `${pfx}placeholder`;
    this.freezClass = `${this.ppfx}freezed`;
    this.canvas = this.em.Canvas;
    this.init(this.config);
  }

  /**
   * On frame scroll callback
   * @param  {[type]} e [description]
   * @return {[type]}   [description]
   */
  onFrameScroll(e: any) {}

  /**
   * Returns canval element
   * @return {HTMLElement}
   */
  getCanvas() {
    return this.canvas.getElement();
  }

  /**
   * Get canvas body element
   * @return {HTMLElement}
   */
  getCanvasBody() {
    return this.canvas.getBody();
  }

  /**
   * Get canvas wrapper element
   * @return {HTMLElement}
   */
  getCanvasTools() {
    return this.canvas.getToolsEl();
  }

  /**
   * Get the offset of the element
   * @param  {HTMLElement} el
   * @return {Object}
   */
  offset(el: HTMLElement) {
    var rect = el.getBoundingClientRect();
    return {
      top: rect.top + el.ownerDocument.body.scrollTop,
      left: rect.left + el.ownerDocument.body.scrollLeft,
    };
  }

  /**
   * Callback triggered after initialize
   * @param  {Object}  o   Options
   * @private
   * */
  init(o: any) {}

  /**
   * Method that run command
   * @param  {Object}  editor Editor instance
   * @param  {Object}  [options={}] Options
   * @private
   * */
  callRun(editor: Editor, opts: TRunOptions = {} as TRunOptions) {
    const { id } = this;
    const options = opts as CommandOptions;
    editor.trigger(`${CommandsEvents.runBeforeCommand}${id}`, { options });

    if (options.abort) {
      editor.trigger(`${CommandsEvents.abort}${id}`, { options });
      return;
    }

    const sender = options.sender || editor;
    const result = this.run(editor, sender, options as TRunOptions);
    const data: CommandEventData = { id, result, options };
    const dataCall: CommandCallEventData = { ...data, type: 'run' };

    if (!this.noStop) {
      editor.Commands.active[id] = result;
    }

    editor.trigger(`${CommandsEvents.runCommand}${id}`, data);
    editor.trigger(`${CommandsEvents.callCommand}${id}`, dataCall);
    editor.trigger(CommandsEvents.run, data);
    editor.trigger(CommandsEvents.call, dataCall);

    return result;
  }

  /**
   * Method that run command
   * @param  {Object}  editor Editor instance
   * @param  {Object}  [options={}] Options
   * @private
   * */
  callStop(editor: Editor, opts: TStopOptions = {} as TStopOptions) {
    const { id } = this;
    const options = opts as CommandOptions;
    const sender = options.sender || editor;
    editor.trigger(`${CommandsEvents.stopBeforeCommand}${id}`, { options });
    const result = this.stop(editor, sender, options as TStopOptions);
    const data: CommandEventData = { id, result, options };
    const dataCall: CommandCallEventData = { ...data, type: 'stop' };
    delete editor.Commands.active[id];
    editor.trigger(`${CommandsEvents.stopCommand}${id}`, data);
    editor.trigger(`${CommandsEvents.callCommand}${id}`, dataCall);
    editor.trigger(CommandsEvents.stop, data);
    editor.trigger(CommandsEvents.call, dataCall);
    return result;
  }

  /**
   * Stop current command
   */
  stopCommand(opts?: any) {
    this.em?.Commands?.stop?.(this.id as string, opts);
  }

  /**
   * Method that run command
   * @param  {Object}  em     Editor model
   * @param  {Object}  sender  Button sender
   * @private
   * */
  run(em: Editor, sender: any, options: TRunOptions): TRunResult {
    return undefined as TRunResult;
  }

  /**
   * Method that stop command
   * @param  {Object}  em Editor model
   * @param  {Object}  sender  Button sender
   * @private
   * */
  stop(em: Editor, sender: any, options: TStopOptions): TStopResult {
    return undefined as TStopResult;
  }
}
