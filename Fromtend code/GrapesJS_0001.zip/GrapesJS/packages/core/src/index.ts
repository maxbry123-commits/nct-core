import { isElement } from 'underscore';
import Editor from './editor';
import { EditorConfig } from './editor/config/config';
import { PluginInput } from './plugin_manager/types';
import { legacyGlobalPlugins, usePlugin as pluginUsePlugin } from './plugin_manager/utils';
import $ from './utils/cash-dom';
import polyfills from './utils/polyfills';

export interface InitEditorConfig extends EditorConfig {
  grapesjs?: typeof grapesjs;
}

polyfills();

const editors: Editor[] = [];
export const usePlugin = pluginUsePlugin;

export const grapesjs = {
  $,

  editors,

  plugins: legacyGlobalPlugins,

  usePlugin,

  // @ts-ignore Will be replaced on build
  version: __GJS_VERSION__ as string,

  /**
   * Initialize the editor with passed options
   * @param {Object} config Configuration object
   * @param {string|HTMLElement} config.container Selector which indicates where render the editor
   * @param {Boolean} [config.autorender=true] If true, auto-render the content
   * @param {Array} [config.plugins=[]] Array of plugins to execute on start
   * @param {Object} [config.pluginsOpts={}] Custom options for plugins
   * @param {Boolean} [config.headless=false] Init headless editor
   * @return {Editor} Editor instance
   * @example
   * var editor = grapesjs.init({
   *   container: '#myeditor',
   *   components: '<article class="hello">Hello world</article>',
   *   style: '.hello{color: red}',
   * })
   */
  init(config: EditorConfig = {}) {
    const { headless } = config;
    const els = config.container;
    if (!els && !headless) throw new Error("'container' is required");
    const initConfig: InitEditorConfig = {
      autorender: true,
      plugins: [],
      pluginsOpts: {},
      ...config,
      grapesjs: this,
      el: headless ? undefined : isElement(els) ? els : (document.querySelector(els!) as HTMLElement),
    };
    const editor = new Editor(initConfig, { $ });
    const em = editor.getModel();
    em.initModules();

    // Load plugins
    initConfig.plugins?.forEach((pluginInput) => editor.Plugins.add(pluginInput as PluginInput));

    // Execute `onLoad` on modules once all plugins are initialized.
    // A plugin might have extended/added some custom type so this
    // is a good point to load stuff like components, css rules, etc.
    em.loadOnStart();
    initConfig.autorender && !headless && editor.render();
    editors.push(editor);

    return editor;
  },
};

/**
 * @deprecated Changed to CategoryProperties
 */
export type { CategoryProperties as BlockCategoryProperties } from './abstract/ModuleCategory';
export type { CommandRegistryRun, CommandRegistryStop } from './commands/registry';
export type { ComponentDragEventProps } from './commands/view/ComponentDrag';

// Exports for TS
export type { default as Categories } from './abstract/ModuleCategories';
export type { default as Category } from './abstract/ModuleCategory';
export type { default as Asset } from './asset_manager/model/Asset';
export type { default as Assets } from './asset_manager/model/Assets';
export type { default as Block } from './block_manager/model/Block';
export type { default as Blocks } from './block_manager/model/Blocks';
export type { default as Canvas } from './canvas/model/Canvas';
export type { default as CanvasSpot } from './canvas/model/CanvasSpot';
export type { default as CanvasSpots } from './canvas/model/CanvasSpots';
export type { default as Frame } from './canvas/model/Frame';
export type { default as Frames } from './canvas/model/Frames';
export type { default as CssRule } from './css_composer/model/CssRule';
export type { default as CssRules } from './css_composer/model/CssRules';
export type { default as DataSourceManager } from './data_sources';
export type { default as ComponentDataVariable } from './data_sources/model/ComponentDataVariable';
export type { default as ComponentWithCollectionsState } from './data_sources/model/ComponentWithCollectionsState';
export type { ComponentWithDataResolver } from './data_sources/model/ComponentWithDataResolver';
export type { default as ComponentDataCondition } from './data_sources/model/conditional_variables/ComponentDataCondition';
export type {
  DataCondition,
  DataConditionProps,
  ExpressionProps,
  LogicGroupProps,
} from './data_sources/model/conditional_variables/DataCondition';
export type { default as ComponentDataCollection } from './data_sources/model/data_collection/ComponentDataCollection';
export type { default as DataRecord } from './data_sources/model/DataRecord';
export type { default as DataRecords } from './data_sources/model/DataRecords';
export type { default as DataSource } from './data_sources/model/DataSource';
export type { default as DataSources } from './data_sources/model/DataSources';
export type { default as DataVariable } from './data_sources/model/DataVariable';
export type {
  DataBindingImportAction,
  DataBindingImportContext,
  DataBindingImportPolicy,
  DataBindingImportSource,
  DataBindingKind,
} from './data_sources/types';
export type { default as Device } from './device_manager/model/Device';
export type { default as Devices } from './device_manager/model/Devices';
export type { default as ComponentManager } from './dom_components';
export type { default as Component } from './dom_components/model/Component';
export type { default as Components } from './dom_components/model/Components';
export type { default as ComponentView } from './dom_components/view/ComponentView';
export type { default as Editor } from './editor';
export type { default as Modal } from './modal_dialog/model/Modal';
export type { default as Page } from './pages/model/Page';
export type { default as Pages } from './pages/model/Pages';
export type { default as Button } from './panels/model/Button';
export type { default as Buttons } from './panels/model/Buttons';
export type { default as Panel } from './panels/model/Panel';
export type { default as Panels } from './panels/model/Panels';
export type {
  CustomParserCode,
  CustomParserCodeContext,
  CustomParserCodeFunction,
  HTMLParseResult,
  ParsedCssRule,
  ParsedNode,
} from './parser/types';
export type { default as Selector } from './selector_manager/model/Selector';
export type { default as Selectors } from './selector_manager/model/Selectors';
export type { default as State } from './selector_manager/model/State';
export type { default as Properties } from './style_manager/model/Properties';
export type { default as Property } from './style_manager/model/Property';
export type { default as PropertyComposite } from './style_manager/model/PropertyComposite';
export type { default as PropertyNumber } from './style_manager/model/PropertyNumber';
export type { default as PropertyRadio } from './style_manager/model/PropertyRadio';
export type { default as PropertySelect } from './style_manager/model/PropertySelect';
export type { default as PropertySlider } from './style_manager/model/PropertySlider';
export type { default as PropertyStack } from './style_manager/model/PropertyStack';
export type { default as Sector } from './style_manager/model/Sector';
export type { default as Sectors } from './style_manager/model/Sectors';
export type { default as Trait } from './trait_manager/model/Trait';
export type { default as Traits } from './trait_manager/model/Traits';

export default grapesjs;
