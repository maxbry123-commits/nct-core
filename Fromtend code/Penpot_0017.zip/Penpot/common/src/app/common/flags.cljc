;; This Source Code Form is subject to the terms of the Mozilla Public
;; License, v. 2.0. If a copy of the MPL was not distributed with this
;; file, You can obtain one at http://mozilla.org/MPL/2.0/.
;;
;; Copyright (c) KALEIDOS SUBSIDIARY SL

(ns app.common.flags
  "Flags parsing algorithm."
  (:require
   [clojure.set :as set]
   [cuerdas.core :as str]))

(def ^:dynamic *current* #{})

(def login
  "Flags related to login features"
  #{;; Allows registration with login / password
    ;; if disabled, it's still possible to register/login with providers
    :registration
    ;; Redundant flag. TODO: remove it
    :login
    ;; enables the section of Access Tokens on profile.
    :access-tokens
    ;; Uses email and password as credentials.
    :login-with-password
    ;; Uses Github authentication as credentials.
    :login-with-github
    ;; Uses GitLab authentication as credentials.
    :login-with-gitlab
    ;; Uses Google/Gmail authentication as credentials.
    :login-with-google
    ;; Uses LDAP authentication as credentials.
    :login-with-ldap
    ;; Uses any generic authentication provider that implements OIDC protocol as credentials.
    :login-with-oidc
    ;; Enables custom SSO flow
    :login-with-custom-sso
    ;; Allows registration with OIDC (takes effect only when general `registration` is disabled)
    :oidc-registration
    ;; This logs to console the invitation tokens. It's useful in case the SMTP is not configured.
    :log-invitation-tokens})

(def email
  "Flags related to email features"
  #{;; Uses the domains in whitelist as the only allowed domains to register in the application.
    ;; Used with PENPOT_REGISTRATION_DOMAIN_WHITELIST
    :email-whitelist
    ;; Prevents the domains in blacklist to register in the application.
    ;; Used with PENPOT_REGISTRATION_DOMAIN_BLACKLIST
    :email-blacklist
    ;; Skips the email verification process. Not recommended for production environments.
    :email-verification
    ;; Only used if SMTP is disabled. Logs the emails into the console.
    :log-emails
    ;; Enable it to configure email settings.
    :smtp
    ;; Enables the debug mode of the SMTP library.
    :smtp-debug})

(def varia
  "Rest of the flags"
  #{:audit-log
    :audit-log-archive
    :audit-log-gc
    :audit-log-logger
    :auto-file-snapshot
    ;; enables the `/api/doc` endpoint that lists all the rpc methods available.
    :backend-api-doc
    ;; TODO: remove it and use only `backend-api-doc` flag
    :backend-openapi-doc
    ;; Disable it to start the RPC without the worker.
    :backend-worker
    ;; Only for development
    :component-thumbnails
    ;; Enables CORS support for the RPC API. Requires an explicit
    ;; allowlist of origins via PENPOT_ALLOWED_ORIGINS; if no allowlist
    ;; is configured the middleware fails closed (a warning is logged
    ;; and CORS headers are not emitted) to avoid CSRF / data
    ;; exfiltration via origin reflection.
    :cors
    ;; Enables the templates dialog on Penpot dashboard.
    :dashboard-templates-section
    ;; disabled by default. When enabled, Penpot create demo users with a 7 days expiration.
    :demo-users
    ;; disabled by default. When enabled, it displays a warning that this is a test instance and data will be deleted periodically.
    :demo-warning
    ;; Activates the schema validation during update file.
    :file-schema-validation
    ;; Reports the schema validation errors internally.
    :soft-file-schema-validation
    ;; Activates the referential integrity validation during update file.
    :file-validation
    ;; Reports the referential integrity validation errors internally.
    :soft-file-validation
    ;; TODO: deprecate this flag and consolidate the code
    :frontend-svgo
    ;; TODO: deprecate this flag and consolidate the code
    :exporter-svgo
    ;; TODO: deprecate this flag and consolidate the code
    :backend-svgo
    ;; If enabled, it makes the Google Fonts available.
    :google-fonts-provider
    ;; Enables the Ladybug graph subsystem: the `/dbg` graph console and its
    ;; actions. Off by default. With the flag off, `app.graph.*` never loads,
    ;; so the Ladybug native library never enters the JVM.
    :graph
    ;; Only for development.
    :nrepl-server
    ;; Interactive repl. Only for development.
    :urepl-server
    ;; Programatic access to the runtime, used in administrative tasks.
    ;; It's mandatory to enable it to use the `manage.py` script.
    :prepl-server
    ;; Shows the onboarding modals right after registration.
    :onboarding
    :quotes
    :soft-quotes
    ;; Concurrency limit.
    :rpc-climit
    ;; Rate limit.
    :rpc-rlimit
    ;; Soft rate limit.
    :soft-rpc-rlimit
    ;; Disable it if you want to serve Penpot under a different domain than `http://localhost` without HTTPS.
    :secure-session-cookies
    ;; If `cors` enabled, this is ignored.
    :strict-session-cookies
    :telemetry
    :terms-and-privacy-checkbox
    :tiered-file-data-storage

    ;; Tokens
    :token-base-font-size
    :token-combobox
    :token-color
    :token-shadow
    :token-tokenscript
    :token-import-from-library
    :token-typography-row

    ;; Only for developtment.
    :transit-readable-response
    :user-feedback
    ;; TODO: remove this flag.
    :v2-migration
    :webhooks
    ;; TODO: deprecate this flag and consolidate the code
    :render-wasm-dpr
    ;; Show WASM renderer info label (hidden by default).
    :render-wasm-info
    :render-switch
    :hide-release-modal
    :subscriptions
    :inspect-styles
    ;; Enable performance logs in devconsole (disabled by default)
    :perf-logs

    ;; Security layer middleware that filters request by fetch
    ;; metadata headers
    :sec-fetch-metadata-middleware

    ;; Security layer middleware that check the precense of x-client
    ;; http headers and enables an addtional csrf protection
    :client-header-check-middleware

    ;; A temporal flag, enables backend code use more extensivelly
    ;; redis for caching data
    :redis-cache

    ;; Activates the admin-console module
    :admin-console

    ;; disabled by default. When enabled, allows the admin-console
    ;; `bulk-create-profiles` method to create batches of already
    ;; active profiles. Only intended for test environments.
    :admin-console-bulk-create-profiles

    :mcp
    :background-blur
    :available-viewer-wasm
    :stroke-path
    :stroke-per-side

    ;; Exporter only: uses render-wasm for export instead of browser
    ;; renderer.
    :wasm-export
    :custom-shortcuts
    :remote-media-processing})

(def all-flags
  (set/union email login varia))

(def default
  "Flags with default configuration"
  [:enable-registration
   :enable-login-with-password
   :enable-export-file-v3
   :enable-frontend-svgo
   :enable-exporter-svgo
   :enable-backend-svgo
   :enable-backend-api-doc
   :enable-backend-openapi-doc
   :enable-backend-worker
   :enable-secure-session-cookies
   :enable-email-verification
   :enable-onboarding
   :enable-dashboard-templates-section
   :enable-google-fonts-provider
   :enable-component-thumbnails
   :enable-render-wasm-dpr
   :enable-token-color
   :enable-token-shadow
   :enable-token-typography-row
   :enable-inspect-styles
   :enable-feature-fdata-objects-map
   :enable-feature-render-wasm
   :enable-token-import-from-library
   :enable-render-switch
   :enable-render-wasm-info
   :enable-available-viewer-wasm
   :enable-background-blur
   :enable-stroke-path
   :enable-token-combobox])

(defn parse
  [& flags]
  (loop [flags  (apply concat flags)
         result #{}]
    (let [item (first flags)]
      (if (nil? item)
        result
        (let [sname (name item)]
          (cond
            (str/starts-with? sname "enable-")
            (recur (rest flags)
                   (conj result (keyword (subs sname 7))))

            (str/starts-with? sname "disable-")
            (recur (rest flags)
                   (disj result (keyword (subs sname 8))))

            :else
            (recur (rest flags) result)))))))
