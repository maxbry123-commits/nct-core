import { expect, Page } from "@playwright/test";
import { PageModels, test } from "../fixtures/test";
import { setDynamicVisibility } from "../utils/auto-open-utils";
import { pasteIntoMonaco } from "../utils/key-utils";
import { goToProject } from "../utils/studio-utils";

const MOCK_API_URL = "https://mock-api-for-server-queries.test";

async function createServerQuery(
  models: PageModels,
  opts: {
    name: string;
    expectedResult: string;
  } & ({ url: string } | { urlExpression: string })
) {
  await test.step(`Create server query "${opts.name}"`, async () => {
    const serverQueryModal = models.studio.serverQueryBottomModal;
    const previewResult = serverQueryModal.locator(".code-preview-inner");

    await models.studio.rightPanel.addServerQueryButton.click();
    // When other components already have configured queries the add button becomes
    // a dropdown (New / Copy from…). Wait briefly for the "New" item and click it
    // if the dropdown appeared; otherwise the button already added the query directly.
    const newMenuItem = models.studio.frame
      .locator(".ant-dropdown-menu-item")
      .getByText("New", { exact: true });
    try {
      await newMenuItem.waitFor({ state: "visible", timeout: 1000 });
      await newMenuItem.click();
    } catch {
      // No dropdown – query was created directly by the button click.
    }
    // This is the server query created in the previous line
    await models.studio.rightPanel.serverQueriesSection
      .locator(`[data-plasmic-role="labeled-item"]`)
      .last()
      .click();

    const queryNameInput = serverQueryModal.locator(
      `[data-test-id="query-name"] input`
    );
    await queryNameInput.fill(opts.name);

    const urlInput = serverQueryModal
      .locator(`[data-test-id="prop-editor-row-url"]`)
      .locator(`[data-plasmic-prop="url"]`);

    if ("urlExpression" in opts) {
      await urlInput.click({ button: "right" });
      await models.studio.frame.getByText("Use dynamic value").click();
      await models.studio.rightPanel.insertMonacoCode(opts.urlExpression);
    } else {
      await urlInput.click();
      await models.studio.page.keyboard.type(opts.url);
    }

    await serverQueryModal.locator("button").getByText("Execute").click();
    await expect(previewResult).toContainText(opts.expectedResult);

    await serverQueryModal.locator("button").getByText("Save").click();
    await serverQueryModal.waitFor({ state: "hidden" });
  });
}

async function assertNotification(
  models: PageModels,
  expectedText: string,
  expectedDescription?: string
) {
  await test.step(`Assert notification "${expectedText}"`, async () => {
    await expect(models.studio.notificationMessage).toContainText(expectedText);
    if (expectedDescription) {
      await expect(models.studio.notificationDescription).toContainText(
        expectedDescription
      );
    } else {
      await expect(models.studio.notificationDescription).not.toBeVisible();
    }
    await models.studio.notificationClose.click();
  });
}

async function copyQueryFromPage(
  models: PageModels,
  sourcePage: string,
  queryName: string
) {
  await models.studio.rightPanel.addServerQueryButton.click();

  // Hover to open antd nested submenus. Clicking can race with submenu open/close
  // and leave the menu collapsed before the leaf is clickable.
  const copyFromTitle = models.studio.frame
    .locator(".ant-dropdown-menu-submenu-title")
    .filter({ hasText: "Copy from..." });
  await copyFromTitle.hover();

  const sourcePageTitle = models.studio.frame
    .locator(".ant-dropdown-menu-submenu-title")
    .filter({ hasText: sourcePage });
  await sourcePageTitle.hover();

  const queryItem = models.studio.frame
    .locator(".ant-dropdown-menu-item")
    .getByText(queryName, { exact: true });
  await queryItem.waitFor({ state: "visible" });
  await queryItem.click();
}

/**
 * Opens a new custom code server query with the given name.
 * Returns the code editor locator (ready for code insertion).
 */
async function openNewCustomCodeQuery(models: PageModels, name: string) {
  const serverQueryModal = models.studio.serverQueryBottomModal;

  await models.studio.rightPanel.addServerQueryButton.click();
  await models.studio.rightPanel.serverQueriesSection
    .locator(`[data-plasmic-role="labeled-item"]`)
    .last()
    .click();

  await serverQueryModal
    .locator(`[data-test-id="query-name"] input`)
    .fill(name);

  await serverQueryModal.getByText("Select...").click();
  await models.studio.frame.locator('[data-key="__custom_code__"]').click();

  const codeEditor = serverQueryModal.locator(
    "div.react-monaco-editor-container"
  );
  await codeEditor.click();
  await codeEditor.locator(".view-lines").waitFor({ state: "visible" });

  return codeEditor;
}

async function generateMocks(page: Page) {
  const mockTodos = [
    { id: 1, title: "Buy milk", completed: false },
    { id: 2, title: "Walk the dog", completed: true },
    { id: 3, title: "Read a book", completed: false },
  ];
  // Mock the fetch endpoints
  await page.route(`${MOCK_API_URL}/todos/1`, async (route) => {
    await route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify(mockTodos[0]),
    });
  });
  await page.route(`${MOCK_API_URL}/todos`, async (route) => {
    await route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify(mockTodos),
    });
  });
}

test.describe("server queries", () => {
  let projectId: string;

  test.afterEach(async ({ apiClient }) => {
    await apiClient.removeProjectAfterTest(
      projectId,
      "user2@example.com",
      "!53kr3tz!"
    );
  });

  test("create custom code server queries with data tokens and data context", async ({
    apiClient,
    page,
    models,
  }) => {
    projectId = await apiClient.setupNewProject({
      name: "custom-code-server-queries",
    });
    await goToProject(
      page,
      `/projects/${projectId}?serverQueries=true&dataTokens=true`
    );

    const serverQueryModal = models.studio.serverQueryBottomModal;
    const previewResult = serverQueryModal.locator(".code-preview-inner");
    const queryRows =
      models.studio.rightPanel.serverQueriesSectionContent.locator(
        `[data-plasmic-role="labeled-item"]`
      );

    const QUERIES = {
      greeting: { name: "Greeting", preview: "Welcome to Mars" },
      fullGreeting: {
        name: "Full Greeting",
        preview: "Welcome to Mars, enjoy your stay!",
      },
      fullGreeting2: {
        name: "Full Greeting 2",
        preview: "Welcome to Mars, enjoy your stay!",
      },
    } as const;

    async function assertQuerySummary(key: keyof typeof QUERIES) {
      const { name, preview } = QUERIES[key];
      const row = queryRows.filter({
        has: models.studio.frame.getByText(name, { exact: true }),
      });
      await expect(row).toContainText("Custom code");
      await expect(row).toContainText(preview);
    }

    await models.studio.leftPanel.createNewDataToken({
      name: "planet",
      type: "text",
      value: "Mars",
    });

    await models.studio.leftPanel.createNewPage("Custom Code Page");
    await models.studio.rightPanel.clickPageData();

    await expect(queryRows).toHaveCount(0);

    await test.step('Create "Greeting" query with data token from inspector', async () => {
      const codeEditor = await openNewCustomCodeQuery(models, "Greeting");

      await pasteIntoMonaco(
        codeEditor,
        "await new Promise(resolve => setTimeout(() => {\n  resolve(`Welcome to ${ }`)\n}, 2000))"
      );

      // Position cursor between ${ and } to insert the data token there
      for (let i = 0; i < 14; i++) {
        await page.keyboard.press("ArrowLeft");
      }

      await serverQueryModal
        .locator('[data-insert-path="$dataTokens"]')
        .click();
      await serverQueryModal
        .locator('[data-insert-path="$dataTokens.planet"]')
        .click({ button: "right" });
      await models.studio.frame
        .locator(".ant-dropdown-menu-item")
        .filter({ hasText: "Insert" })
        .click();

      // Verify the data token was inserted in display format
      await expect(codeEditor.locator(".view-lines")).toContainText(
        "$dataTokens.planet"
      );

      await serverQueryModal.locator("button").getByText("Execute").click();
      await expect(previewResult).toContainText("Welcome to Mars");

      await serverQueryModal.locator("button").getByText("Save").click();
      await serverQueryModal.waitFor({ state: "hidden" });
    });
    await assertQuerySummary("greeting");

    await test.step('Create "Full Greeting" query with $q reference from inspector', async () => {
      const codeEditor = await openNewCustomCodeQuery(models, "Full Greeting");

      // Insert $q.greeting.data from the data context inspector
      await serverQueryModal.locator('[data-insert-path="$q"]').click();
      await serverQueryModal
        .locator('[data-insert-path="$q.greeting"]')
        .click();
      await serverQueryModal
        .locator('[data-insert-path="$q.greeting.data"]')
        .click({ button: "right" });
      await models.studio.frame
        .locator(".ant-dropdown-menu-item")
        .filter({ hasText: "Insert" })
        .click();

      await page.keyboard.press("End");
      // Use synthetic paste so Monaco doesn't auto-close the inner `"`.
      await pasteIntoMonaco(codeEditor, ' + ", enjoy your stay!"');

      await serverQueryModal.locator("button").getByText("Execute").click();
      await expect(previewResult).toContainText(
        "Welcome to Mars, enjoy your stay!"
      );

      await serverQueryModal.locator("button").getByText("Save").click();
      await serverQueryModal.waitFor({ state: "hidden" });
    });
    await assertQuerySummary("greeting");
    await assertQuerySummary("fullGreeting");

    await test.step("reopened query shows data token in display format", async () => {
      await queryRows.getByText("Greeting", { exact: true }).click();

      const codeEditor = serverQueryModal.locator(
        "div.react-monaco-editor-container"
      );
      await codeEditor.waitFor({ state: "visible" });

      // Verify the code editor shows the display format ($dataTokens.planet)
      // not the stored format ($dataTokens_<projectShortId>_planet)
      await expect(codeEditor.locator(".view-lines")).toContainText(
        "$dataTokens.planet"
      );

      await serverQueryModal.locator("button").getByText("Save").click();
      await serverQueryModal.waitFor({ state: "hidden" });
    });

    await test.step("duplicate Full Greeting query", async () => {
      await queryRows
        .getByText("Full Greeting", { exact: true })
        .click({ button: "right" });
      await models.studio.frame
        .locator(".ant-dropdown-menu-item")
        .getByText("Duplicate")
        .click();

      await assertQuerySummary("greeting");
      await assertQuerySummary("fullGreeting");
      await assertQuerySummary("fullGreeting2");
    });

    await test.step("bind text element to duplicated query result", async () => {
      await models.studio.leftPanel.insertNode("Text");
      await models.studio.rightPanel.switchToSettingsTab();

      const studioFrame = models.studio.frame;
      const textContentLabel = studioFrame.locator(
        '[data-test-id="text-content"] label'
      );
      await textContentLabel.click({ button: "right" });
      await models.studio.rightPanel.useDynamicValueButton.click();

      const dataPicker = models.studio.rightPanel.frame.locator(
        '[data-test-id="data-picker"]'
      );
      await dataPicker.waitFor({ state: "visible" });

      // Select fullGreeting2 to verify the duplicated query is available in the picker.
      await models.studio.rightPanel.selectPathInDataPicker(["fullGreeting2"]);

      // Verify the text element shows the query result on the canvas
      await expect(
        models.studio.componentFrame.getByText(
          "Welcome to Mars, enjoy your stay!"
        )
      ).toBeVisible();
    });

    await test.step("queries reload correctly after refreshing canvas data", async () => {
      await models.studio.frame.locator("#view-menu").click();
      await models.studio.frame.getByText("Refresh data").click();

      await models.studio.rightPanel.clickPageData();

      await assertQuerySummary("greeting");
      await assertQuerySummary("fullGreeting");
      await assertQuerySummary("fullGreeting2");

      // PLA-12947: This currently fails.
      // await expect(
      //   models.studio.componentFrame.getByText(
      //     "Welcome to Mars, enjoy your stay!"
      //   )
      // ).toBeVisible();
    });

    await test.step("text renders in live preview", async () => {
      await models.studio.withinLiveMode(async (liveFrame) => {
        await expect(
          liveFrame.getByText("Welcome to Mars, enjoy your stay!")
        ).toBeVisible();
      });
    });
  });

  test("create, duplicate, and copy server queries", async ({
    apiClient,
    page,
    models,
  }) => {
    projectId = await apiClient.setupProjectWithHostlessPackages({
      name: "server-queries",
      hostLessPackagesInfo: {
        name: "fetch",
        npmPkg: ["@plasmicpkgs/fetch"],
      },
    });
    await goToProject(page, `/projects/${projectId}?serverQueries=true`);

    await generateMocks(page);

    await models.studio.leftPanel.createNewPage("Source Page");
    await models.studio.rightPanel.clickPageData();

    const queryRows =
      models.studio.rightPanel.serverQueriesSectionContent.locator(
        `[data-plasmic-role="labeled-item"]`
      );

    await expect(queryRows).toHaveCount(0);

    // Create Todos query with $state, $props, $ctx references
    await createServerQuery(models, {
      name: "Todos",
      urlExpression: `"${MOCK_API_URL}/todos" + ($state.extra ?? "") + ($props.filter ?? "") + ($ctx.suffix ?? "")`,
      expectedResult: "Array(3)",
    });
    await expect(queryRows).toHaveCount(1);

    // Create a dependent query
    await createServerQuery(models, {
      name: "Todo",
      urlExpression: `"${MOCK_API_URL}/todos/" + $q.todos.data.body[0].id`,
      expectedResult: "Buy milk",
    });
    await expect(queryRows).toHaveCount(2);

    await expect(queryRows.nth(0)).toContainText("Todos");
    await expect(queryRows.nth(1)).toContainText("Todo");

    await test.step(`Duplicate independent query within the same page"`, async () => {
      await queryRows
        .getByText("Todos", { exact: true })
        .click({ button: "right" });
      await models.studio.frame
        .locator(".ant-dropdown-menu-item")
        .getByText("Duplicate")
        .click();

      await expect(queryRows).toHaveCount(3);
      await expect(queryRows.nth(2)).toContainText("Todos 2");
      await expect(models.studio.notification).not.toBeVisible();
    });

    await test.step(`Duplicate dependent query within the same page"`, async () => {
      await queryRows
        .getByText("Todo", { exact: true })
        .click({ button: "right" });
      await models.studio.frame
        .locator(".ant-dropdown-menu-item")
        .getByText("Duplicate")
        .click();

      // Only the main query is copied
      await expect(queryRows).toHaveCount(4);
      await expect(queryRows.nth(3)).toContainText("Todo 2");
      await expect(models.studio.notification).not.toBeVisible();
    });

    await test.step(`Duplicate dependent query to a different page"`, async () => {
      await models.studio.leftPanel.createNewPage("Target Page");
      await models.studio.rightPanel.clickPageData();

      const targetQueryRows =
        models.studio.rightPanel.serverQueriesSectionContent.locator(
          `[data-plasmic-role="labeled-item"]`
        );
      await expect(targetQueryRows).toHaveCount(0);

      await copyQueryFromPage(models, "Source Page", "Todo");

      // The whole chain is copied
      await expect(targetQueryRows).toHaveCount(2);
      await expect(targetQueryRows.nth(0)).toContainText("Todos");
      await expect(targetQueryRows.nth(1)).toContainText("Todo");

      // Warning includes vars from the transitive dependency (Todos)
      await assertNotification(
        models,
        "Copied queries: Todos, Todo",
        "References component state (extra), props (filter), context (suffix) that may not exist or differ"
      );

      // Copy Todo again — Todos already exists on this page,
      // so only the Todo query should be added
      await copyQueryFromPage(models, "Source Page", "Todo");

      await expect(targetQueryRows).toHaveCount(3);
      await expect(targetQueryRows.nth(2)).toContainText("Todo 2");

      // No warning — Todo itself has no component-dependent vars
      await assertNotification(models, "Copied query: Todo 2");

      // Copy Todos separately — warns about all component-dependent vars
      await copyQueryFromPage(models, "Source Page", "Todos");

      await expect(targetQueryRows).toHaveCount(4);
      await expect(targetQueryRows.nth(3)).toContainText("Todos 2");

      await assertNotification(
        models,
        "Copied query: Todos 2",
        "References component state (extra), props (filter), context (suffix) that may not exist or differ"
      );
    });
  });

  test("param required validation, removal, and reset to default", async ({
    apiClient,
    page,
    models,
  }) => {
    // The graphql function registers a flattened object param whose fields
    // exercise everything under test: `url` (required, no default), `request`
    // (required, no default), and `method` (optional, defaults to "POST").
    projectId = await apiClient.setupProjectWithHostlessPackages({
      name: "server-queries-graphql-params",
      hostLessPackagesInfo: {
        name: "graphql",
        npmPkg: ["@plasmicpkgs/graphql"],
      },
    });
    await goToProject(page, `/projects/${projectId}?serverQueries=true`);

    const GRAPHQL_MOCK_URL = "https://mock-graphql-for-server-queries.test";
    const receivedMethods: string[] = [];
    await page.route(GRAPHQL_MOCK_URL, async (route) => {
      receivedMethods.push(route.request().method());
      await route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify({ data: { hello: "world" } }),
      });
    });

    await models.studio.leftPanel.createNewPage("GraphQL Page");
    await models.studio.rightPanel.clickPageData();

    const serverQueryModal = models.studio.serverQueryBottomModal;
    const previewResult = serverQueryModal.locator(".code-preview-inner");
    const executeButton = serverQueryModal
      .locator("button")
      .getByText("Execute");

    // First query in the project, so the add button creates it directly.
    await models.studio.rightPanel.addServerQueryButton.click();
    await models.studio.rightPanel.serverQueriesSection
      .locator(`[data-plasmic-role="labeled-item"]`)
      .last()
      .click();
    await serverQueryModal
      .locator(`[data-test-id="query-name"] input`)
      .fill("gqlQuery");

    const urlRow = serverQueryModal.locator(
      '[data-test-id="prop-editor-row-url"]'
    );
    const methodRow = serverQueryModal.locator(
      '[data-test-id="prop-editor-row-method"]'
    );
    const requestRow = serverQueryModal.locator(
      '[data-test-id="prop-editor-row-request"]'
    );
    const urlInput = urlRow.locator('[data-plasmic-prop="url"]');
    const invalidArgIcons = serverQueryModal.locator(".invalid-arg-icon");
    const setIndicator = (row: typeof urlRow) =>
      row.locator('[class*="DefinedIndicator--set"]');

    await test.step("required params are labeled; method seeded with its default", async () => {
      await expect(urlRow.locator(".required-prop")).toBeVisible();
      await expect(requestRow.locator(".required-prop")).toBeVisible();
      await expect(methodRow.locator(".required-prop")).toHaveCount(0);

      // method has a registered defaultValue ("POST"), so it starts set
      // (with a defined indicator), while url starts unset.
      await expect(methodRow).toContainText("POST");
      await expect(setIndicator(methodRow)).toBeVisible();
      await expect(setIndicator(urlRow)).toHaveCount(0);
    });

    await test.step("executing with missing required params is blocked with validation errors", async () => {
      await executeButton.click();
      await expect(
        serverQueryModal.getByText("Fix validation errors")
      ).toBeVisible();
      await expect(
        serverQueryModal.getByText("These parameters have invalid values:")
      ).toBeVisible();
      await expect(serverQueryModal.getByText("URL: Required")).toBeVisible();
      await expect(
        serverQueryModal.getByText("Request: Required")
      ).toBeVisible();
      await expect(invalidArgIcons).toHaveCount(2);
      expect(receivedMethods).toEqual([]);
    });

    await test.step("filling a required param clears its validation error on next execute", async () => {
      await urlInput.click();
      await models.studio.page.keyboard.type(GRAPHQL_MOCK_URL);
      await models.studio.page.keyboard.press("Enter");
      await expect(setIndicator(urlRow)).toBeVisible();

      await executeButton.click();
      await expect(
        serverQueryModal.getByText("This parameter has an invalid value:")
      ).toBeVisible();
      await expect(
        serverQueryModal.getByText("Request: Required")
      ).toBeVisible();
      await expect(
        serverQueryModal.getByText("URL: Required")
      ).not.toBeVisible();
      await expect(invalidArgIcons).toHaveCount(1);
    });

    await test.step("removing a param without defaultValue unsets it", async () => {
      await urlInput.click({ button: "right" });
      await models.studio.frame
        .locator(".ant-dropdown-menu-item")
        .filter({ hasText: "Remove URL param" })
        .click();
      await expect(urlInput).toContainText("unset");
      await expect(setIndicator(urlRow)).toHaveCount(0);

      // Restore it for the final execute.
      await urlInput.click();
      await models.studio.page.keyboard.type(GRAPHQL_MOCK_URL);
      await models.studio.page.keyboard.press("Enter");
      await expect(setIndicator(urlRow)).toBeVisible();
    });

    await test.step("removing a param with defaultValue resets it to the default", async () => {
      await methodRow.locator('[data-plasmic-prop="method"]').click();
      await models.studio.frame.locator(`[data-key="'GET'"]`).click();
      await expect(methodRow).toContainText("GET");

      await methodRow
        .getByText("Method", { exact: true })
        .click({ button: "right" });
      await models.studio.frame
        .locator(".ant-dropdown-menu-item")
        .filter({ hasText: "Remove Method param" })
        .click();
      await expect(methodRow).toContainText("POST");
      await expect(setIndicator(methodRow)).toBeVisible();
    });

    await test.step("query executes once all required params are set", async () => {
      // Set `request` as a dynamic value to avoid the GraphiQL editor UI.
      await requestRow
        .getByText("Request", { exact: true })
        .click({ button: "right" });
      await models.studio.frame.getByText("Use dynamic value").click();
      await models.studio.rightPanel.insertMonacoCode(
        '({ query: "query { hello }" })'
      );
      await expect(setIndicator(requestRow)).toBeVisible();

      await executeButton.click();
      await expect(previewResult).toContainText("statusCode: 200");
      await expect(
        serverQueryModal.getByText("Fix validation errors")
      ).not.toBeVisible();
      await expect(invalidArgIcons).toHaveCount(0);

      // The reset `method` default actually flowed through to the request.
      expect([...new Set(receivedMethods)]).toEqual(["POST"]);

      await serverQueryModal.locator("button").getByText("Save").click();
      await serverQueryModal.waitFor({ state: "hidden" });
    });
  });

  test("Use Data Query interaction runs custom code with await", async ({
    apiClient,
    page,
    models,
  }) => {
    projectId = await apiClient.setupNewProject({
      name: "use-data-query-interaction-await",
    });
    await page
      .context()
      .grantPermissions(["clipboard-read", "clipboard-write"]);
    await generateMocks(page);
    await goToProject(page, `/projects/${projectId}?serverQueries=true`);

    await models.studio.leftPanel.createNewPage("Await Page");

    // State the second interaction will write into, so live mode has something
    // to assert against.
    await models.studio.rightPanel.clickPageData();
    await models.studio.rightPanel.addState({
      name: "todoTitle",
      variableType: "text",
      accessType: "private",
      initialValue: "",
    });

    // Button that triggers the interaction.
    await models.studio.leftPanel.switchToTreeTab();
    await models.studio.leftPanel.insertNode("Button");

    await models.studio.rightPanel.addComplexInteraction("onClick", [
      {
        actionName: "customFunctionOp",
        args: {
          customFunctionOpCode: `const res = await fetch("${MOCK_API_URL}/todos/1");\nres.json()`,
        },
      },
      {
        actionName: "customFunctionOp",
        args: {
          customFunctionOpCode: "$steps.customCodeQuery.title.toUpperCase()",
        },
        assertCustomFunctionOpModal: async (modal) => {
          await expect(
            modal.locator('[data-insert-path="$steps"]')
          ).toBeVisible();
        },
      },
      {
        actionName: "updateVariable",
        args: {
          variable: ["todoTitle"],
          operation: "newValue",
          value: "$steps.customCodeQuery2",
        },
      },
    ]);

    // Text bound to the state, so we can assert the runtime result.
    await models.studio.leftPanel.switchToTreeTab();
    await models.studio.leftPanel.insertNode("Text");
    await bindTextContent(models, "$state.todoTitle");

    await models.studio.withinLiveMode(async (liveFrame) => {
      await liveFrame.getByRole("button").click();
      await expect(liveFrame.getByText("BUY MILK")).toBeVisible();
    });
  });
});

const ADVANCED_MOCK_URL = "https://mock-api-advanced-sq.test";

const mockItems = [
  { id: 1, name: "Alpha" },
  { id: 2, name: "Beta" },
];

async function generateAdvancedMocks(page: Page) {
  await page.route(`${ADVANCED_MOCK_URL}/items`, async (route) => {
    await route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify(mockItems),
    });
  });
  await page.route(`${ADVANCED_MOCK_URL}/items/1`, async (route) => {
    await route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify({ id: 1, name: "Alpha", detail: "Alpha detail" }),
    });
  });
}

/**
 * Set selected element's text to an expr.
 */
async function bindTextContent(models: PageModels, expression: string) {
  await models.studio.rightPanel.frame
    .locator('[data-test-id="text-content"] label')
    .click({ button: "right" });
  await models.studio.useDynamicValueButton.click();
  // Insert code and save data picker
  await models.studio.rightPanel.insertMonacoCode(expression);
}

test.describe("server queries – advanced", () => {
  let projectId: string;

  test.afterEach(async ({ apiClient }) => {
    await apiClient.removeProjectAfterTest(
      projectId,
      "user2@example.com",
      "!53kr3tz!"
    );
  });

  test("component server queries within data-repeat", async ({
    apiClient,
    page,
    models,
  }) => {
    projectId = await apiClient.setupProjectWithHostlessPackages({
      name: "server-queries-component",
      hostLessPackagesInfo: {
        name: "fetch",
        npmPkg: ["@plasmicpkgs/fetch"],
      },
    });
    await goToProject(page, `/projects/${projectId}?serverQueries=true`);
    await generateAdvancedMocks(page);

    // Mock for the dependent query in ItemCard
    await page.route(`${ADVANCED_MOCK_URL}/items/1/extra`, async (route) => {
      await route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify({ note: "Alpha extra" }),
      });
    });

    // Create page and items query first ItemCard has queries, otherwise
    // the add button becomes a dropdown and we need to click "New".
    await models.studio.leftPanel.createNewPage("Card Page");
    await models.studio.rightPanel.clickPageData();

    await createServerQuery(models, {
      name: "items",
      url: `${ADVANCED_MOCK_URL}/items`,
      expectedResult: "Array(2)",
    });

    // Create ItemCard component with two dependent queries
    await models.studio.leftPanel.addComponent("ItemCard");
    await models.studio.rightPanel.switchToComponentDataTab();

    // Query 1 fetches an specific item
    await createServerQuery(models, {
      name: "cardBase",
      url: `${ADVANCED_MOCK_URL}/items/1`,
      expectedResult: "statusCode: 200",
    });

    // Query 2 depends on cardBase id in a url expression
    await createServerQuery(models, {
      name: "cardExtra",
      urlExpression: `"${ADVANCED_MOCK_URL}/items/" + $q.cardBase.data.body.id + "/extra"`,
      expectedResult: "statusCode: 200",
    });

    // Add text in ItemCard to show query results
    await models.studio.leftPanel.switchToTreeTab();
    await models.studio.leftPanel.insertNode("Text");
    await bindTextContent(models, "$q.cardBase.data.body.name");

    await models.studio.leftPanel.switchToTreeTab();
    await models.studio.leftPanel.insertNode("Text");
    await bindTextContent(models, "$q.cardExtra.data.body.note");
    await models.studio.leftPanel.switchToTreeTab();

    await models.studio.switchArena("Card Page");

    // Insert ItemCard in Card Page and add repetition
    await models.studio.leftPanel.insertNode("ItemCard");
    await models.studio.rightPanel.repeatOnCustomCodeFast("$q.items.data.body");

    // Verify queries resolve in preview
    await models.studio.withinLiveMode(async (liveFrame) => {
      // cardBase resolves the item name (2 repeated instances → use first())
      const baseText = liveFrame.getByText("Alpha", { exact: true });
      await expect(baseText).toHaveCount(2);
      await expect(baseText.first()).toBeVisible();
      // cardExtra (dependent on cardBase) resolves the extra note
      await expect(
        liveFrame.getByText("Alpha extra", { exact: true }).first()
      ).toBeVisible();
    });
  });

  test("dependent query, data-repeat, and state-driven visibility", async ({
    apiClient,
    page,
    models,
  }) => {
    projectId = await apiClient.setupProjectWithHostlessPackages({
      name: "server-queries-advanced",
      hostLessPackagesInfo: {
        name: "fetch",
        npmPkg: ["@plasmicpkgs/fetch"],
      },
    });
    await goToProject(page, `/projects/${projectId}?serverQueries=true`);
    await generateAdvancedMocks(page);

    await models.studio.leftPanel.createNewPage("Advanced Page");
    await models.studio.rightPanel.clickPageData();

    // Add a boolean state for the visibility condition
    await models.studio.rightPanel.addState({
      name: "showExtra",
      variableType: "boolean",
      accessType: "private",
    });

    // Create base query (fetches list of items)
    await createServerQuery(models, {
      name: "items",
      url: `${ADVANCED_MOCK_URL}/items`,
      expectedResult: "Array(2)",
    });

    // Dependent query (URL uses the first item's id from `items`)
    await createServerQuery(models, {
      name: "firstItem",
      urlExpression: `"${ADVANCED_MOCK_URL}/items/" + $q.items.data.body[0].id`,
      expectedResult: "statusCode: 200",
    });

    // Text element that repeats the items query result and renders the item name
    await models.studio.leftPanel.insertNode("Text");
    await models.studio.rightPanel.repeatOnCustomCodeFast("$q.items.data.body");
    await bindTextContent(models, "currentItem.name");

    // Switch to tree tab to insert in page root
    await models.studio.leftPanel.switchToTreeTab();

    // Button that toggles the showExtra state
    await models.studio.leftPanel.insertNode("Button");
    await models.studio.rightPanel.addComplexInteraction("onClick", [
      {
        actionName: "updateVariable",
        args: { variable: ["showExtra"], operation: "toggle" },
      },
    ]);

    // Insert visibility-gated text.
    await models.studio.leftPanel.switchToTreeTab();
    await models.studio.leftPanel.insertNode("Text");
    await bindTextContent(models, "$q.firstItem.data.body.detail");
    await setDynamicVisibility(models, "$state.showExtra");

    await models.studio.withinLiveMode(async (liveFrame) => {
      // Both item names should be rendered from the `items` query
      await expect(liveFrame.getByText("Alpha")).toBeVisible();
      await expect(liveFrame.getByText("Beta")).toBeVisible();

      // Visibility condition: dependent-query result is hidden before toggle
      await expect(liveFrame.getByText("Alpha detail")).not.toBeVisible();

      // Click the button to set showExtra=true
      await liveFrame.getByRole("button").click();

      // The dependent query result is now visible
      await expect(liveFrame.getByText("Alpha detail")).toBeVisible();
    });
  });
});
