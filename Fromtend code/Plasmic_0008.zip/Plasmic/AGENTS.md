# CLAUDE.md

## Sandbox

You might be in a sandbox. Check out [safehouse.sb](docs/internal/ai-sandbox/macos/safehouse.sb).

## Key tools of root directory

This is root directory of the monorepo. Most development will be done in individual packages, but this directory is responsible for some centrally managed concerns:

- package.json - common devDependencies where we want to use the same version everywhere
- build.mjs - common build script for `packages/`
- .eslintrc.js - shared eslint lint configuration
- vitest.root.ts - shared Vitest unit test configuration for `packages/` and `plasmicpkgs/`
- knip.ts - checks for unused dependencies, run with `knip:deps`

## Key directories

Plasmic is an open-source visual web builder. This monorepo contains:

- **Platform** (`platform/`) - Apps that make up the Plasmic platform, such as the wab, img-optimizer, etc
- **SDK packages** (`packages/`) - npm packages for integrating with Plasmic
- **Plasmic packages** (`plasmicpkgs/`) - npm packages that provide code components on Plasmic
- **Examples** (`examples/`) - Miscellaneous reference implementations

## Tech Stack

- Infra: Docker, k8s, Terraform
- Package Managers: asdf, npm, yarn, pnpm
- Languages: Node.js, TypeScript
- Libraries: React, MobX, TypeORM, Vitest, Playwright, Storybook

## Instructions for AI assistant

- `CLAUDE.md` is the canonical instruction file, and `AGENTS.md` is a symlink to it. Edit `CLAUDE.md`, never `AGENTS.md`.
- Instructions are scoped by directory: the file nearest a path applies to it, and adds to the root file rather than contradicting it. Read `platform/wab/CLAUDE.md` before changing anything under `platform/wab`.
- Do not worry about styling/formatting. All files will be formatted to the same style in git hooks, which husky manages via the generated, gitignored `.husky/_` directory. In a fresh worktree that directory doesn't exist and git silently skips all hooks, so run `pnpm install` at the worktree root before your first commit.
- When searching files, you should almost never look through node_modules/ files and other gitignored files unless you have a explicit reason to.
- When you review a pull request or a diff, these files are the conventions to review it against.
