export { clamp } from './number';
