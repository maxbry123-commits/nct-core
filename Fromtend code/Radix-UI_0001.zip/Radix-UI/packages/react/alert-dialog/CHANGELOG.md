# @radix-ui/react-alert-dialog

## 1.1.23

- Reverted breaking changes that caused compatibility issues with React Server Components.
- Updated dependencies: `@radix-ui/react-compose-refs@1.1.5`, `@radix-ui/react-context@1.2.2`, `@radix-ui/react-dialog@1.1.23`, `@radix-ui/react-primitive@2.1.10`

## 1.1.22

- Updated dependencies: `@radix-ui/react-dialog@1.1.22`, `@radix-ui/react-primitive@2.1.9`

## 1.1.21

- Republish through CI to attach provenance attestations. The previous versions of these packages were published manually outside of CI and therefore shipped without provenance; this patch re-releases the same code through the CI pipeline so every package includes an attestation.
- Updated dependencies: `@radix-ui/primitive@1.1.7`, `@radix-ui/react-compose-refs@1.1.4`, `@radix-ui/react-context@1.2.1`, `@radix-ui/react-dialog@1.1.21`, `@radix-ui/react-primitive@2.1.8`

## 1.1.20

- Improved tree-shaking so bundlers can drop unused components. Component parts are now marked `/* @__PURE__ */` and use named render functions instead of `Component.displayName = ...` assignments, which previously prevented dead-code elimination with some bundlers.
- Updated dependencies: `@radix-ui/react-dialog@1.1.20`, `@radix-ui/primitive@1.1.6`, `@radix-ui/react-compose-refs@1.1.3`, `@radix-ui/react-context@1.2.0`, `@radix-ui/react-primitive@2.1.7`

## 1.1.19

- Updated dependencies: `@radix-ui/primitive@1.1.5`, `@radix-ui/react-context@1.2.0`, `@radix-ui/react-dialog@1.1.19`

## 1.1.18

- Updated dependencies: `@radix-ui/react-primitive@2.1.7`, `@radix-ui/react-dialog@1.1.18`

## 1.1.17

- Removed dev-only warnings for dialogs when title and/or description is not rendered.
- Updated dependencies: `@radix-ui/react-dialog@1.1.17`, `@radix-ui/react-primitive@2.1.6`

## 1.1.16

- Added repository.directory to all package.json files
- Updated dependencies: `@radix-ui/react-dialog@1.1.16`, `@radix-ui/react-slot@1.2.5`, `@radix-ui/primitive@1.1.4`, `@radix-ui/react-compose-refs@1.1.3`, `@radix-ui/react-context@1.1.4`, `@radix-ui/react-primitive@2.1.5`

## 1.1.15

- Updated dependencies: `@radix-ui/react-slot@1.2.4`, `@radix-ui/primitive@1.1.3`, `@radix-ui/react-context@1.1.3`, `@radix-ui/react-dialog@1.1.15`, `@radix-ui/react-primitive@2.1.4`

## 1.1.14

- Replace deprecated 'ElementRef' with 'ComponentRef' (#3426)
- Updated dependencies: `@radix-ui/react-dialog@1.1.14`, `@radix-ui/react-slot@1.2.3`, `@radix-ui/react-primitive@2.1.3`

## 1.1.13

- Updated dependencies: `@radix-ui/react-slot@1.2.2`, `@radix-ui/react-dialog@1.1.13`, `@radix-ui/react-primitive@2.1.2`

## 1.1.12

- Updated dependencies: `@radix-ui/react-slot@1.2.1`, `@radix-ui/react-dialog@1.1.12`, `@radix-ui/react-primitive@2.1.1`

## 1.1.11

- Updated dependencies: `@radix-ui/react-dialog@1.1.11`

## 1.1.10

- Updated dependencies: `@radix-ui/react-dialog@1.1.10`

## 1.1.9

- Updated dependencies: `@radix-ui/react-dialog@1.1.9`

## 1.1.8

- Updated dependencies: `@radix-ui/react-dialog@1.1.8`, `@radix-ui/react-primitive@2.1.0`
