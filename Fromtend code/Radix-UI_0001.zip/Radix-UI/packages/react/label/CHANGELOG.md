# @radix-ui/react-label

## 2.1.15

- Reverted breaking changes that caused compatibility issues with React Server Components.
- Updated dependencies: `@radix-ui/react-primitive@2.1.10`

## 2.1.14

- Updated dependencies: `@radix-ui/react-primitive@2.1.9`

## 2.1.13

- Republish through CI to attach provenance attestations. The previous versions of these packages were published manually outside of CI and therefore shipped without provenance; this patch re-releases the same code through the CI pipeline so every package includes an attestation.
- Updated dependencies: `@radix-ui/react-primitive@2.1.8`

## 2.1.12

- Improved tree-shaking so bundlers can drop unused components. Component parts are now marked `/* @__PURE__ */` and use named render functions instead of `Component.displayName = ...` assignments, which previously prevented dead-code elimination with some bundlers.
- Updated dependencies: `@radix-ui/react-primitive@2.1.7`

## 2.1.11

- Updated dependencies: `@radix-ui/react-primitive@2.1.7`

## 2.1.10

- Updated dependencies: `@radix-ui/react-primitive@2.1.6`

## 2.1.9

- Added repository.directory to all package.json files
- Updated dependencies: `@radix-ui/react-primitive@2.1.5`

## 2.1.8

- Updated dependencies: `@radix-ui/react-primitive@2.1.4`

## 2.1.7

- Replace deprecated 'ElementRef' with 'ComponentRef' (#3426)
- Updated dependencies: `@radix-ui/react-primitive@2.1.3`

## 2.1.6

- Updated dependencies: `@radix-ui/react-primitive@2.1.2`

## 2.1.5

- Updated dependencies: `@radix-ui/react-primitive@2.1.1`

## 2.1.4

- Updated dependencies: `@radix-ui/react-primitive@2.1.0`
