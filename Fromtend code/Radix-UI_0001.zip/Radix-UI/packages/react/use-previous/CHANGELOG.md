# @radix-ui/react-use-previous

## 1.1.4

- Reverted breaking changes that caused compatibility issues with React Server Components.

## 1.1.3

- Republish through CI to attach provenance attestations. The previous versions of these packages were published manually outside of CI and therefore shipped without provenance; this patch re-releases the same code through the CI pipeline so every package includes an attestation.

## 1.1.2

- Added repository.directory to all package.json files
