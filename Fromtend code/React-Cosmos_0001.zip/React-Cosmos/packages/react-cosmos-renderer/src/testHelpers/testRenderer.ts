import type {
  RendererTestArgs,
  RendererTestCallback,
} from './mountTestRenderer.js';
import { mountTestRenderer } from './mountTestRenderer.js';

export function testRenderer(
  testName: string,
  args: RendererTestArgs,
  cb: RendererTestCallback
) {
  const test = () => mountTestRenderer(args, cb);

  if (args.skip) {
    it.skip(testName, test);
  } else if (args.only) {
    it.only(testName, test);
  } else {
    it(testName, test);
  }
}
