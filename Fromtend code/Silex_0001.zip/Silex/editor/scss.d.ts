declare module '*.scss'
