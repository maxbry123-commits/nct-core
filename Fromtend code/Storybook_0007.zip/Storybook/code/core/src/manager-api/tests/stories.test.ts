import type { Mocked } from 'vitest';
import { describe, expect, it, vi } from 'vitest';

import {
  CONFIG_ERROR,
  CURRENT_STORY_WAS_SET,
  DOCS_PREPARED,
  RESET_STORY_ARGS,
  SET_CONFIG,
  SET_FILTER,
  SET_INDEX,
  SET_STORIES,
  STORY_ARGS_UPDATED,
  STORY_INDEX_INVALIDATED,
  STORY_MISSING,
  STORY_PREPARED,
  STORY_SPECIFIED,
  UPDATE_STORY_ARGS,
} from 'storybook/internal/core-events';
import { type API_StoryEntry, type StoryIndex } from 'storybook/internal/types';

import { global } from '@storybook/global';

import { EventEmitter } from 'events';

import { getEventMetadata as getEventMetadataOriginal } from '../lib/events.ts';
import type { ModuleArgs } from '../lib/types.tsx';
import { init as initStories } from '../modules/stories.ts';
import { parseStatusesParam, serializeStatusesParam } from '../modules/statuses.ts';
import type { API, State } from '../root.tsx';
import type Store from '../store.ts';
import { fullStatusStore } from '../stores/status.ts';
import {
  docsEntries,
  mockEntries,
  navigationEntries,
  preparedEntries,
} from './mockStoriesEntries.ts';

const mockGetEntries = vi.fn();
const fetch = vi.mocked(global.fetch);
const getEventMetadata = vi.mocked(getEventMetadataOriginal);

const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

vi.mock('../lib/events.ts', () => ({
  getEventMetadata: vi.fn(() => ({ sourceType: 'local' })),
}));
vi.mock('@storybook/global', () => ({
  global: {
    ...globalThis,
    fetch: vi.fn(() => ({ json: () => ({ v: 5, entries: mockGetEntries() }) })),
    CONFIG_TYPE: 'DEVELOPMENT',
  },
}));

function createMockStore(initialState: Partial<State> = {}) {
  let state = initialState;
  return {
    getState: vi.fn(() => state),
    setState: vi.fn((s: Partial<State> | ((s: Partial<State>) => Partial<State>)) => {
      if (typeof s === 'function') {
        state = { ...state, ...s(state) };
      } else {
        state = { ...state, ...s };
      }
      return Promise.resolve(state);
    }),
  } as any as Store;
}
function createMockProvider() {
  return {
    getConfig: vi.fn().mockReturnValue({}),
    channel: new EventEmitter(),
  };
}
function createMockModuleArgs({
  fullAPI = {},
  initialState = {},
}: {
  fullAPI?: Partial<Mocked<API>>;
  initialState?: Partial<State>;
}) {
  const navigate = vi.fn();
  const store = createMockStore({ filters: {}, status: {}, ...initialState });
  const provider = createMockProvider();

  return { navigate, store, provider, fullAPI: { ...fullAPI, getRefs: () => ({}) } };
}

describe('stories API', () => {
  it('sets a sensible initialState', () => {
    const moduleArgs = createMockModuleArgs({});
    const { state } = initStories({
      ...(moduleArgs as unknown as ModuleArgs),
      storyId: 'id',
      viewMode: 'story',
    });

    expect(state).toEqual(
      expect.objectContaining({
        previewInitialized: false,
        storyId: 'id',
        viewMode: 'story',
        hasCalledSetOptions: false,
      })
    );
  });

  describe('setIndex', () => {
    it('sets the initial set of stories in the stories hash', async () => {
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;
      api.setIndex({ v: 5, entries: mockEntries });
      const { index } = store.getState();
      // We need exact key ordering, even if in theory JS doesn't guarantee it
      expect(Object.keys(index!)).toEqual([
        'component-a',
        'component-a--docs',
        'component-a--story-1',
        'component-a--story-2',
        'component-b',
        'component-b--story-3',
      ]);
      expect(index!['component-a']).toMatchObject({
        type: 'component',
        id: 'component-a',
        children: ['component-a--docs', 'component-a--story-1', 'component-a--story-2'],
      });
      expect(index!['component-a--docs']).toMatchObject({
        type: 'docs',
        id: 'component-a--docs',
        parent: 'component-a',
        title: 'Component A',
        name: 'Docs',
        storiesImports: [],
        prepared: false,
      });
      expect(index!['component-a--story-1']).toMatchObject({
        type: 'story',
        subtype: 'story',
        id: 'component-a--story-1',
        parent: 'component-a',
        title: 'Component A',
        name: 'Story 1',
        prepared: false,
      });
      expect(
        (index!['component-a--story-1'] as API_StoryEntry as API_StoryEntry).args
      ).toBeUndefined();
    });
    it('trims whitespace of group/component names (which originate from the kind)', () => {
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;
      api.setIndex({
        v: 5,
        entries: {
          'design-system-some-component--my-story': {
            type: 'story',
            subtype: 'story',
            id: 'design-system-some-component--my-story',
            title: '  Design System  /  Some Component  ', // note the leading/trailing whitespace around each part of the path
            name: '  My Story  ', // we only trim the path, so this will be kept as-is (it may intentionally have whitespace)
            importPath: './path/to/some-component.ts',
          },
        },
      });
      const { index } = store.getState();
      // We need exact key ordering, even if in theory JS doesn't guarantee it
      expect(Object.keys(index!)).toEqual([
        'design-system',
        'design-system-some-component',
        'design-system-some-component--my-story',
      ]);
      expect(index!['design-system']).toMatchObject({
        type: 'root',
        name: 'Design System', // root name originates from `kind`, so it gets trimmed
        tags: [],
      });
      expect(index!['design-system-some-component']).toMatchObject({
        type: 'component',
        name: 'Some Component', // component name originates from `kind`, so it gets trimmed
      });
      expect(index!['design-system-some-component--my-story']).toMatchObject({
        type: 'story',
        subtype: 'story',
        title: '  Design System  /  Some Component  ', // title is kept as-is, because it may be used as identifier
        name: '  My Story  ', // story name is kept as-is, because it's set directly on the story
      });
    });
    it('moves rootless stories to the front of the list', async () => {
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;
      api.setIndex({
        v: 5,
        entries: {
          'root-first--story-1': {
            type: 'story',
            subtype: 'story',
            id: 'root-first--story-1',
            title: 'Root/First',
            name: 'Story 1',
            importPath: './path/to/root/first.ts',
            tags: [],
          },
          ...mockEntries,
        },
      });
      const { index } = store.getState();
      // We need exact key ordering, even if in theory JS doesn't guarantee it
      expect(Object.keys(index!)).toEqual([
        'component-a',
        'component-a--docs',
        'component-a--story-1',
        'component-a--story-2',
        'component-b',
        'component-b--story-3',
        'root',
        'root-first',
        'root-first--story-1',
      ]);
      expect(index!.root).toMatchObject({
        type: 'root',
        id: 'root',
        children: ['root-first'],
        tags: [],
      });
    });
    it('sets roots when showRoots = true', () => {
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store, provider } = moduleArgs;
      provider.getConfig.mockReturnValue({ sidebar: { showRoots: true } });
      api.setIndex({
        v: 5,
        entries: {
          'a-b--1': {
            type: 'story',
            subtype: 'story',
            id: 'a-b--1',
            title: 'a/b',
            name: '1',
            tags: [],
            importPath: './a/b.ts',
          },
        },
      });
      const { index } = store.getState();
      // We need exact key ordering, even if in theory JS doesn't guarantee it
      expect(Object.keys(index!)).toEqual(['a', 'a-b', 'a-b--1']);
      expect(index!.a).toMatchObject({
        type: 'root',
        id: 'a',
        children: ['a-b'],
        tags: [],
      });
      expect(index!['a-b']).toMatchObject({
        type: 'component',
        id: 'a-b',
        parent: 'a',
        children: ['a-b--1'],
      });
      expect(index!['a-b--1']).toMatchObject({
        type: 'story',
        subtype: 'story',
        id: 'a-b--1',
        parent: 'a-b',
        name: '1',
        title: 'a/b',
      });
    });
    it('does not put bare stories into a root when showRoots = true', () => {
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store, provider } = moduleArgs;
      provider.getConfig.mockReturnValue({ sidebar: { showRoots: true } });
      api.setIndex({
        v: 5,
        entries: {
          'a--1': {
            type: 'story',
            subtype: 'story',
            id: 'a--1',
            title: 'a',
            name: '1',
            importPath: './a.ts',
          },
        },
      });
      const { index } = store.getState();
      // We need exact key ordering, even if in theory JS doesn't guarantee it
      expect(Object.keys(index!)).toEqual(['a', 'a--1']);
      expect(index!.a).toMatchObject({
        type: 'component',
        id: 'a',
        children: ['a--1'],
      });
      expect(index!['a--1']).toMatchObject({
        type: 'story',
        subtype: 'story',
        id: 'a--1',
        parent: 'a',
        title: 'a',
        name: '1',
      });
    });
    it('intersects story/docs tags to compute tags for component entries', () => {
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;
      api.setIndex({
        v: 5,
        entries: {
          'a--1': {
            type: 'story',
            subtype: 'story',
            id: 'a--1',
            title: 'a',
            name: '1',
            tags: ['shared', 'one-specific'],
            importPath: './a.ts',
          },
          'a--2': {
            type: 'story',
            subtype: 'story',
            id: 'a--2',
            title: 'a',
            name: '2',
            tags: ['shared', 'two-specific'],
            importPath: './a.ts',
          },
        },
      });
      const { index } = store.getState();
      // We need exact key ordering, even if in theory JS doesn't guarantee it
      expect(Object.keys(index!)).toEqual(['a', 'a--1', 'a--2']);
      expect(index!.a).toMatchObject({
        type: 'component',
        id: 'a',
        tags: ['shared'],
        children: ['a--1', 'a--2'],
      });
      expect(index!['a--1']).toMatchObject({
        type: 'story',
        subtype: 'story',
        id: 'a--1',
        parent: 'a',
        title: 'a',
        name: '1',
        tags: ['shared', 'one-specific'],
      });
      expect(index!['a--2']).toMatchObject({
        type: 'story',
        subtype: 'story',
        id: 'a--2',
        parent: 'a',
        title: 'a',
        name: '2',
        tags: ['shared', 'two-specific'],
      });
    });

    it('intersects story/docs tags to compute tags for root and group entries', () => {
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;
      api.setIndex({
        v: 5,
        entries: {
          'a-sampleone': {
            type: 'story',
            subtype: 'story',
            id: 'a-sampleone',
            title: 'A/SampleOne',
            name: '1',
            tags: ['shared', 'one-specific'],
            importPath: './a.ts',
          },
          'a-sampletwo': {
            type: 'story',
            subtype: 'story',
            id: 'a-sampletwo',
            title: 'A/SampleTwo',
            name: '2',
            tags: ['shared', 'two-specific'],
            importPath: './a.ts',
          },
          'a-embedded-othertopic': {
            type: 'docs',
            id: 'a-embedded-othertopic',
            title: 'A/Embedded/OtherTopic',
            name: '3',
            tags: ['shared', 'embedded-docs-specific', 'other'],
            storiesImports: [],
            importPath: './embedded/other.mdx',
          },
          'a-embedded-extras': {
            type: 'docs',
            id: 'a-embedded-extras',
            title: 'A/Embedded/Extras',
            name: '3',
            tags: ['shared', 'embedded-docs-specific', 'extras'],
            storiesImports: [],
            importPath: './embedded/extras.mdx',
          },
        },
      });
      const { index } = store.getState();
      // We need exact key ordering, even if in theory JS doesn't guarantee it
      expect(Object.keys(index!)).toEqual([
        'a',
        'a-sampleone',
        'a-sampletwo',
        'a-embedded',
        'a-embedded-othertopic',
        'a-embedded-extras',
      ]);
      // Acts as the root, so that the next level is a group we're testing.
      expect(index!.a).toMatchObject({
        type: 'root',
        id: 'a',
        children: ['a-sampleone', 'a-sampletwo', 'a-embedded'],
        tags: ['shared'],
      });
      // The object of this test.
      expect(index!['a-embedded']).toMatchObject({
        type: 'group',
        id: 'a-embedded',
        parent: 'a',
        name: 'Embedded',
        tags: ['shared', 'embedded-docs-specific'],
      });
    });
    // Stories can get out of order for a few reasons -- see reproductions on
    //   https://github.com/storybookjs/storybook/issues/5518
    it('does the right thing for out of order stories', async () => {
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store, provider } = moduleArgs;
      provider.getConfig.mockReturnValue({ sidebar: { showRoots: true } });
      api.setIndex({
        v: 5,
        entries: {
          'a--1': {
            type: 'story',
            subtype: 'story',
            title: 'a',
            name: '1',
            id: 'a--1',
            importPath: './a.ts',
          },
          'b--1': {
            type: 'story',
            subtype: 'story',
            title: 'b',
            name: '1',
            id: 'b--1',
            importPath: './b.ts',
          },
          'a--2': {
            type: 'story',
            subtype: 'story',
            title: 'a',
            name: '2',
            id: 'a--2',
            importPath: './a.ts',
          },
        },
      });
      const { index } = store.getState();
      // We need exact key ordering, even if in theory JS doesn't guarantee it
      expect(Object.keys(index!)).toEqual(['a', 'a--1', 'a--2', 'b', 'b--1']);
      expect(index!.a).toMatchObject({
        type: 'component',
        id: 'a',
        children: ['a--1', 'a--2'],
      });
      expect(index!.b).toMatchObject({
        type: 'component',
        id: 'b',
        children: ['b--1'],
      });
    });
    // Entries on the SET_STORIES event will be prepared
    it('handles properly prepared stories', async () => {
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;
      api.setIndex({
        v: 5,
        entries: {
          'prepared--story': {
            type: 'story',
            subtype: 'story',
            id: 'prepared--story',
            title: 'Prepared',
            name: 'Story',
            importPath: './path/to/prepared.ts',
            parameters: { parameter: 'exists' },
            args: { arg: 'exists' },
          },
        },
      });
      const { index } = store.getState();
      expect(index!['prepared--story']).toMatchObject({
        type: 'story',
        subtype: 'story',
        id: 'prepared--story',
        parent: 'prepared',
        title: 'Prepared',
        name: 'Story',
        prepared: true,
        parameters: { parameter: 'exists' },
        args: { arg: 'exists' },
      });
    });
    it('retains prepared-ness of stories', async () => {
      const fullAPI = { setOptions: vi.fn() };
      const moduleArgs = createMockModuleArgs({ fullAPI });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store, provider } = moduleArgs;
      api.setIndex({ v: 5, entries: mockEntries });
      provider.channel.emit(STORY_PREPARED, {
        id: 'component-a--story-1',
        parameters: { a: 'b' },
        args: { c: 'd' },
      });
      // Let the promise/await chain resolve
      await new Promise((r) => setTimeout(r, 0));
      expect(store.getState().index!['component-a--story-1'] as API_StoryEntry).toMatchObject({
        prepared: true,
        parameters: { a: 'b' },
        args: { c: 'd' },
      });
      api.setIndex({ v: 5, entries: mockEntries });
      // Let the promise/await chain resolve
      await new Promise((r) => setTimeout(r, 0));
      expect(store.getState().index!['component-a--story-1'] as API_StoryEntry).toMatchObject({
        prepared: true,
        parameters: { a: 'b' },
        args: { c: 'd' },
      });
    });

    describe('docs entries', () => {
      it('handles docs entries', async () => {
        const moduleArgs = createMockModuleArgs({});
        const { api } = initStories(moduleArgs as unknown as ModuleArgs);
        const { store } = moduleArgs;

        api.setIndex({ v: 5, entries: docsEntries });
        const { index } = store.getState();
        // We need exact key ordering, even if in theory JS doesn't guarantee it
        expect(Object.keys(index!)).toEqual([
          'component-a',
          'component-a--page',
          'component-a--story-2',
          'component-b',
          'component-b--docs',
          'component-c',
          'component-c--story-4',
        ]);
        expect(index!['component-a--page'].type).toBe('story');
        expect(index!['component-a--story-2'].type).toBe('story');
        expect(index!['component-b--docs'].type).toBe('docs');
        expect(index!['component-c--story-4'].type).toBe('story');
      });
      describe('when DOCS_MODE = true', () => {
        it('strips out story entries', async () => {
          const moduleArgs = createMockModuleArgs({});
          const { api } = initStories({
            ...(moduleArgs as unknown as ModuleArgs),
            docsOptions: { docsMode: true },
          });
          const { store } = moduleArgs;
          api.setIndex({ v: 5, entries: docsEntries });
          const { index } = store.getState();
          expect(Object.keys(index!)).toEqual(['component-b', 'component-b--docs']);
        });
      });
    });
  });

  describe('SET_INDEX event', () => {
    it('calls setIndex w/ the data', () => {
      const fullAPI = { setOptions: vi.fn() };
      const moduleArgs = createMockModuleArgs({ fullAPI });
      initStories(moduleArgs as unknown as ModuleArgs);
      const { store, provider } = moduleArgs;

      provider.channel.emit(SET_INDEX, { v: 5, entries: mockEntries });
      expect(store.getState().index).toEqual(
        expect.objectContaining({
          'component-a': expect.any(Object),
          'component-a--docs': expect.any(Object),
          'component-a--story-1': expect.any(Object),
        })
      );
    });
    it('calls setOptions w/ first story parameter', () => {
      const fullAPI = { setOptions: vi.fn() };
      const moduleArgs = createMockModuleArgs({ fullAPI });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { provider } = moduleArgs;

      // HACK api to effectively mock getCurrentParameter
      Object.assign(api, {
        getCurrentParameter: vi.fn().mockReturnValue('options'),
      });

      provider.channel.emit(SET_INDEX, { v: 5, entries: mockEntries });
      expect(fullAPI.setOptions).toHaveBeenCalledWith('options');
    });
  });

  describe('fetchIndex', () => {
    it('deals with 500 errors', async () => {
      fetch.mockReturnValue(
        Promise.resolve({
          status: 500,
          text: async () => new Error('sorting error'),
        } as any as Response)
      );
      const moduleArgs = createMockModuleArgs({});
      const { init } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;

      await init!();

      const { indexError } = store.getState();
      expect(indexError).toBeDefined();
    });
    it('watches for the INVALIDATE event and re-fetches -- and resets the hash', async () => {
      fetch.mockReturnValue(
        Promise.resolve({
          status: 200,
          ok: true,
          json: () => ({
            v: 5,
            entries: {
              'component-a--story-1': {
                type: 'story',
                subtype: 'story',
                id: 'component-a--story-1',
                title: 'Component A',
                name: 'Story 1',
                importPath: './path/to/component-a.ts',
              },
            },
          }),
        } as any as Response)
      );

      const moduleArgs = createMockModuleArgs({});
      const { init } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store, provider } = moduleArgs;

      await init!();

      expect(fetch).toHaveBeenCalledTimes(1);
      provider.channel.emit(STORY_INDEX_INVALIDATED);
      expect(global.fetch).toHaveBeenCalledTimes(2);

      // this side-effect is in an un-awaited promise.
      await wait(16);

      const { index } = store.getState();
      expect(Object.keys(index!)).toEqual(['component-a', 'component-a--story-1']);
    });
    it('clears 500 errors when invalidated', async () => {
      fetch.mockReturnValueOnce(
        Promise.resolve({
          status: 500,
          text: async () => new Error('sorting error'),
        } as any as Response)
      );
      const moduleArgs = createMockModuleArgs({});
      const { init } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store, provider } = moduleArgs;

      await init!();

      const { indexError } = store.getState();
      expect(indexError).toBeDefined();

      fetch.mockReturnValueOnce(
        Promise.resolve({
          status: 200,
          ok: true,
          json: () => ({
            v: 5,
            entries: {
              'component-a--story-1': {
                type: 'story',
                subtype: 'story',
                id: 'component-a--story-1',
                title: 'Component A',
                name: 'Story 1',
                importPath: './path/to/component-a.ts',
              },
            },
          }),
        } as any as Response)
      );

      provider.channel.emit(STORY_INDEX_INVALIDATED);
      expect(global.fetch).toHaveBeenCalledTimes(2);

      // this side-effect is in an un-awaited promise.
      await wait(16);

      const { index, indexError: newIndexError } = store.getState();
      expect(newIndexError).not.toBeDefined();
      expect(Object.keys(index!)).toEqual(['component-a', 'component-a--story-1']);
    });
  });

  describe('STORY_SPECIFIED event', () => {
    it('navigates to the story', async () => {
      const moduleArgs = createMockModuleArgs({ initialState: { path: '/', index: {} } });
      initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate, provider } = moduleArgs;

      provider.channel.emit(STORY_SPECIFIED, { storyId: 'a--1', viewMode: 'story' });
      expect(navigate).toHaveBeenCalledWith('/story/a--1', undefined);
    });
    it('DOES not navigate if the story was already selected', async () => {
      const moduleArgs = createMockModuleArgs({ initialState: { path: '/story/a--1', index: {} } });
      initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate, provider } = moduleArgs;

      provider.channel.emit(STORY_SPECIFIED, { storyId: 'a--1', viewMode: 'story' });
      expect(navigate).not.toHaveBeenCalled();
    });
    it('DOES not navigate if a settings page was selected', async () => {
      const moduleArgs = createMockModuleArgs({
        initialState: { path: '/settings/about', index: {} },
      });
      initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate, provider } = moduleArgs;

      provider.channel.emit(STORY_SPECIFIED, { storyId: 'a--1', viewMode: 'story' });
      expect(navigate).not.toHaveBeenCalled();
    });
    it('DOES not navigate if a custom page was selected', async () => {
      const moduleArgs = createMockModuleArgs({
        initialState: { path: '/custom/page', index: {} },
      });
      initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate, provider } = moduleArgs;

      provider.channel.emit(STORY_SPECIFIED, { storyId: 'a--1', viewMode: 'story' });
      expect(navigate).not.toHaveBeenCalled();
    });
  });

  describe('CURRENT_STORY_WAS_SET event', () => {
    it('sets previewInitialized', async () => {
      const moduleArgs = createMockModuleArgs({});
      initStories(moduleArgs as unknown as ModuleArgs);
      const { store, provider } = moduleArgs;
      provider.channel.emit(CURRENT_STORY_WAS_SET, { id: 'a--1' });

      expect(store.getState().previewInitialized).toBe(true);
    });
    it('sets a ref to previewInitialized', async () => {
      const fullAPI = { updateRef: vi.fn() };
      const moduleArgs = createMockModuleArgs({ fullAPI });
      initStories(moduleArgs as unknown as ModuleArgs);
      const { provider } = moduleArgs;
      provider.channel.emit(CURRENT_STORY_WAS_SET, { id: 'a--1' });

      getEventMetadata.mockReturnValueOnce({
        sourceType: 'external',
        refId: 'refId',
        source: '',
        sourceLocation: '',
        type: '',
        ref: { id: 'refId', index: { 'a--1': { args: { a: 'b' } } } } as any,
      });
      provider.channel.emit(CURRENT_STORY_WAS_SET, { id: 'a--1' });
      expect(fullAPI.updateRef.mock.calls.length).toBe(1);
      expect(fullAPI.updateRef.mock.calls[0][1]).toEqual({
        previewInitialized: true,
      });
    });
  });

  describe('args handling', () => {
    it('changes args properly, per story when receiving STORY_ARGS_UPDATED', () => {
      const fullAPI = { updateRef: vi.fn() };
      const moduleArgs = createMockModuleArgs({ fullAPI });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { provider, store } = moduleArgs;

      api.setIndex({ v: 5, entries: preparedEntries });
      const { index } = store.getState();
      expect((index!['a--1'] as API_StoryEntry).args).toEqual({ a: 'b' });
      expect((index!['b--1'] as API_StoryEntry).args).toEqual({ x: 'y' });
      provider.channel.emit(STORY_ARGS_UPDATED, { storyId: 'a--1', args: { foo: 'bar' } });
      const { index: changedIndex } = store.getState();
      expect((changedIndex!['a--1'] as API_StoryEntry).args).toEqual({ foo: 'bar' });
      expect((changedIndex!['b--1'] as API_StoryEntry).args).toEqual({ x: 'y' });
    });
    it('changes reffed args properly, per story when receiving STORY_ARGS_UPDATED', () => {
      const fullAPI = { updateRef: vi.fn() };
      const moduleArgs = createMockModuleArgs({ fullAPI });
      initStories(moduleArgs as unknown as ModuleArgs);
      const { provider } = moduleArgs;

      getEventMetadata.mockReturnValueOnce({
        sourceType: 'external',
        refId: 'refId',
        source: '',
        sourceLocation: '',
        type: '',
        ref: {
          id: 'refId',
          index: { 'a--1': { args: { a: 'b' } } },
          filteredIndex: { 'a--1': { args: { a: 'b' } } },
        } as any,
      });
      provider.channel.emit(STORY_ARGS_UPDATED, { storyId: 'a--1', args: { foo: 'bar' } });
      expect(fullAPI.updateRef).toHaveBeenCalledWith('refId', {
        filteredIndex: { 'a--1': { args: { foo: 'bar' } } },
        index: { 'a--1': { args: { foo: 'bar' } } },
        // Runtime enrichment is also cached on the ref so it survives index rebuilds (#34553).
        storyUpdates: { 'a--1': { args: { foo: 'bar' } } },
      });
    });
    it('updateStoryArgs emits UPDATE_STORY_ARGS to the local frame and does not change anything', () => {
      const fullAPI = { updateRef: vi.fn() };
      const moduleArgs = createMockModuleArgs({ fullAPI });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { provider, store } = moduleArgs;

      const listener = vi.fn();
      provider.channel.on(UPDATE_STORY_ARGS, listener);

      api.setIndex({ v: 5, entries: preparedEntries });
      api.updateStoryArgs({ id: 'a--1' } as API_StoryEntry, { foo: 'bar' });

      expect(listener).toHaveBeenCalledWith({
        storyId: 'a--1',
        updatedArgs: { foo: 'bar' },
        options: {
          target: undefined,
        },
      });

      const { index } = store.getState();
      expect((index!['a--1'] as API_StoryEntry).args).toEqual({ a: 'b' });
      expect((index!['b--1'] as API_StoryEntry).args).toEqual({ x: 'y' });
    });
    it('updateStoryArgs emits UPDATE_STORY_ARGS to the right frame', () => {
      const fullAPI = { updateRef: vi.fn() };
      const moduleArgs = createMockModuleArgs({ fullAPI });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { provider } = moduleArgs;

      const listener = vi.fn();
      provider.channel.on(UPDATE_STORY_ARGS, listener);

      api.setIndex({ v: 5, entries: preparedEntries });
      api.updateStoryArgs({ id: 'a--1', refId: 'refId' } as API_StoryEntry, { foo: 'bar' });
      expect(listener).toHaveBeenCalledWith({
        storyId: 'a--1',
        updatedArgs: { foo: 'bar' },
        options: {
          target: 'refId',
        },
      });
    });
    it('refId to the local frame and does not change anything', () => {
      const fullAPI = { updateRef: vi.fn() };
      const moduleArgs = createMockModuleArgs({ fullAPI });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { provider, store } = moduleArgs;
      const listener = vi.fn();
      provider.channel.on(RESET_STORY_ARGS, listener);

      api.setIndex({ v: 5, entries: preparedEntries });
      api.resetStoryArgs({ id: 'a--1' } as API_StoryEntry, ['foo']);

      expect(listener).toHaveBeenCalledWith({
        storyId: 'a--1',
        argNames: ['foo'],
        options: {
          target: undefined,
        },
      });

      const { index } = store.getState();
      expect((index!['a--1'] as API_StoryEntry).args).toEqual({ a: 'b' });
      expect((index!['b--1'] as API_StoryEntry).args).toEqual({ x: 'y' });
    });
    it('resetStoryArgs emits RESET_STORY_ARGS to the right frame', () => {
      const fullAPI = { updateRef: vi.fn() };
      const moduleArgs = createMockModuleArgs({ fullAPI });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { provider } = moduleArgs;

      const listener = vi.fn();
      provider.channel.on(RESET_STORY_ARGS, listener);

      api.setIndex({ v: 5, entries: preparedEntries });
      api.resetStoryArgs({ id: 'a--1', refId: 'refId' } as API_StoryEntry, ['foo']);
      expect(listener).toHaveBeenCalledWith({
        storyId: 'a--1',
        argNames: ['foo'],
        options: {
          target: 'refId',
        },
      });
    });
  });

  describe('jumpToStory', () => {
    it('works forward', () => {
      const initialState = { path: '/story/a--1', storyId: 'a--1', viewMode: 'story' };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate } = moduleArgs;

      api.setIndex({ v: 5, entries: navigationEntries });
      api.jumpToStory(1);

      expect(navigate).toHaveBeenCalledWith('/story/a--2', undefined);
    });
    it('works backwards', () => {
      const initialState = { path: '/story/a--2', storyId: 'a--2', viewMode: 'story' };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate } = moduleArgs;

      api.setIndex({ v: 5, entries: navigationEntries });
      api.jumpToStory(-1);

      expect(navigate).toHaveBeenCalledWith('/story/a--1', undefined);
    });
    it('does nothing if you are at the last story and go forward', () => {
      const initialState = {
        path: '/story/custom-id--1',
        storyId: 'custom-id--1',
        viewMode: 'story',
      };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate } = moduleArgs;

      api.setIndex({ v: 5, entries: navigationEntries });
      api.jumpToStory(1);
      expect(navigate).not.toHaveBeenCalled();
    });
    it('does nothing if you are at the first story and go backward', () => {
      const initialState = { path: '/story/a--1', storyId: 'a--1', viewMode: 'story' };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate } = moduleArgs;

      api.setIndex({ v: 5, entries: navigationEntries });
      api.jumpToStory(-1);
      expect(navigate).not.toHaveBeenCalled();
    });
    it('does nothing if you have not selected a story', () => {
      const initialState = { path: '/story', storyId: undefined, viewMode: 'story' };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate } = moduleArgs;

      api.setIndex({ v: 5, entries: navigationEntries });
      api.jumpToStory(1);
      expect(navigate).not.toHaveBeenCalled();
    });
  });

  describe('findSiblingStoryId', () => {
    it('works forward', () => {
      const initialState = { path: '/story/a--1', storyId: 'a--1', viewMode: 'story' };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;

      api.setIndex({ v: 5, entries: navigationEntries });
      const result = api.findSiblingStoryId('a--1', store.getState().index!, 1, false);
      expect(result).toBe('a--2');
    });
    it('works forward toSiblingGroup', () => {
      const initialState = { path: '/story/a--1', storyId: 'a--1', viewMode: 'story' };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;

      api.setIndex({ v: 5, entries: navigationEntries });
      const result = api.findSiblingStoryId('a--1', store.getState().index!, 1, true);
      expect(result).toBe('b-c--1');
    });
  });
  describe('findAllLeafStoryIds', () => {
    it('work for a leaf story', () => {
      const initialState = { path: '/story/a--1', storyId: 'a--1', viewMode: 'story' };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);

      api.setIndex({ v: 5, entries: navigationEntries });
      const result = api.findAllLeafStoryIds('a--1');
      expect(result).toEqual(['a--1']);
    });
    it('work for an entry with children', () => {
      const initialState = {
        path: '/story/group-a/component-a',
        storyId: 'component-a--story-1',
        viewMode: 'story',
      };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);

      api.setIndex({
        v: 5,
        entries: mockEntries,
      });
      const result = api.findAllLeafStoryIds('component-a');
      expect(result).toEqual(['component-a--story-1', 'component-a--story-2']);
    });
  });
  describe('jumpToComponent', () => {
    it('works forward', () => {
      const initialState = { path: '/story/a--1', storyId: 'a--1', viewMode: 'story' };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate } = moduleArgs;

      api.setIndex({ v: 5, entries: navigationEntries });
      api.jumpToComponent(1);
      expect(navigate).toHaveBeenCalledWith('/story/b-c--1', undefined);
    });
    it('works backwards', () => {
      const initialState = {
        path: '/story/b-c--1',
        storyId: 'b-c--1',
        viewMode: 'story',
      };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate } = moduleArgs;

      api.setIndex({ v: 5, entries: navigationEntries });
      api.jumpToComponent(-1);
      expect(navigate).toHaveBeenCalledWith('/story/a--1', undefined);
    });
    it('does nothing if you are in the last component and go forward', () => {
      const initialState = {
        path: '/story/custom-id--1',
        storyId: 'custom-id--1',
        viewMode: 'story',
      };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate } = moduleArgs;

      api.setIndex({ v: 5, entries: navigationEntries });
      api.jumpToComponent(1);
      expect(navigate).not.toHaveBeenCalled();
    });
    it('does nothing if you are at the first component and go backward', () => {
      const initialState = { path: '/story/a--2', storyId: 'a--2', viewMode: 'story' };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate } = moduleArgs;

      api.setIndex({ v: 5, entries: navigationEntries });
      api.jumpToComponent(-1);
      expect(navigate).not.toHaveBeenCalled();
    });
  });
  describe('selectStory', () => {
    it('navigates', () => {
      const initialState = { path: '/story/a--1', storyId: 'a--1', viewMode: 'story' };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate } = moduleArgs;

      api.setIndex({ v: 5, entries: navigationEntries });
      api.selectStory('a--2');
      expect(navigate).toHaveBeenCalledWith('/story/a--2', undefined);
    });
    it('sets view mode to docs if doc-level component is selected', () => {
      const initialState = { path: '/docs/a--1', storyId: 'a--1', viewMode: 'docs' };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate } = moduleArgs;

      api.setIndex({
        v: 5,
        entries: {
          ...navigationEntries,
          'intro--docs': {
            type: 'docs',
            id: 'intro--docs',
            title: 'Intro',
            name: 'Page',
            importPath: './intro.mdx',
            storiesImports: [],
          },
        },
      });
      api.selectStory('intro');
      expect(navigate).toHaveBeenCalledWith('/docs/intro--docs', undefined);
    });
    it('updates lastTrackedStoryId', () => {
      const initialState = { path: '/story/a--1', storyId: 'a--1', viewMode: 'story' };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;

      api.setIndex({ v: 5, entries: navigationEntries });
      api.selectStory('a--1');
      expect(store.getState().settings.lastTrackedStoryId).toBe('a--1');
    });
    it('selects first visible child when component is clicked with filtered index', () => {
      const initialState = { path: '/story/a--1', storyId: 'a--1', viewMode: 'story' };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate, store } = moduleArgs;

      // Set index with stories
      api.setIndex({ v: 5, entries: navigationEntries });

      // Set up filtered index where first child (a--1) is hidden
      const filteredIndex = {
        a: {
          id: 'a',
          type: 'component' as const,
          name: 'a',
          depth: 0,
          tags: [],
          children: ['a--1', 'a--2'],
          importPath: './a.ts',
        },
        'a--2': {
          ...navigationEntries['a--2'],
          type: 'story' as const,
          subtype: 'story' as const,
          parent: 'a',
          depth: 1,
          tags: [],
          prepared: false,
          exportName: '2',
        },
        // Note: 'a--1' is missing from filtered index (hidden)
      };

      store.setState({ filteredIndex });

      // When selecting the component, it should select the first visible child (a--2)
      api.selectStory('a');
      expect(navigate).toHaveBeenCalledWith('/story/a--2', undefined);
    });
    describe('deprecated api', () => {
      it('allows navigating to a combination of title + name', () => {
        const initialState = { path: '/story/a--1', storyId: 'a--1', viewMode: 'story' };
        const moduleArgs = createMockModuleArgs({ initialState });
        const { api } = initStories(moduleArgs as unknown as ModuleArgs);
        const { navigate } = moduleArgs;

        api.setIndex({ v: 5, entries: navigationEntries });
        api.selectStory('a', '2');
        expect(navigate).toHaveBeenCalledWith('/story/a--2', undefined);
      });
      it('allows navigating to a given name (in the current component)', () => {
        const initialState = { path: '/story/a--1', storyId: 'a--1', viewMode: 'story' };
        const moduleArgs = createMockModuleArgs({ initialState });
        const { api } = initStories(moduleArgs as unknown as ModuleArgs);
        const { navigate } = moduleArgs;

        api.setIndex({ v: 5, entries: navigationEntries });
        api.selectStory(undefined, '2');
        expect(navigate).toHaveBeenCalledWith('/story/a--2', undefined);
      });
    });
    it('allows navigating away from the settings pages', () => {
      const initialState = { path: '/settings/a--1', storyId: 'a--1', viewMode: 'settings' };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate } = moduleArgs;

      api.setIndex({ v: 5, entries: navigationEntries });
      api.selectStory('a--2');
      expect(navigate).toHaveBeenCalledWith('/story/a--2', undefined);
    });
    it('allows navigating to first story in component on call by component id', () => {
      const initialState = { path: '/story/a--1', storyId: 'a--1', viewMode: 'story' };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate } = moduleArgs;

      api.setIndex({ v: 5, entries: navigationEntries });
      api.selectStory('a');
      expect(navigate).toHaveBeenCalledWith('/story/a--1', undefined);
    });
    it('allows navigating to first story in group on call by group id', () => {
      const initialState = { path: '/story/a--1', storyId: 'a--1', viewMode: 'story' };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate } = moduleArgs;

      api.setIndex({ v: 5, entries: navigationEntries });
      api.selectStory('b');
      expect(navigate).toHaveBeenCalledWith('/story/b-c--1', undefined);
    });
    it('allows navigating to first story in component on call by title', () => {
      const initialState = { path: '/story/a--1', storyId: 'a--1', viewMode: 'story' };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate } = moduleArgs;

      api.setIndex({ v: 5, entries: navigationEntries });
      api.selectStory('A');
      expect(navigate).toHaveBeenCalledWith('/story/a--1', undefined);
    });
    it('allows navigating to the first story of the current component if passed nothing', () => {
      const initialState = { path: '/story/a--1', storyId: 'a--1', viewMode: 'story' };
      const moduleArgs = createMockModuleArgs({ initialState });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate } = moduleArgs;

      api.setIndex({ v: 5, entries: navigationEntries });
      api.selectStory();
      expect(navigate).toHaveBeenCalledWith('/story/a--1', undefined);
    });
    describe('component permalinks', () => {
      it('allows navigating to kind/storyname (legacy api)', () => {
        const initialState = { path: '/story/a--1', storyId: 'a--1', viewMode: 'story' };
        const moduleArgs = createMockModuleArgs({ initialState });
        const { api } = initStories(moduleArgs as unknown as ModuleArgs);
        const { navigate } = moduleArgs;

        api.setIndex({ v: 5, entries: navigationEntries });
        api.selectStory('b/e', '1');
        expect(navigate).toHaveBeenCalledWith('/story/custom-id--1', undefined);
      });
      it('allows navigating to component permalink/storyname (legacy api)', () => {
        const initialState = { path: '/story/a--1', storyId: 'a--1', viewMode: 'story' };
        const moduleArgs = createMockModuleArgs({ initialState });
        const { api } = initStories(moduleArgs as unknown as ModuleArgs);
        const { navigate } = moduleArgs;

        api.setIndex({ v: 5, entries: navigationEntries });
        api.selectStory('custom-id', '1');
        expect(navigate).toHaveBeenCalledWith('/story/custom-id--1', undefined);
      });
      it('allows navigating to first story in kind on call by kind', () => {
        const initialState = { path: '/story/a--1', storyId: 'a--1', viewMode: 'story' };
        const moduleArgs = createMockModuleArgs({ initialState });
        const { api } = initStories(moduleArgs as unknown as ModuleArgs);
        const { navigate } = moduleArgs;

        api.setIndex({ v: 5, entries: navigationEntries });
        api.selectStory('b/e');
        expect(navigate).toHaveBeenCalledWith('/story/custom-id--1', undefined);
      });
    });
  });
  describe('STORY_PREPARED', () => {
    it('prepares the story', async () => {
      const fullAPI = { setOptions: vi.fn() };
      const initialState = { path: '/story/a--1', storyId: 'a--1', viewMode: 'story' };
      const moduleArgs = createMockModuleArgs({ initialState, fullAPI });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { provider, store } = moduleArgs;

      api.setIndex({ v: 5, entries: mockEntries });

      provider.channel.emit(STORY_PREPARED, {
        id: 'component-a--story-1',
        parameters: { a: 'b' },
        args: { c: 'd' },
      });
      const { index } = store.getState();
      expect(index!['component-a--story-1']).toMatchObject({
        type: 'story',
        subtype: 'story',
        id: 'component-a--story-1',
        parent: 'component-a',
        title: 'Component A',
        name: 'Story 1',
        prepared: true,
        parameters: { a: 'b' },
        args: { c: 'd' },
      });
    });
    it('sets options the first time it is called', async () => {
      const fullAPI = { setOptions: vi.fn() };
      const initialState = { path: '/story/a--1', storyId: 'a--1', viewMode: 'story' };
      const moduleArgs = createMockModuleArgs({ initialState, fullAPI });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { provider } = moduleArgs;

      api.setIndex({ v: 5, entries: mockEntries });

      provider.channel.emit(STORY_PREPARED, {
        id: 'component-a--story-1',
        parameters: { options: 'options' },
      });
      expect(fullAPI.setOptions).toHaveBeenCalledWith('options');

      fullAPI.setOptions.mockClear();

      provider.channel.emit(STORY_PREPARED, {
        id: 'component-a--story-1',
        parameters: { options: 'options2' },
      });
      expect(fullAPI.setOptions).not.toHaveBeenCalled();
    });
  });
  describe('DOCS_PREPARED', () => {
    it('prepares the docs entry', async () => {
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { provider, store } = moduleArgs;

      api.setIndex({ v: 5, entries: mockEntries });

      provider.channel.emit(DOCS_PREPARED, {
        id: 'component-a--docs',
        parameters: { a: 'b' },
      });
      const { index } = store.getState();
      expect(index!['component-a--docs']).toMatchObject({
        type: 'docs',
        id: 'component-a--docs',
        parent: 'component-a',
        title: 'Component A',
        name: 'Docs',
        prepared: true,
        parameters: { a: 'b' },
      });
    });
  });
  describe('CONFIG_ERROR', () => {
    it('sets previewInitialized to true, local', async () => {
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { provider, store } = moduleArgs;

      api.setIndex({ v: 5, entries: mockEntries });

      provider.channel.emit(CONFIG_ERROR, { message: 'Failed to run configure' });
      const { previewInitialized } = store.getState();
      expect(previewInitialized).toBe(true);
    });
    it('sets previewInitialized to true, ref', async () => {
      const fullAPI = { updateRef: vi.fn() };
      const moduleArgs = createMockModuleArgs({ fullAPI });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { provider } = moduleArgs;

      api.setIndex({ v: 5, entries: mockEntries });

      getEventMetadata.mockReturnValueOnce({
        sourceType: 'external',
        ref: { id: 'refId', stories: { 'a--1': { args: { a: 'b' } } } },
      } as any);
      provider.channel.emit(CONFIG_ERROR, { message: 'Failed to run configure' });
      expect(fullAPI.updateRef.mock.calls.length).toBe(1);
      expect(fullAPI.updateRef.mock.calls[0][1]).toEqual({
        previewInitialized: true,
      });
    });
  });
  describe('STORY_MISSING', () => {
    it('sets previewInitialized to true, local', async () => {
      const moduleArgs = createMockModuleArgs({});
      initStories(moduleArgs as unknown as ModuleArgs);
      const { provider, store } = moduleArgs;

      provider.channel.emit(STORY_MISSING, { message: 'Failed to run configure' });
      const { previewInitialized } = store.getState();
      expect(previewInitialized).toBe(true);
    });
    it('sets previewInitialized to true, ref', async () => {
      const fullAPI = { updateRef: vi.fn() };
      const moduleArgs = createMockModuleArgs({ fullAPI });
      initStories(moduleArgs as unknown as ModuleArgs);
      const { provider } = moduleArgs;

      getEventMetadata.mockReturnValueOnce({
        sourceType: 'external',
        ref: { id: 'refId', stories: { 'a--1': { args: { a: 'b' } } } },
      } as any);
      provider.channel.emit(STORY_MISSING, { message: 'Failed to run configure' });
      expect(fullAPI.updateRef.mock.calls.length).toBe(1);
      expect(fullAPI.updateRef.mock.calls[0][1]).toEqual({
        previewInitialized: true,
      });
    });
  });
  describe('v2 SET_STORIES event', () => {
    it('normalizes parameters and calls setRef for external stories', () => {
      const fullAPI = {
        findRef: vi.fn(),
        setRef: vi.fn(),
      };
      const moduleArgs = createMockModuleArgs({ fullAPI });
      initStories(moduleArgs as unknown as ModuleArgs);
      const { provider, store } = moduleArgs;

      getEventMetadata.mockReturnValueOnce({
        sourceType: 'external',
        ref: { id: 'ref' },
      } as any);
      const setStoriesPayload = {
        v: 2,
        globalParameters: { global: 'global' },
        kindParameters: { a: { kind: 'kind' } },
        stories: { 'a--1': { kind: 'a', parameters: { story: 'story' } } },
      };
      provider.channel.emit(SET_STORIES, setStoriesPayload);
      expect(store.getState().index).toBeUndefined();
      expect(fullAPI.setRef).toHaveBeenCalledWith(
        'ref',
        {
          id: 'ref',
          setStoriesData: {
            'a--1': { kind: 'a', parameters: { global: 'global', kind: 'kind', story: 'story' } },
          },
        },
        true
      );
    });
  });
  describe('legacy (v1) SET_STORIES event', () => {
    it('calls setRef with stories', () => {
      const fullAPI = {
        findRef: vi.fn(),
        setRef: vi.fn(),
      };
      const moduleArgs = createMockModuleArgs({ fullAPI });
      initStories(moduleArgs as unknown as ModuleArgs);
      const { provider, store } = moduleArgs;

      getEventMetadata.mockReturnValueOnce({
        sourceType: 'external',
        ref: { id: 'ref' },
      } as any);
      const setStoriesPayload = {
        stories: { 'a--1': {} },
      };
      provider.channel.emit(SET_STORIES, setStoriesPayload);
      expect(store.getState().index).toBeUndefined();
      expect(fullAPI.setRef).toHaveBeenCalledWith(
        'ref',
        {
          id: 'ref',
          setStoriesData: {
            'a--1': {},
          },
        },
        true
      );
    });
  });
  describe('SET_CONFIG', () => {
    it('applies config sidebar filters to an index that was already set', async () => {
      const moduleArgs = createMockModuleArgs({
        initialState: {
          tagPresets: {},
          includedTagFilters: [],
          excludedTagFilters: [],
          includedStatusFilters: [],
          excludedStatusFilters: [],
        } as Partial<State>,
      });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store, provider } = moduleArgs;

      const entries: StoryIndex['entries'] = {
        'a--1': {
          type: 'story',
          subtype: 'story',
          id: 'a--1',
          title: 'a',
          name: '1',
          tags: ['dev'],
          importPath: './a.ts',
        },
        'b--1': {
          type: 'story',
          subtype: 'story',
          id: 'b--1',
          title: 'b',
          name: '1',
          tags: ['dev'],
          importPath: './b.ts',
        },
      };

      // The index arrives before the addon config (e.g. slow-loading manager entry)
      await api.setIndex({ v: 5, entries });

      expect(Object.keys(store.getState().filteredIndex!)).toContain('b--1');

      // Now the addon config with sidebar filters lands
      provider.getConfig.mockReturnValue({
        sidebar: { filters: { pattern: (item: any) => item.id.startsWith('a') } },
      });
      provider.channel.emit(SET_CONFIG);
      await new Promise((resolve) => setTimeout(resolve, 0));

      const { filteredIndex } = store.getState();
      expect(Object.keys(filteredIndex!)).toEqual(['a', 'a--1']);
    });
  });
  describe('experimental_setFilters', () => {
    it('applies multiple filters in a single call', async () => {
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;

      await api.setIndex({ v: 5, entries: navigationEntries });
      await api.experimental_setFilters({
        one: (item: any) => !item.id.startsWith('b'),
        two: (item: any) => !item.id.startsWith('custom'),
      });

      expect(store.getState().filters).toEqual(
        expect.objectContaining({
          one: expect.any(Function),
          two: expect.any(Function),
        })
      );
      expect(Object.keys(store.getState().filteredIndex!)).toEqual(['a', 'a--1', 'a--2']);
    });

    it('emits SET_FILTER for each filter once the index is set', async () => {
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { provider } = moduleArgs;

      const listener = vi.fn();
      provider.channel.on(SET_FILTER, listener);

      // Without an index, nothing is emitted (the filters only take effect later)
      await api.experimental_setFilters({ one: () => true });
      expect(listener).not.toHaveBeenCalled();

      await api.setIndex({ v: 5, entries: navigationEntries });
      await api.experimental_setFilters({ one: () => true, two: () => true });
      expect(listener).toHaveBeenCalledTimes(2);
      expect(listener).toHaveBeenCalledWith({ id: 'one' });
      expect(listener).toHaveBeenCalledWith({ id: 'two' });
    });
  });
  describe('experimental_setFilter', () => {
    it('is included in the initial state', async () => {
      const moduleArgs = createMockModuleArgs({});
      const { state, api } = initStories(moduleArgs as unknown as ModuleArgs);

      await api.setIndex({ v: 5, entries: mockEntries });

      expect(state).toEqual(
        expect.objectContaining({
          defaultExcludedTagFilters: expect.arrayContaining([]),
          defaultIncludedTagFilters: expect.arrayContaining([]),
          excludedTagFilters: expect.arrayContaining([]),
          includedTagFilters: expect.arrayContaining([]),
          filters: expect.objectContaining({
            'static-filter': expect.any(Function),
            'tags-filter': expect.any(Function),
          }),
          tagPresets: expect.objectContaining({}),
        })
      );
    });

    it('updates state', async () => {
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;

      await api.setIndex({ v: 5, entries: mockEntries });

      await api.experimental_setFilter('myCustomFilter', () => true);

      expect(store.getState()).toEqual(
        expect.objectContaining({
          filters: {
            myCustomFilter: expect.any(Function),
          },
        })
      );
    });

    it('can filter', async () => {
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;

      await api.setIndex({ v: 5, entries: navigationEntries });
      await api.experimental_setFilter('myCustomFilter', (item: any) => item.id.startsWith('a'));

      const { filteredIndex } = store.getState();

      expect(filteredIndex).toMatchInlineSnapshot(`
        {
          "a": {
            "children": [
              "a--1",
              "a--2",
            ],
            "depth": 0,
            "id": "a",
            "importPath": "./a.ts",
            "name": "a",
            "parent": undefined,
            "renderLabel": undefined,
            "tags": [],
            "type": "component",
          },
          "a--1": {
            "depth": 1,
            "id": "a--1",
            "importPath": "./a.ts",
            "name": "1",
            "parent": "a",
            "prepared": false,
            "renderLabel": undefined,
            "subtype": "story",
            "tags": [],
            "title": "a",
            "type": "story",
          },
          "a--2": {
            "depth": 1,
            "id": "a--2",
            "importPath": "./a.ts",
            "name": "2",
            "parent": "a",
            "prepared": false,
            "renderLabel": undefined,
            "subtype": "story",
            "tags": [],
            "title": "a",
            "type": "story",
          },
        }
      `);
    });

    it('can filter on status', async () => {
      vi.mock('../stores/status');
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;

      await api.setIndex({ v: 5, entries: navigationEntries });
      await api.experimental_setFilter(
        'myCustomFilter',
        (item) =>
          item.statuses !== undefined &&
          Object.values(item.statuses).some((status) => status.value === 'status-value:pending')
      );

      // empty, because there are no stories with status
      expect(store.getState().filteredIndex).toMatchInlineSnapshot('{}');

      // setting status should update the index
      fullStatusStore.set([
        {
          typeId: 'a-addon-id',
          storyId: 'a--1',
          value: 'status-value:pending',
          title: 'an addon title',
          description: 'an addon description',
        },
        {
          typeId: 'a-addon-id',
          storyId: 'a--2',
          value: 'status-value:success',
          title: 'an addon title',
          description: 'an addon description',
        },
      ]);

      await vi.waitFor(() => {
        expect(Object.keys(store.getState().filteredIndex ?? {})).toHaveLength(2);
      });
      expect(store.getState().filteredIndex).toMatchInlineSnapshot(`
        {
          "a": {
            "children": [
              "a--1",
            ],
            "depth": 0,
            "id": "a",
            "importPath": "./a.ts",
            "name": "a",
            "parent": undefined,
            "renderLabel": undefined,
            "tags": [],
            "type": "component",
          },
          "a--1": {
            "depth": 1,
            "id": "a--1",
            "importPath": "./a.ts",
            "name": "1",
            "parent": "a",
            "prepared": false,
            "renderLabel": undefined,
            "subtype": "story",
            "tags": [],
            "title": "a",
            "type": "story",
          },
        }
      `);
    });

    it('persists filter when index is updated', async () => {
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;

      await api.setIndex({ v: 5, entries: navigationEntries });
      await api.experimental_setFilter('myCustomFilter', (item: any) => item.id.startsWith('a'));

      await api.setIndex({ v: 5, entries: navigationEntries });

      const { filteredIndex } = store.getState();

      expect(filteredIndex).toMatchInlineSnapshot(`
        {
          "a": {
            "children": [
              "a--1",
              "a--2",
            ],
            "depth": 0,
            "id": "a",
            "importPath": "./a.ts",
            "name": "a",
            "parent": undefined,
            "renderLabel": undefined,
            "tags": [],
            "type": "component",
          },
          "a--1": {
            "depth": 1,
            "id": "a--1",
            "importPath": "./a.ts",
            "name": "1",
            "parent": "a",
            "prepared": false,
            "renderLabel": undefined,
            "subtype": "story",
            "tags": [],
            "title": "a",
            "type": "story",
          },
          "a--2": {
            "depth": 1,
            "id": "a--2",
            "importPath": "./a.ts",
            "name": "2",
            "parent": "a",
            "prepared": false,
            "renderLabel": undefined,
            "subtype": "story",
            "tags": [],
            "title": "a",
            "type": "story",
          },
        }
      `);
    });
  });

  describe('parseStatusesParam', () => {
    it('returns empty arrays for undefined input', () => {
      expect(parseStatusesParam(undefined)).toEqual({ included: [], excluded: [] });
    });

    it('returns empty arrays for empty string', () => {
      expect(parseStatusesParam('')).toEqual({ included: [], excluded: [] });
    });

    it('parses included status short names', () => {
      const result = parseStatusesParam('new;modified;related');
      expect(result.included).toEqual([
        'status-value:new',
        'status-value:modified',
        'status-value:affected',
      ]);
      expect(result.excluded).toEqual([]);
    });

    it('parses excluded status short names with ! prefix', () => {
      const result = parseStatusesParam('!error;!warning');
      expect(result.included).toEqual([]);
      expect(result.excluded).toEqual(['status-value:error', 'status-value:warning']);
    });

    it('parses mixed included and excluded', () => {
      const result = parseStatusesParam('new;!error;pending');
      expect(result.included).toEqual(['status-value:new', 'status-value:pending']);
      expect(result.excluded).toEqual(['status-value:error']);
    });

    it('silently ignores unknown short names', () => {
      const result = parseStatusesParam('new;unknownstatus;modified');
      expect(result.included).toEqual(['status-value:new', 'status-value:modified']);
      expect(result.excluded).toEqual([]);
    });

    it('parses all known status values', () => {
      const result = parseStatusesParam(
        'new;modified;related;error;warning;success;pending;unknown'
      );
      expect(result.included).toEqual([
        'status-value:new',
        'status-value:modified',
        'status-value:affected',
        'status-value:error',
        'status-value:warning',
        'status-value:success',
        'status-value:pending',
        'status-value:unknown',
      ]);
    });

    it('keeps backward compatibility for affected in URL params', () => {
      const result = parseStatusesParam('affected');
      expect(result.included).toEqual(['status-value:affected']);
      expect(result.excluded).toEqual([]);
    });
  });

  describe('serializeStatusesParam', () => {
    it('returns undefined for empty arrays', () => {
      expect(serializeStatusesParam([], [])).toBeUndefined();
    });

    it('serializes included status values', () => {
      expect(serializeStatusesParam(['status-value:new', 'status-value:modified'], [])).toBe(
        'modified;new'
      );
    });

    it('serializes excluded status values with ! prefix', () => {
      expect(serializeStatusesParam([], ['status-value:error', 'status-value:warning'])).toBe(
        '!error;!warning'
      );
    });

    it('serializes mixed included and excluded', () => {
      expect(serializeStatusesParam(['status-value:new'], ['status-value:error'])).toBe(
        'new;!error'
      );
    });

    it('serializes affected as related for URL params', () => {
      expect(serializeStatusesParam(['status-value:affected'], [])).toBe('related');
      expect(serializeStatusesParam([], ['status-value:affected'])).toBe('!related');
    });

    it('round-trips with parseStatusesParam', () => {
      const included = ['status-value:new', 'status-value:pending'] as const;
      const excluded = ['status-value:error'] as const;
      const serialized = serializeStatusesParam([...included], [...excluded]);
      const parsed = parseStatusesParam(serialized);
      expect(parsed.included).toEqual(included);
      expect(parsed.excluded).toEqual(excluded);
    });
  });

  describe('status filter state', () => {
    it('initializes with empty status filters', () => {
      const moduleArgs = createMockModuleArgs({});
      const { state } = initStories(moduleArgs as unknown as ModuleArgs);
      expect(state.includedStatusFilters).toEqual([]);
      expect(state.excludedStatusFilters).toEqual([]);
    });

    it('initializes status filters from URL statuses param', () => {
      const moduleArgs = createMockModuleArgs({
        initialState: {
          location: { search: '?path=/story/a--1&statuses=new%3Bmodified' } as any,
        } as any,
      });
      const { state } = initStories({
        ...(moduleArgs as unknown as ModuleArgs),
        state: {
          location: { search: '?statuses=new;modified' } as any,
        } as any,
      });
      // 'new' and 'modified' are both included statuses from the URL param
      expect(state.includedStatusFilters).toEqual(['status-value:new', 'status-value:modified']);
      expect(state.excludedStatusFilters).toEqual([]);
    });

    it('addStatusFilters adds to included list', async () => {
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;

      await api.setIndex({ v: 5, entries: navigationEntries });
      await api.addStatusFilters(['status-value:new'], false);

      const { includedStatusFilters, excludedStatusFilters } = store.getState();
      expect(includedStatusFilters).toEqual(['status-value:new']);
      expect(excludedStatusFilters).toEqual([]);
    });

    it('addStatusFilters adds to excluded list when excluded=true', async () => {
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;

      await api.setIndex({ v: 5, entries: navigationEntries });
      await api.addStatusFilters(['status-value:error'], true);

      const { includedStatusFilters, excludedStatusFilters } = store.getState();
      expect(includedStatusFilters).toEqual([]);
      expect(excludedStatusFilters).toEqual(['status-value:error']);
    });

    it('addStatusFilters moves a status from included to excluded', async () => {
      const moduleArgs = createMockModuleArgs({
        initialState: {
          includedStatusFilters: ['status-value:new'],
          excludedStatusFilters: [],
        } as any,
      });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;

      await api.setIndex({ v: 5, entries: navigationEntries });
      await api.addStatusFilters(['status-value:new'], true);

      const { includedStatusFilters, excludedStatusFilters } = store.getState();
      expect(includedStatusFilters).toEqual([]);
      expect(excludedStatusFilters).toEqual(['status-value:new']);
    });

    it('removeStatusFilters removes from both included and excluded', async () => {
      const moduleArgs = createMockModuleArgs({
        initialState: {
          includedStatusFilters: ['status-value:new', 'status-value:modified'],
          excludedStatusFilters: ['status-value:error'],
        } as any,
      });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;

      await api.setIndex({ v: 5, entries: navigationEntries });
      await api.removeStatusFilters(['status-value:new', 'status-value:error']);

      const { includedStatusFilters, excludedStatusFilters } = store.getState();
      expect(includedStatusFilters).toEqual(['status-value:modified']);
      expect(excludedStatusFilters).toEqual([]);
    });

    it('resetStatusFilters clears both included and excluded', async () => {
      const moduleArgs = createMockModuleArgs({
        initialState: {
          includedStatusFilters: ['status-value:new'],
          excludedStatusFilters: ['status-value:error'],
        } as any,
      });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;

      await api.setIndex({ v: 5, entries: navigationEntries });
      await api.resetStatusFilters();

      const { includedStatusFilters, excludedStatusFilters } = store.getState();
      expect(includedStatusFilters).toEqual([]);
      expect(excludedStatusFilters).toEqual([]);
    });

    it('setAllStatusFilters replaces both included and excluded lists', async () => {
      const moduleArgs = createMockModuleArgs({
        initialState: {
          includedStatusFilters: ['status-value:new'],
          excludedStatusFilters: ['status-value:error'],
        } as any,
      });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;

      await api.setIndex({ v: 5, entries: navigationEntries });
      await api.setAllStatusFilters(
        ['status-value:modified', 'status-value:affected'],
        ['status-value:warning']
      );

      const { includedStatusFilters, excludedStatusFilters } = store.getState();
      expect(includedStatusFilters).toEqual(['status-value:modified', 'status-value:affected']);
      expect(excludedStatusFilters).toEqual(['status-value:warning']);
    });
  });

  describe('computeStatusFilterFn (via experimental_setFilter)', () => {
    it('passes through all stories when both included and excluded are empty', async () => {
      vi.mock('../stores/status');
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;

      await api.setIndex({ v: 5, entries: navigationEntries });
      // no status filters set - all stories should pass
      const { filteredIndex } = store.getState();
      expect(Object.keys(filteredIndex!)).toContain('a--1');
      expect(Object.keys(filteredIndex!)).toContain('a--2');
    });

    it('applies OR logic within included status filters', async () => {
      vi.mock('../stores/status');
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;

      await api.setIndex({ v: 5, entries: navigationEntries });

      fullStatusStore.set([
        {
          typeId: 'addon-id',
          storyId: 'a--1',
          value: 'status-value:new',
          title: 'title',
          description: 'desc',
        },
        {
          typeId: 'addon-id',
          storyId: 'a--2',
          value: 'status-value:error',
          title: 'title',
          description: 'desc',
        },
      ]);

      // Include only 'new' - only a--1 should appear (has 'new'), a--2 has 'error' only
      await api.addStatusFilters(['status-value:new'], false);

      await vi.waitFor(() => {
        const { filteredIndex } = store.getState();
        expect(Object.keys(filteredIndex!)).toContain('a--1');
        expect(Object.keys(filteredIndex!)).not.toContain('a--2');
      });
    });

    it('applies exclude logic: story with excluded status is hidden', async () => {
      vi.mock('../stores/status');
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;

      await api.setIndex({ v: 5, entries: navigationEntries });

      fullStatusStore.set([
        {
          typeId: 'addon-id',
          storyId: 'a--1',
          value: 'status-value:error',
          title: 'title',
          description: 'desc',
        },
        {
          typeId: 'addon-id',
          storyId: 'a--2',
          value: 'status-value:success',
          title: 'title',
          description: 'desc',
        },
      ]);

      // Exclude 'error' - a--1 should be hidden, a--2 with 'success' should pass
      await api.addStatusFilters(['status-value:error'], true);

      await vi.waitFor(() => {
        const { filteredIndex } = store.getState();
        expect(Object.keys(filteredIndex!)).not.toContain('a--1');
        expect(Object.keys(filteredIndex!)).toContain('a--2');
      });
    });

    it('story with no statuses is hidden when included filters are active', async () => {
      vi.mock('../stores/status');
      const moduleArgs = createMockModuleArgs({});
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { store } = moduleArgs;

      await api.setIndex({ v: 5, entries: navigationEntries });

      // Set status only for a--1, leave a--2 with no status
      fullStatusStore.set([
        {
          typeId: 'addon-id',
          storyId: 'a--1',
          value: 'status-value:new',
          title: 'title',
          description: 'desc',
        },
      ]);

      // Include 'new' - only a--1 passes (a--2 has no status so fails include check)
      await api.addStatusFilters(['status-value:new'], false);

      await vi.waitFor(() => {
        const { filteredIndex } = store.getState();
        expect(Object.keys(filteredIndex!)).toContain('a--1');
        expect(Object.keys(filteredIndex!)).not.toContain('a--2');
      });
    });
  });

  describe('selectFirstStory with status filters', () => {
    it('uses filteredIndex when status filters are active', () => {
      const moduleArgs = createMockModuleArgs({
        initialState: {
          path: '/',
          index: {
            'a--1': { type: 'story', id: 'a--1', depth: 0 } as any,
            'a--2': { type: 'story', id: 'a--2', depth: 0 } as any,
          },
          filteredIndex: {
            'a--2': { type: 'story', id: 'a--2', depth: 0 } as any,
          },
          includedStatusFilters: ['status-value:new'],
          excludedStatusFilters: [],
          includedTagFilters: [],
          excludedTagFilters: [],
        } as any,
      });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate } = moduleArgs;

      api.selectFirstStory();
      expect(navigate).toHaveBeenCalledWith('/story/a--2', undefined);
    });

    /**
     * Whilst the two of the built-in filters (status and tag) have easy ways to determine
     * whether or not they are active, no other filters do - in particular, user-provided filters
     * from experimental_setFilter.
     *
     * As such, the filtered index is now used if it is present, regardless of the heuristics that
     * could be used to determine if the status/tag filters are active.
     */
    it('uses filteredIndex when status filters are not active', () => {
      const moduleArgs = createMockModuleArgs({
        initialState: {
          path: '/',
          index: {
            'a--1': { type: 'story', id: 'a--1', depth: 0 } as any,
            'a--2': { type: 'story', id: 'a--2', depth: 0 } as any,
          },
          filteredIndex: {
            'a--2': { type: 'story', id: 'a--2', depth: 0 } as any,
          },
          includedStatusFilters: [],
          excludedStatusFilters: [],
          includedTagFilters: [],
          excludedTagFilters: [],
        } as any,
      });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate } = moduleArgs;

      api.selectFirstStory();
      expect(navigate).toHaveBeenCalledWith('/story/a--2', undefined);
    });

    it('suppresses navigation when status filters active but filteredIndex is empty', () => {
      const moduleArgs = createMockModuleArgs({
        initialState: {
          path: '/',
          index: {
            'a--1': { type: 'story', id: 'a--1', depth: 0 } as any,
          },
          filteredIndex: {},
          includedStatusFilters: ['status-value:new'],
          excludedStatusFilters: [],
          includedTagFilters: [],
          excludedTagFilters: [],
        } as any,
      });
      const { api } = initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate } = moduleArgs;

      api.selectFirstStory();
      expect(navigate).not.toHaveBeenCalled();
    });
  });

  describe('STORY_SPECIFIED handler with status filters', () => {
    it('navigates to first filtered story when active status filters exclude the emitted story', async () => {
      const moduleArgs = createMockModuleArgs({
        initialState: {
          path: '/',
          index: {
            'a--1': { type: 'story', id: 'a--1' } as any,
            'a--2': { type: 'story', id: 'a--2' } as any,
          },
          filteredIndex: {
            'a--2': { type: 'story', id: 'a--2' } as any,
          },
          includedStatusFilters: ['status-value:new'],
          excludedStatusFilters: [],
          includedTagFilters: [],
          excludedTagFilters: [],
        } as any,
      });
      initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate, provider } = moduleArgs;

      // a--1 is NOT in filteredIndex, so it should navigate to a--2 instead
      provider.channel.emit(STORY_SPECIFIED, { storyId: 'a--1', viewMode: 'story' });
      expect(navigate).toHaveBeenCalledWith('/story/a--2', undefined);
    });

    it('suppresses navigation when active status filters exclude the emitted story and filteredIndex is empty', async () => {
      const moduleArgs = createMockModuleArgs({
        initialState: {
          path: '/',
          index: {
            'a--1': { type: 'story', id: 'a--1' } as any,
          },
          filteredIndex: {},
          includedStatusFilters: ['status-value:new'],
          excludedStatusFilters: [],
          includedTagFilters: [],
          excludedTagFilters: [],
        } as any,
      });
      initStories(moduleArgs as unknown as ModuleArgs);
      const { navigate, provider } = moduleArgs;

      provider.channel.emit(STORY_SPECIFIED, { storyId: 'a--1', viewMode: 'story' });
      expect(navigate).not.toHaveBeenCalled();
    });
  });
});
