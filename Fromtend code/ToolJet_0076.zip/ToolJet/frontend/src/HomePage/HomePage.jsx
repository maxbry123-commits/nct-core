import React from 'react';
import cx from 'classnames';
import moment from 'moment';
import {
  appsService,
  folderService,
  authenticationService,
  libraryAppService,
  gitSyncService,
  licenseService,
  pluginsService,
  aiOnboardingService,
} from '@/_services';
import { ConfirmDialog, AppModal, ToolTip } from '@/_components';
import Select from '@/_ui/Select';
import { AppsMultiSelect } from '@/_ui/Modal/AppsMultiSelect';
import _, { sample, isEmpty, capitalize, has } from 'lodash';
import { Folders } from './Folders';
import { BlankPage } from './BlankPage';
import { toast } from 'react-hot-toast';
import { Button, ButtonGroup, Dropdown } from 'react-bootstrap';
import Layout from '@/_ui/Layout';
import AppList from './AppList';
import TemplateLibraryModal from './TemplateLibraryModal/';
import HomeHeader from './Header';
import Modal from './Modal';
import configs from './Configs/AppIcon.json';
import { withTranslation } from 'react-i18next';
import ExportAppModal from './ExportAppModal';
import Footer from './Footer';
import { ButtonSolid } from '@/_ui/AppButton/AppButton';
import BulkIcon from '@/_ui/Icon/bulkIcons/index';
import { getWorkspaceId } from '@/_helpers/utils';
import { getQueryParams } from '@/_helpers/routes';
import { withRouter } from '@/_hoc/withRouter';
import LicenseBanner from '@/modules/common/components/LicenseBanner';
import { LicenseTooltip } from '@/LicenseTooltip';
import ModalBase from '@/_ui/Modal';
import FolderFilter from './FolderFilter';
import { useLicenseStore } from '@/_stores/licenseStore';
import { getFolderGroupPermissions, appTypeToDisplayNameMapping, getFolderPermissionField } from './helper';
import { shallow } from 'zustand/shallow';
import { fetchAndSetWindowTitle, pageTitles } from '@white-label/whiteLabelling';
import HeaderSkeleton from '@/_ui/FolderSkeleton/HeaderSkeleton';
import {
  ImportAppMenu,
  AppActionModal,
  OrganizationList,
  ConsultationBanner,
  AppTypeTab,
} from '@/modules/dashboard/components';
import CreateAppWithPrompt from '@/modules/AiBuilder/components/CreateAppWithPrompt';
import CreateModuleWithPrompt from '@/modules/AiBuilder/components/CreateModuleWithPrompt';
import SolidIcon from '@/_ui/Icon/SolidIcons';
import { isWorkflowsFeatureEnabled } from '@/modules/common/helpers/utils';
import EmptyModuleSvg from '../../assets/images/icons/empty-modules.svg';
import { v4 as uuidv4 } from 'uuid';
import { TJLoader } from '@/_ui/TJLoader/TJLoader';
import posthogHelper from '@/modules/common/helpers/posthogHelper';
const { iconList, defaultIcon } = configs;
import { PermissionDeniedModal } from './PermissionDeniedModal/PermissionDeniedModal';
import { canEditModule } from '@/modules/Modules/helpers/modulePermissions';
import { updateCurrentSession } from '@/_helpers/authorizeWorkspace';
import { WorkspaceLockedBanner } from '@/_ui/WorkspaceLockedBanner';
import { useWorkspaceBranchesStore } from '@/_stores/workspaceBranchesStore';
import { isGitSyncLicenseInvalid } from '@/_helpers/gitSyncLicense';
import { whenBranchResolved } from '@/_helpers/active-branch';
import { subscribeLiveNotifications } from '@/_stores/notificationsStore';
import { WorkspaceSwitchBranchModal } from '@/_ui/WorkspaceBranchDropdown/SwitchBranchModal';
import { PullConflictModal } from '@/_ui/WorkspaceBranchDropdown/WorkspacePullConflictModal';
import { TriangleAlert } from 'lucide-react';

const MAX_APPS_PER_PAGE = 9; // Keep in sync with server pagination limit
class HomePageComponent extends React.Component {
  constructor(props) {
    super(props);

    const currentSession = authenticationService?.currentSessionValue;
    this.fileInput = React.createRef();
    this.state = {
      currentUser: {
        id: currentSession?.current_user?.id,
        organization_id: currentSession?.current_organization_id,
      },
      tj_api_source: currentSession?.tj_api_source,
      shouldRedirect: false,
      users: null,
      isLoading: true,
      creatingApp: false,
      isDeletingApp: false,
      isCloningApp: false,
      isExportingApp: false,
      isImportingApp: false,
      isDeletingAppFromFolder: false,
      deletingAppIds: new Set(),
      currentFolder: {},
      currentPage: 1,
      appSearchKey: '',
      appToBeDeleted: false,
      showAppDeletionConfirmation: false,
      showRemoveAppFromFolderConfirmation: false,
      showAddToFolderModal: false,
      addToFolderApps: [],
      apps: [],
      folders: [],
      meta: {
        count: 1,
        folders: [],
      },
      appOperations: {},
      showTemplateLibraryModal: false,
      app: {},
      appsLimit: {},
      featureAccess: null,
      newAppName: '',
      commitEnabled: false,
      fetchingOrgGit: false,
      orgGit: null,
      showGitRepositoryImportModal: false,
      fetchingAppsFromRepos: false,
      appsFromRepos: {},
      selectedAppRepo: null,
      importingApp: false,
      importingGitAppOperations: {},
      gitImportConflictGroups: null,
      latestCommitData: null,
      selectedImportBranch: null,
      remoteBranches: [],
      fetchingRemoteBranches: false,
      tags: [],
      fetchingLatestCommitData: false,
      selectedVersionOption: null,
      featuresLoaded: false,
      showCreateAppModal: false,
      showSwitchBranchForCreate: false,
      showSwitchBranchForDelete: false,
      showSwitchBranchForClone: false,
      showCreateAppFromTemplateModal: false,
      showImportAppModal: false,
      showCloneAppModal: false,
      showRenameAppModal: false,
      fileContent: '',
      fileName: '',
      selectedTemplate: null,
      deploying: false,
      workflowWorkspaceLevelLimit: {},
      workflowInstanceLevelLimit: {},
      showUserGroupMigrationModal: false,
      showGroupMigrationBanner: true,
      shouldAutoImportPlugin: false,
      dependentPlugins: [],
      dependentPluginsDetail: {},
      importedAppName: {},
      showMissingGroupsModal: false,
      missingGroups: [],
      missingGroupsExpanded: false,
      showAIOnboardingLoadingScreen: false,
      showInsufficentPermissionModal: false,
      showDependentAppsModal: false,
    };
  }

  setQueryParameter = () => {
    const showImportTemplateModal = getQueryParams('fromtemplate');
    this.setState({
      showTemplateLibraryModal: showImportTemplateModal ? showImportTemplateModal : false,
    });
  };

  checkIfUserHasBuilderAccess = () => {
    const role = authenticationService.currentSessionValue?.role.name;
    const hasBuilderAccess = role === 'admin' || role === 'builder';
    return hasBuilderAccess;
  };

  /* For cloud ai onboarding */
  handleAiOnboarding = () => {
    const aiCookies = authenticationService.currentSessionValue?.ai_cookies;
    const latestPrompt = aiCookies?.tj_ai_prompt;
    const templateId = aiCookies?.tj_template_id;

    /* First check the user permission */
    if (latestPrompt || templateId) {
      if (!this.checkIfUserHasBuilderAccess()) {
        this.setState({ showInsufficentPermissionModal: true });
        return;
      }
    }

    switch (true) {
      case !!latestPrompt:
        // toast.success(`Prompt you have entered: ${decodeURIComponent(latestPrompt)}`, {
        //   duration: 10000,
        // });
        // Optional: Clear the cookie after showing toast
        this.setState({ showAIOnboardingLoadingScreen: true });
        this.createApp(`Untitled App: ${uuidv4()}`, undefined, `${decodeURIComponent(latestPrompt)}`);
        break;
      case !!templateId: {
        this.setState({ showAIOnboardingLoadingScreen: true });
        if (templateId) {
          /*TODO: I Believe the people who will try the templates from site should be new to tooljet. so making name unique for existed user can be do it in sometime */
          this.deployApp(new Event('deploy'), `${templateId.replace(/-/g, ' ')}`, {
            id: templateId,
          });
        }
        break;
      }
      default:
        break;
    }
  };

  componentDidMount() {
    const gitSyncToast = sessionStorage.getItem('git_sync_toast');
    if (gitSyncToast) {
      sessionStorage.removeItem('git_sync_toast');
      setTimeout(() => toast.error(gitSyncToast), 500);
    }
    this.handleAiOnboarding();
    if (this.props.appType === 'workflow') {
      if (!this.canViewWorkflow()) {
        toast.error('You do not have permission to view workflows');
        this.setState({ shouldRedirect: true });
        return;
      }
    }
    if (this.props.appType === 'module' && authenticationService.currentSessionValue?.role?.name == 'end-user') {
      //Restrict route
      this.setState({ shouldRedirect: true });
      return;
    }
    fetchAndSetWindowTitle({ page: pageTitles.DASHBOARD });
    // ?folder= deep-link: fetchFolders will chain to fetchApps after slug resolves.
    const urlFolderSlug = new URL(window.location.href)?.searchParams?.get('folder');
    // Gate the first apps/folders fetch on branch resolution so they carry the right branch_id
    // after a hard reload on a feature branch (no-op when the URL has no `branch` param).
    whenBranchResolved().then(() => {
      if (!urlFolderSlug) {
        this.fetchApps(1, this.state.currentFolder.id);
      }
      this.fetchFolders();
    });
    this.fetchFeatureAccesss();
    this.fetchAppsLimit();
    this.fetchWorkflowsInstanceLimit();
    this.fetchWorkflowsWorkspaceLimit();
    // Layout already fetched orgGitConfig — mirror it instead of duplicating.
    const initialOrgGit = useWorkspaceBranchesStore.getState().orgGitConfig;
    if (initialOrgGit) this.setState({ orgGit: initialOrgGit });
    this.setQueryParameter();

    // Check module access permission
    this.props.checkModuleAccess();

    // Refetch on real branch switch only (skip the initial null→<id> hydration).
    this._branchStoreUnsubscribe = useWorkspaceBranchesStore.subscribe((state, prevState) => {
      if (state.activeBranchId && prevState.activeBranchId && state.activeBranchId !== prevState.activeBranchId) {
        this.fetchApps(1, this.state.currentFolder.id);
        this.fetchFolders();
      }
      if (state.orgGitConfig !== prevState.orgGitConfig) {
        this.setState({ orgGit: state.orgGitConfig });
      }
    });

    // Store is a singleton — refetch on dashboard return; active branch may have been deleted while away.
    if (useWorkspaceBranchesStore.getState().isInitialized) {
      useWorkspaceBranchesStore.getState().actions.fetchBranches();
    }
    this._liveNotificationsUnsubscribe = subscribeLiveNotifications(this.handleGitSyncNotification);

    const hasClosedBanner = localStorage.getItem('hasClosedGroupMigrationBanner');

    //Only show the banner once
    if (hasClosedBanner) {
      this.setState({ showGroupMigrationBanner: false });
    }
  }

  componentWillUnmount() {
    if (this._branchStoreUnsubscribe) {
      this._branchStoreUnsubscribe();
    }
    if (this._liveNotificationsUnsubscribe) {
      this._liveNotificationsUnsubscribe();
    }
  }

  // Aftermath for git-sync background jobs — live WS arrivals only, REST backfill never reaches here.
  handleGitSyncNotification = (n) => {
    const meta = n?.metadata;
    if (meta?.source !== 'git-sync' || n?.type !== 'success') return;
    const branchActions = useWorkspaceBranchesStore.getState().actions;
    switch (meta.action) {
      case 'git-delete-branch':
        // fetchBranches self-heals a deleted active branch to default; the
        // activeBranchId change triggers the apps refetch above. Silent — the
        // notification toast already announces the deletion.
        branchActions.fetchBranches();
        break;
      case 'git-pull-branch':
        // same branch id — subscription won't fire, refetch directly
        this.fetchApps(1, this.state.currentFolder.id);
        this.fetchFolders();
        break;
      case 'git-create-branch':
        branchActions.fetchBranches();
        break;
      default:
        break;
    }
  };

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.appType != this.props.appType) {
      this.fetchFolders();
      this.fetchApps(1);
    }
    if (Object.keys(this.props.featureAccess).length && !this.state.featureAccess) {
      this.setState({ featureAccess: this.props.featureAccess, featuresLoaded: this.props.featuresLoaded });
    }
    if (this.state.shouldRedirect && !prevState.shouldRedirect) {
      const workspaceId = getWorkspaceId();
      this.props.navigate(`/${workspaceId}/home`);
    }
  }

  fetchFeatureAccesss = () => {
    licenseService.getFeatureAccess().then((data) => {
      this.setState({
        featureAccess: data,
        featuresLoaded: true,
      });
    });
  };

  fetchAppsLimit() {
    appsService.getAppsLimit().then((data) => {
      this.setState({ appsLimit: data?.appsCount });
    });
  }

  fetchWorkflowsInstanceLimit() {
    appsService.getWorkflowLimit('instance').then((data) => {
      this.setState({ workflowInstanceLevelLimit: data?.appsCount });
    });
  }

  fetchWorkflowsWorkspaceLimit() {
    appsService.getWorkflowLimit('workspace').then((data) => {
      this.setState({ workflowWorkspaceLevelLimit: data?.appsCount });
    });
  }

  fetchApps = (page = 1, folder, searchKey) => {
    const appSearchKey = searchKey !== '' ? searchKey || this.state.appSearchKey : '';
    this.setState({
      apps: [],
      isLoading: true,
      currentPage: page,
      appSearchKey,
    });
    appsService.getAll(page, folder, appSearchKey, this.props.appType).then((data) => {
      this.setState({
        apps: data.apps,
        meta: { ...this.state.meta, ...data.meta },
        searchedAppCount: appSearchKey ? data.apps.length : this.state.currentFolder.count,
        isLoading: false,
      });
    });
  };

  fetchFolders = (searchKey) => {
    const appSearchKey = searchKey !== '' ? searchKey || this.state.appSearchKey : '';
    this.setState({
      foldersLoading: true,
      appSearchKey: appSearchKey,
    });

    folderService.getAll(appSearchKey, this.props.appType).then((data) => {
      const folder_slug = new URL(window.location.href)?.searchParams?.get('folder');
      const folder = data?.folders?.find((folder) => folder.name === folder_slug);
      const currentFolderId = folder ? folder.id : this.state.currentFolder?.id;
      const currentFolder = data?.folders?.find((folder) => currentFolderId && folder.id === currentFolderId);
      const slugIsStale = !!folder_slug && !folder;
      this.setState({
        folders: data.folders,
        foldersLoading: false,
        currentFolder: currentFolder || {},
      });
      if (currentFolder) {
        this.fetchApps(1, currentFolder.id);
      } else if (slugIsStale) {
        // Stale ?folder= (renamed/deleted) — load All apps so dashboard isn't blank.
        this.fetchApps(1, undefined);
      }
    });
  };

  pageChanged = (page) => {
    this.fetchApps(page, this.state.currentFolder.id);
  };

  folderChanged = (folder) => {
    this.setState({ currentFolder: folder });
    this.fetchApps(1, folder.id);
  };

  foldersChanged = () => {
    this.fetchFolders();
  };

  getAppType = () => {
    const { appType } = this.props;
    if (appType === 'front-end') return 'App';
    if (appType === 'workflow') return 'Workflow';
    if (appType === 'module') return 'Module';
    return 'app';
  };

  createApp = async (appName, type, prompt, taggedResources) => {
    const { currentBranch, actions } = useWorkspaceBranchesStore.getState();
    if (currentBranch && this.props.appType !== 'workflow') {
      try {
        const exists = await actions.checkBranchExistsOnRemote(currentBranch.name);
        if (!exists) {
          toast.error(
            'Branch does not exist in git. Delete this branch and create a new one to continue to make changes.'
          );
          return;
        }
      } catch (_err) {
        /* allow on network error */
      }
    }

    appName = appName?.trim().replace(/\s+/g, ' ');
    let _self = this;
    _self.setState({ creatingApp: true });
    try {
      const data = await appsService.createApp({
        icon: sample(iconList),
        name: appName,
        type: this.props.appType,
        prompt,
      });
      /* Posthog Event */
      posthogHelper.captureEvent('click_new_app', {
        workspace_id:
          authenticationService?.currentUserValue?.organization_id ||
          authenticationService?.currentSessionValue?.current_organization_id,
        app_id: data?.id,
        button_name: this.state.posthog_from === 'blank_page' ? 'click_new_app_from_scratch' : 'click_new_app_button',
      });

      posthogHelper.captureEvent('app_created', { entry_source: prompt ? 'prompt' : 'create_button', prompt });

      const workspaceId = getWorkspaceId();
      _self.props.navigate(`/${workspaceId}/apps/${data.id}`, {
        state: { commitEnabled: this.state.commitEnabled, prompt, taggedResources },
      });
      this.eraseAIOnboardingRelatedCookies();
      this.props.appType !== 'front-end' && toast.success(`${capitalize(this.getAppType())} created successfully!`);
      _self.setState({ creatingApp: false, posthog_from: null, showAIOnboardingLoadingScreen: false });
      return true;
    } catch (errorResponse) {
      this.eraseAIOnboardingRelatedCookies();
      _self.setState({ creatingApp: false, showAIOnboardingLoadingScreen: false });
      if (errorResponse.statusCode === 409) {
        return false;
      } else if (errorResponse.statusCode !== 451) {
        throw errorResponse;
      }
    }
  };

  renameApp = async (newAppName, appId) => {
    newAppName = newAppName?.trim().replace(/\s+/g, ' ');
    let _self = this;
    _self.setState({ renamingApp: true });
    try {
      // Fetch current editing version for the app
      const versionsResp = await appsService.getVersions(appId);
      const versions = versionsResp?.versions || [];
      const currentEditingVersion = versions.find((version) => version?.isCurrentEditingVersion);
      const editingVersionId = currentEditingVersion?.id;
      const savePayload = editingVersionId ? { name: newAppName, editingVersionId } : { name: newAppName };
      await appsService.saveApp(appId, savePayload, this.props.appType);
      await this.fetchApps(this.state.currentPage, this.state.currentFolder.id);
      toast.success(`${this.getAppType()} name has been updated!`);
      _self.setState({ renamingApp: false });
      return true;
    } catch (errorResponse) {
      _self.setState({ renamingApp: false });
      if (errorResponse.statusCode === 409) {
        return false;
      } else if (errorResponse.statusCode !== 451) {
        throw errorResponse;
      }
    }
  };

  deleteApp = (app) => {
    if (this.isWorkspaceBranchLocked(app)) {
      this.setState({ appToBeDeleted: app, showSwitchBranchForDelete: true });
      return;
    }
    this.setState({ showAppDeletionConfirmation: true, appToBeDeleted: app });
  };

  cloneApp = async (appName, appId) => {
    appName = appName?.trim().replace(/\s+/g, ' ');
    const { appsLimit } = this.state;
    const current = appsLimit?.current ?? 0;
    const total = appsLimit?.total ?? 0;
    const canAddUnlimited = appsLimit?.canAddUnlimited ?? false;

    //  Check app limit before cloning
    if (!canAddUnlimited && current >= total) {
      toast.error('You have reached your maximum limit for apps. Upgrade your plan for more.');
      return;
    }
    this.setState({ isCloningApp: true });
    try {
      const data = await appsService.cloneResource(
        {
          app: [{ id: appId, name: appName }],
          organization_id: this.state.currentUser?.organization_id,
        },
        this.props.appType
      );
      toast.success(`${this.getAppType()} cloned successfully!`);
      this.props.navigate(`/${getWorkspaceId()}/apps/${data?.imports?.app[0]?.id}`, {
        state: { commitEnabled: this.state.commitEnabled },
      });
      this.setState({ isCloningApp: false });
      return true;
    } catch (_error) {
      this.setState({ isCloningApp: false });
      if (_error.statusCode === 409) {
        return false;
      } else if (_error.statusCode !== 451) {
        throw _error;
      }
    }
  };

  exportApp = async (app) => {
    this.setState({ isExportingApp: true, app: app });
  };

  exportAppDirectly = async (app) => {
    try {
      const fetchVersions = await appsService.getVersions(app.id);
      const { versions } = fetchVersions;

      const currentEditingVersion = versions?.filter((version) => version?.isCurrentEditingVersion)[0];
      if (!currentEditingVersion) {
        toast.error('Could not find current editing version.', {
          position: 'top-center',
        });
        return;
      }

      // Export all TJDB tables used by default
      const fetchTables = await appsService.getTables(app.id);
      const { tables: allTables } = fetchTables;

      const versionId = currentEditingVersion.id;
      const exportTjDb = true;
      const exportTables = allTables;

      const appOpts = {
        app: [
          {
            id: app.id,
            search_params: { version_id: versionId },
          },
        ],
      };

      const requestBody = {
        ...appOpts,
        ...(exportTjDb && { tooljet_database: exportTables }),
        organization_id: app.organization_id,
      };

      const data = await appsService.exportResource(requestBody);

      const appName = app.name.replace(/\s+/g, '-');
      const fileName = `${appName}-export-${new Date().getTime()}`;
      const json = JSON.stringify(data, null, 2);
      const blob = new Blob([json], { type: 'application/json' });
      const href = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = href;
      link.download = fileName + '.json';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast.success('Workflow exported successfully!', {
        position: 'top-center',
      });
    } catch (error) {
      toast.error(`Could not export workflow: ${error?.data?.message || error.message}`, {
        position: 'top-center',
      });
    }
  };

  readAndImport = (event) => {
    try {
      const file = event.target.files[0];
      if (!file) return;

      const fileReader = new FileReader();
      const fileName = file.name.replace('.json', '').substring(0, 100);
      fileReader.readAsText(file, 'UTF-8');
      fileReader.onload = async (event) => {
        const result = event.target.result;
        let fileContent;
        try {
          fileContent = JSON.parse(result);
        } catch (parseError) {
          toast.error(`Could not import: ${parseError}`);
          return;
        }

        const importedAppDef = fileContent.app || fileContent.appV2;
        const dataSourcesUsedInApps = [];
        importedAppDef.forEach((appDefinition) => {
          appDefinition?.definition?.appV2?.dataSources.forEach((dataSource) => {
            dataSourcesUsedInApps.push(dataSource);
          });
        });

        const dependentPluginsResponse = await pluginsService.findDependentPlugins(dataSourcesUsedInApps);
        const { pluginsToBeInstalled = [], pluginsListIdToDetailsMap = {} } = dependentPluginsResponse.data;
        this.setState({
          fileContent,
          fileName,
          showImportAppModal: true,
          dependentPlugins: pluginsToBeInstalled,
          dependentPluginsDetail: { ...pluginsListIdToDetailsMap },
        });
      };

      fileReader.onerror = (error) => {
        toast.error(`Could not import the app: ${error}`);
        return;
      };
      event.target.value = null;
    } catch (error) {
      let errorMessage = 'Some Error Occured';
      if (error?.error) {
        errorMessage = error.error;
      } else if (error?.message) {
        errorMessage = error.message;
      }
      toast.error(errorMessage);
    }
  };

  importFile = async (importJSON, appName, skipPermissionsGroupCheck = false) => {
    const { currentBranch, actions } = useWorkspaceBranchesStore.getState();
    if (currentBranch && this.props.appType !== 'workflow') {
      try {
        const exists = await actions.checkBranchExistsOnRemote(currentBranch.name);
        if (!exists) {
          toast.error(
            'Branch does not exist in git. Delete this branch and create a new one to continue to make changes.'
          );
          return;
        }
      } catch (_err) {
        /* allow on network error */
      }
    }

    appName = appName?.trim().replace(/\s+/g, ' ');
    this.setState({ isImportingApp: true });
    // For backward compatibility with legacy app import
    const organization_id = this.state.currentUser?.organization_id;
    const isLegacyImport = isEmpty(importJSON.tooljet_version);
    if (isLegacyImport) {
      importJSON = {
        app: [{ definition: importJSON, appName: appName }],
        tooljet_version: importJSON.tooljetVersion,
      };
    } else {
      importJSON.app[0].appName = appName;
    }
    const requestBody = {
      organization_id,
      ...importJSON,
      skip_permissions_group_check: skipPermissionsGroupCheck,
    };
    let installedPluginsInfo = [];
    try {
      if (this.state.dependentPlugins.length) {
        ({ installedPluginsInfo = [] } = await pluginsService.installDependentPlugins(
          this.state.dependentPlugins,
          true
        ));
      }

      if (importJSON.app[0].definition.appV2.type !== this.props.appType) {
        toast.error(
          `${this.props.appType === 'module' ? 'App' : 'Module'} could not be imported in ${
            this.props.appType === 'module' ? 'modules' : 'apps'
          } section. Switch to ${this.props.appType === 'module' ? 'apps' : 'modules'} section and try again.`,
          { style: { maxWidth: '425px' } }
        );
        this.setState({ isImportingApp: false });
        return;
      }

      const data = await appsService.importResource(requestBody, this.props.appType);
      toast.success(`${this.getAppType()} imported successfully.`);
      this.setState({ isImportingApp: false });

      if (!isEmpty(data.imports.app)) {
        this.props.navigate(`/${getWorkspaceId()}/apps/${data.imports.app[0].id}`, {
          state: { commitEnabled: this.state.commitEnabled },
        });
      } else if (!isEmpty(data.imports.tooljet_database)) {
        this.props.navigate(`/${getWorkspaceId()}/database`);
      }
    } catch (error) {
      if (error?.error?.type === 'permission-check') {
        this.setState({ showMissingGroupsModal: true, missingGroups: error?.error?.data });
        return;
      }
      if (installedPluginsInfo.length) {
        const pluginsId = installedPluginsInfo.map((pluginInfo) => pluginInfo.id);
        await pluginsService.uninstallPlugins(pluginsId);
      }

      this.setState({ isImportingApp: false });
      if (error.statusCode === 409) return false;
      toast.error(error?.error || error?.message || `${capitalize(this.getAppType())} import failed`);
    }
  };

  deployApp = async (event, appName, selectedApp) => {
    event.preventDefault();
    const { currentBranch, actions, activeBranchId } = useWorkspaceBranchesStore.getState();
    if (currentBranch && this.props.appType !== 'workflow') {
      try {
        const exists = await actions.checkBranchExistsOnRemote(currentBranch.name);
        if (!exists) {
          toast.error(
            'Branch does not exist in git. Delete this branch and create a new one to continue to make changes.'
          );
          return;
        }
      } catch (_err) {
        /* allow on network error */
      }
    }

    const id = selectedApp.id;
    this.setState({ deploying: true });
    try {
      const data = await libraryAppService.deploy(
        id,
        appName,
        this.state.dependentPlugins,
        this.state.shouldAutoImportPlugin,
        activeBranchId
      );
      this.setState({ deploying: false, showAIOnboardingLoadingScreen: false });
      toast.success(`${this.getAppType()} created successfully!`, { position: 'top-center' });

      posthogHelper.captureEvent('app_created', { entry_source: 'template' });

      this.props.navigate(`/${getWorkspaceId()}/apps/${data.app[0].id}`, {
        state: { commitEnabled: this.state.commitEnabled },
      });
      this.eraseAIOnboardingRelatedCookies();
    } catch (e) {
      this.setState({ deploying: false, showAIOnboardingLoadingScreen: false });
      toast.error(e.error);
      this.eraseAIOnboardingRelatedCookies();
      if (e.statusCode === 409) {
        return false;
      } else {
        return e;
      }
    }
  };

  eraseAIOnboardingRelatedCookies = () => {
    aiOnboardingService
      .deleteAiCookies()
      .then(() => {
        console.log('AI onboarding server side cookies deleted successfully');
      })
      .catch((error) => {
        console.error('Deleting AI onboarding server side cookies failed', error);
      })
      .finally(() => {
        updateCurrentSession({
          ai_cookies: {
            tj_api_source: null,
            tj_template_id: null,
          },
        });
      });
  };

  canViewWorkflow = () => {
    return this.canUserPerform(this.state.currentUser, 'view') && isWorkflowsFeatureEnabled();
  };

  canUserPerform(user, action, app) {
    const currentSession = authenticationService.currentSessionValue;
    const { user_permissions, app_group_permissions, workflow_group_permissions, super_admin, admin } = currentSession;

    if (super_admin) return true;

    if (this.props.appType === 'workflow') {
      const canCreateWorkflow = admin || user_permissions?.workflow_create;
      const canUpdateWorkflow =
        workflow_group_permissions?.is_all_editable ||
        workflow_group_permissions?.editable_workflows_id?.includes(app?.id);
      const canExecuteWorkflow =
        canUpdateWorkflow ||
        workflow_group_permissions?.is_all_executable ||
        workflow_group_permissions?.executable_workflows_id?.includes(app?.id);
      const canDeleteWorkflow = user_permissions?.workflow_delete || admin;

      switch (action) {
        case 'create':
          return canCreateWorkflow;
        case 'read':
          return canCreateWorkflow || canUpdateWorkflow || canDeleteWorkflow || canExecuteWorkflow;
        case 'update':
          return canUpdateWorkflow;
        case 'delete':
          return canDeleteWorkflow;
        case 'view':
          return (
            canCreateWorkflow ||
            canUpdateWorkflow ||
            canDeleteWorkflow ||
            canExecuteWorkflow ||
            workflow_group_permissions?.editable_workflows_id?.length > 0 ||
            workflow_group_permissions?.executable_workflows_id?.length > 0
          );
        default:
          return false;
      }
    } else if (this.props.appType === 'front-end') {
      // Backend resolves all folder-derived permissions (owned folders + granular folder permissions)
      // into editable_apps_id / viewable_apps_id at session time, so no frontend folder checks needed here.
      const canUpdateApp =
        app_group_permissions &&
        (app_group_permissions.is_all_editable || app_group_permissions.editable_apps_id.includes(app?.id));
      const canReadApp =
        (app_group_permissions && canUpdateApp) ||
        app_group_permissions.is_all_viewable ||
        app_group_permissions.viewable_apps_id.includes(app?.id);

      switch (action) {
        case 'create':
          return user_permissions.app_create;
        case 'read':
          return this.isUserOwnerOfApp(user, app) || canReadApp;
        case 'update':
          return canUpdateApp || this.isUserOwnerOfApp(user, app);
        case 'delete':
          return user_permissions.app_delete || this.isUserOwnerOfApp(user, app);
        default:
          return false;
      }
    } else if (this.props.appType === 'module') {
      // Admins have implicit full access to all modules
      if (currentSession?.admin || currentSession?.super_admin) {
        return true;
      }
      const modulePerms = currentSession?.module_group_permissions;
      if (modulePerms) {
        // Shared with the module editor read-only gate (useAppData) so the two can't drift.
        const canEdit = canEditModule(currentSession, app?.id, app?.user_id);
        const canReadModule =
          canEdit || modulePerms.is_all_viewable || (app?.id && modulePerms.viewable_apps_id?.includes(app.id));
        switch (action) {
          case 'create':
            return user_permissions.module_create;
          case 'read':
            return this.isUserOwnerOfApp(user, app) || canReadModule;
          case 'update':
            return canEdit;
          case 'delete':
            return user_permissions.module_delete || this.isUserOwnerOfApp(user, app);
          default:
            return false;
        }
      }
      // CE fallback: any builder can perform all module actions
      return currentSession?.role?.name === 'builder';
    }
  }

  isUserOwnerOfApp(user, app) {
    return user.id == app.user_id;
  }

  canCreateApp = () => {
    return this.canUserPerform(this.state.currentUser, 'create');
  };

  canUpdateApp = (app) => {
    return this.canUserPerform(this.state.currentUser, 'update', app);
  };

  canViewApp = (app) => {
    return this.canUserPerform(this.state.currentUser, 'read', app) && !this.canUpdateApp(app);
  };

  canDeleteApp = (app) => {
    return this.canUserPerform(this.state.currentUser, 'delete', app);
  };

  canCreateFolder = () => {
    const user_permissions = authenticationService.currentSessionValue?.user_permissions;
    return getFolderPermissionField(user_permissions, this.props.appType, 'create');
  };

  canDeleteFolder = () => {
    const user_permissions = authenticationService.currentSessionValue?.user_permissions;
    return getFolderPermissionField(user_permissions, this.props.appType, 'delete');
  };

  canUpdateFolder = () => {
    // Update folder (rename) requires either folderCreate permission or granular canEditFolder permission
    // For now, we use folderCreate (or its per-app-type equivalent) as the master permission for folder update
    const user_permissions = authenticationService.currentSessionValue?.user_permissions;
    return getFolderPermissionField(user_permissions, this.props.appType, 'create');
  };

  isWorkspaceBranchLocked = (app) => {
    const state = useWorkspaceBranchesStore.getState();
    if (!state.isInitialized || !state.orgGitConfig) return false;

    // Unsynced apps (pre-git or not yet pushed) are always mutable, even on master
    if (app?.app_versions?.[0]?.is_synced === false) return false;

    // Branching affects folder mutations for front-end apps and modules.
    // Workflows are not branch-scoped, so folder operations there remain unrestricted.
    const isBranchingEnabled =
      this.props.appType === 'front-end' || this.props.appType === 'module'
        ? state.orgGitConfig?.is_branching_enabled || state.orgGitConfig?.isBranchingEnabled
        : false;
    const isDefault = state.currentBranch?.is_default || state.currentBranch?.isDefault;
    return !!(isBranchingEnabled && isDefault);
  };

  // Git sync is configured but the workspace's license no longer covers it (expired/invalid, or the
  // current plan simply doesn't include git sync). This is the exact case the dashboard
  // WorkspaceLockedBanner surfaces ("...disable git sync to continue"): the workspace is read-locked
  // until git sync is disabled, so creating apps/modules must be blocked too.
  isGitSyncLicenseLocked = () => {
    const state = useWorkspaceBranchesStore.getState();
    if (!state.isInitialized || !state.orgGitConfig) return false;
    return !!(state.isGitSyncConfigured && isGitSyncLicenseInvalid(this.state.featureAccess));
  };

  isOnFeatureBranch = () => {
    const state = useWorkspaceBranchesStore.getState();
    if (!state.isInitialized || !state.orgGitConfig) return false;
    const isBranchingEnabled =
      this.props.appType === 'front-end' || this.props.appType === 'module'
        ? state.orgGitConfig?.is_branching_enabled || state.orgGitConfig?.isBranchingEnabled
        : false;
    const isDefault = state.currentBranch?.is_default || state.currentBranch?.isDefault;
    return !!(isBranchingEnabled && !isDefault);
  };

  // Git sync ON but in single-branch mode (branching disabled / unlicensed for multi-branch):
  // the delete lands on the default branch and is auto-committed + pushed to git — so it needs
  // the same "committed to git, cannot be retrieved" warning as a feature-branch delete, just
  // without the merge step. Only front-end apps and modules are branch-scoped and auto-commit
  // deletions to git (workflows are not). Multi-branch feature-branch deletes are handled by
  // isOnFeatureBranch(); multi-branch default-branch deletes are blocked upstream (switch-branch
  // modal), so the only case reaching here with git on is single-branch mode.
  isGitSyncSingleBranchDelete = () => {
    const state = useWorkspaceBranchesStore.getState();
    if (!state.isInitialized || !state.orgGitConfig) return false;
    if (this.props.appType !== 'front-end' && this.props.appType !== 'module') return false;
    const isBranchingEnabled = state.orgGitConfig?.is_branching_enabled || state.orgGitConfig?.isBranchingEnabled;
    return !isBranchingEnabled;
  };

  cancelDeleteAppDialog = () => {
    this.setState({
      appToBeDeleted: null,
      showAppDeletionConfirmation: false,
    });
  };

  executeAppDeletion = () => {
    const appId = this.state.appToBeDeleted.id;

    this.setState((prevState) => {
      const deletingAppIds = new Set(prevState.deletingAppIds);
      deletingAppIds.add(appId);
      return { isDeletingApp: true, deletingAppIds };
    });

    const finish = () => {
      this.setState((prevState) => {
        const deletingAppIds = new Set(prevState.deletingAppIds);
        deletingAppIds.delete(appId);
        return { deletingAppIds, isDeletingApp: false, appToBeDeleted: null, showAppDeletionConfirmation: false };
      });
    };

    appsService
      .deleteApp(appId, this.props.appType)
      .then((_data) => {
        this.fetchApps(
          this.state.currentPage
            ? this.state.apps?.length === 1
              ? this.state.currentPage - 1
              : this.state.currentPage
            : 1,
          this.state.currentFolder.id
        );
        this.fetchFolders();
        if (this.props.appType === 'workflow') {
          this.fetchWorkflowsInstanceLimit();
          this.fetchWorkflowsWorkspaceLimit();
        } else {
          this.fetchAppsLimit();
        }

        toast.success(`${this.getAppType()} deleted successfully.`);
        finish();
      })
      .catch((error) => {
        toast.error(error?.error || error?.message || 'Could not delete the app.');
        finish();
      });
  };

  isExistingPlanUser = (date) => {
    return new Date(date) < new Date('2025-04-01');
  };

  pageCount = () => {
    return this.state.currentFolder.id ? this.state.meta.folder_count : this.state.meta.total_count;
  };

  onSearchSubmit = (key) => {
    if (this.state.appSearchKey === key) {
      return;
    }
    this.fetchApps(1, this.state.currentFolder.id, key || '');
  };

  fetchOrgGit = () => {
    const workspaceId = authenticationService.currentSessionValue.current_organization_id;
    this.setState({ fetchingOrgGit: true });
    gitSyncService
      .getGitStatus(workspaceId)
      .then((data) => {
        this.setState({ orgGit: data });
      })
      .finally(() => {
        this.setState({ fetchingOrgGit: false });
      });
  };

  fetchRepoApps = (branch) => {
    this.setState({
      fetchingAppsFromRepos: true,
      selectedAppRepo: null,
      importingGitAppOperations: {},
      latestCommitData: null,
      selectedVersionOption: null,
    });
    const currentBranchId = useWorkspaceBranchesStore.getState().activeBranchId;
    gitSyncService
      .gitPull(branch, currentBranchId)
      .then((data) => {
        this.setState({ appsFromRepos: data?.meta_data });
      })
      .catch((error) => {
        toast.error(error?.error);
      })
      .finally(() => {
        this.setState({ fetchingAppsFromRepos: false });
      });
  };

  importGitApp = () => {
    const {
      appsFromRepos,
      selectedAppRepo,
      orgGit,
      importedAppName,
      selectedVersionOption,
      tags,
      selectedImportBranch,
    } = this.state;
    const appToImport = appsFromRepos[selectedAppRepo];
    const {
      git_app_name,
      git_version_id,
      git_version_name,
      last_commit_message,
      last_commit_user,
      lastpush_date,
      app_co_relation_id,
    } = appToImport;

    let commitHash = null;
    let commitMessage = last_commit_message;
    let commitUser = last_commit_user;
    let commitDate = lastpush_date;
    let gitVersionNameToUse = git_version_name;

    // If a tag is selected (not latest), use tag's commit info
    if (selectedVersionOption && selectedVersionOption !== 'latest') {
      const selectedTag = tags.find((t) => t.name === selectedVersionOption);
      if (selectedTag) {
        commitHash = selectedTag.commit?.sha;
        commitMessage = selectedTag.message;
        commitUser = selectedTag.tagger?.name;
        commitDate = selectedTag.tagger?.date;
        gitVersionNameToUse = selectedTag.name.split('/').pop();
      } else {
        commitMessage = last_commit_message;
        commitUser = last_commit_user;
        commitDate = lastpush_date;
      }
    }

    this.setState({ importingApp: true });
    const currentWorkspaceBranchId = useWorkspaceBranchesStore.getState().activeBranchId;
    const body = {
      gitAppId: selectedAppRepo,
      gitAppName: git_app_name,
      gitVersionName: gitVersionNameToUse,
      gitVersionId: git_version_id,
      organizationGitId: orgGit?.id,
      appName: importedAppName?.trim().replace(/\s+/g, ' '),
      // Imported apps are non-editable by default; editability is driven by git branch/sync state.
      allowEditing: false,
      ...(selectedImportBranch && { gitBranchName: selectedImportBranch }),
      ...(currentWorkspaceBranchId && { workspaceBranchId: currentWorkspaceBranchId }),
      ...(commitHash && { commitHash, appCoRelationId: app_co_relation_id }),
      ...(commitMessage && { lastCommitMessage: commitMessage }),
      ...(commitUser && { lastCommitUser: commitUser }),
      ...(commitDate && { lastPushDate: new Date(commitDate) }),
    };

    gitSyncService
      .importGitApp(body)
      .then((data) => {
        const workspaceId = getWorkspaceId();
        const appName = importedAppName?.trim() || git_app_name;
        toast.success(`${appName} and its dependent resources have been imported successfully!`);
        this.props.navigate(`/${workspaceId}/apps/${data.app.id}`);
      })
      .catch((error) => {
        if (error?.statusCode === 409) {
          try {
            const parsed = JSON.parse(error?.data?.message || error?.error || '{}');
            if (parsed?.conflictGroups?.length || parsed?.multiDraftResources?.length) {
              this.setState({
                gitImportConflictGroups: parsed.conflictGroups || [],
                gitImportMultiDraftResources: parsed.multiDraftResources || [],
                importingApp: false,
                showGitRepositoryImportModal: false,
              });
              return;
            }
          } catch {
            /* fall through to inline error */
          }
        }
        this.setState({ importingGitAppOperations: { message: error?.error } });
      })
      .finally(() => {
        this.setState({ importingApp: false });
      });
  };

  handleResolveImportConflicts = async (resolutions) => {
    try {
      const { actions } = useWorkspaceBranchesStore.getState();
      await actions.resolveConflicts(resolutions);
      this.setState({ gitImportConflictGroups: null });
      // resolveConflicts hydrates the affected apps server-side (isSynced, content),
      // but this component's in-memory state doesn't know that happened — reload so
      // the UI (app list, sync badges) reflects it immediately.
      // A toast fired now would be destroyed by the reload before it's visible, so
      // persist it and let App.jsx's componentDidMount show it once the fresh page mounts.
      sessionStorage.setItem('sync_success_toast', 'Resource(s) synced successfully!');
      window.location.reload();
    } catch (error) {
      toast.error(error?.error || error?.message || 'Failed to resolve conflicts');
    }
  };

  addAppToFolder = () => {
    const { appOperations } = this.state;
    const selectedApps = (appOperations?.selectedApps || []).filter((app) => !app?.isAllField);
    if (!appOperations?.selectedFolder || selectedApps.length === 0) {
      return toast.error('Select a folder');
    }
    this.setState({ appOperations: { ...appOperations, isAdding: true } });

    const workspaceId =
      authenticationService?.currentUserValue?.organization_id ||
      authenticationService?.currentSessionValue?.current_organization_id;

    const folderName = this.state.folders.find((f) => f.id === appOperations.selectedFolder)?.name || 'folder';

    const appIds = selectedApps.map((app) => app.value);
    folderService
      .bulkAddToFolder(appIds, appOperations.selectedFolder, this.props.appType)
      .then(() => {
        toast.success(`Apps moved to "${folderName}" folder successfully!`);
        this.foldersChanged();
        this.setState({ appOperations: {}, showAddToFolderModal: false });
        posthogHelper.captureEvent('click_add_to_folder_button', {
          workspace_id: workspaceId,
          app_ids: appIds,
          folder_id: appOperations?.selectedFolder,
        });
      })
      .catch(() => {
        toast.error('Failed to move apps to folder');
        this.setState({ appOperations: { ...appOperations, isAdding: false } });
      });
  };

  removeAppFromFolder = () => {
    const { appOperations } = this.state;
    if (!appOperations?.selectedFolder || !appOperations?.selectedApp) {
      return toast.error('Select a folder');
    }
    this.setState({ isDeletingAppFromFolder: true });

    folderService
      .removeAppFromFolder(appOperations.selectedApp.id, appOperations.selectedFolder.id, this.props.appType)
      .then(() => {
        toast.success('Application removed from folder successfully!');

        this.fetchApps(1, appOperations.selectedFolder.id);
        this.fetchFolders();
      })
      .catch(({ error }) => {
        toast.error(error);
      })
      .finally(() => {
        this.setState({
          appOperations: {},
          isDeletingAppFromFolder: false,
          showRemoveAppFromFolderConfirmation: false,
        });
      });
  };

  fetchAddToFolderApps = async () => {
    const folderId = this.state.currentFolder?.id;
    try {
      // page=0 triggers all=true backend param — returns all apps in one call, no pagination
      const result = await appsService.getAll(0, folderId || '', '', this.props.appType);
      this.setState({ addToFolderApps: result.apps || [] });
    } catch {
      this.setState({ addToFolderApps: [] });
    }
  };

  appActionModal = (app, folder, action) => {
    const { appOperations } = this.state;

    switch (action) {
      case 'add-to-folder':
        this.setState({
          appOperations: {
            ...appOperations,
            selectedApp: app,
            selectedApps: [{ label: app.name, name: app.name, value: app.id }],
            selectedFolder: folder?.id || null,
          },
          showAddToFolderModal: true,
          addToFolderApps: [],
        });
        this.fetchAddToFolderApps();
        break;
      case 'change-icon':
        if (this.isWorkspaceBranchLocked(app)) {
          this.setState({
            appOperations: { ...appOperations, selectedApp: app, selectedIcon: app?.icon },
            showSwitchBranchForChangeIcon: true,
          });
          break;
        }
        this.setState({
          appOperations: { ...appOperations, selectedApp: app, selectedIcon: app?.icon },
          showChangeIconModal: true,
        });
        break;
      case 'remove-app-from-folder':
        this.setState({
          appOperations: { ...appOperations, selectedApp: app, selectedFolder: folder },
          showRemoveAppFromFolderConfirmation: true,
        });
        break;
      case 'clone-app':
        if (this.isWorkspaceBranchLocked(app)) {
          this.setState({
            appOperations: { ...appOperations, selectedApp: app, selectedIcon: app?.icon },
            showSwitchBranchForClone: true,
          });
          break;
        }
        this.setState({
          appOperations: { ...appOperations, selectedApp: app, selectedIcon: app?.icon },
          showCloneAppModal: true,
        });
        break;
      case 'rename-app': {
        if (this.isWorkspaceBranchLocked(app)) {
          toast.error("Renaming isn't allowed on master. Switch branch to update name.");
          break;
        }
        this.setState({
          appOperations: { ...appOperations, selectedApp: app },
          showRenameAppModal: true,
        });
        break;
      }
    }
  };

  getIcons = () => {
    const { appOperations } = this.state;
    const selectedIcon = appOperations.selectedIcon || appOperations.selectedApp?.icon || defaultIcon;
    return iconList.map((icon, index) => (
      <li
        className={`p-3 ms-1 me-2 mt-1 mb-2${selectedIcon === icon ? ' selected' : ''}`}
        onClick={() => this.setState({ appOperations: { ...appOperations, selectedIcon: icon } })}
        key={index}
      >
        <BulkIcon name={icon} data-cy={`${icon}-icon`} />
      </li>
    ));
  };

  changeIcon = () => {
    const { appOperations, apps } = this.state;

    if (!appOperations?.selectedIcon || !appOperations?.selectedApp) {
      return toast.error('Select an icon');
    }
    if (appOperations.selectedIcon === appOperations.selectedApp.icon) {
      this.setState({ appOperations: {}, showChangeIconModal: false });
      return toast.success('Icon updated.');
    }
    this.setState({ appOperations: { ...appOperations, isAdding: true } });

    appsService
      .changeIcon(appOperations.selectedIcon, appOperations.selectedApp.id)
      .then(() => {
        toast.success('Icon updated.');

        const updatedApps = apps.map((app) => {
          if (app.id === appOperations.selectedApp.id) {
            app.icon = appOperations.selectedIcon;
          }
          return app;
        });
        this.setState({ appOperations: {}, showChangeIconModal: false, apps: updatedApps });
      })
      .catch(({ error }) => {
        this.setState({ appOperations: { ...appOperations, isAdding: false } });
        toast.error(error);
      });
  };

  generateOptionsForRepository = () => {
    const { appsFromRepos } = this.state;

    // Filter out non-app keys like 'has_latest_changes' and 'tags'
    const appIds = Object.keys(appsFromRepos).filter(
      (key) => key !== 'has_latest_changes' && key !== 'tags' && appsFromRepos[key]?.git_app_name
    );

    return appIds.map((gitAppId) => ({
      name: appsFromRepos[gitAppId].git_app_name,
      value: gitAppId,
    }));
  };

  handleNewAppNameChange = (e) => {
    this.setState({ newAppName: e.target.value });
  };
  removeQueryParameters = () => {
    const urlWithoutParams = window.location.origin + window.location.pathname;
    window.history.replaceState({}, document.title, urlWithoutParams);
  };

  showTemplateLibraryModal = () => {
    posthogHelper.captureEvent('click_import_from_template', {
      workspace_id:
        authenticationService?.currentUserValue?.organization_id ||
        authenticationService?.currentSessionValue?.current_organization_id,
      button_name: 'click_import_from_template',
    });
    this.setState({ showTemplateLibraryModal: true });
  };
  hideTemplateLibraryModal = () => {
    this.removeQueryParameters();
    this.setState({ showTemplateLibraryModal: false });
  };
  handleCommitEnableChange = (e) => {
    this.setState({ commitEnabled: e.target.checked });
  };
  toggleGitRepositoryImportModal = async () => {
    if (!this.state.showGitRepositoryImportModal) {
      const { currentBranch, actions } = useWorkspaceBranchesStore.getState();
      if (currentBranch) {
        try {
          const exists = await actions.checkBranchExistsOnRemote(currentBranch.name);
          if (!exists) {
            toast.error(
              'Branch does not exist in git. Delete this branch and create a new one to continue to make changes.'
            );
            return;
          }
        } catch (_err) {
          /* allow on network error */
        }
      }

      // OLD: fetch remote branches for branch picker
      // this.setState({
      //   showGitRepositoryImportModal: true,
      //   fetchingRemoteBranches: true,
      //   selectedImportBranch: null,
      //   appsFromRepos: {},
      //   selectedAppRepo: null,
      //   importingGitAppOperations: {},
      //   latestCommitData: null,
      //   selectedVersionOption: null,
      // });
      // useWorkspaceBranchesStore
      //   .getState()
      //   .actions.fetchRemoteBranches()
      //   .then((branches) => this.setState({ remoteBranches: branches || [], fetchingRemoteBranches: false }))
      //   .catch(() => {
      //     toast.error('Failed to fetch remote branches');
      //     this.setState({ fetchingRemoteBranches: false });
      //   });

      // Auto-set branch to current workspace branch and immediately fetch apps
      const branchName = currentBranch?.name || null;
      this.setState({
        showGitRepositoryImportModal: true,
        selectedImportBranch: branchName,
        appsFromRepos: {},
        selectedAppRepo: null,
        importingGitAppOperations: {},
        latestCommitData: null,
        selectedVersionOption: null,
      });
      if (branchName) {
        this.fetchRepoApps(branchName);
      }
    } else {
      this.setState({ showGitRepositoryImportModal: false });
    }
  };

  openCreateAppFromTemplateModal = async (template) => {
    if (this.isWorkspaceBranchLocked()) {
      this.setState({ showSwitchBranchForCreate: true });
      return;
    }
    try {
      const { plugins_to_be_installed = [], plugins_detail_by_id = {} } =
        (await libraryAppService.findDependentPluginsInTemplate?.(template.id)) || {};

      this.setState({
        showCreateAppFromTemplateModal: true,
        selectedTemplate: template,
        ...(plugins_to_be_installed.length && {
          shouldAutoImportPlugin: true,
          dependentPlugins: plugins_to_be_installed,
          dependentPluginsDetail: { ...plugins_detail_by_id },
        }),
      });
    } catch (error) {
      console.error('Error checking template plugins:', error);
      // Continue with template creation without plugins
      this.setState({
        showCreateAppFromTemplateModal: true,
        selectedTemplate: template,
      });
    }
  };

  closeCreateAppFromTemplateModal = () => {
    this.setState({
      showCreateAppFromTemplateModal: false,
      selectedTemplate: null,
      dependentPlugins: [],
      dependentPluginsDetail: {},
      shouldAutoImportPlugin: false,
    });
  };

  openCreateAppModal = () => {
    this.setState({ showCreateAppModal: true });
  };

  closeCreateAppModal = () => {
    this.setState({ showCreateAppModal: false });
  };

  openImportAppModal = async () => {
    /* Posthog Events */
    posthogHelper.captureEvent('click_import_button', {
      workspace_id:
        authenticationService?.currentUserValue?.organization_id ||
        authenticationService?.currentSessionValue?.current_organization_id,
      button_name: 'click_import_dropdown_button',
    });
    this.setState({ showImportAppModal: true });
  };

  closeImportAppModal = () => {
    this.setState({
      showImportAppModal: false,
      dependentPlugins: [],
      dependentPluginsDetail: {},
      shouldAutoImportPlugin: false,
    });
  };

  isWithinSevenDaysOfSignUp = (date) => {
    const currentDate = new Date().toISOString();
    const differenceInTime = new Date(currentDate).getTime() - new Date(date).getTime();
    const differenceInDays = differenceInTime / (1000 * 3600 * 24);
    return differenceInDays <= 7;
  };

  setShowUserGroupMigrationModal = () => {
    this.setState({ showUserGroupMigrationModal: false });
  };

  setShowGroupMigrationBanner = () => {
    this.setState({ showGroupMigrationBanner: false });
    localStorage.setItem('hasClosedGroupMigrationBanner', 'true');
  };
  // We are using this method to get notified from the child component that commit enabled status has been changed
  // To be removed once all git related functionalities are moved to specific components
  handleCommitChange = (commitEnabled) => {
    this.setState({ commitEnabled: commitEnabled });
  };
  shouldShowMigrationBanner = () => {
    const { currentSessionValue } = authenticationService;
    const { appType } = this.props;
    return (
      currentSessionValue?.admin &&
      this.state.showGroupMigrationBanner &&
      new Date(currentSessionValue?.current_user?.created_at) < new Date('2025-02-01') &&
      appType !== 'workflow'
    );
  };
  handleImportBranchChange = (newVal) => {
    this.setState({ selectedImportBranch: newVal });
    this.fetchRepoApps(newVal);
  };

  handleAppNameChange = (e) => {
    const newAppName = e.target.value;
    const { appsFromRepos } = this.state;
    const MAX_LENGTH = 100;
    let validationMessage = {};
    if (!newAppName.trim()) {
      validationMessage = { message: 'App name cannot be empty' };
    } else if (newAppName.length > 100) {
      validationMessage = { message: 'App name cannot exceed 100 characters' };
    }
    if (newAppName.length > MAX_LENGTH) {
      this.setState({
        importingGitAppOperations: validationMessage,
      });
      return;
    }
    this.setState({
      importedAppName: newAppName,
      importingGitAppOperations: validationMessage,
    });
  };

  handleAppRepoChange = async (newVal) => {
    const { appsFromRepos, selectedImportBranch } = this.state;
    const selectedApp = appsFromRepos[newVal];
    this.setState({
      selectedAppRepo: newVal,
      importedAppName: selectedApp?.git_app_name,
    });
    // if (selectedApp?.app_name_exist === 'EXIST') {
    //   this.setState({
    //     importingGitAppOperations: { message: 'App name already exists' },
    //     fetchingLatestCommitData: true,
    //     latestCommitData: null,
    //   });
    // } else {
    this.setState({
      importingGitAppOperations: {},
      fetchingLatestCommitData: true,
      latestCommitData: null,
      selectedVersionOption: null,
    });
    // }

    try {
      const data = await gitSyncService.checkForUpdatesByAppName(selectedApp?.git_app_name, selectedImportBranch);
      this.setState({
        latestCommitData: data?.metaData,
        tags: data?.metaData.tags,
        fetchingLatestCommitData: false,
        selectedVersionOption: 'latest',
      });
    } catch (error) {
      console.error('Failed to check for updates:', error);
      this.setState({ fetchingLatestCommitData: false });
    }
  };

  // Helper functions for workflow limit checks
  hasWorkflowLimitReached = () => {
    const { workflowInstanceLevelLimit, workflowWorkspaceLevelLimit } = this.state;

    const instanceLimitReached =
      workflowInstanceLevelLimit.total === 0 || workflowInstanceLevelLimit.current >= workflowInstanceLevelLimit.total;
    const workspaceLimitReached =
      workflowWorkspaceLevelLimit.total === 0 ||
      workflowWorkspaceLevelLimit.current >= workflowWorkspaceLevelLimit.total;

    return instanceLimitReached || workspaceLimitReached;
  };

  hasWorkflowLimitWarning = () => {
    const { workflowInstanceLevelLimit, workflowWorkspaceLevelLimit } = this.state;
    return this.hasInstanceLimitWarning() || this.hasWorkspaceLimitWarning();
  };

  hasInstanceLimitWarning = () => {
    const { workflowInstanceLevelLimit } = this.state;
    const percentage = workflowInstanceLevelLimit.percentage;

    return (
      workflowInstanceLevelLimit.current >= workflowInstanceLevelLimit.total ||
      (percentage >= 90 && percentage < 100) ||
      workflowInstanceLevelLimit.current === workflowInstanceLevelLimit.total - 1
    );
  };

  hasWorkspaceLimitWarning = () => {
    const { workflowWorkspaceLevelLimit } = this.state;
    const percentage = workflowWorkspaceLevelLimit.percentage;

    return (
      workflowWorkspaceLevelLimit.current >= workflowWorkspaceLevelLimit.total ||
      (percentage >= 90 && percentage < 100) ||
      workflowWorkspaceLevelLimit.current === workflowWorkspaceLevelLimit.total - 1
    );
  };

  getWorkflowLimit = () => {
    return this.hasInstanceLimitWarning()
      ? this.state.workflowInstanceLevelLimit
      : this.state.workflowWorkspaceLevelLimit;
  };

  onPermissionDeniedModalHide = () => {
    this.setState({ showInsufficentPermissionModal: false });
    this.eraseAIOnboardingRelatedCookies();
  };

  generateVersionOptions = () => {
    const { latestCommitData, tags } = this.state;
    const options = [];

    if (latestCommitData?.latestCommit?.[0]) {
      options.push({
        label: 'Latest commit',
        value: 'latest',
        isLatest: true,
        isDraft: true,
        sha: latestCommitData?.latestCommit?.[0]?.commitId,
      });
    }

    // Add tags - filter out tags that have the same SHA as the latest commit
    if (tags && tags.length > 0) {
      tags.forEach((tag) => {
        const [, version] = tag.name.split('/');
        options.push({
          label: version,
          value: tag.name,
          isLatest: false,
          isDraft: false,
        });
      });
    }

    return options;
  };

  getSelectedVersionCommitInfo = () => {
    const { selectedVersionOption, latestCommitData, tags } = this.state;
    const isLatest = !selectedVersionOption || selectedVersionOption === 'latest';

    if (isLatest) {
      return {
        message: latestCommitData?.latestCommit[0]?.message,
        author: latestCommitData?.latestCommit[0]?.author,
        date: latestCommitData?.latestCommit[0]?.date,
        versionName: latestCommitData?.gitVersionName,
      };
    }

    const selectedTag = tags?.find((t) => t.name === selectedVersionOption);
    return {
      message: selectedTag?.message,
      author: selectedTag?.tagger?.name,
      date: selectedTag?.tagger?.date,
      versionName: selectedVersionOption?.split('/')?.pop(),
    };
  };

  renderVersionOption = (option) => {
    return (
      <div className="version-option-item" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
        <span className="version-option-name">{option.label}</span>
      </div>
    );
  };

  handleVersionOptionChange = (newVal) => {
    this.setState({ selectedVersionOption: newVal });
  };

  render() {
    const {
      apps,
      isLoading,
      creatingApp,
      meta,
      currentFolder,
      showAppDeletionConfirmation,
      showRemoveAppFromFolderConfirmation,
      isDeletingApp,
      isImportingApp,
      isDeletingAppFromFolder,
      appSearchKey,
      showAddToFolderModal,
      showChangeIconModal,
      showCloneAppModal,
      appOperations,
      isExportingApp,
      appToBeDeleted,
      app,
      appsLimit,
      featureAccess,
      commitEnabled,
      fetchingOrgGit,
      orgGit,
      showGitRepositoryImportModal,
      fetchingAppsFromRepos,
      selectedAppRepo,
      appsFromRepos,
      latestCommitData,
      fetchingLatestCommitData,
      importingApp,
      selectedVersionOption,
      importingGitAppOperations,
      selectedImportBranch,
      remoteBranches,
      fetchingRemoteBranches,
      featuresLoaded,
      showCreateAppModal,
      showImportAppModal,
      fileContent,
      fileName,
      showRenameAppModal,
      showCreateAppFromTemplateModal,
      workflowWorkspaceLevelLimit,
      workflowInstanceLevelLimit,
      showUserGroupMigrationModal,
      showGroupMigrationBanner,
      dependentPlugins,
      dependentPluginsDetail,
      showMissingGroupsModal,
      missingGroups,
      missingGroupsExpanded,
      showAIOnboardingLoadingScreen,
      showInsufficentPermissionModal,
      showDependentAppsModal,
    } = this.state;

    if (showAIOnboardingLoadingScreen) {
      return <TJLoader />;
    }

    const invalidLicense = featureAccess?.licenseStatus?.isExpired || !featureAccess?.licenseStatus?.isLicenseValid;
    const hasMultiEnvironment = featureAccess?.multiEnvironment || false;
    // Only exclude env param if license is invalid/expired (basic plan)
    // If license is valid but multi-environment feature is not available, still include env param
    const shouldExcludeEnvParam = invalidLicense;
    const moduleEnabled = featureAccess?.modulesEnabled || false;
    const deleteModuleText =
      'This action will permanently delete the module from all connected applications. This cannot be reversed. Confirm deletion?';

    const getDisabledState = () => {
      if (this.props.appType === 'module') {
        return !moduleEnabled || this.isGitSyncLicenseLocked();
      } else if (this.props.appType === 'front-end') {
        return appsLimit?.percentage >= 100 || this.isGitSyncLicenseLocked();
      } else {
        return this.hasWorkflowLimitReached();
      }
    };

    const showCreateAppButtonTooltip = () => {
      return this.canCreateApp();
    };
    const modalConfigs = {
      create: {
        modalType: 'create',
        closeModal: this.closeCreateAppModal,
        processApp: (name) => this.createApp(name),
        show: this.openCreateAppModal,
        title: `Create ${this.getAppType().toLocaleLowerCase()}`,
        actionButton: `+ Create ${this.getAppType().toLocaleLowerCase()}`,
        actionLoadingButton: 'Creating',
        appType: this.props.appType,
      },
      clone: {
        modalType: 'clone',
        closeModal: () => this.setState({ showCloneAppModal: false }),
        processApp: this.cloneApp,
        show: () => this.setState({ showCloneAppModal: true }),
        title: `Clone ${this.getAppType().toLocaleLowerCase()}`,
        actionButton: `Clone ${this.getAppType().toLocaleLowerCase()}`,
        actionLoadingButton: 'Cloning',
        selectedAppId: appOperations?.selectedApp?.id,
        selectedAppName: appOperations?.selectedApp?.name,
        appType: this.props.appType,
      },
      import: {
        modalType: 'import',
        closeModal: () => this.setState({ showImportAppModal: false }),
        processApp: this.importFile,
        show: this.openImportAppModal,
        title: `Import ${this.getAppType().toLocaleLowerCase()}`,
        actionButton: `Import ${this.getAppType().toLocaleLowerCase()}`,
        actionLoadingButton: 'Importing',
        fileContent: fileContent,
        selectedAppName: fileName,
        dependentPluginsDetail: dependentPluginsDetail,
        dependentPlugins: dependentPlugins,
        appType: this.props.appType,
      },
      template: {
        modalType: 'template',
        closeModal: this.closeCreateAppFromTemplateModal,
        processApp: this.deployApp,
        show: this.openCreateAppFromTemplateModal,
        title: 'Create new app from template',
        actionButton: '+ Create app',
        actionLoadingButton: 'Creating',
        templateDetails: this.state.selectedTemplate,
        dependentPluginsDetail: dependentPluginsDetail,
        dependentPlugins: dependentPlugins,
      },
    };
    const isAdmin = authenticationService?.currentSessionValue?.admin;
    const isBuilder = authenticationService?.currentSessionValue?.is_builder;

    //import app missing groups modal config
    const threshold = 3;
    const isLong = missingGroups.length > threshold;
    const displayedGroups = missingGroupsExpanded ? missingGroups : missingGroups.slice(0, threshold);
    return (
      <Layout switchDarkMode={this.props.switchDarkMode} darkMode={this.props.darkMode}>
        <div className="wrapper home-page">
          {/* <WorkspaceLockedBanner /> */}
          {/* this needs more revamp and conditions---> currently added this for testing*/}
          {showInsufficentPermissionModal && (
            <PermissionDeniedModal
              show={showInsufficentPermissionModal}
              onHide={this.onPermissionDeniedModalHide}
              darkMode={this.props.darkMode}
            />
          )}
          <WorkspaceSwitchBranchModal
            show={this.state.showSwitchBranchForCreate}
            onClose={() => this.setState({ showSwitchBranchForCreate: false })}
            onBranchSwitch={() => {
              this.fetchApps(1, this.state.currentFolder.id);
              this.setState({ showSwitchBranchForCreate: false, showCreateAppModal: true });
            }}
          />
          <WorkspaceSwitchBranchModal
            show={this.state.showSwitchBranchForDelete}
            onClose={() => this.setState({ showSwitchBranchForDelete: false, appToBeDeleted: null })}
            onBranchSwitch={() => {
              this.fetchApps(1, this.state.currentFolder.id);
              this.setState({ showSwitchBranchForDelete: false, showAppDeletionConfirmation: true });
            }}
          />
          <WorkspaceSwitchBranchModal
            show={this.state.showSwitchBranchForClone}
            onClose={() => this.setState({ showSwitchBranchForClone: false })}
            onBranchSwitch={() => {
              this.fetchApps(1, this.state.currentFolder.id);
              this.setState({ showSwitchBranchForClone: false, showCloneAppModal: true });
            }}
          />
          <WorkspaceSwitchBranchModal
            show={this.state.showSwitchBranchForChangeIcon}
            onClose={() => this.setState({ showSwitchBranchForChangeIcon: false })}
            onBranchSwitch={() => {
              this.fetchApps(1, this.state.currentFolder.id);
              this.setState({ showSwitchBranchForChangeIcon: false, showChangeIconModal: true });
            }}
          />
          <PullConflictModal
            show={!!(this.state.gitImportConflictGroups?.length || this.state.gitImportMultiDraftResources?.length)}
            conflictGroups={this.state.gitImportConflictGroups || []}
            multiDraftResources={this.state.gitImportMultiDraftResources || []}
            onClose={() => this.setState({ gitImportConflictGroups: null, gitImportMultiDraftResources: [] })}
            onResolve={this.handleResolveImportConflicts}
            context="import"
          />
          <AppActionModal
            modalStates={{
              showCreateAppModal,
              showCloneAppModal,
              showImportAppModal,
              showCreateAppFromTemplateModal,
            }}
            configs={modalConfigs}
            onCommitChange={this.handleCommitChange}
          />
          <ModalBase
            showHeader={false}
            showFooter={false}
            handleConfirm={() => this.importFile(fileContent, fileName, true)}
            show={showMissingGroupsModal}
            isLoading={importingApp}
            handleClose={() => this.setState({ showMissingGroupsModal: false })}
            confirmBtnProps={{
              title: 'Import',
              tooltipMessage: '',
            }}
            className="missing-groups-modal"
            darkMode={this.props.darkMode}
          >
            <div className="missing-groups-modal-body">
              <div className="flex items-start">
                <SolidIcon name="warning" width="40px" fill="var(--icon-warning)" />
                <div>
                  <div className="header">Warning: Missing user groups for permissions</div>
                  <p className="sub-header">
                    Permissions for the following user group(s) won’t be applied since they do not exist in this
                    workspace.
                  </p>
                </div>
              </div>

              <div className="groups-list">
                <div
                  className={`border rounded text-sm container ${
                    missingGroupsExpanded ? 'max-h-48 overflow-y-auto' : ''
                  }`}
                >
                  <div style={{ color: 'var(--text-placeholder)' }} className="tj-text-xsm font-weight-500">
                    User groups
                  </div>
                  <div className="mt-1">
                    {displayedGroups.map((group, idx) => (
                      <span className="tj-text-xsm font-weight-500" key={idx}>
                        {group}
                        {idx < displayedGroups.length - 1 ? ', ' : ''}
                      </span>
                    ))}
                    {!missingGroupsExpanded && isLong && '...'}
                  </div>
                </div>

                {isLong && (
                  <button
                    class="toggle-button"
                    onClick={() => this.setState({ missingGroupsExpanded: !missingGroupsExpanded })}
                  >
                    <span className="chevron">
                      <SolidIcon
                        fill="var(--icon-brand)"
                        name={missingGroupsExpanded ? 'cheveronup' : 'cheverondown'}
                      />
                    </span>
                    <span class="label">{missingGroupsExpanded ? 'See less' : 'See more'}</span>
                  </button>
                )}
              </div>

              <p className="info">
                Restricted pages, queries, or components will become accessible to all users or to existing groups with
                permissions. To avoid this, create the missing groups before importing, or reconfigure permissions after
                import.
              </p>

              <div className="mt-6 d-flex justify-between action-btns">
                <ButtonSolid
                  className="secondary-action"
                  variant={'tertiary'}
                  onClick={() => this.setState({ showMissingGroupsModal: false, isImportingApp: false })}
                >
                  Cancel import
                </ButtonSolid>
                <ButtonSolid
                  isLoading={importingApp}
                  variant={'primary'}
                  onClick={() => this.importFile(fileContent, fileName, true)}
                  className="primary-action"
                >
                  Import with limited permissions
                </ButtonSolid>
              </div>
            </div>
          </ModalBase>
          {showRenameAppModal && (
            <AppModal
              show={() => this.setState({ showRenameAppModal: true })}
              closeModal={() => this.setState({ showRenameAppModal: false })}
              processApp={this.renameApp}
              selectedAppId={appOperations.selectedApp.id}
              selectedAppName={appOperations.selectedApp.name}
              title={`Rename ${this.getAppType().toLocaleLowerCase()}`}
              titleAdornment={
                this.isOnFeatureBranch() ? (
                  <ToolTip
                    message="This is a global setting which follows the same PR flow but are not version controlled, they apply across all versions once merged."
                    placement="top"
                    width="272px"
                  >
                    <span className="tw-inline-flex tw-items-center tw-ml-2">
                      <TriangleAlert size={18} className="tw-text-[var(--icon-warning)]" />
                    </span>
                  </ToolTip>
                ) : null
              }
              actionButton={`Rename ${this.getAppType().toLocaleLowerCase()}`}
              actionLoadingButton={'Renaming'}
              appType={this.props.appType}
            />
          )}
          <ConfirmDialog
            show={showAppDeletionConfirmation}
            title="Delete"
            message={
              this.isOnFeatureBranch() ? (
                <span>
                  {`The ${appTypeToDisplayNameMapping[this.props.appType]?.toLowerCase() ?? 'app'} ${
                    appToBeDeleted?.name
                  } and the associated data will be deleted from this branch. On merge to ${
                    useWorkspaceBranchesStore.getState().branches?.find((b) => b.is_default || b.isDefault)?.name ??
                    'the default branch'
                  }, `}
                  <strong>
                    {appTypeToDisplayNameMapping[this.props.appType]?.toLowerCase() ?? 'app'} and all its associated
                    versions
                  </strong>
                  {' will be deleted from git and cannot be retrieved.'}
                  <br />
                  <br />
                  {'Are you sure you want to continue?'}
                </span>
              ) : this.isGitSyncSingleBranchDelete() ? (
                <span>
                  {`The ${appTypeToDisplayNameMapping[this.props.appType]?.toLowerCase() ?? 'app'} ${
                    appToBeDeleted?.name
                  } and the associated data will be deleted and `}
                  <strong>
                    {appTypeToDisplayNameMapping[this.props.appType]?.toLowerCase() ?? 'app'} and all its associated
                    versions
                  </strong>
                  {' will be deleted from git and cannot be retrieved.'}
                  <br />
                  <br />
                  {'Are you sure you want to continue?'}
                </span>
              ) : (
                this.props.t(
                  this.props.appType === 'workflow'
                    ? 'homePage.deleteWorkflowAndData'
                    : this.props.appType === 'front-end'
                      ? 'homePage.deleteAppAndData'
                      : deleteModuleText,
                  { appName: appToBeDeleted?.name }
                )
              )
            }
            confirmButtonText={
              this.isOnFeatureBranch() || this.isGitSyncSingleBranchDelete() ? 'Delete and commit' : undefined
            }
            confirmButtonLoading={isDeletingApp}
            cancelButtonDisabled={isDeletingApp}
            staticBackdrop={true}
            hideCloseIcon={true}
            onConfirm={() => this.executeAppDeletion()}
            onCancel={() => this.cancelDeleteAppDialog()}
            darkMode={this.props.darkMode}
            cancelButtonText="Cancel"
          />

          <ModalBase
            show={showDependentAppsModal}
            handleClose={() => this.setState({ showDependentAppsModal: false })}
            showHeader={false}
            showFooter={false}
            darkMode={this.props.darkMode}
            className="dependent-apps-modal"
          >
            <div className="tw-flex tw-flex-col tw-gap-6 tw-p-6">
              <div className="tw-flex tw-flex-col tw-gap-2">
                <SolidIcon name="warning" width="40" fill="var(--icon-danger)" />
                <div className="tw-flex tw-flex-col tw-gap-[2px]">
                  <div className="tw-font-medium tw-text-[16px] tw-leading-6 tw-text-default tw-opacity-80">
                    Dependent apps found!
                  </div>
                  <div className="tw-font-normal tw-text-xs tw-leading-[18px] tw-text-default">
                    Cannot delete this module as it is being used in one or more apps.
                  </div>
                </div>
              </div>
              <div className="tw-flex tw-justify-end">
                <ButtonSolid
                  variant="tertiary"
                  onClick={() => this.setState({ showDependentAppsModal: false })}
                  data-cy="dependent-apps-acknowledge-button"
                >
                  I understand
                </ButtonSolid>
              </div>
            </div>
          </ModalBase>

          <ConfirmDialog
            show={showRemoveAppFromFolderConfirmation}
            message={`The ${
              appTypeToDisplayNameMapping[this.props.appType]?.toLowerCase() ?? 'app'
            } will be removed from this folder, do you want to continue?`}
            confirmButtonLoading={isDeletingAppFromFolder}
            onConfirm={() => this.removeAppFromFolder()}
            onCancel={() =>
              this.setState({
                appOperations: {},
                isDeletingAppFromFolder: false,
                showRemoveAppFromFolderConfirmation: false,
              })
            }
            darkMode={this.props.darkMode}
          />
          <ModalBase
            title={'Import app from git repository'}
            show={showGitRepositoryImportModal}
            handleClose={this.toggleGitRepositoryImportModal}
            handleConfirm={this.importGitApp}
            confirmBtnProps={{
              title: 'Import app',
              tooltipMessage: '',
              isLoading: importingApp,
              disabled: importingApp || !selectedAppRepo || importingGitAppOperations?.message,
            }}
            darkMode={this.props.darkMode}
          >
            {/* NEW MODAL CONTENT */}
            <>
              {/* IMPORT IN */}
              <div className="import-in-row">
                <span className="tj-text-xsm font-weight-500 tj-text">Import in </span>
                <span className="branch-name-badge">
                  <SolidIcon name="gitbranch" width="14" fill="var(--indigo9)" />
                  {useWorkspaceBranchesStore.getState().currentBranch?.name || 'main'}
                </span>
              </div>

              {/* IMPORT FROM — locked to current branch */}
              <div className="form-group">
                <label
                  className="mb-1 tj-text-xsm font-weight-500"
                  style={{ color: 'var(--slate8)' }}
                  data-cy="import-from-label"
                >
                  Import from
                </label>
                <div className="tj-app-input import-from-disabled-select" data-cy="import-from-select">
                  <Select
                    options={[
                      {
                        name: useWorkspaceBranchesStore.getState().currentBranch?.name || 'main',
                        value: useWorkspaceBranchesStore.getState().currentBranch?.name || 'main',
                      },
                    ]}
                    isDisabled={true}
                    value={useWorkspaceBranchesStore.getState().currentBranch?.name || 'main'}
                    width={'100%'}
                    closeMenuOnSelect={true}
                    customWrap={true}
                  />
                </div>
                <div className="tj-text-xxsm import-from-helper-text" data-cy="import-from-helper">
                  Apps can only be imported from the same branch
                </div>
              </div>

              {/* APP SELECT */}
              <div className="form-group">
                <label className="mb-1 tj-text-sm tj-text font-weight-500" data-cy="create-app-from-label">
                  App
                </label>
                <div className="tj-app-input" data-cy="app-select">
                  <Select
                    options={this.generateOptionsForRepository()}
                    disabled={importingApp || fetchingAppsFromRepos}
                    onChange={this.handleAppRepoChange}
                    width={'100%'}
                    value={selectedAppRepo}
                    placeholder={fetchingAppsFromRepos ? 'Loading apps...' : 'Select app...'}
                    closeMenuOnSelect={true}
                    customWrap={true}
                  />
                </div>
                {importingGitAppOperations?.message && (
                  <div className={cx('tj-input-error', 'tj-text-xxsm info-text')} data-cy="app-name-helper-text">
                    {importingGitAppOperations.message}
                  </div>
                )}
              </div>

              {selectedAppRepo && (
                <>
                  {fetchingLatestCommitData ? (
                    <div className="d-flex flex-column" style={{ gap: '8px', padding: '4px 0' }}>
                      <div style={{ height: '12px', borderRadius: '4px', background: 'var(--slate4)', width: '40%' }} />
                      <div style={{ height: '12px', borderRadius: '4px', background: 'var(--slate4)', width: '65%' }} />
                      <div style={{ height: '12px', borderRadius: '4px', background: 'var(--slate4)', width: '55%' }} />
                    </div>
                  ) : (
                    <>
                      {/* VERSION SELECT — default/main branch only */}
                      {(useWorkspaceBranchesStore.getState().currentBranch?.is_default ||
                        useWorkspaceBranchesStore.getState().currentBranch?.isDefault) && (
                        <div className="form-group">
                          <label className="mb-1 info-label tj-text-xsm font-weight-500" data-cy="version-select-label">
                            Version
                          </label>
                          <div className="tj-app-input" data-cy="version-select">
                            <Select
                              options={this.generateVersionOptions()}
                              disabled={importingApp}
                              onChange={this.handleVersionOptionChange}
                              width={'100%'}
                              value={this.state.selectedVersionOption}
                              placeholder="Select version or tag..."
                              closeMenuOnSelect={true}
                              customWrap={true}
                              customOption={this.renderVersionOption}
                            />
                          </div>
                        </div>
                      )}

                      {/* INFO ALERT */}
                      <div className="import-dependent-info-alert" data-cy="import-info-alert">
                        <SolidIcon name="warning" width="16" fill="var(--indigo9)" />
                        <span>
                          This app with its <strong>dependent modules &amp; data sources</strong> will be pulled
                        </span>
                      </div>
                    </>
                  )}
                </>
              )}
            </>
          </ModalBase>
          <Modal
            show={showAddToFolderModal && !!appOperations.selectedApp}
            closeModal={() => this.setState({ showAddToFolderModal: false, appOperations: {} })}
            title={this.props.t('homePage.appCard.updateFolder', 'Update folder')}
          >
            <div className="row">
              <div className="col modal-main">
                <div className="mb-3 move-selected-app-to-text " data-cy="move-selected-app-to-text">
                  <label className="form-label">
                    {this.props.t('homePage.appCard.moveSelectedApps', 'Move selected apps')}
                  </label>
                  <AppsMultiSelect
                    options={this.state.addToFolderApps.map((app) => ({
                      label: app.name,
                      name: app.name,
                      value: app.id,
                    }))}
                    value={appOperations?.selectedApps || []}
                    onChange={(selectedApps) => this.setState({ appOperations: { ...appOperations, selectedApps } })}
                    isDisabled={!!appOperations?.isAdding}
                    placeholder={this.props.t('homePage.appCard.selectApps', 'Select apps...')}
                    inFolder={!!this.state.currentFolder?.id}
                  />
                </div>
                <div className="mb-3">
                  <span>{this.props.t('homePage.appCard.to', 'to')}</span>
                </div>
                <div data-cy="select-folder" className="select-folder-container">
                  <label className="form-label">{this.props.t('homePage.appCard.folderName', 'Folder name')}</label>
                  <Select
                    options={this.state.folders
                      .filter((folder) => {
                        const currentSession = authenticationService.currentSessionValue;
                        if (currentSession?.super_admin || currentSession?.admin) return true;

                        // Check if user has edit permissions for the folder — resolved per
                        // appType (front-end/module/workflow each have their own granular bucket).
                        const folderPermissions = getFolderGroupPermissions(currentSession, this.props.appType);
                        if (folderPermissions?.is_all_editable) return true;
                        if (folderPermissions?.editable_folders_id?.includes(folder.id)) return true;

                        // Allow folder owners to add apps to their own folders
                        const currentUserId = currentSession?.current_user?.id;
                        return !!(currentUserId && folder.created_by === currentUserId);
                      })
                      .map((folder) => ({ name: folder.name, value: folder.id }))}
                    disabled={!!appOperations?.isAdding}
                    onChange={(newVal) => {
                      this.setState({ appOperations: { ...appOperations, selectedFolder: newVal } });
                    }}
                    width={'100%'}
                    value={appOperations?.selectedFolder}
                    placeholder={this.props.t('homePage.appCard.selectFolder', 'Select folder')}
                    closeMenuOnSelect={true}
                  />
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col d-flex modal-footer-btn justify-content-end">
                <ButtonSolid
                  variant="tertiary"
                  onClick={() => this.setState({ showAddToFolderModal: false, appOperations: {} })}
                  data-cy="cancel-button"
                >
                  {this.props.t('globals.cancel', 'Cancel')}
                </ButtonSolid>
                <ButtonSolid
                  onClick={this.addAppToFolder}
                  data-cy="add-to-folder-button"
                  isLoading={appOperations?.isAdding}
                  disabled={!appOperations?.selectedFolder || !appOperations?.selectedApps?.length}
                >
                  {this.props.t('homePage.appCard.addToFolder', 'Add to folder')}
                </ButtonSolid>
              </div>
            </div>
          </Modal>

          <Modal
            show={showChangeIconModal && !!appOperations.selectedApp}
            closeModal={() => this.setState({ showChangeIconModal: false, appOperations: {} })}
            title={this.props.t('homePage.appCard.changeIcon', 'Change Icon')}
            titleAdornment={
              this.isOnFeatureBranch() ? (
                <ToolTip
                  message="This is a global setting which follows the same PR flow but are not version controlled, they apply across all versions once merged."
                  placement="top"
                  width="272px"
                >
                  <span className="tw-inline-flex tw-items-center tw-ml-2">
                    <TriangleAlert size={18} className="tw-text-[var(--icon-warning)]" />
                  </span>
                </ToolTip>
              ) : null
            }
          >
            <div className="row">
              <div className="col modal-main icon-change-modal">
                <ul className="p-0">{this.getIcons()}</ul>
              </div>
            </div>
            <div className="row">
              <div className="col d-flex modal-footer-btn justify-content-end">
                <ButtonSolid
                  onClick={() => this.setState({ showChangeIconModal: false, appOperations: {} })}
                  data-cy="cancel-button"
                  variant="tertiary"
                >
                  {this.props.t('globals.cancel', 'Cancel')}
                </ButtonSolid>
                <ButtonSolid
                  className={`btn btn-primary ${appOperations?.isAdding ? 'btn-loading' : ''}`}
                  onClick={this.changeIcon}
                  data-cy="change-button"
                >
                  {this.props.t('homePage.change', 'Change')}
                </ButtonSolid>
              </div>
            </div>
          </Modal>
          {isExportingApp && app.hasOwnProperty('id') && (
            <ExportAppModal
              show={isExportingApp}
              closeModal={() => {
                this.setState({ isExportingApp: false, app: {} });
              }}
              customClassName="modal-version-lists"
              title={'Select a version to export'}
              app={app}
              darkMode={this.props.darkMode}
            />
          )}
          <div className="row gx-0">
            <div className="home-page-sidebar col p-0">
              <div className="create-new-app-license-wrapper">
                {showCreateAppButtonTooltip() && (
                  <LicenseTooltip
                    limits={appsLimit}
                    feature={
                      this.props.appType === 'workflow'
                        ? 'workflows'
                        : this.props.appType === 'module'
                          ? 'modules'
                          : 'apps'
                    }
                    isAvailable={true}
                    noTooltipIfValid={true}
                  >
                    <div className="create-new-app-wrapper">
                      <Dropdown as={ButtonGroup} className="d-inline-flex create-new-app-dropdown">
                        <Button
                          disabled={getDisabledState()}
                          className={`create-new-app-button col-11 ${creatingApp ? 'btn-loading' : ''}`}
                          onClick={() => {
                            if (this.isWorkspaceBranchLocked()) {
                              this.setState({ showSwitchBranchForCreate: true });
                            } else {
                              this.setState({ showCreateAppModal: true });
                            }
                          }}
                          data-cy={`create-new-${
                            this.props.appType === 'workflow'
                              ? 'workflows'
                              : this.props.appType === 'module'
                                ? 'modules'
                                : 'apps'
                          }-button`}
                        >
                          <>
                            {isImportingApp && (
                              <span className="spinner-border spinner-border-sm mx-2" role="status"></span>
                            )}
                            {this.props.appType === 'module'
                              ? 'Create new module'
                              : this.props.t(
                                  `${
                                    this.props.appType === 'workflow' ? 'workflowsDashboard' : 'homePage'
                                  }.header.createNewApplication`,
                                  'Create new app'
                                )}
                          </>
                        </Button>
                        <Dropdown.Toggle
                          disabled={getDisabledState()}
                          split
                          className="d-inline"
                          data-cy="import-dropdown-menu"
                        />
                        <ImportAppMenu
                          darkMode={this.props.darkMode}
                          showTemplateLibraryModal={
                            this.props.appType !== 'module'
                              ? () => {
                                  if (this.isWorkspaceBranchLocked()) {
                                    this.setState({ showSwitchBranchForCreate: true });
                                    return;
                                  }
                                  this.showTemplateLibraryModal();
                                }
                              : undefined
                          }
                          featureAccess={featureAccess}
                          orgGit={orgGit}
                          toggleGitRepositoryImportModal={
                            this.props.appType !== 'module' ? this.toggleGitRepositoryImportModal : undefined
                          }
                          readAndImport={this.readAndImport}
                          onImportFromDeviceClick={() => {
                            if (this.isWorkspaceBranchLocked()) {
                              this.setState({ showSwitchBranchForCreate: true });
                              return false;
                            }
                          }}
                          appType={this.props.appType}
                        />
                      </Dropdown>
                    </div>
                  </LicenseTooltip>
                )}
              </div>
              <Folders
                foldersLoading={this.state.foldersLoading}
                folders={this.state.folders}
                currentFolder={currentFolder}
                folderChanged={this.folderChanged}
                foldersChanged={this.foldersChanged}
                canCreateFolder={this.canCreateFolder()}
                canDeleteFolder={this.canDeleteFolder()}
                canUpdateFolder={this.canUpdateFolder()}
                isWorkspaceBranchLocked={this.isWorkspaceBranchLocked()}
                darkMode={this.props.darkMode}
                canCreateApp={this.canCreateApp()}
                appType={this.props.appType}
              />
              {this.props.appType === 'front-end' && (
                <LicenseBanner classes="mb-3 small" limits={appsLimit} type="apps" size="small" />
              )}
              {this.props.appType === 'workflow' &&
                (workflowInstanceLevelLimit.current >= workflowInstanceLevelLimit.total ||
                  100 > workflowInstanceLevelLimit.percentage >= 90 ||
                  workflowInstanceLevelLimit.current === workflowInstanceLevelLimit.total - 1 ||
                  workflowWorkspaceLevelLimit.current >= workflowWorkspaceLevelLimit.total ||
                  100 > workflowWorkspaceLevelLimit.percentage >= 90 ||
                  workflowWorkspaceLevelLimit.current === workflowWorkspaceLevelLimit.total - 1) && (
                  <>
                    <LicenseBanner
                      classes="mb-3 small"
                      limits={
                        workflowInstanceLevelLimit.current >= workflowInstanceLevelLimit.total ||
                        100 > workflowInstanceLevelLimit.percentage >= 90 ||
                        workflowInstanceLevelLimit.current === workflowInstanceLevelLimit.total - 1
                          ? workflowInstanceLevelLimit
                          : workflowWorkspaceLevelLimit
                      }
                      type="workflow"
                      size="small"
                    />
                  </>
                )}
              {authenticationService.currentSessionValue?.super_admin &&
                this.isWithinSevenDaysOfSignUp(authenticationService.currentSessionValue?.consultation_banner_date) && (
                  <ConsultationBanner
                    classes={`${this.props.darkMode ? 'theme-dark dark-theme m-3 trial-banner' : 'm-3 trial-banner'}`}
                  />
                )}

              <OrganizationList customStyle={{ marginBottom: isAdmin || isBuilder ? '' : '0px' }} />
            </div>

            <div className={cx('col home-page-content')} data-cy="home-page-content">
              {this.props.appType !== 'workflow' && (
                <WorkspaceLockedBanner pageContext={this.props.appType === 'module' ? 'modules' : 'apps'} />
              )}
              <div className="w-100 mb-5 container home-page-content-container">
                {featuresLoaded && !isLoading ? (
                  <>
                    <AppTypeTab
                      appType={this.props.appType}
                      navigate={this.props.navigate}
                      darkMode={this.props.darkMode}
                      hasModuleAccess={this.props.hasModuleAccess}
                    />
                  </>
                ) : (
                  !appSearchKey && <HeaderSkeleton />
                )}

                {/* <WorkspaceLockedBanner pageContext={this.props.appType === 'workflow' ? 'workflows' : this.props.appType === 'module' ? 'modules' : 'apps'} /> */}
                {this.props.appType !== 'workflow' && this.props.appType !== 'module' && this.canCreateApp() && (
                  <CreateAppWithPrompt createApp={this.createApp} />
                )}

                {this.props.appType === 'module' && this.canCreateApp() && <CreateModuleWithPrompt />}

                {(meta?.total_count > 0 || appSearchKey) && (
                  <>
                    {!(isLoading && !appSearchKey) && (
                      <HomeHeader
                        onSearchSubmit={this.onSearchSubmit}
                        darkMode={this.props.darkMode}
                        appType={this.props.appType}
                        disabled={this.props.appType === 'module' && invalidLicense}
                      />
                    )}
                    <div className="filter-container">
                      <span>{currentFolder?.count ?? meta?.total_count} APPS</span>
                      <div className="d-flex align-items-center">
                        <div className="mx-2">Filter by</div>
                        <FolderFilter
                          disabled={!!appOperations?.isAdding}
                          options={this.state.folders.map((folder) => {
                            return {
                              name: folder.name,
                              label: folder.name,
                              value: folder.id,
                              id: folder.id,
                              ...folder,
                            };
                          })}
                          onChange={this.folderChanged}
                          value={currentFolder}
                          closeMenuOnSelect={true}
                        />
                      </div>
                    </div>
                  </>
                )}
                {!isLoading &&
                  featuresLoaded &&
                  meta?.total_count === 0 &&
                  !currentFolder.id &&
                  !appSearchKey &&
                  (['front-end', 'workflow'].includes(this.props.appType) ? (
                    <BlankPage
                      canCreateApp={this.canCreateApp}
                      isLoading={true}
                      createApp={this.createApp}
                      readAndImport={this.readAndImport}
                      onImportFromDeviceClick={() => {
                        if (this.isWorkspaceBranchLocked()) {
                          this.setState({ showSwitchBranchForCreate: true });
                          return false;
                        }
                      }}
                      isImportingApp={isImportingApp}
                      fileInput={this.fileInput}
                      openCreateAppModal={() => {
                        if (this.isWorkspaceBranchLocked()) {
                          this.setState({ showSwitchBranchForCreate: true });
                        } else {
                          this.openCreateAppModal();
                        }
                      }}
                      openCreateAppFromTemplateModal={(template) => {
                        if (this.isWorkspaceBranchLocked()) {
                          toast.error('Master is locked. Create a branch to create an app from template.');
                          return;
                        }
                        this.openCreateAppFromTemplateModal(template);
                      }}
                      creatingApp={creatingApp}
                      darkMode={this.props.darkMode}
                      showTemplateLibraryModal={this.state.showTemplateLibraryModal}
                      viewTemplateLibraryModal={this.showTemplateLibraryModal}
                      hideTemplateLibraryModal={this.hideTemplateLibraryModal}
                      appType={this.props.appType}
                      gitSyncLicenseLocked={this.isGitSyncLicenseLocked()}
                      workflowsLimit={
                        workflowInstanceLevelLimit.current >= workflowInstanceLevelLimit.total ||
                        100 > workflowInstanceLevelLimit.percentage >= 90 ||
                        workflowInstanceLevelLimit.current === workflowInstanceLevelLimit.total - 1
                          ? workflowInstanceLevelLimit
                          : workflowWorkspaceLevelLimit
                      }
                    />
                  ) : (
                    <div className="empty-module-container">
                      <EmptyModuleSvg />
                      <div className="empty-title mt-3" style={{ display: 'block' }}>
                        <div>Create reusable groups of components and queries via modules.</div>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          <a
                            href="https://docs.tooljet.com/docs/app-builder/modules/overview"
                            target="_blank"
                            className="docs-link"
                            rel="noreferrer"
                          >
                            Check out our guide
                          </a>
                          &nbsp;on creating modules.
                        </div>
                      </div>

                      <ButtonSolid
                        disabled={!moduleEnabled || !this.canCreateApp() || this.isGitSyncLicenseLocked()}
                        leftIcon="folderdownload"
                        isLoading={false}
                        onClick={() => {
                          if (this.isWorkspaceBranchLocked()) {
                            this.setState({ showSwitchBranchForCreate: true });
                            return;
                          }
                          this.openCreateAppModal();
                        }}
                        data-cy="button-import-an-app"
                        className="col"
                        variant="tertiary"
                      >
                        <ToolTip
                          show={!moduleEnabled || !this.canCreateApp() || this.isGitSyncLicenseLocked()}
                          message={
                            !moduleEnabled
                              ? 'Modules are not available on your current plan.'
                              : this.isGitSyncLicenseLocked()
                                ? 'Git sync is not enabled as per your current plan. Disable git sync to continue.'
                                : "You don't have permission to create a module."
                          }
                          placement="bottom"
                        >
                          <label style={{ visibility: isImportingApp ? 'hidden' : 'visible' }} data-cy="create-module">
                            {'Create new module'}
                          </label>
                        </ToolTip>
                      </ButtonSolid>
                    </div>
                  ))}
                {!isLoading && apps?.length === 0 && appSearchKey && (
                  <div>
                    <span className={`d-block text-center text-body pt-5 ${this.props.darkMode && 'text-white-50'}`}>
                      {this.props.appType === 'workflow'
                        ? this.props.t('homePage.noWorkflowFound', 'No Workflows found')
                        : this.props.appType === 'module'
                          ? this.props.t('homePage.noModuleFound', 'No Modules found')
                          : this.props.t('homePage.noApplicationFound', 'No Applications found')}
                    </span>
                  </div>
                )}
                {(isLoading || meta.total_count > 0 || !_.isEmpty(currentFolder)) && (
                  <AppList
                    apps={apps}
                    canCreateApp={this.canCreateApp}
                    canDeleteApp={this.canDeleteApp}
                    canUpdateApp={this.canUpdateApp}
                    canViewApp={this.canViewApp}
                    deleteApp={this.deleteApp}
                    cloneApp={this.cloneApp}
                    exportApp={this.exportApp}
                    meta={meta}
                    currentFolder={currentFolder}
                    isLoading={isLoading || !featuresLoaded}
                    darkMode={this.props.darkMode}
                    appActionModal={this.appActionModal}
                    removeAppFromFolder={this.removeAppFromFolder}
                    refreshApps={() => this.fetchApps(this.state.currentPage, this.state.currentFolder.id)}
                    appType={this.props.appType}
                    basicPlan={shouldExcludeEnvParam}
                    moduleEnabled={moduleEnabled}
                    appSearchKey={this.state.appSearchKey}
                    deletingAppIds={this.state.deletingAppIds}
                    ownedFolders={this.state.folders.filter(
                      (folder) => folder.created_by === authenticationService.currentSessionValue?.current_user?.id
                    )}
                  />
                )}
              </div>
              <div className="footer-container">
                {this.pageCount() > MAX_APPS_PER_PAGE && (
                  <Footer
                    currentPage={meta.current_page}
                    count={this.pageCount()}
                    itemsPerPage={MAX_APPS_PER_PAGE}
                    pageChanged={this.pageChanged}
                    darkMode={this.props.darkMode}
                    dataLoading={isLoading}
                    appType={this.props.appType}
                  />
                )}
                {/* need to review the mobile view */}
                <div className="org-selector-mobile">
                  <OrganizationList />
                </div>
              </div>
            </div>
          </div>
          <TemplateLibraryModal
            show={this.state.showTemplateLibraryModal}
            onHide={() => this.setState({ showTemplateLibraryModal: false })}
            onCloseButtonClick={() => this.setState({ showTemplateLibraryModal: false })}
            darkMode={this.props.darkMode}
            openCreateAppFromTemplateModal={this.openCreateAppFromTemplateModal}
            appCreationDisabled={!this.canCreateApp()}
          />
        </div>
      </Layout>
    );
  }
}

const withStore = (Component) => (props) => {
  const { featureAccess, featuresLoaded, hasModuleAccess } = useLicenseStore(
    (state) => ({
      featureAccess: state.featureAccess,
      featuresLoaded: state.featuresLoaded,
      hasModuleAccess: state.hasModuleAccess,
    }),
    shallow
  );
  const { checkModuleAccess } = useLicenseStore((state) => state.actions, shallow);

  return (
    <Component
      {...props}
      featureAccess={featureAccess}
      featuresLoaded={featuresLoaded}
      checkModuleAccess={checkModuleAccess}
      hasModuleAccess={hasModuleAccess}
    />
  );
};

export const HomePage = withTranslation()(withStore(withRouter(HomePageComponent)));

// Need to fix latest commit thing ->
// Call the same api with latest commit flag as true once the user selects a specific app from the list,
// It should make that call once the endpoint is selected
