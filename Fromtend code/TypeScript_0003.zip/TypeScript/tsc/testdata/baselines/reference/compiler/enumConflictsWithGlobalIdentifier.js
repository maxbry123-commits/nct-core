//// [tests/cases/compiler/enumConflictsWithGlobalIdentifier.ts] ////

//// [enumConflictsWithGlobalIdentifier.ts]
enum Position { 
    IgnoreRulesSpecific = 0,
}
var x = IgnoreRulesSpecific.
var y = Position.IgnoreRulesSpecific;


//// [enumConflictsWithGlobalIdentifier.js]
"use strict";
var Position;
(function (Position) {
    Position[Position["IgnoreRulesSpecific"] = 0] = "IgnoreRulesSpecific";
})(Position || (Position = {}));
var x = IgnoreRulesSpecific.
;
var y = Position.IgnoreRulesSpecific;
