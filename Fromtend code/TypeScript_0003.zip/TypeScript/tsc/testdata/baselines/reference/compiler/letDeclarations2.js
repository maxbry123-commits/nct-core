//// [tests/cases/compiler/letDeclarations2.ts] ////

//// [letDeclarations2.ts]
namespace M {
    let l1 = "s";
    export let l2 = 0;
}

//// [letDeclarations2.js]
"use strict";
var M;
(function (M) {
    let l1 = "s";
    M.l2 = 0;
})(M || (M = {}));


//// [letDeclarations2.d.ts]
declare namespace M {
    let l2: number;
}
