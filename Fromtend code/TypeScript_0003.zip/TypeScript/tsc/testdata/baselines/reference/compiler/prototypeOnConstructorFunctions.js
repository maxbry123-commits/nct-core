//// [tests/cases/compiler/prototypeOnConstructorFunctions.ts] ////

//// [prototypeOnConstructorFunctions.ts]
interface I1 {
    const: new (options?, element?) => any;
}


var i: I1;


i.const.prototype.prop = "yo";


//// [prototypeOnConstructorFunctions.js]
"use strict";
var i;
i.const.prototype.prop = "yo";
