//// [tests/cases/compiler/recursiveExportAssignmentAndFindAliasedType2.ts] ////

//// [recursiveExportAssignmentAndFindAliasedType2_moduleDef.d.ts]
declare module "moduleC" {
    import self = require("moduleD");
    export = self;
}
declare module "moduleD" {
    import self = require("moduleC");
    export = self;
}

//// [recursiveExportAssignmentAndFindAliasedType2_moduleB.ts]
class ClassB { }
export = ClassB;

//// [recursiveExportAssignmentAndFindAliasedType2_moduleA.ts]
/// <reference path="recursiveExportAssignmentAndFindAliasedType2_moduleDef.d.ts"/>
import moduleC = require("moduleC");
import ClassB = require("./recursiveExportAssignmentAndFindAliasedType2_moduleB");
export var b: ClassB; // This should result in type ClassB

//// [recursiveExportAssignmentAndFindAliasedType2_moduleB.js]
"use strict";
class ClassB {
}
module.exports = ClassB;
//// [recursiveExportAssignmentAndFindAliasedType2_moduleA.js]
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.b = void 0;
