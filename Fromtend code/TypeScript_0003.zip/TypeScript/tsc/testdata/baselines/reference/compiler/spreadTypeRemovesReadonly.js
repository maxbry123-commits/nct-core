//// [tests/cases/compiler/spreadTypeRemovesReadonly.ts] ////

//// [spreadTypeRemovesReadonly.ts]
interface ReadonlyData {
    readonly value: string;
}

const data: ReadonlyData = { value: 'foo' };
const clone = { ...data };
clone.value = 'bar';


//// [spreadTypeRemovesReadonly.js]
"use strict";
const data = { value: 'foo' };
const clone = Object.assign({}, data);
clone.value = 'bar';
