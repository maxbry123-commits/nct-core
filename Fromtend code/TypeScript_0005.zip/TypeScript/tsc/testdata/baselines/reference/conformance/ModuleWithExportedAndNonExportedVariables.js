//// [tests/cases/conformance/internalModules/exportDeclarations/ModuleWithExportedAndNonExportedVariables.ts] ////

//// [ModuleWithExportedAndNonExportedVariables.ts]
namespace A {
    export var x = 'hello world'
    var y = 12;
}


var x: string;
var x = A.x;

// Error, since y is not exported
var y = A.y;


//// [ModuleWithExportedAndNonExportedVariables.js]
"use strict";
var A;
(function (A) {
    A.x = 'hello world';
    var y = 12;
})(A || (A = {}));
var x;
var x = A.x;
// Error, since y is not exported
var y = A.y;
