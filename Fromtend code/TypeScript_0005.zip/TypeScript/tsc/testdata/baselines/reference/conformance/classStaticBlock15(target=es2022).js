//// [tests/cases/conformance/classes/classStaticBlock/classStaticBlock15.ts] ////

//// [classStaticBlock15.ts]
var _C__1;

class C {
  static #_1 = 1;
  static #_3 = 3;
  static #_5 = 5;

  static {}
  static {}
  static {}
  static {}
  static {}
  static {}
}

console.log(_C__1)


//// [classStaticBlock15.js]
"use strict";
var _C__1;
class C {
    static #_1 = 1;
    static #_3 = 3;
    static #_5 = 5;
    static { }
    static { }
    static { }
    static { }
    static { }
    static { }
}
console.log(_C__1);
