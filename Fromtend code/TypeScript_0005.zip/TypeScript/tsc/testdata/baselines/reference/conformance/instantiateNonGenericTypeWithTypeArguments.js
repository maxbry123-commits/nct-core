//// [tests/cases/conformance/types/typeParameters/typeArgumentLists/instantiateNonGenericTypeWithTypeArguments.ts] ////

//// [instantiateNonGenericTypeWithTypeArguments.ts]
// it is an error to provide type arguments to a non-generic call
// all of these are errors

class C {
    x!: string;
}

var c = new C<number>();

function Foo(): void { }
var r = new Foo<number>();

declare var f: { (): void };
var r2 = new f<number>();

var a: any;
// BUG 790977
var r2 = new a<number>();

//// [instantiateNonGenericTypeWithTypeArguments.js]
"use strict";
// it is an error to provide type arguments to a non-generic call
// all of these are errors
class C {
}
var c = new C();
function Foo() { }
var r = new Foo();
var r2 = new f();
var a;
// BUG 790977
var r2 = new a();
