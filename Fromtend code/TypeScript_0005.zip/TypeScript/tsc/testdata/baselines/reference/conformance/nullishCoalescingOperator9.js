//// [tests/cases/conformance/expressions/nullishCoalescingOperator/nullishCoalescingOperator9.ts] ////

//// [nullishCoalescingOperator9.ts]
declare let f: null | ((x: string) => void);

let g = f || (abc => { void abc.toLowerCase() })
let gg = f ?? (abc => { void abc.toLowerCase() })


//// [nullishCoalescingOperator9.js]
"use strict";
let g = f || (abc => { void abc.toLowerCase(); });
let gg = f !== null && f !== void 0 ? f : (abc => { void abc.toLowerCase(); });
