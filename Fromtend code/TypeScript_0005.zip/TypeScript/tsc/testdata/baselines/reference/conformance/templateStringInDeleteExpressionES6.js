//// [tests/cases/conformance/es6/templates/templateStringInDeleteExpressionES6.ts] ////

//// [templateStringInDeleteExpressionES6.ts]
delete `abc${0}abc`;

//// [templateStringInDeleteExpressionES6.js]
"use strict";
delete `abc${0}abc`;
