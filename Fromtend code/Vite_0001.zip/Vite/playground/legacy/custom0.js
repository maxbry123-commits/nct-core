export const foo = 'bar'
