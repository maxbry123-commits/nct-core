export default '[success] absolute'
