export default '[success] worker'
