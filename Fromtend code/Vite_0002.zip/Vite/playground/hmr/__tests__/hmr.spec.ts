import { stripVTControlCharacters } from 'node:util'
import type { Page } from 'playwright-chromium'
import { beforeAll, describe, expect, it, test } from 'vitest'
import {
  addFile,
  browser,
  browserLogs,
  editFile,
  getBg,
  getColor,
  isBuild,
  isBundledDev,
  page,
  readFile,
  removeFile,
  serverLogs,
  untilBrowserLogAfter,
  viteTestUrl,
} from '~utils'

test('should render', async () => {
  await expect.poll(() => page.textContent('.app')).toBe('1')
  await expect.poll(() => page.textContent('.dep')).toBe('1')
  await expect.poll(() => page.textContent('.nested')).toBe('1')
})

if (!isBuild) {
  test('should connect', async () => {
    if (isBundledDev) {
      // bundled-dev logs extra `connecting...` and `connected` message (5 + 2)
      // if the first bundle is not ready and a fallback page is shown when the client connects.
      expect(browserLogs.length).toBeOneOf([5, 7])
    } else {
      expect(browserLogs.length).toBe(5)
    }
    expect(browserLogs.some((msg) => msg.includes('connected'))).toBe(true)
    browserLogs.length = 0
  })

  const fetchHotEvents = async (): Promise<{
    connectCount: number
    disconnectCount: number
  }> => {
    const res = await fetch(viteTestUrl + '/hot-events-counts')
    return res.json()
  }
  test('hot events', async () => {
    if (isBundledDev) {
      expect(await fetchHotEvents()).toBeOneOf([
        { connectCount: 1, disconnectCount: 0 },
        { connectCount: 2, disconnectCount: 1 }, // landed on fallback page first, then reconnected to main page
      ])
    } else {
      expect(await fetchHotEvents()).toStrictEqual({
        connectCount: 1,
        disconnectCount: 0,
      })
    }
    await untilBrowserLogAfter(() => page.reload(), [/connected/])

    if (isBundledDev) {
      expect(await fetchHotEvents()).toBeOneOf([
        { connectCount: 2, disconnectCount: 1 },
        { connectCount: 3, disconnectCount: 2 },
      ])
    } else {
      expect(await fetchHotEvents()).toStrictEqual({
        connectCount: 2,
        disconnectCount: 1,
      })
    }
  })

  test('self accept', async () => {
    const el = page.locator('.app')
    await untilBrowserLogAfter(
      () =>
        editFile('hmr.ts', (code) =>
          code.replace('const foo = 1', 'const foo = 2 '),
        ),
      [
        '>>> vite:beforeUpdate -- update',
        'foo was: 1',
        '(self-accepting 1) foo is now: 2',
        '(self-accepting 2) foo is now: 2',
        // bundled dev: the client logs rolldown module ids (cwd-relative, like
        // `playground-temp/hmr/hmr.ts`). The same `cwd` issue as in hot update log in #23028.
        isBundledDev
          ? '[vite] hot updated: playground-temp/hmr/hmr.ts'
          : '[vite] hot updated: /hmr.ts',
        '>>> vite:afterUpdate -- update',
      ],
      true,
    )
    await expect.poll(() => el.textContent()).toMatch('2')

    await untilBrowserLogAfter(
      () =>
        editFile('hmr.ts', (code) =>
          code.replace('const foo = 2', 'const foo = 3 '),
        ),
      [
        '>>> vite:beforeUpdate -- update',
        'foo was: 2',
        '(self-accepting 1) foo is now: 3',
        '(self-accepting 2) foo is now: 3',
        isBundledDev
          ? '[vite] hot updated: playground-temp/hmr/hmr.ts'
          : '[vite] hot updated: /hmr.ts',
        '>>> vite:afterUpdate -- update',
      ],
      true,
    )
    await expect.poll(() => el.textContent()).toMatch('3')
  })

  test('hot data persists across module instances', async () => {
    await untilBrowserLogAfter(
      () =>
        editFile('hotData.js', (code) =>
          code.replace('const value = 1', 'const value = 2 '),
        ),
      [
        '>>> vite:beforeUpdate -- update',
        '(hot data) value from execution: 1',
        '(hot data) value from dispose: 1',
        isBundledDev
          ? '[vite] hot updated: playground-temp/hmr/hotData.js'
          : '[vite] hot updated: /hotData.js',
        '>>> vite:afterUpdate -- update',
      ],
      true,
    )

    await untilBrowserLogAfter(
      () =>
        editFile('hotData.js', (code) =>
          code.replace('const value = 2', 'const value = 3  '),
        ),
      [
        '>>> vite:beforeUpdate -- update',
        '(hot data) value from execution: 2',
        '(hot data) value from dispose: 2',
        isBundledDev
          ? '[vite] hot updated: playground-temp/hmr/hotData.js'
          : '[vite] hot updated: /hotData.js',
        '>>> vite:afterUpdate -- update',
      ],
      true,
    )
  })

  test('accept dep', async () => {
    const el = page.locator('.dep')
    await untilBrowserLogAfter(
      () =>
        editFile('hmrDep.js', (code) =>
          code.replace('const foo = 1', 'const foo = 2 '),
        ),
      [
        '>>> vite:beforeUpdate -- update',
        '(dep) foo was: 1',
        '(dep) foo from dispose: 1',
        '(single dep) foo is now: 2',
        '(single dep) nested foo is now: 1',
        '(multi deps) foo is now: 2',
        '(multi deps) nested foo is now: 1',
        isBundledDev
          ? '[vite] hot updated: playground-temp/hmr/hmrDep.js via playground-temp/hmr/hmr.ts'
          : '[vite] hot updated: /hmrDep.js via /hmr.ts',
        '>>> vite:afterUpdate -- update',
      ],
      true,
    )
    await expect.poll(() => el.textContent()).toMatch('2')

    await untilBrowserLogAfter(
      () =>
        editFile('hmrDep.js', (code) =>
          code.replace('const foo = 2', 'const foo = 3 '),
        ),
      [
        '>>> vite:beforeUpdate -- update',
        '(dep) foo was: 2',
        '(dep) foo from dispose: 2',
        '(single dep) foo is now: 3',
        '(single dep) nested foo is now: 1',
        '(multi deps) foo is now: 3',
        '(multi deps) nested foo is now: 1',
        isBundledDev
          ? '[vite] hot updated: playground-temp/hmr/hmrDep.js via playground-temp/hmr/hmr.ts'
          : '[vite] hot updated: /hmrDep.js via /hmr.ts',
        '>>> vite:afterUpdate -- update',
      ],
      true,
    )
    await expect.poll(() => el.textContent()).toMatch('3')
  })

  test('nested dep propagation', async () => {
    const el = page.locator('.nested')
    await untilBrowserLogAfter(
      () =>
        editFile('hmrNestedDep.js', (code) =>
          code.replace('const foo = 1', 'const foo = 2 '),
        ),
      [
        '>>> vite:beforeUpdate -- update',
        '(dep) foo was: 3',
        '(dep) foo from dispose: 3',
        '(single dep) foo is now: 3',
        '(single dep) nested foo is now: 2',
        '(multi deps) foo is now: 3',
        '(multi deps) nested foo is now: 2',
        isBundledDev
          ? '[vite] hot updated: playground-temp/hmr/hmrDep.js via playground-temp/hmr/hmr.ts'
          : '[vite] hot updated: /hmrDep.js via /hmr.ts',
        '>>> vite:afterUpdate -- update',
      ],
      true,
    )
    await expect.poll(() => el.textContent()).toMatch('2')

    await untilBrowserLogAfter(
      () =>
        editFile('hmrNestedDep.js', (code) =>
          code.replace('const foo = 2', 'const foo = 3 '),
        ),
      [
        '>>> vite:beforeUpdate -- update',
        '(dep) foo was: 3',
        '(dep) foo from dispose: 3',
        '(single dep) foo is now: 3',
        '(single dep) nested foo is now: 3',
        '(multi deps) foo is now: 3',
        '(multi deps) nested foo is now: 3',
        isBundledDev
          ? '[vite] hot updated: playground-temp/hmr/hmrDep.js via playground-temp/hmr/hmr.ts'
          : '[vite] hot updated: /hmrDep.js via /hmr.ts',
        '>>> vite:afterUpdate -- update',
      ],
      true,
    )
    await expect.poll(() => el.textContent()).toMatch('3')
  })

  // bundled dev: propagating `import.meta.hot.invalidate()` to the importer
  // fails with `no factory for module \`...invalidation/parent.js\``, so the
  // client falls back to a full page reload instead of hot-updating the parent
  test.skipIf(isBundledDev)('invalidate', async () => {
    const el = page.locator('.invalidation-parent')
    await untilBrowserLogAfter(
      () =>
        editFile('invalidation/child.js', (code) =>
          code.replace('child', 'child updated'),
        ),
      [
        '>>> vite:beforeUpdate -- update',
        '>>> vite:invalidate -- /invalidation/child.js',
        '[vite] invalidate /invalidation/child.js',
        '[vite] hot updated: /invalidation/child.js',
        '>>> vite:afterUpdate -- update',
        '>>> vite:beforeUpdate -- update',
        '(invalidation) parent is executing',
        '[vite] hot updated: /invalidation/parent.js',
        '>>> vite:afterUpdate -- update',
      ],
      true,
    )
    await expect.poll(() => el.textContent()).toMatch('child updated')
  })

  // bundled dev: same missing-importer-factory fallback as `invalidate`
  test.skipIf(isBundledDev)('invalidate works with multiple tabs', async () => {
    let page2: Page
    try {
      page2 = await browser.newPage()
      await page2.goto(viteTestUrl)

      const el = page.locator('.invalidation-parent')
      await untilBrowserLogAfter(
        () =>
          editFile('invalidation/child.js', (code) =>
            code.replace('child', 'child updated'),
          ),
        [
          '>>> vite:beforeUpdate -- update',
          '>>> vite:invalidate -- /invalidation/child.js',
          '[vite] invalidate /invalidation/child.js',
          '[vite] hot updated: /invalidation/child.js',
          '>>> vite:afterUpdate -- update',
          // if invalidate dedupe doesn't work correctly, this beforeUpdate will be called twice
          '>>> vite:beforeUpdate -- update',
          '(invalidation) parent is executing',
          '[vite] hot updated: /invalidation/parent.js',
          '>>> vite:afterUpdate -- update',
        ],
        true,
      )
      await expect.poll(() => el.textContent()).toMatch('child updated')
    } finally {
      await page2.close()
    }
  })

  // bundled dev: same missing-importer-factory fallback as `invalidate`
  test.skipIf(isBundledDev)(
    'invalidate virtual module propagates to importers',
    async () => {
      const el = await page.$('.virtual-invalidation-parent')
      await expect.poll(() => el.textContent()).toBe('initial')

      // Edit the real dep file — Vite detects the change and sends
      // js-update to the virtual module.  The virtual module accepts
      // then invalidates, which should propagate to parent.js.
      editFile('virtual-invalidation/dep.js', (code) =>
        code.replace('initial', 'updated2'),
      )

      await expect.poll(() => el.textContent()).toBe('updated2')
    },
  )

  test('invalidate on root triggers page reload', async () => {
    editFile('invalidation/root.js', (code) => code.replace('Init', 'Updated'))
    await page.waitForEvent('load')
    await expect
      .poll(() => page.textContent('.invalidation-root'))
      .toMatch('Updated')
  })

  test('soft invalidate', async () => {
    const el = page.locator('.soft-invalidation')
    await expect
      .poll(() => el.textContent())
      .toBe('soft-invalidation/index.js is transformed 1 times. child is bar')
    editFile('soft-invalidation/child.js', (code) =>
      code.replace('bar', 'updated'),
    )
    await expect
      .poll(() => el.textContent())
      .toBe(
        'soft-invalidation/index.js is transformed 1 times. child is updated',
      )

    editFile('soft-invalidation/index.js', (code) =>
      code.replace('child is', 'child is now'),
    )
    editFile('soft-invalidation/child.js', (code) =>
      code.replace('updated', 'updated?'),
    )
    await expect
      .poll(() => el.textContent())
      .toBe(
        'soft-invalidation/index.js is transformed 2 times. child is now updated?',
      )
  })

  test('invalidate in circular dep should not trigger infinite HMR', async () => {
    const el = page.locator('.invalidation-circular-deps')
    await expect.poll(() => el.textContent()).toMatch('child')
    editFile(
      'invalidation-circular-deps/circular-invalidate/child.js',
      (code) => code.replace('child', 'child updated'),
    )
    await page.waitForEvent('load')
    await expect
      .poll(() => page.textContent('.invalidation-circular-deps'))
      .toMatch('child updated')
  })

  test('invalidate in circular dep should be hot updated if possible', async () => {
    const el = page.locator('.invalidation-circular-deps-handled')
    await expect.poll(() => el.textContent()).toMatch('child')
    editFile(
      'invalidation-circular-deps/invalidate-handled-in-circle/child.js',
      (code) => code.replace('child', 'child updated'),
    )
    await expect.poll(() => el.textContent()).toMatch('child updated')
  })

  // bundled dev: file changes do not run the `hotUpdate` plugin hook, so the
  // plugin's custom events never reach the page
  test.skipIf(isBundledDev)('plugin hmr handler + custom event', async () => {
    const el = page.locator('.custom')
    editFile('customFile.js', (code) => code.replace('custom', 'edited2'))
    await expect.poll(() => el.textContent()).toMatch('edited2')
  })

  // bundled dev: same missing `hotUpdate` plugin hook as the previous case
  test.skipIf(isBundledDev)('plugin hmr remove custom events', async () => {
    const el = page.locator('.toRemove')
    await expect.poll(() => el.textContent()).toMatch('edited2')
    editFile('customFile.js', (code) => code.replace('edited2', 'custom33'))
    await expect.poll(() => el.textContent()).toMatch('edited2')
  })

  test('plugin client-server communication', async () => {
    const el = page.locator('.custom-communication')
    await expect.poll(() => el.textContent()).toMatch('3')
  })

  // bundled dev: editing an html file does not trigger a page reload
  test.skipIf(isBundledDev)('full-reload encodeURI path', async () => {
    await page.goto(
      viteTestUrl + '/unicode-path/中文-にほんご-한글-🌕🌖🌗/index.html',
    )
    const el = page.locator('#app')
    await expect.poll(() => el.textContent()).toBe('title')
    editFile('unicode-path/中文-にほんご-한글-🌕🌖🌗/index.html', (code) =>
      code.replace('title', 'title2'),
    )
    await page.waitForEvent('load')
    await expect.poll(() => el.textContent()).toBe('title2')
  })

  // bundled dev: css is a bundle asset, so an edit does not swap the
  // stylesheet link in place and the query params are lost
  test.skipIf(isBundledDev)('CSS update preserves query params', async () => {
    await page.goto(viteTestUrl)

    editFile('global.css', (code) => code.replace('white', 'tomato'))

    const elprev = page.locator('.css-prev')
    const elpost = page.locator('.css-post')
    await expect.poll(() => elprev.textContent()).toMatch('param=required')
    await expect.poll(() => elpost.textContent()).toMatch('param=required')
    const textprev = await elprev.textContent()
    const textpost = await elpost.textContent()
    expect(textprev).not.toBe(textpost)
    expect(textprev).not.toMatch('direct')
    expect(textpost).not.toMatch('direct')
  })

  // bundled dev: stylesheet links point at bundle assets and are not swapped
  // on css edits
  test.skipIf(isBundledDev)('it swaps out link tags', async () => {
    await page.goto(viteTestUrl)

    editFile('global.css', (code) => code.replace('tomato', 'white'))

    await expect
      .poll(() => page.locator('.link-tag-added').textContent())
      .toMatch('yes')
    await expect
      .poll(() => page.locator('.link-tag-removed').textContent())
      .toMatch('yes')

    await expect.poll(() => page.locator('link').count()).toBe(1)
  })

  // bundled dev: editing a dynamic import that was never loaded triggers a
  // page reload; plain dev ignores the change (#7561)
  test.skipIf(isBundledDev)('not loaded dynamic import', async () => {
    await page.goto(viteTestUrl + '/counter/index.html', { waitUntil: 'load' })

    const btn = page.locator('button')
    await expect.poll(() => btn.textContent()).toBe('Counter 0')
    await btn.click()
    await expect.poll(() => btn.textContent()).toBe('Counter 1')

    // Modifying `index.ts` triggers a page reload, as expected
    const indexTsLoadPromise = page.waitForEvent('load')
    editFile('counter/index.ts', (code) => code + '\n')
    await indexTsLoadPromise
    await expect.poll(() => btn.textContent()).toBe('Counter 0')

    await btn.click()
    await expect.poll(() => btn.textContent()).toBe('Counter 1')

    // #7561
    // `dep.ts` defines `import.module.hot.accept` and has not been loaded.
    // Therefore, modifying it has no effect (doesn't trigger a page reload).
    // (Note that, a dynamic import that is never loaded and that does not
    // define `accept.module.hot.accept` may wrongfully trigger a full page
    // reload, see discussion at #7561.)
    const depTsLoadPromise = page.waitForEvent('load', { timeout: 1000 })
    editFile('counter/dep.ts', (code) => code + ' ')
    await expect(depTsLoadPromise).rejects.toThrow(
      /page\.waitForEvent: Timeout \d+ms exceeded while waiting for event "load"/,
    )

    await expect.poll(() => btn.textContent()).toBe('Counter 1')
  })

  // #2255
  // bundled dev: the test passes on its own, but its edits queue stray page
  // reloads that swallow a later hot update (`import.meta.hot?.accept` times out)
  test.skipIf(isBundledDev)('importing reloaded', async () => {
    await page.goto(viteTestUrl)
    const outputEle = page.locator('.importing-reloaded')
    const getOutput = () => {
      return outputEle.innerHTML()
    }

    await expect
      .poll(getOutput)
      .toMatch(['a.js: a0', 'b.js: b0,a0'].join('<br>'))

    editFile('importing-updated/a.js', (code) => code.replace("'a0'", "'a1' "))
    await expect
      .poll(getOutput)
      .toMatch(['a.js: a0', 'b.js: b0,a0', 'a.js: a1'].join('<br>'))

    editFile('importing-updated/b.js', (code) =>
      code.replace('`b0,${a}`', '`b1,${a}` '),
    )
    // note that "a.js: a1" should not happen twice after "b.js: b0,a0'"
    await expect
      .poll(getOutput)
      .toMatch(
        ['a.js: a0', 'b.js: b0,a0', 'a.js: a1', 'b.js: b1,a1'].join('<br>'),
      )
  })

  // bundled dev: partial accept (`import.meta.hot.acceptExports`) is not
  // supported (rolldown#10061)
  describe.skipIf(isBundledDev)('acceptExports', () => {
    const HOT_UPDATED = /hot updated/
    const CONNECTED = /connected/

    const baseDir = 'accept-exports'

    describe('when all used exports are accepted', () => {
      const testDir = baseDir + '/main-accepted'

      const fileName = 'target.ts'
      const file = `${testDir}/${fileName}`
      const url = '/' + file

      let dep = 'dep0'

      beforeAll(async () => {
        await untilBrowserLogAfter(
          () => page.goto(`${viteTestUrl}/${testDir}/`),
          [CONNECTED, />>>>>>/],
          (logs) => {
            expect(logs).toContain(`<<<<<< A0 B0 D0 ; ${dep}`)
            expect(logs).toContain('>>>>>> A0 D0')
          },
        )
      })

      it('the callback is called with the new version the module', async () => {
        const callbackFile = `${testDir}/callback.ts`
        const callbackUrl = '/' + callbackFile

        await untilBrowserLogAfter(
          () => {
            editFile(callbackFile, (code) =>
              code
                .replace("x = 'X'", "x = 'Y'")
                .replace('reloaded >>>', 'reloaded (2) >>>'),
            )
          },
          HOT_UPDATED,
          (logs) => {
            expect(logs).toEqual([
              'reloaded >>> Y',
              `[vite] hot updated: ${callbackUrl}`,
            ])
          },
        )

        await untilBrowserLogAfter(
          () => {
            editFile(callbackFile, (code) =>
              code.replace("x = 'Y'", "x = 'Z' "),
            )
          },
          HOT_UPDATED,
          (logs) => {
            expect(logs).toEqual([
              'reloaded (2) >>> Z',
              `[vite] hot updated: ${callbackUrl}`,
            ])
          },
        )
      })

      it('stops HMR bubble on dependency change', async () => {
        const depFileName = 'dep.ts'
        const depFile = `${testDir}/${depFileName}`

        await untilBrowserLogAfter(
          () => {
            editFile(
              depFile,
              (code) => code.replace('dep0', (dep = 'dep1')) + '\n',
            )
          },
          HOT_UPDATED,
          (logs) => {
            expect(logs).toEqual([
              `<<<<<< A0 B0 D0 ; ${dep}`,
              `[vite] hot updated: ${url}`,
            ])
          },
        )
      })

      it('accepts itself and refreshes on change', async () => {
        await untilBrowserLogAfter(
          () => {
            editFile(file, (code) => code.replace(/(\b[A-Z])0/g, '$11') + '\n')
          },
          HOT_UPDATED,
          (logs) => {
            expect(logs).toEqual([
              `<<<<<< A1 B1 D1 ; ${dep}`,
              `[vite] hot updated: ${url}`,
            ])
          },
        )
      })

      it('accepts itself and refreshes on 2nd change', async () => {
        await untilBrowserLogAfter(
          () => {
            editFile(
              file,
              (code) =>
                code
                  .replace(/(\b[A-Z])1/g, '$12')
                  .replace(
                    "acceptExports(['a', 'default']",
                    "acceptExports(['b', 'default']",
                  ) + '\n',
            )
          },
          HOT_UPDATED,
          (logs) => {
            expect(logs).toEqual([
              `<<<<<< A2 B2 D2 ; ${dep}`,
              `[vite] hot updated: ${url}`,
            ])
          },
        )
      })

      it('does not accept itself anymore after acceptedExports change', async () => {
        await untilBrowserLogAfter(
          async () => {
            editFile(file, (code) => code.replace(/(\b[A-Z])2/g, '$13') + '\n')
            await page.waitForEvent('load')
          },
          [CONNECTED, />>>>>>/],
          (logs) => {
            expect(logs).toContain(`<<<<<< A3 B3 D3 ; ${dep}`)
            expect(logs).toContain('>>>>>> A3 D3')
          },
        )
      })
    })

    describe('when some used exports are not accepted', () => {
      const testDir = baseDir + '/main-non-accepted'

      const namedFileName = 'named.ts'
      const namedFile = `${testDir}/${namedFileName}`
      const defaultFileName = 'default.ts'
      const defaultFile = `${testDir}/${defaultFileName}`
      const depFileName = 'dep.ts'
      const depFile = `${testDir}/${depFileName}`

      const a = 'A0'
      let dep = 'dep0'

      beforeAll(async () => {
        await untilBrowserLogAfter(
          () => page.goto(`${viteTestUrl}/${testDir}/`),
          [CONNECTED, />>>>>>/],
          (logs) => {
            expect(logs).toContain(`<<< named: ${a} ; ${dep}`)
            expect(logs).toContain(`<<< default: def0`)
            expect(logs).toContain(`>>>>>> ${a} def0`)
          },
        )
      })

      it('does not stop the HMR bubble on change to dep', async () => {
        await untilBrowserLogAfter(
          async () => {
            editFile(
              depFile,
              (code) => code.replace('dep0', (dep = 'dep1')) + '\n',
            )
            await page.waitForEvent('load')
          },
          [CONNECTED, />>>>>>/],
          (logs) => {
            expect(logs).toContain(`<<< named: ${a} ; ${dep}`)
          },
        )
      })

      describe('does not stop the HMR bubble on change to self', () => {
        it('with named exports', async () => {
          await untilBrowserLogAfter(
            async () => {
              editFile(namedFile, (code) => code.replace(a, 'A1') + '\n')
              await page.waitForEvent('load')
            },
            [CONNECTED, />>>>>>/],
            (logs) => {
              expect(logs).toContain(`<<< named: A1 ; ${dep}`)
            },
          )
        })

        it('with default export', async () => {
          await untilBrowserLogAfter(
            async () => {
              editFile(
                defaultFile,
                (code) => code.replace('def0', 'def1') + '\n',
              )
              await page.waitForEvent('load')
            },
            [CONNECTED, />>>>>>/],
            (logs) => {
              expect(logs).toContain(`<<< default: def1`)
            },
          )
        })
      })
    })

    test('accepts itself when imported for side effects only (no bindings imported)', async () => {
      const testDir = baseDir + '/side-effects'
      const file = 'side-effects.ts'

      await untilBrowserLogAfter(
        () => page.goto(`${viteTestUrl}/${testDir}/`),
        [CONNECTED, />>>/],
        (logs) => {
          expect(logs).toContain('>>> side FX')
        },
      )

      await untilBrowserLogAfter(
        () => {
          editFile(`${testDir}/${file}`, (code) =>
            code.replace('>>> side FX', '>>> side FX !!'),
          )
        },
        HOT_UPDATED,
        (logs) => {
          expect(logs).toEqual([
            '>>> side FX !!',
            `[vite] hot updated: /${testDir}/${file}`,
          ])
        },
      )
    })

    describe('acceptExports([])', () => {
      const testDir = baseDir + '/unused-exports'

      test('accepts itself if no exports are imported', async () => {
        const fileName = 'unused.ts'
        const file = `${testDir}/${fileName}`
        const url = '/' + file

        await untilBrowserLogAfter(
          () => page.goto(`${viteTestUrl}/${testDir}/`),
          [CONNECTED, '-- unused --'],
          (logs) => {
            expect(logs).toContain('-- unused --')
          },
        )

        await untilBrowserLogAfter(
          () => {
            editFile(
              file,
              (code) => code.replace('-- unused --', '-> unused <-') + '\n',
            )
          },
          HOT_UPDATED,
          (logs) => {
            expect(logs).toEqual(['-> unused <-', `[vite] hot updated: ${url}`])
          },
        )
      })

      test("doesn't accept itself if any of its exports is imported", async () => {
        const fileName = 'used.ts'
        const file = `${testDir}/${fileName}`

        await untilBrowserLogAfter(
          () => page.goto(`${viteTestUrl}/${testDir}/`),
          [CONNECTED, '-- used --'],
          (logs) => {
            expect(logs).toContain('-- used --')
            expect(logs).toContain('used:foo0')
          },
        )

        await untilBrowserLogAfter(
          async () => {
            editFile(
              file,
              (code) =>
                code
                  .replace('foo0', 'foo1')
                  .replace('-- used --', '-> used <-') + '\n',
            )
            await page.waitForEvent('load')
          },
          [CONNECTED, /used:foo/],
          (logs) => {
            expect(logs).toContain('-> used <-')
            expect(logs).toContain('used:foo1')
          },
        )
      })
    })

    describe('indiscriminate imports: import *', () => {
      const testStarExports = (testDirName: string) => {
        const testDir = `${baseDir}/${testDirName}`

        it('accepts itself if all its exports are accepted', async () => {
          const fileName = 'deps-all-accepted.ts'
          const file = `${testDir}/${fileName}`
          const url = '/' + file

          await untilBrowserLogAfter(
            () => page.goto(`${viteTestUrl}/${testDir}/`),
            [CONNECTED, '>>> ready <<<'],
            (logs) => {
              expect(logs).toContain('loaded:all:a0b0c0default0')
              expect(logs).toContain('all >>>>>> a0, b0, c0')
            },
          )

          await untilBrowserLogAfter(
            () => {
              editFile(file, (code) => code.replace(/([abc])0/g, '$11') + '\n')
            },
            HOT_UPDATED,
            (logs) => {
              expect(logs).toEqual([
                'all >>>>>> a1, b1, c1',
                `[vite] hot updated: ${url}`,
              ])
            },
          )

          await untilBrowserLogAfter(
            () => {
              editFile(file, (code) => code.replace(/([abc])1/g, '$12') + '\n')
            },
            HOT_UPDATED,
            (logs) => {
              expect(logs).toEqual([
                'all >>>>>> a2, b2, c2',
                `[vite] hot updated: ${url}`,
              ])
            },
          )
        })

        it("doesn't accept itself if one export is not accepted", async () => {
          const fileName = 'deps-some-accepted.ts'
          const file = `${testDir}/${fileName}`

          await untilBrowserLogAfter(
            () => page.goto(`${viteTestUrl}/${testDir}/`),
            [CONNECTED, '>>> ready <<<'],
            (logs) => {
              expect(logs).toContain('loaded:some:a0b0c0default0')
              expect(logs).toContain('some >>>>>> a0, b0, c0')
            },
          )

          await untilBrowserLogAfter(
            async () => {
              const loadPromise = page.waitForEvent('load')
              editFile(file, (code) => code.replace(/([abc])0/g, '$11') + '\n')
              await loadPromise
            },
            [CONNECTED, '>>> ready <<<'],
            (logs) => {
              expect(logs).toContain('loaded:some:a1b1c1default0')
              expect(logs).toContain('some >>>>>> a1, b1, c1')
            },
          )
        })
      }

      describe('import * from ...', () => testStarExports('star-imports'))

      describe('dynamic import(...)', () => testStarExports('dynamic-imports'))
    })
  })

  // bundled dev: the icon is inlined as a data URI (build-style inlining),
  // and editing index.html does not trigger a page reload
  test.skipIf(isBundledDev)('css in html hmr', async () => {
    await page.goto(viteTestUrl)
    await expect.poll(() => getBg('.import-image')).toMatch('icon')
    await page.goto(viteTestUrl + '/foo/', { waitUntil: 'load' })
    await expect.poll(() => getBg('.import-image')).toMatch('icon')

    const loadPromise = page.waitForEvent('load')
    editFile('index.html', (code) => code.replace("url('./icon.png')", ''))
    await loadPromise
    await expect.poll(() => getBg('.import-image')).toMatch('')
  })

  // bundled dev: editing an html file does not trigger a page reload
  test.skipIf(isBundledDev)('HTML', async () => {
    await page.goto(viteTestUrl + '/counter/index.html')
    const btn = page.locator('button')
    await expect.poll(() => btn.textContent()).toBe('Counter 0')

    const loadPromise = page.waitForEvent('load')
    editFile('counter/index.html', (code) =>
      code.replace('Counter', 'Compteur'),
    )
    await loadPromise
    await expect.poll(() => btn.textContent()).toBe('Compteur 0')
  })

  // bundled dev: the update itself applies via HMR, but the edit also queues
  // stray page reloads that swallow a later hot update
  // (`import.meta.hot?.accept` times out)
  test.skipIf(isBundledDev)('handle virtual module updates', async () => {
    await page.goto(viteTestUrl)
    const el = page.locator('.virtual')
    await expect.poll(() => el.textContent()).toBe('[success]0')
    editFile('importedVirtual.js', (code) => code.replace('[success]', '[wow]'))
    await expect.poll(() => el.textContent()).toBe('[wow]0')
  })

  // bundled dev: `server.moduleGraph` is empty, so the plugin's
  // `reloadModule(virtual module)` call finds nothing to reload
  test.skipIf(isBundledDev)('invalidate virtual module', async () => {
    await page.goto(viteTestUrl)
    const el = page.locator('.virtual')
    await expect.poll(() => el.textContent()).toBe('[wow]0')
    await page.locator('.virtual-update').click()
    await expect.poll(() => el.textContent()).toBe('[wow]1')
  })

  // bundled dev: same stray-reload fallout as `handle virtual module updates`
  test.skipIf(isBundledDev)(
    'handle virtual module accept updates',
    async () => {
      await page.goto(viteTestUrl)
      const el = page.locator('.virtual-dep')
      await expect.poll(() => el.textContent()).toBe('0')
      editFile('importedVirtual.js', (code) => code.replace('[wow]', '[wow2]'))
      await expect.poll(() => el.textContent()).toBe('[wow2]0')
    },
  )

  // bundled dev: same empty-module-graph gap as `invalidate virtual module`
  test.skipIf(isBundledDev)(
    'invalidate virtual module and accept',
    async () => {
      await page.goto(viteTestUrl)
      const el = page.locator('.virtual-dep')
      await expect.poll(() => el.textContent()).toBe('0')
      await page.locator('.virtual-update-dep').click()
      await expect.poll(() => el.textContent()).toBe('[wow2]2')
    },
  )

  // bundled dev: recovery after a startup build error (missing import) does
  // not rebuild and reload the page
  test.skipIf(isBundledDev)(
    'keep hmr reload after missing import on server startup',
    async () => {
      const file = 'missing-import/a.js'
      const importCode = "import 'missing-modules'"
      const unImportCode = `// ${importCode}`

      await untilBrowserLogAfter(
        () =>
          page.goto(viteTestUrl + '/missing-import/index.html', {
            waitUntil: 'load',
          }),
        /connected/, // wait for HMR connection
      )

      await untilBrowserLogAfter(async () => {
        const loadPromise = page.waitForEvent('load')
        editFile(file, (code) => code.replace(importCode, unImportCode))
        await loadPromise
      }, ['missing test', /connected/])

      await untilBrowserLogAfter(async () => {
        const loadPromise = page.waitForEvent('load')
        editFile(file, (code) => code.replace(unImportCode, importCode))
        await loadPromise
      }, [/500/, /connected/])
    },
  )

  // bundled dev: deleting and re-adding files is not handled — no dispose
  // events, no rebuild, no reload
  test.skipIf(isBundledDev)(
    'should hmr when file is deleted and restored',
    async () => {
      await page.goto(viteTestUrl)

      const parentFile = 'file-delete-restore/parent.js'
      const childFile = 'file-delete-restore/child.js'

      await expect
        .poll(() => page.textContent('.file-delete-restore'))
        .toMatch('parent:child')

      editFile(childFile, (code) =>
        code.replace("value = 'child'", "value = 'child1'"),
      )
      await expect
        .poll(() => page.textContent('.file-delete-restore'))
        .toMatch('parent:child1')

      // delete the file
      editFile(parentFile, (code) =>
        code.replace(
          "export { value as childValue } from './child'",
          "export const childValue = 'not-child'",
        ),
      )
      const originalChildFileCode = readFile(childFile)
      await Promise.all([
        untilBrowserLogAfter(
          () => removeFile(childFile),
          `${childFile} is disposed`,
        ),
        expect
          .poll(() => page.textContent('.file-delete-restore'))
          .toMatch('parent:not-child'),
      ])

      await untilBrowserLogAfter(async () => {
        const loadPromise = page.waitForEvent('load')
        addFile(childFile, originalChildFileCode)
        editFile(parentFile, (code) =>
          code.replace(
            "export const childValue = 'not-child'",
            "export { value as childValue } from './child'",
          ),
        )
        await loadPromise
      }, [/connected/])
      await expect
        .poll(() => page.textContent('.file-delete-restore'))
        .toMatch('parent:child')
    },
  )

  // bundled dev: same file-delete gap as
  // `should hmr when file is deleted and restored`
  test.skipIf(isBundledDev)('delete file should not break hmr', async () => {
    await page.goto(viteTestUrl)

    await expect
      .poll(() => page.textContent('.intermediate-file-delete-display'))
      .toMatch('count is 1')

    // add state
    await page.click('.intermediate-file-delete-increment')
    await expect
      .poll(() => page.textContent('.intermediate-file-delete-display'))
      .toMatch('count is 2')

    // update import, hmr works
    editFile('intermediate-file-delete/index.js', (code) =>
      code.replace("from './re-export.js'", "from './display.js'"),
    )
    editFile('intermediate-file-delete/display.js', (code) =>
      code.replace('count is ${count}', 'count is ${count}!'),
    )
    await expect
      .poll(() => page.textContent('.intermediate-file-delete-display'))
      .toMatch('count is 2!')

    // remove unused file, page reload because it's considered entry point now
    removeFile('intermediate-file-delete/re-export.js')
    await expect
      .poll(() => page.textContent('.intermediate-file-delete-display'))
      .toMatch('count is 1!')

    // re-add state
    await page.click('.intermediate-file-delete-increment')
    await expect
      .poll(() => page.textContent('.intermediate-file-delete-display'))
      .toMatch('count is 2!')

    // hmr works after file deletion
    editFile('intermediate-file-delete/display.js', (code) =>
      code.replace('count is ${count}!', 'count is ${count}'),
    )
    await expect
      .poll(() => page.textContent('.intermediate-file-delete-display'))
      .toMatch('count is 2')
  })

  // bundled dev: dispose and prune events for deleted files are not sent
  test.skipIf(isBundledDev)(
    'deleted file should trigger dispose and prune callbacks',
    async () => {
      await page.goto(viteTestUrl)

      const parentFile = 'file-delete-restore/parent.js'
      const childFile = 'file-delete-restore/child.js'
      const originalChildFileCode = readFile(childFile)

      await untilBrowserLogAfter(
        () => {
          // delete the file
          editFile(parentFile, (code) =>
            code.replace(
              "export { value as childValue } from './child'",
              "export const childValue = 'not-child'",
            ),
          )
          removeFile(childFile)
        },
        [
          'file-delete-restore/child.js is disposed',
          'file-delete-restore/child.js is pruned',
        ],
        false,
      )
      await expect
        .poll(() => page.textContent('.file-delete-restore'))
        .toMatch('parent:not-child')

      // restore the file
      await untilBrowserLogAfter(() => {
        addFile(childFile, originalChildFileCode)
        editFile(parentFile, (code) =>
          code.replace(
            "export const childValue = 'not-child'",
            "export { value as childValue } from './child'",
          ),
        )
      }, 'file-delete-restore/child.js hot data after prune: undefined')
      await expect
        .poll(() => page.textContent('.file-delete-restore'))
        .toMatch('parent:child')
    },
  )

  // bundled dev: prune events are not sent when an import is removed
  test.skipIf(isBundledDev)(
    'deleting import from non-self-accepting module can trigger prune event',
    async () => {
      await page.goto(viteTestUrl)
      await expect.poll(() => page.textContent('.prune')).toMatch('prune-init')
      editFile('prune/dep1.js', (code) =>
        code.replace(`import './dep2.js'`, `// import './dep2.js'`),
      )
      // Prune is triggered when there are other dependencies.
      await expect
        .poll(() => page.textContent('.prune'))
        .toMatch('prune-init|dep2-disposed|dep2-pruned')
      editFile('prune/dep1.js', (code) =>
        code.replace(`import './dep3.js'`, `// import './dep3.js'`),
      )
      // Prune is triggered when there are no more dependencies.
      await expect
        .poll(() => page.textContent('.prune'))
        .toMatch(
          'prune-init|dep2-disposed|dep2-pruned|dep3-disposed|dep3-pruned',
        )
    },
  )

  test('import.meta.hot?.accept', async () => {
    await page.goto(viteTestUrl)

    const el = page.locator('.optional-chaining')
    await untilBrowserLogAfter(
      () =>
        editFile(
          'optional-chaining/child.js',
          (code) => code.replace('const foo = 1', 'const foo = 2') + '\n',
        ),
      '(optional-chaining) child update',
    )
    await expect.poll(() => el.textContent()).toMatch('2')
  })

  test('hmr works for self-accepted module within circular imported files', async () => {
    await page.goto(viteTestUrl + '/self-accept-within-circular/index.html')
    const el = page.locator('.self-accept-within-circular')
    await expect.poll(() => el.textContent()).toBe('c')
    const lastServerLogIndex = serverLogs.length
    editFile('self-accept-within-circular/c.js', (code) =>
      code.replace(`export const c = 'c'`, `export const c = 'cc'`),
    )
    await expect.poll(() => el.textContent()).toBe('cc')
    // Should still keep hmr update, but it'll error on the browser-side and will refresh itself.
    expect(
      serverLogs.slice(lastServerLogIndex).map(stripVTControlCharacters),
    ).toContain(
      isBundledDev
        ? 'hmr update playground-temp/hmr/self-accept-within-circular/c.js'
        : 'hmr update /self-accept-within-circular/c.js',
    )
  })

  test('hmr should not reload if no accepted within circular imported files', async () => {
    await page.goto(viteTestUrl + '/circular/index.html')
    const el = page.locator('.circular')
    await expect
      .poll(() => el.textContent())
      .toBe(
        isBundledDev
          ? // bundled-dev: `unexpected no error` is shown instead of `expected error`.
            // Vite uses `output.topLevelVar = true` by default in bundled dev, which causes the circular import to be `undefined` instead of throwing a TDZ error,
            // (see https://rolldown.rs/guide/troubleshooting#avoid-relying-on-temporal-dead-zone-tdz-errors),
            // whereas in unbundled dev, it follows TDZ and shows `expected error`.
            'mod-a -> mod-b -> mod-c -> undefined (unexpected no error)'
          : 'mod-a -> mod-b -> mod-c -> mod-a (expected error)',
      )
    editFile('circular/mod-b.js', (code) =>
      code.replace(`mod-b ->`, `mod-b (edited) ->`),
    )
    await expect
      .poll(() => el.textContent())
      .toBe('mod-a -> mod-b (edited) -> mod-c -> mod-a (expected error)')
  })

  // bundled dev: editing an asset file does not push an update to the page
  test.skipIf(isBundledDev)('not inlined assets HMR', async () => {
    await page.goto(viteTestUrl)
    const el = page.locator('#logo-no-inline')
    await untilBrowserLogAfter(
      () =>
        editFile('logo-no-inline.svg', (code) =>
          code.replace('height="30px"', 'height="40px" '),
        ),
      /Logo-no-inline updated/,
    )
    await expect
      .poll(() => el.evaluate((it) => `${it.clientHeight}`))
      .toMatch('40')
  })

  // bundled dev: same asset-edit gap as `not inlined assets HMR`
  test.skipIf(isBundledDev)('inlined assets HMR', async () => {
    await page.goto(viteTestUrl)
    const el = page.locator('#logo')
    await untilBrowserLogAfter(
      () =>
        editFile('logo.svg', (code) =>
          code.replace('height="30px"', 'height="40px" '),
        ),
      /Logo updated/,
    )
    await expect
      .poll(() => el.evaluate((it) => `${it.clientHeight}`))
      .toMatch('40')
  })

  test('CSS HMR with this.addWatchFile', async () => {
    await page.goto(viteTestUrl + '/css-deps/index.html')
    await expect.poll(() => getColor('.css-deps')).toBe('red')
    editFile('css-deps/dep.js', (code) => code.replace(`red`, `green`))
    await expect.poll(() => getColor('.css-deps')).toBe('green')
  })

  // bundled dev: adding the missing file does not rebuild and reload the page
  test.skipIf(isBundledDev)(
    'hmr should happen after missing file is created',
    async () => {
      const file = 'missing-file/a.js'
      const code = 'console.log("a.js")'

      await untilBrowserLogAfter(
        () =>
          page.goto(viteTestUrl + '/missing-file/index.html', {
            waitUntil: 'load',
          }),
        /connected/, // wait for HMR connection
      )

      await untilBrowserLogAfter(async () => {
        const loadPromise = page.waitForEvent('load')
        addFile(file, code)
        await loadPromise
      }, [/connected/, 'a.js'])
    },
  )

  // bundled dev: /css-link/index.html is not a bundle input, so the page is
  // never served and the styled element never appears
  test.skipIf(isBundledDev)(
    'deduplicate server rendered link stylesheet',
    async () => {
      await page.goto(viteTestUrl + '/css-link/index.html')
      await expect.poll(() => getColor('.test-css-link')).toBe('orange')

      // remove color
      editFile('css-link/styles.css', (code) =>
        code.replace('color: orange;', '/* removed */'),
      )
      await expect.poll(() => getColor('.test-css-link')).toBe('black')

      // add color
      editFile('css-link/styles.css', (code) =>
        code.replace('/* removed */', 'color: blue;'),
      )
      await expect.poll(() => getColor('.test-css-link')).toBe('blue')

      // // remove css import from js
      editFile('css-link/main.js', (code) =>
        code.replace(`import './styles.css'`, ``),
      )
      await expect.poll(() => getColor('.test-css-link')).toBe('black')
    },
  )
}
