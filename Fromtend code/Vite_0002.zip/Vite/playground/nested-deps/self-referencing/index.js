export const isSelfReference = true
