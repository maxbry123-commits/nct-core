export const greeting = 'hello!'
