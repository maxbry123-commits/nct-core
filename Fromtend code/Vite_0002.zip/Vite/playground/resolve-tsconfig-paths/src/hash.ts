export { default } from '#/imported'
