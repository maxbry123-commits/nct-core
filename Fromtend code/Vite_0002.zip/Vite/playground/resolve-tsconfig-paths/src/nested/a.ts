export { value } from '@imported'
