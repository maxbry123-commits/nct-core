export default 'A string'
