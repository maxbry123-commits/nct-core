import * as projectApi from "../db/project";
import { z } from "zod";
import {
  router,
  procedure,
  AuthorizationError,
  authorizeProject,
  createErrorResponse,
  getProjectOwnerId,
} from "@webstudio-is/trpc-interface/index.server";
import { projectTitle } from "../shared/project-schema";
import { marketplaceApprovalStatus } from "../shared/marketplace-schema";

export const projectRouter = router({
  rename: procedure
    .input(
      z.object({
        title: projectTitle,
        projectId: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      return await projectApi.rename(input, ctx);
    }),

  delete: procedure
    .input(z.object({ projectId: z.string() }))
    .mutation(async ({ input, ctx }) => {
      return await projectApi.markAsDeleted(input.projectId, ctx);
    }),

  clone: procedure
    .input(
      z.object({
        projectId: z.string(),
        title: z.optional(z.string()),
        authToken: z.optional(z.string()),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const sourceContext = input.authToken
        ? await ctx.createTokenContext(input.authToken)
        : ctx;
      return await projectApi.clone(input, ctx, sourceContext);
    }),

  create: procedure
    .input(
      z.object({ title: projectTitle, workspaceId: z.string().optional() })
    )
    .mutation(async ({ input, ctx }) => {
      return await projectApi.create(input, ctx);
    }),

  setMarketplaceApprovalStatus: procedure
    .input(
      z.object({
        projectId: z.string(),
        marketplaceApprovalStatus: marketplaceApprovalStatus,
      })
    )
    .mutation(async ({ input, ctx }) => {
      return await projectApi.setMarketplaceApprovalStatus(input, ctx);
    }),

  updateTags: procedure
    .input(
      z.object({
        projectId: z.string(),
        tags: z.array(z.string()),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await projectApi.updateProjectTags(input, ctx);
    }),

  findCurrentUserProjectIds: procedure.query(async ({ ctx }) => {
    if (ctx.authorization.type !== "user") {
      return [];
    }
    const projectIds = await projectApi.findProjectIdsByUserId(
      ctx.authorization.userId,
      ctx
    );
    return projectIds.map((project) => project.id);
  }),

  userPublishCount: procedure
    .input(z.object({ projectId: z.string() }).optional())
    .query(async ({ input, ctx }) => {
      try {
        if (
          ctx.authorization.type !== "user" &&
          ctx.authorization.type !== "token"
        ) {
          throw new Error("Not authorized");
        }
        const userId =
          ctx.authorization.type === "user"
            ? ctx.authorization.userId
            : ctx.authorization.ownerId;

        let ownerId = userId;

        if (input?.projectId !== undefined) {
          const canView = await authorizeProject.hasProjectPermit(
            { projectId: input.projectId, permit: "view" },
            ctx
          );

          if (canView === false) {
            throw new AuthorizationError(
              "Not authorized to access this project"
            );
          }

          ownerId = await getProjectOwnerId(input.projectId, ctx);
        }

        const result = await ctx.postgrest.client
          .from("user_publish_count")
          .select("count")
          .eq("user_id", ownerId)
          .maybeSingle();
        if (result.error) {
          throw result.error;
        }
        return {
          success: true,
          data: result.data?.count ?? 0,
        };
      } catch (error) {
        return createErrorResponse(error);
      }
    }),

  publishedBuilds: procedure
    .input(
      z.object({
        projectId: z.string(),
      })
    )
    .query(async ({ input, ctx }) => {
      try {
        if (
          ctx.authorization.type !== "user" &&
          ctx.authorization.type !== "token"
        ) {
          throw new AuthorizationError("Not authorized");
        }
        const permit = await authorizeProject.getProjectPermit(
          {
            projectId: input.projectId,
            permits: ["view", "build", "admin"],
          },
          ctx
        );
        if (permit === undefined) {
          throw new AuthorizationError("Not authorized to access this project");
        }
        const publishedBuilds = await ctx.postgrest.client
          .from("published_builds")
          .select("*")
          .eq("projectId", input.projectId);
        if (publishedBuilds.error) {
          throw publishedBuilds.error;
        }
        return {
          success: true,
          data: publishedBuilds.data,
        };
      } catch (error) {
        return createErrorResponse(error);
      }
    }),

  restoreDevelopmentBuild: procedure
    .input(
      z.object({
        projectId: z.string(),
        fromBuildId: z.string(),
      })
    )
    .mutation(
      async ({
        input,
        ctx,
      }): Promise<{ success: true } | { success: false; error: string }> => {
        try {
          const permit = await authorizeProject.getProjectPermit(
            {
              projectId: input.projectId,
              permits: ["build", "admin"],
            },
            ctx
          );
          if (!permit) {
            throw new AuthorizationError("Not authorized");
          }
          const build = await ctx.postgrest.client.rpc(
            "restore_development_build",
            {
              project_id: input.projectId,
              from_build_id: input.fromBuildId,
            }
          );
          if (build.error) {
            throw build.error;
          }
          return {
            success: true,
          };
        } catch (error) {
          return createErrorResponse(error);
        }
      }
    ),
});

export type ProjectRouter = typeof projectRouter;
