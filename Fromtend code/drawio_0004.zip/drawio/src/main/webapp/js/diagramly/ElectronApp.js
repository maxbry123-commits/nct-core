/**
 * Copyright (c) 2020-2025, JGraph Holdings Ltd
 * Copyright (c) 2020-2025, draw.io AG
 */
window.PLUGINS_BASE_PATH = '.';
window.TEMPLATE_PATH = 'templates';
window.DRAW_MATH_URL = 'math4/es5';
window.DRAWIO_BASE_URL = '.'; //Prevent access to online website since it is not allowed
window.DRAWIO_SERVER_URL = '.';
EditorUi.draftSaveDelay = 5000;
//Disables eval for JS (uses shapes-14-6-5.min.js)
mxStencilRegistry.allowEval = false;

(async function()
{
	let requestSync = async function(msg)
	{
		if (typeof msg === 'string')
		{
			msg = {
				action: msg
			};
		}

		async function doRequest()
		{
			return new Promise((resolve, reject) => {
				electron.request(msg, function(data)
				{
					resolve(data);
				}, function(errMsg, e)
				{
					reject(e || errMsg);
				});
			});
		};

		return await doRequest();
	};
	
	// Overrides default mode
	App.mode = App.MODE_DEVICE;
	
	// Automatic sync on conflicts
	Editor.desktopAutoSync = true;

	// Recovers drawio XML from PDFs where pdf-lib 2.6.0+ wrote the
	// hex-encoded /Subject as a top-level indirect object instead of
	// inside /ObjStm [jgraph/drawio-desktop#2394]
	var origExtractGraphModelFromPdf = Editor.extractGraphModelFromPdf;

	Editor.extractGraphModelFromPdf = function(base64)
	{
		var result = origExtractGraphModelFromPdf.apply(this, arguments);

		if (result != null)
		{
			return result;
		}

		try
		{
			var data = base64.substring(base64.indexOf(',') + 1);
			var f = (window.atob && !mxClient.IS_SF) ? atob(data) : Base64.decode(data, true);

			// UTF-16-BE encoding of BOM + '%3Cmxfile' (URL-encoded '<mxfile')
			var anchor = 'FEFF002500330043006D007800660069006C0065';
			var pos = 0;

			while ((pos = f.indexOf('/Subject <', pos)) > -1)
			{
				var hexStart = pos + 10;
				var hexEnd = f.indexOf('>', hexStart);

				if (hexEnd < 0)
				{
					break;
				}

				var hex = f.substring(hexStart, hexEnd).replace(/\s/g, '').toUpperCase();

				if (hex.indexOf(anchor) === 0)
				{
					var decoded = '';

					// Skip FEFF BOM, decode UTF-16-BE code units
					for (var i = 4; i + 4 <= hex.length; i += 4)
					{
						decoded += String.fromCharCode(parseInt(hex.substr(i, 4), 16));
					}

					var xml = decodeURIComponent(decoded.
						replace(/\\\(/g, '(').replace(/\\\)/g, ')'));

					if (xml.indexOf('<mxfile') === 0)
					{
						return xml;
					}
				}

				pos = hexEnd;
			}
		}
		catch (e)
		{
			// Fall through to null
		}

		return null;
	};

	// Disables all external transmission functionality
	App.prototype.isExternalDataComms = function()
	{
		return false;
	};
	
	// Disables preview option in embed dialog
	EmbedDialog.showPreviewOption = false;

	// Disables new window option in edit diagram dialog
	EditDiagramDialog.showNewWindowOption = false;

	PrintDialog.previewEnabled = false;

	// Adds PDF with embedded XML as an editable file format (PDF export
	// and re-save run through the local Electron export pipeline)
	Editor.prototype.diagramFileTypes = Editor.prototype.diagramFileTypes.concat(
		[{description: 'formatPdf', extension: 'pdf', mimeType: 'application/pdf'}]);

	PrintDialog.electronPrint = function(editorUi, args)
	{
		var graph = editorUi.editor.graph;
		var file = editorUi.getCurrentFile();

		if (file)
		{
			file.updateFileData();
		}

		var xml = editorUi.getFileData(true, null, null, null,
			!args.selection, false, null, null, null, false, true);
		
		var extras = {globalVars: graph.getExportVariables()};

		if (Graph.translateDiagram)
		{
			extras.diagramLanguage = Graph.diagramLanguage;
		}

		if (args.grid)
		{
			extras.grid = {
				size: graph.gridSize,
				steps: graph.view.gridSteps,
				color: graph.view.gridColor
			};
		}

		// Passes hidden tags per page to export backend
		var hiddenTagsMap = editorUi.getHiddenTagsMap();

		if (hiddenTagsMap != null)
		{
			extras.hiddenTags = hiddenTagsMap;
		}

		new mxElectronRequest('export', {
			fileTitle: editorUi.getBaseFilename(true),
			print: true,
			format: 'pdf',
			xml: xml,
			from: args.pagesFrom - 1,
			to: args.pagesTo - 1,
			allPages: args.allPages ? '1' : '0',
			pageWidth: graph.pageFormat.width,
			pageHeight: graph.pageFormat.height,
			// Rendered pages span pageFormat * pageScale to match the editor's
			// page breaks; the main process maps each rendered page onto one
			// physical sheet via scaleFactor = 100 / pageScale. A hardcoded 1
			// here printed the page cuts of an unscaled page grid
			// [jgraph/drawio#5540]
			pageScale: graph.pageScale,
			fit: args.fit ? '1' : '0',
			sheetsAcross: args.sheetsAcross,
			sheetsDown: args.sheetsDown,
			scale: args.scale,
			extras: JSON.stringify(extras),
			border: null,
			pageMargin: args.border,
			crop: args.crop ? '1' : '0'
		}).send(function(){}, function(){});
	};
	
	var oldWindowOpen = window.open;
	window.open = async function(url)
	{
		// Only open a native electron window when url is empty. We use this in our code in several places.
		if (url == null)
		{
			return oldWindowOpen(url);
		}
		else
		{
			// Open external will filter urls based on their protocol
			await requestSync({action: 'openExternal', url: url});
		}
	}

	var origAppMain = App.main;
	
	App.main = async function()
	{
		// Set AutoSave delay
		var draftSaveDelay = mxSettings.getDraftSaveDelay();
		
		if (draftSaveDelay != null)
		{
			EditorUi.draftSaveDelay = draftSaveDelay * 1000;
			EditorUi.enableDrafts = draftSaveDelay > 0;
		}

		//Load desktop plugins
		var plugins = (mxSettings.settings != null) ? mxSettings.getPlugins() : null;
		App.initPluginCallback();

		if (plugins != null && plugins.length > 0)
		{
			// Workaround for body not defined if plugins are used in dev mode
			if (urlParams['dev'] == '1')
			{
				EditorUi.debug('App.main', 'Skipped plugins', plugins);
			}
			else
			{
				for (var i = 0; i < plugins.length; i++)
				{
					try
					{
						// Resolved into a local variable as plugins is the live settings
						// array and rewritten entries would be persisted on the next
						// settings save, breaking resolution on the following start
						var pluginUrl = plugins[i];

						if (pluginUrl.indexOf('..') >= 0)
						{
							continue;
						}
						else if (pluginUrl.startsWith('/plugins/'))
						{
							pluginUrl = '.' + pluginUrl;
						}
						else if (pluginUrl.startsWith('plugins/'))
						{
							pluginUrl = './' + pluginUrl;
						}

						// Only built-in plugins shipped with the app are supported;
						// settings entries for the removed external plugins are skipped
						if (!pluginUrl.startsWith('./plugins/'))
						{
							continue;
						}

						mxscript(pluginUrl);
					}
					catch (e)
					{
						// ignore
					}
				}
			}
		}
		
		//Remove old relaxed CSP and add strict one
		var allMeta = document.getElementsByTagName('meta');

		for (var i = 0; i < allMeta.length; i++)
		{
			if (allMeta[i].getAttribute('http-equiv') == 'Content-Security-Policy')
			{
				allMeta[i].parentNode.removeChild(allMeta[i]);
			}

			break;
		}

		mxmeta(null, 'default-src \'self\'; connect-src \'self\' https://fonts.googleapis.com https://fonts.gstatic.com; img-src * data:; ' +
			'media-src *; font-src * data:; frame-src \'self\'; style-src \'self\' \'unsafe-inline\' https://fonts.googleapis.com', 'Content-Security-Policy');

		//Disable web plugins loading
		urlParams['plugins'] = '0';
		origAppMain.apply(this, arguments);
	};

	var editorCongigure = Editor.configure;
	Editor.configure = function(config)
	{
		editorCongigure.apply(this, arguments);

		if (config != null)
		{
			if (config.desktopAutoSync != null)
			{
				Editor.desktopAutoSync = config.desktopAutoSync;
			}

			if (Editor.enableLocalFonts)
			{
				requestSync({action: 'getLocalFonts'}).then(function(fonts)
				{
					if (fonts != null && fonts.length > 0)
					{
						Editor.localFonts = fonts;

						if (config.defaultFonts == null &&
							config.customFonts == null)
						{
							Menus.prototype.defaultFonts = fonts;
						}
					}
				}).catch(function()
				{
					// Ignore errors from font enumeration
				});
			}
		}
	};
	
	var menusInit = Menus.prototype.init;
	Menus.prototype.init = function()
	{
		menusInit.apply(this, arguments);

		var editorUi = this.editorUi;
		
		this.put('openRecent', new Menu(function(menu, parent)
		{
			var recent = editorUi.getRecent();

			if (recent != null)
			{
				for (var i = 0; i < recent.length; i++)
				{
					(function(entry)
					{
						menu.addItem(entry.title, null, function()
						{
							function doOpenRecent()
							{
								//Simulate opening a file via args
								editorUi.loadArgs({args: [entry.id]});
							};
							
							var file = editorUi.getCurrentFile();
							
							if (file != null && file.isModified())
							{
								editorUi.confirm(mxResources.get('allChangesLost'), null, doOpenRecent,
									mxResources.get('cancel'), mxResources.get('discardChanges'));
							}
							else
							{
								doOpenRecent();
							}
						}, parent);
					})(recent[i]);
				}

				menu.addSeparator(parent);
			}

			menu.addItem(mxResources.get('reset'), null, function()
			{
				editorUi.resetRecent();
			}, parent);
		}));
		
		// Replaces file menu to replace openFrom menu with open and rename downloadAs to export
		this.put('file', new Menu(mxUtils.bind(this, function(menu, parent)
		{
			this.addMenuItems(menu, ['new', 'open'], parent);
			this.addSubmenu('openRecent', menu, parent);
			this.addMenuItems(menu, ['-', 'synchronize', '-', 'save', 'saveAs', '-', 'import'], parent);
			this.addSubmenu('exportAs', menu, parent);
			menu.addSeparator(parent);
			this.addSubmenu('embed', menu, parent);
			this.addMenuItems(menu, ['presentationMode'], parent);
			menu.addSeparator(parent);
			this.addMenuItems(menu, ['newLibrary', 'openLibrary'], parent);

			if (editorUi.getCurrentFile() != null && editorUi.fileNode != null)
			{
				this.addMenuItems(menu, ['-', 'properties']);
			}
			
			this.addMenuItems(menu, ['-', 'pageSetup', 'print', '-', 'close', '-', 'exit'], parent);
		})));
	};

	var graphCreateLinkForHint = Graph.prototype.createLinkForHint;
	
	Graph.prototype.createLinkForHint = function(href, label, associatedCell)
	{
		var a = graphCreateLinkForHint.call(this, href, label, associatedCell);
		
		if (href != null && !this.isCustomLink(href))
		{
			// KNOWN: Event with gesture handler mouseUp the middle click opens a framed window
			mxEvent.addListener(a, 'click', mxUtils.bind(this, function(evt)
			{
				// The href is not written for links that did not pass the check
				// in createLinkForHint, in which case there is nothing to open
				var url = a.getAttribute('href');

				if (url != null)
				{
					this.openLink(url, a.getAttribute('target'));
				}

				mxEvent.consume(evt);
			}));
		}
		
		return a;
	};
	
	Graph.prototype.openLink = async function(url, target)
	{
		await requestSync({action: 'openExternal', url: url});
	};

	// Initializes the user interface
	var editorUiInit = EditorUi.prototype.init;
	EditorUi.prototype.init = async function()
	{
		editorUiInit.apply(this, arguments);

		var editorUi = this;
		var graph = this.editor.graph;
		
		electron.registerMsgListener('isModified', (uniqueId) =>
		{
			const currentFile = editorUi.getCurrentFile();
			let reply = {isModified: false, draftPath: null, uniqueId: uniqueId};

			if (currentFile != null)
			{
				if (editorUi.editor.graph.isEditing())
				{
					editorUi.editor.graph.stopEditing();
				}

				reply.isModified = currentFile.isModified();
				reply.draftPath = EditorUi.enableDrafts && currentFile.fileObject? currentFile.fileObject.draftFileName : null;
			}

			electron.sendMessage('isModified-result', reply);
		});

		electron.registerMsgListener('removeDraft', () =>
		{
			editorUi.getCurrentFile().removeDraft();
			electron.sendMessage('draftRemoved', {});
		});

		electron.registerMsgListener('saveAndClose', (uniqueId) =>
		{
			const currentFile = editorUi.getCurrentFile();
			let resultSent = false;

			// Ensures a single result is sent even if the save flow calls
			// more than one callback
			let sendResult = (success) =>
			{
				if (!resultSent)
				{
					resultSent = true;
					electron.sendMessage('saveAndClose-result', {uniqueId: uniqueId, success: success});
				}
			};

			if (currentFile == null || !currentFile.isModified())
			{
				sendResult(true);
			}
			else
			{
				editorUi.saveFile(null, () => sendResult(true),
					() => sendResult(false), () => sendResult(false));
			}
		});

		// Adds support for libraries
		this.actions.addAction('newLibrary...', mxUtils.bind(this, function()
		{
			editorUi.showLibraryDialog(null, null, null, null, App.MODE_DEVICE);
		}));
		
		this.actions.addAction('openLibrary...', mxUtils.bind(this, function()
		{
			editorUi.pickLibrary(App.MODE_DEVICE);
		}));

		// Replaces import action
		this.actions.addAction('import...', mxUtils.bind(this, async function()
		{
			if (editorUi.getCurrentFile() != null)
			{
				var lastDir = localStorage.getItem('.lastImpDir');
				
				var paths = await requestSync({
					action: 'showOpenDialog',
					defaultPath: lastDir || (await requestSync('getDocumentsFolder')),
					properties: ['openFile']
				});
			           
		        if (paths !== undefined && paths[0] != null)
		        {
		        	var path = paths[0];
		        	localStorage.setItem('.lastImpDir', await requestSync({action: 'dirname', path: path}));
		        	var asImage = /\.png$/i.test(path) || /\.gif$/i.test(path) || /\.jpe?g$/i.test(path);
		        	var encoding = (asImage || /\.pdf$/i.test(path) || /\.vsdx$/i.test(path) || /\.vssx$/i.test(path)) ?
		        		'base64' : 'utf-8';

					if (editorUi.spinner.spin(document.body, mxResources.get('loading')))
					{
						electron.request({action: 'readFile', filename: path, encoding: encoding} , mxUtils.bind(this, function (data)
				        {
							try
							{
								if (editorUi.isLucidChartData(data))
								{
									editorUi.convertLucidChart(data, function(xml)
									{
										editorUi.spinner.stop();
										graph.setSelectionCells(editorUi.importXml(xml));
									}, function(e)
									{
										editorUi.spinner.stop();
										editorUi.handleError(e);
									});
								}
								else if  (/(\.vsdx)($|\?)/i.test(path))
								{
									editorUi.importVisio(editorUi.base64ToBlob(data, 'application/octet-stream'), function(xml)
									{
										editorUi.spinner.stop();
										graph.setSelectionCells(editorUi.importXml(xml));
									});
								}
								else if (editorUi.isGliffyData(data, path))
								{
									editorUi.spinner.stop();
									editorUi.showError(mxResources.get('error'), mxResources.get('notInDesktop'));
								}
								else
								{
									if (/\.pdf$/i.test(path))
									{
										var tmp = Editor.extractGraphModelFromPdf(data);
										
										if (tmp != null)
										{
											data = tmp;
										}
									}
									else if (/\.png$/i.test(path))
									{
										var tmp = editorUi.extractGraphModelFromPng(data);
										
										if (tmp != null)
										{
											asImage = false;
											data = tmp;
										}
									}
									else if (/\.svg$/i.test(path))
									{
										// LATER: Use importXml without throwing exception if no data
										// Checks if SVG contains content attribute
										var root = mxUtils.parseXml(data);
										var svgs = root.getElementsByTagName('svg');
										
										if (svgs.length > 0)
										{
											var svgRoot = svgs[0];
											var cont = svgRoot.getAttribute('content');

											if (cont != null && cont.charAt(0) != '<' && cont.charAt(0) != '%')
											{
												cont = unescape((window.atob) ? atob(cont) : Base64.decode(cont, true));
											}
											
											if (cont != null && cont.charAt(0) == '%')
											{
												cont = decodeURIComponent(cont);
											}

											if (cont != null && (cont.substring(0, 8) === '<mxfile ' ||
												cont.substring(0, 14) === '<mxGraphModel '))
											{
												asImage = false;
												data = cont;
											}
											else
											{
												asImage = true;
											}
										}
									}
									
									if (asImage)
									{
										var img = new Image();
										img.onload = function()
										{
											editorUi.resizeImage(img, img.src, function(data2, w, h)
											{
												editorUi.spinner.stop();
												var pt = graph.getInsertPoint();
												graph.setSelectionCell(graph.insertVertex(null, null, '', pt.x, pt.y, w, h,
													'shape=image;aspect=fixed;image=' + editorUi.convertDataUri(data2) + ';'));
											}, true);
										};
										
										img.onerror = function(e)
										{
											editorUi.spinner.stop();
											editorUi.handleError();
										};
										
										var format = path.substring(path.lastIndexOf('.') + 1);
										img.src = (format == 'svg') ? Editor.createSvgDataUri(data) :
											'data:image/' + format + ';base64,' + data;
									}
									else
									{
										editorUi.spinner.stop();
										
										if (data != null)
										{
											graph.setSelectionCells(editorUi.importXml(data));
										}
									}
								}
							}
							catch(e)
							{
								editorUi.spinner.stop();
								editorUi.handleError(e);
							}
			        	}), function(e)
						{
							editorUi.spinner.stop();
							editorUi.handleError(e);
						});
					}
		        }
			}
		}));
		
		// Replaces new action
		var oldNew = this.actions.get('new').funct;
		
		this.actions.addAction('new...', mxUtils.bind(this, function()
		{
			if (this.getCurrentFile() == null)
			{
				oldNew();
			}
			else
			{
				electron.sendMessage('newfile', {width: 1600});
			}
		}), null, null, Editor.ctrlKey + '+N');
		
		this.actions.get('open').shortcut = Editor.ctrlKey + '+O';
		
		// Adds shortcut keys for file operations
		editorUi.keyHandler.bindAction(78, true, 'new'); // Ctrl+N
		editorUi.keyHandler.bindAction(79, true, 'open'); // Ctrl+O

		var isFullScreen = await requestSync('isFullscreen');

		var fullscreenAction = editorUi.actions.addAction('fullscreen', async function()
		{
			electron.sendMessage('toggleFullscreen');
			isFullScreen = await requestSync('isFullscreen');
		});

		fullscreenAction.visible = true;
		fullscreenAction.setToggleAction(true);
		
		fullscreenAction.setSelectedCallback(function()
		{
			return isFullScreen;
		});
		
		function createGraph()
		{
			var graph = new Graph();
	        graph.setExtendParents(false);
	        graph.setExtendParentsOnAdd(false);
	        graph.setConstrainChildren(false);
	        graph.setHtmlLabels(true);
	        graph.getModel().maintainEdgeParent = false;
	        return graph;
		};
		
		async function cloneMxCLipboardToSys()
		{
			var cells = mxClipboard.getCells();
			
			if (cells && cells.length > 0)
			{
				try
				{
					var tmpGraph = createGraph();
					tmpGraph.importCells(cells, 0, 0, tmpGraph.getDefaultParent());
					var codec = new mxCodec();
		            var node = codec.encode(tmpGraph.getModel());
		            var modelString = mxUtils.getXml(node);
					await requestSync({
						action: 'clipboardAction', 
						method: 'writeText',
						data: encodeURIComponent(modelString)
					});
				}
				catch(e)
				{
					//Ignore
				} 
			}
		};
		
		async function cloneSysCLipboardToMx()
		{
			try
			{
				var modelString = await requestSync({
					action: 'clipboardAction', 
					method: 'readText',
				});
				
				if (modelString)
				{
					modelString = decodeURIComponent(modelString);
					var xmlDoc = mxUtils.parseXml(modelString);
					var tmpGraph = createGraph();
					var codec = new mxCodec(xmlDoc);
					var model = tmpGraph.getModel();
					codec.decode(xmlDoc.documentElement, model);
					mxClipboard.setCells(model.root.children[0].children);
				}
			}
			catch(e)
			{
				//Ignore, the contents of mxClipboard will be used
			}
		};
		
		//Set system clipboard on menu copy/cut
		var origCut = this.actions.get('cut').funct;
		
		editorUi.actions.addAction('cut', function()
		{
			origCut();
			cloneMxCLipboardToSys();
		}, null, '', Editor.ctrlKey + '+X');
		
		var origCopy = this.actions.get('copy').funct;
		
		editorUi.actions.addAction('copy', function()
		{
			origCopy();
			cloneMxCLipboardToSys();
		}, null, '', Editor.ctrlKey + '+C');
		
		//Get data from system clipboard for pase/pasteHere
		var origPaste = this.actions.get('paste').funct;
		
		editorUi.actions.addAction('paste', function()
		{
			cloneSysCLipboardToMx();
			origPaste();
		}, false, '', Editor.ctrlKey + '+V');
	
		var origPasteHere = this.actions.get('pasteHere').funct;

		editorUi.actions.addAction('pasteHere', function()
		{
			cloneSysCLipboardToMx();
			origPasteHere();
		});
		
		//Enable paste action even if mxClipboard is empty! TODO Is this OK?
		editorUi.updatePasteActionStates = function()
		{
			var graph = this.editor.graph;
			var paste = this.actions.get('paste');
			var pasteHere = this.actions.get('pasteHere');
			
			paste.setEnabled(this.editor.graph.cellEditor.isContentEditing() || 
				(graph.isEnabled() && !graph.isCellLocked(graph.getDefaultParent())));
			pasteHere.setEnabled(paste.isEnabled());
		};
		
		editorUi.actions.addAction('plugins...', function()
		{
			var pluginsMap = {};
			//Initialize it with plugins in settings
			var plugins = (mxSettings.settings != null) ? mxSettings.getPlugins() : null;

			if (plugins != null)
			{
				for (var i = 0; i < plugins.length; i++)
				{
					pluginsMap[plugins[i]] = true;
				}
			}

			editorUi.showDialog(new PluginsDialog(editorUi, function(callback)
			{
				var div = document.createElement('div');
				
				var title = document.createElement('span');
				title.style.marginTop = '6px';
				mxUtils.write(title, mxResources.get('builtinPlugins') + ': ');
				div.appendChild(title);
				
				var pluginsSelect = document.createElement('select');
				pluginsSelect.style.width = '150px';
				
				for (var i = 0; i < App.publicPlugin.length; i++)
				{
					var p = App.publicPlugin[i];

					if  (pluginsMap[App.pluginRegistry[p]]) continue;

					var option = document.createElement('option');
					mxUtils.write(option, p);
					option.value = p;
					pluginsSelect.appendChild(option);
				}
				
				div.appendChild(pluginsSelect);
							
				var dlg = new CustomDialog(editorUi, div, mxUtils.bind(this, function()
				{
					var newP = App.pluginRegistry[pluginsSelect.value];
					pluginsMap[newP] = true;
	        		callback(newP);
				}));
				editorUi.showDialog(dlg.container, 300, 125, true, true);
			},
			function(plugin)
			{
				delete pluginsMap[plugin];
			}, true).container, 380, null, true, false);
		});

		editorUi.actions.addAction('exit', function()
		{
			electron.request({
				action: 'exit'
			});
		});
	}
	
	var appLoad = App.prototype.load;

	App.prototype.load = function()
	{
		appLoad.apply(this, arguments);
		
		electron.registerMsgListener('args-obj', (argsObj) =>
		{
			this.loadArgs(argsObj)
		})

		//We do some async stuff during app loading so we need to know exactly when loading is finished (it is not when onload is finished)
		electron.sendMessage('app-load-finished', null);

		//Change offline translation
		mxResources.parse('notInOffline=' + mxResources.get('notInDesktop'));
	}
	
	App.prototype.loadArgs = function(argsObj)
	{
		var paths = argsObj.args;
		var layoutName = argsObj.layout;
		// Set by the --mermaid-image command-line flag (parsed in the desktop
		// main process, like layout): opens .mmd/.mermaid files as a static
		// image instead of an editable diagram.
		var mermaidImage = argsObj.mermaidImage;

		// If a file is passed, and it is not an argument (has a leading -)
		if (paths !== undefined && paths[0] != null && paths[0].indexOf('-') != 0 && this.spinner.spin(document.body, mxResources.get('loading')))
		{
			var path = paths[0];
			this.hideDialog();

			var success = mxUtils.bind(this, function(fileEntry, data, stat, name, isModified)
			{
				this.spinner.stop();

				if (data != null)
				{
					var file = new LocalFile(this, data, name || '');
					file.fileObject = fileEntry;
					file.stat = stat;
					file.setModified(isModified? true : false);
					this.fileLoaded(file);

					// --layout: run the requested ELK layout once the diagram
					// is loaded (applies to any opened file, generated or not).
					// executeLayoutSpec (EditorUi) is shared with the embed
					// "layout" action and the #create / load "layout" option.
					if (layoutName != null)
					{
						this.executeLayoutSpec(layoutName);
					}
				}
			});
			
			var error = mxUtils.bind(this, function(e)
			{
				this.spinner.stop();
				
				if (e.code === 'ENOENT')
				{
					var title = path.replace(/^.*[\\\/]/, '');
					var data = this.emptyDiagramXml;
					var file = new LocalFile(this, data, title, null);
					
					file.fileObject = new Object();
					file.fileObject.path = path;
					file.fileObject.name = title;
					file.fileObject.type = 'utf-8';
					this.fileCreated(file, null, null, null);					
					this.saveFile();
				}
				else
				{
					this.handleError(e);
				}
				
			});
			
			// Tries to open the file
			this.readGraphFile(success, error, path, null, mermaidImage);
		}
		// If no file is passed, but there is the "create-if-not-exists" flag
		else if (argsObj.create != null)
		{
			var title = 'Untitled document';
			var data = this.emptyDiagramXml;
			var file = new LocalFile(this, data, title, null);
			this.fileCreated(file, null, null, null);
		}
		else
		{
			this.checkDrafts();
		}
	}

	// whenScriptReady (bundle-load poll) and the --layout resolver are shared
	// with the webapp; see EditorUi.prototype.whenScriptReady /
	// EditorUi.prototype.executeLayoutSpec in diagramly/EditorUi.js.

	var origFileLoaded = EditorUi.prototype.fileLoaded;
	
	EditorUi.prototype.fileLoaded = async function(file)
	{
		var oldFile = this.getCurrentFile();

		if (oldFile != null)
		{
			//TODO This assumes the user confirmed discarding the file changes to get to this function?
			if (EditorUi.enableDrafts)
			{
				oldFile.removeDraft();
			}
		}
		
		if (file != null)
		{
			if (file.fileObject == null)
			{
				var fname = file.getTitle();
				
				var fileInfo = openFilesMap[fname];
				
				if (fileInfo != null)
				{
					file.fileObject = {
						name: fileInfo.name,
						path: fileInfo.path,
						type: fileInfo.type || 'utf-8'
					};
					//delete it such that it is not used again incorrectly
					delete openFilesMap[fname];
				}
			}
			
			if (file.fileObject != null)
			{
				file.addToRecent();
			}
		}

		this.watchFile(file);
		origFileLoaded.apply(this, arguments);
	};

	var origSetCurrentFile = EditorUi.prototype.setCurrentFile;

	EditorUi.prototype.setCurrentFile = function(file)
	{
		origSetCurrentFile.apply(this, arguments);
		this.watchFile(file);
	};

	// Monitor the given file for changes
	EditorUi.prototype.watchFile = async function(file)
	{
		// Saving a non-current file (eg. a library) must not unwatch
		// the current file's path
		if (file != null && file != this.getCurrentFile())
		{
			return;
		}

		var newPath = (file != null && file.fileObject != null &&
			file == this.getCurrentFile()) ? file.fileObject.path : null;
		
		if (this.watchedPath != newPath)
		{
			this.unwatchPath(this.watchedPath);
		}

		if (newPath != null)
		{
			this.watchedPath = newPath;
			this.watchPath(newPath);
		}
	};
	
	// Unwatches the given path
	EditorUi.prototype.unwatchPath = async function(path)
	{
		if (path != null)
		{
			EditorUi.debug('EditorUi.unwatchPath', [this], 'path', [path]);

			await requestSync({action: 'unwatchFile', path: path});
		};
	};

	// Watches the path for changes
	EditorUi.prototype.watchPath = async function(path)
	{
		if (path != null)
		{
			EditorUi.debug('EditorUi.watchPath', [this], 'path', [path]);

			await requestSync({
				action: 'watchFile', 
				path: path,
				listener: mxUtils.bind(this, function(curr, prev) 
				{
					var file = this.getCurrentFile();

					if (file != null && file.fileObject != null &&
						file.fileObject.path == path)
					{
						this.handleFileChange(curr, prev, file);
					}
				})
			});
		}
	};

	// Uses local picker
	EditorUi.prototype.handleFileChange = function(curr, prev, file)
	{
		// File not deleted, changed (not just accessed) and not already in conflict state
		if (curr.mtimeMs != 0 && curr.mtimeMs != prev.mtimeMs && !file.inConflictState)
		{
			//Ignore our own changes
			if (file.unwatchedSaves || (file.stat != null && file.stat.mtimeMs == curr.mtimeMs))
			{
				file.unwatchedSaves = false;
				return;
			}

			EditorUi.debug('EditorUi.handleFileChange', [this],
				'file', [file], 'stat', [file.stat],
				'curr', [curr], 'prev', [prev],
				'unwatchedSaves', file.unwatchedSaves);

			var addConflictStatus = mxUtils.bind(this, function(latestFile)
			{
				file.inConflictState = true;

				file.addConflictStatus(null, mxUtils.bind(this, function()
				{
					file.ui.updateStatus(mxUtils.bind(this, function()
					{
						file.ui.editor.setStatus(mxUtils.htmlEntities(
							mxResources.get('updatingDocument')));
					}));

					file.synchronizeFile(mxUtils.bind(this, function()
					{
						file.handleFileSuccess(false);
					}), mxUtils.bind(this, function(err)
					{
						file.handleFileError(err, true);
					}));
				}));
			});

			// Checks checksums before notifiying in case of timestamp change
			if (curr.size == prev.size)
			{
				file.getLatestVersion(mxUtils.bind(this, function(latestFile)
				{
					if (this.getHashValueForPages(file.getShadowPages()) !==
						this.getHashValueForPages(latestFile.getShadowPages()))
					{
						addConflictStatus(latestFile);
					}
					else
					{
						// Adopts the new stat for timestamp-only changes (eg. FUSE
						// mounts finalize mtime after write) so the next save
						// doesn't misdetect a conflict
						file.stat = latestFile.stat;

						EditorUi.debug('EditorUi.handleFileChange', [this],
							'No changes detected in file', [file]);
					}
				}), addConflictStatus);
			}
			else
			{
				addConflictStatus();
			}
		}
	};

	// Uses local picker
	App.prototype.pickFile = function()
	{
		var doPickFile = mxUtils.bind(this, function()
		{
			this.chooseFileEntry(mxUtils.bind(this, function(fileEntry, data, stat, name, isModified)
			{
				var file = new LocalFile(this, data, '');
				file.fileObject = fileEntry;
				file.stat = stat;
				file.setModified(isModified? true : false);
				this.fileLoaded(file);
			}));
		});

		var file = this.getCurrentFile();
		
		if (file != null && file.isModified())
		{
			this.confirm(mxResources.get('allChangesLost'), null, doPickFile,
				mxResources.get('cancel'), mxResources.get('discardChanges'));
		}
		else
		{
			doPickFile();
		}
	};
	
	/**
	 * Selects a library to load from a picker
	 * 
	 * @param mode the device mode, ignored in this case
	 */
	App.prototype.pickLibrary = function(mode)
	{
		this.chooseFileEntry(mxUtils.bind(this, function(fileEntry, data, stat)
		{
			try
			{
				var library = new DesktopLibrary(this, data, fileEntry);
				this.loadLibrary(library);
				this.showSidebar();
			}
			catch (e)
			{
				this.handleError(e, mxResources.get('errorLoadingFile'));
			}
		}));
	};
	
	// Uses local picker
	App.prototype.chooseFileEntry = async function(fn)
	{
		var lastDir = localStorage.getItem('.lastOpenDir');
		
		var paths = await requestSync({
			action: 'showOpenDialog',
			defaultPath: lastDir || (await requestSync('getDocumentsFolder')),
			filters: [
				{ name: 'draw.io Diagrams', extensions: ['drawio', 'xml', 'png', 'svg', 'html', 'pdf'] },
        	    { name: 'VSDX Documents', extensions: ['vsdx'] },
        	    { name: 'Mermaid', extensions: ['mmd', 'mermaid'] },
        	    { name: 'All Files', extensions: ['*'] }
			],
			properties: ['openFile']
		});
	           
        if (paths !== undefined && paths[0] != null)
        {
        	localStorage.setItem('.lastOpenDir', await requestSync({action: 'dirname', path: paths[0]}));

			this.readGraphFile(fn, mxUtils.bind(this, function(err)
			{
				this.handleError(err);
			}), paths[0]);
        }
        else
        {
        	this.spinner.stop();
        }
	};
	
	EditorUi.prototype.normalizeFilename = function(title, defaultExtension)
	{
		if (!title || typeof title !== 'string')
		{
			title = mxResources.get('untitledDiagram');
		}

		var tokens = title.split('.');
		var ext = (tokens.length > 1) ? tokens[tokens.length - 1] : '';
		defaultExtension = (defaultExtension != null) ? defaultExtension : 'drawio';

		if (tokens.length == 1 || mxUtils.indexOf(['xml',
			'html', 'drawio', 'png', 'svg', 'pdf'], ext) < 0)
		{
			tokens.push(defaultExtension);
		}

		return tokens.join('.');
	};

	// Adds .pdf to the stripped extensions so exports of foo.drawio.pdf
	// derive foo.* filenames like the other editable formats
	EditorUi.prototype.getBaseFilename = function(ignorePageName)
	{
		var file = this.getCurrentFile();
		var basename = (file != null && file.getTitle() != null) ? file.getTitle() : this.defaultFilename;

		if (/(\.xml)$/i.test(basename) || /(\.html)$/i.test(basename) ||
			/(\.svg)$/i.test(basename) || /(\.png)$/i.test(basename) ||
			/(\.pdf)$/i.test(basename))
		{
			basename = basename.substring(0, basename.lastIndexOf('.'));
		}

		if (/(\.drawio)$/i.test(basename))
		{
			basename = basename.substring(0, basename.lastIndexOf('.'));
		}

		if (!ignorePageName && this.pages != null && this.pages.length > 1 &&
			this.currentPage != null && this.currentPage.node.getAttribute('name') != null &&
			this.currentPage.getName().length > 0)
		{
			basename = basename + '-' + this.currentPage.getName();
		}

		return basename;
	};

	//In order not to repeat the logic for opening a file, we collect files information here and use them in openLocalFile
	var origOpenFiles = EditorUi.prototype.openFiles;
	var openFilesMap = {};
	
	EditorUi.prototype.openFiles = function(files, temp)
	{
		openFilesMap = {};

		for (var i = 0; i < files.length; i++)
		{
			openFilesMap[files[i].name] = files[i];
		}
		
		origOpenFiles.apply(this, arguments);
	};
	
	App.prototype.readGraphFile = function(fn, fnErr, path, noDraftCheck, mermaidImage)
	{
		var index = path.lastIndexOf('.png');
		var isPng = index > -1 && index == path.length - 4;
		var isVsdx = /\.vsdx$/i.test(path) || /\.vssx$/i.test(path);
		var isMermaid = /\.mmd$/i.test(path) || /\.mermaid$/i.test(path);
		var encoding = isVsdx? null : ((isPng || /\.pdf$/i.test(path)) ? 'base64' : 'utf-8');
		var fileEntry = new Object(), stat = null;
		fileEntry.path = path;
		fileEntry.name = path.replace(/^.*[\\\/]/, '');
		fileEntry.type = encoding;

		var checkDrafts = mxUtils.bind(this, function()
		{
			if (noDraftCheck) return;

			electron.request({
				action: 'getFileDrafts',
				fileObject: fileEntry
			}, mxUtils.bind(this, function(drafts)
			{
				if (drafts.length > 0)
				{
					var dlg = new DraftDialog(this, mxResources.get('unsavedChanges'),
								(drafts.length > 1) ? null : drafts[0].data, mxUtils.bind(this, async function(index)
					{
						index = index || 0;
						this.hideDialog();
						fn(fileEntry, drafts[index].data, stat, null, true);
						await requestSync({action: 'deleteFile', file: drafts[index].path});
					}), mxUtils.bind(this, async function(index)
					{
						index = index || 0;
						await requestSync({action: 'deleteFile', file: drafts[index].path});
						this.hideDialog();
					}), null, null, null, (drafts.length > 1) ? drafts : null);
					
					this.showDialog(dlg.container, 640, 480, true, false);
					
					dlg.init();
				}
			}),
			mxUtils.bind(this, function(errMsg, err)
			{
				//TODO Currently ignored, maybe we should retry?
			}));
		});

		var readData = mxUtils.bind(this, function (data)
		{
			// VSDX and PDF files are imported instead of being opened
			if (isVsdx)
			{
				var name = fileEntry.name;

				this.importVisio(data, mxUtils.bind(this, function(xml)
				{
					var dot = name.lastIndexOf('.');
					
					if (dot >= 0)
					{
						name = name.substring(0, name.lastIndexOf('.')) + '.drawio';
					}
					else
					{
						name = name + '.drawio';
					}
					
					if (xml.substring(0, 10) == '<mxlibrary')
					{
						// Creates new temporary file if library is dropped in splash screen
						if (this.getCurrentFile() == null && urlParams['embed'] != '1')
						{
							this.openLocalFile(this.emptyDiagramXml, this.defaultFilename);
						}
					
						try
						{
							this.loadLibrary(new LocalLibrary(this, xml, name));
							this.showSidebar();
						}
						catch (e)
						{
							this.handleError(e, mxResources.get('errorLoadingFile'));
						}
						
						fn();
					}
					else
					{
						fn(null, xml, null, name, false);
					}

					checkDrafts();
				}), null, name);
				
				return;
			}
			else if (isMermaid)
			{
				// Mermaid files are converted to a diagram and opened as a new,
				// unsaved .drawio file (the Mermaid source is preserved on the
				// resulting group/image for re-editing). Mirrors the VSDX/PDF
				// import path. The --mermaid-image command-line flag opens the
				// file as a static SVG image instead of an editable diagram.
				var name = fileEntry.name;
				var dot = name.lastIndexOf('.');
				name = (dot >= 0 ? name.substring(0, dot) : name) + '.drawio';

				// The Mermaid bundle loads asynchronously during startup, so a
				// .mmd/.mermaid file passed on the command line can arrive before
				// it is ready — wait for it before parsing.
				this.whenScriptReady(EditorUi.isMermaidSupported, mxUtils.bind(this, function()
				{
					var onMermaid = mxUtils.bind(this, function(diagramXml)
					{
						fn(null, diagramXml, null, name, false);

						// Mermaid files carry no stored view, so the default scroll
						// can land at an arbitrary edge (e.g. the bottom of a tall
						// flowchart). Apply the standard fit-on-load once the diagram
						// is in place.
						var ui = this;
						window.setTimeout(function() { ui.fitInitialView(); }, 0);

						checkDrafts();
					});

					var onMermaidError = mxUtils.bind(this, function(e)
					{
						fnErr(e);
						checkDrafts();
					});

					if (mermaidImage)
					{
						this.parseMermaidImage(data, onMermaid, onMermaidError);
					}
					else
					{
						this.parseMermaidDiagram(data, null, mxUtils.bind(this, function(mermaidXml)
						{
							// normalize:true shifts the wrapped content so the group's
							// padded bounds start at (0,0) — i.e. the diagram is inset
							// from the page origin by groupPadding instead of sitting
							// flush at (0,0) with the padding spilling into negative space.
							onMermaid(mxMermaidToDrawio.wrapGroup(mermaidXml, data, null, {normalize: true}));
						}), onMermaidError);
					}
				}), mxUtils.bind(this, function()
				{
					fnErr(new Error(mxResources.get('serviceUnavailableOrBlocked')));
					checkDrafts();
				}));

				return;
			}
			else if (/\.pdf$/i.test(path))
			{
				// Opens PDFs with embedded XML in place as editable files
				// like PNG below (previously extracted to a new .drawio file)
				data = Editor.extractGraphModelFromPdf('data:application/pdf;base64,' + data);

				// Stops before the file is bound to the path as a save
				// would overwrite the PDF with an empty diagram
				if (data == null)
				{
					fnErr(new Error(mxResources.get('notADiagramFile')));
					checkDrafts();

					return;
				}
			}
			else if (isPng)
			{
				// Detecting png by extension. Would need https://github.com/mscdex/mmmagic
				// to do it by inspection
				data = this.extractGraphModelFromPng('data:image/png;base64,' + data);

				// Stops before the file is bound to the path as a save
				// would overwrite the image with an empty diagram
				if (data == null)
				{
					fnErr(new Error(mxResources.get('notADiagramFile')));
					checkDrafts();

					return;
				}
			}

			electron.request({action: 'fileStat', file: path}, mxUtils.bind(this, function(stat_p)
			{
				stat = stat_p;
				fn(fileEntry, data, stat, null, false);

				electron.request({action: 'isFileWritable', file: path}, mxUtils.bind(this, function(isWritable)
				{
					if (!isWritable)
					{
						var file = this.getCurrentFile();

						if (file != null && file.fileObject != null && file.fileObject.path == path)
						{
							file.setEditable(false);
							this.updateStatus(mxUtils.bind(this, function()
							{
								this.editor.setStatus('<div class="geStatusBox" title="' +
									mxUtils.htmlEntities(mxResources.get('readOnly')) + '">' +
									mxUtils.htmlEntities(mxResources.get('readOnly')) + '</div>');
							}));						
						}
					}
				}));

				checkDrafts();
			}), function(errMsg, err)
			{
				fnErr(err);
			});
		});
 
		electron.request({
			action: 'readFile',
			filename: path,
			encoding: encoding
		}, readData, function(errMsg, err)
		{
			fnErr(err);
			checkDrafts();
		});
	};

	// Disables temp files in Electron
	var LocalFileCtor = LocalFile;
	
	LocalFile = function(ui, data, title, temp)
	{
		LocalFileCtor.call(this, ui, data, title, false);
	};

	mxUtils.extend(LocalFile, LocalFileCtor);

	LocalFile.prototype.getLatestVersion = function(success, error)
	{
		if (this.fileObject == null)
		{
			if (error != null)
			{
				error({message: mxResources.get('fileNotFound')});
			}
		}
		else
		{
			this.ui.readGraphFile(mxUtils.bind(this, function(fileEntry, data, stat, name, isModified)
			{
				var file = new LocalFile(this.ui, data, '');
				file.stat = stat;
				file.setModified(isModified? true : false);
				success(file);
			}), error, this.fileObject.path, true);
		}
	};
	
	// Call save as for copy
	LocalFile.prototype.copyFile = function(success, error)
	{
		this.saveAs(this.ui.getCopyFilename(this), success, error);
	};

	// Best-effort recovery source: the on-disk .bkp backup (last good save before
	// the most recent overwrite). Returns a lossless prior-version candidate or
	// null. See EditorUi.getRecoveryData / DrawioFile.getRecoveryVersion.
	LocalFile.prototype.getRecoveryVersion = function(success, error)
	{
		if (this.fileObject == null || this.fileObject.path == null)
		{
			success(null);
			return;
		}

		electron.request({action: 'getBkpFile', fileObject: {path: this.fileObject.path}},
			mxUtils.bind(this, function(bkp)
			{
				if (bkp != null && bkp.data != null && this.ui.isFileDataLoadable(bkp.data))
				{
					success({type: 'backup',
						label: mxResources.get('restoreBackupCopy'),
						description: mxResources.get('recoveryVersionDesc'),
						data: bkp.data, date: bkp.modified, lossy: false});
				}
				else
				{
					success(null);
				}
			}), mxUtils.bind(this, function()
			{
				success(null);
			}));
	};
	
	/**
	 * Adds all listeners.
	 */
	LocalFile.prototype.getDescriptor = function()
	{
		return this.stat;
	};

	/**
	* Updates the descriptor of this file with the one from the given file.
	*/
	LocalFile.prototype.setDescriptor = function(stat)
	{
		this.stat = stat;
	};
	
	LocalFile.prototype.isPdfFile = function()
	{
		return this.fileObject != null && /\.pdf$/i.test(this.fileObject.name);
	};

	// Autosave for PDF files re-runs the full export pipeline on every
	// change, so it is off by default and opt-in via the autosave toggle
	LocalFile.prototype.isAutosave = function()
	{
		if (this.isPdfFile())
		{
			return !this.inConflictState && isPdfAutosaveEnabled();
		}

		return this.fileObject != null && DrawioFile.prototype.isAutosave.apply(this, arguments);
	};

	// Detaches PDF files from the global autosave option (see toggle below)
	LocalFile.prototype.isAutosaveOptional = function()
	{
		return this.fileObject != null && !this.isPdfFile();
	};

	var isPdfAutosaveEnabled = function()
	{
		return localStorage.getItem('.pdfAutosave') == '1';
	};

	var setPdfAutosaveEnabled = function(ui, value)
	{
		localStorage.setItem('.pdfAutosave', (value) ? '1' : '0');

		// Refreshes the autosave checkbox and menu item
		ui.editor.fireEvent(new mxEventObject('autosaveChanged'));

		var file = ui.getCurrentFile();

		if (value && file != null && file.isModified())
		{
			file.fileChanged();
		}
	};

	var isCurrentFilePdf = function(ui)
	{
		var file = ui.getCurrentFile();

		return file != null && file.constructor == LocalFile &&
			file.isPdfFile() && file.isEditable();
	};

	// Repurposes the autosave action to toggle PDF autosave for PDF files
	var origMenusInit = Menus.prototype.init;

	Menus.prototype.init = function()
	{
		origMenusInit.apply(this, arguments);

		var editorUi = this.editorUi;
		var action = editorUi.actions.get('autosave');

		action.funct = function()
		{
			if (isCurrentFilePdf(editorUi))
			{
				setPdfAutosaveEnabled(editorUi, !isPdfAutosaveEnabled());
			}
			else
			{
				editorUi.editor.setAutosave(!editorUi.editor.autosave);
			}
		};

		action.setSelectedCallback(function()
		{
			return action.isEnabled() && ((isCurrentFilePdf(editorUi)) ?
				isPdfAutosaveEnabled() : editorUi.editor.autosave);
		});
	};

	// Keeps the autosave menu item enabled for PDF files where
	// isAutosaveOptional is false
	var origUpdateActionStates = EditorUi.prototype.updateActionStates;

	EditorUi.prototype.updateActionStates = function()
	{
		origUpdateActionStates.apply(this, arguments);

		if (isCurrentFilePdf(this))
		{
			this.actions.get('autosave').setEnabled(true);
		}
	};

	// Adds the autosave option for PDF files to the diagram format panel
	// (the global autosave option is hidden via isAutosaveOptional)
	var diagramFormatPanelAddOptions = DiagramFormatPanel.prototype.addOptions;

	DiagramFormatPanel.prototype.addOptions = function(div)
	{
		div = diagramFormatPanelAddOptions.apply(this, arguments);

		var ui = this.editorUi;

		if (ui.editor.graph.isEnabled() && isCurrentFilePdf(ui))
		{
			div.appendChild(this.createOption(mxResources.get('autosave'), function()
			{
				return isPdfAutosaveEnabled();
			}, function(checked)
			{
				setPdfAutosaveEnabled(ui, checked);
			},
			{
				install: function(apply)
				{
					this.listener = function()
					{
						apply(isPdfAutosaveEnabled());
					};

					ui.editor.addListener('autosaveChanged', this.listener);
				},
				destroy: function()
				{
					ui.editor.removeListener(this.listener);
				}
			}));
		}

		return div;
	};
	
	LocalFile.prototype.getTitle = function()
	{
		return (this.fileObject != null) ? this.fileObject.name : this.title;
	};

	LocalFile.prototype.isRenamable = function()
	{
		return false;
	};
	
	var autoSaveEnabled = false;

	LocalFile.prototype.save = function(revision, success, error, unloading, overwrite, cancel)
	{
		if (!this.isEditable())
		{
			this.saveAs(this.title, success, error, cancel);
			return;
		}

		DrawioFile.prototype.save.apply(this, [revision, mxUtils.bind(this, function()
		{
			this.saveFile(revision, mxUtils.bind(this, function()
			{
				//Only for first save after auto save is enabled (excluding the save as [overwrite])
				if (autoSaveEnabled && !overwrite && EditorUi.enableDrafts)
				{
					this.removeDraft();
				}

				autoSaveEnabled = false;
				success.apply(this, arguments);
			}), error, unloading, overwrite, cancel);
		}), error, unloading, overwrite]);
	};

	LocalFile.prototype.isConflict = function(stat)
	{
		return stat != null && this.stat != null && stat.mtimeMs != this.stat.mtimeMs;
	};
	
	LocalFile.prototype.saveFile = async function(revision, success, error, unloading, overwrite, cancel)
	{
		//Safeguard in case saveFile is called from online code in the future
		if (typeof success !== 'function')
		{
			if (typeof unloading === 'function')
			{
				//Call error
				unloading({message: 'This is a bug, please report!'}); //Original draw.io function parameters are (title, revision, success, error, useCurrentData)
			}
			return;
		}
		
		if (!this.savingFile)
		{
			var fn = mxUtils.bind(this, function(fileSavedFn)
			{
				var doSave = mxUtils.bind(this, function(data, enc)
				{
					var savedData = this.data;
					
					// Makes sure no changes get lost while the file is saved
					this.setShadowModified(false);
					this.savingFile = true;
					
					var errorWrapper = mxUtils.bind(this, function(e)
					{
						this.savingFile = false;
						
						if (error != null)
						{
	        				error(e);
						}
					});

					this.unwatchedSaves = true; //Multiple saves doesn't call watch the same number, so use a boolean and check for changes
					
					electron.request({
						action: 'saveFile',
						fileObject: this.fileObject,
						defEnc: enc,
						data: data,
						origStat: this.stat,
						overwrite: overwrite
					}, mxUtils.bind(this, function(stat)
					{
						//No changes during the saving process?
						this.setModified(this.getShadowModified());
						this.savingFile = false;
						var lastDesc = this.stat;
						this.stat = stat;
						
						this.fileSaved(savedData, lastDesc, mxUtils.bind(this, function()
						{
							this.ui.watchFile(this);
							this.contentChanged();
							
							if (fileSavedFn != null)
							{
								fileSavedFn();
							}

							if (success != null)
							{
								success();
							}
						}), error);
					}), 
					mxUtils.bind(this, function(errMsg, err)
					{
						if (errMsg == 'empty data')
						{
							this.ui.handleError({message: mxResources.get('errorSavingFile')});
							errorWrapper();
						}
						else if (errMsg == 'conflict')
						{
							this.inConflictState = true;
							errorWrapper();
						}
						else
						{
							errorWrapper(err || errMsg);
						}
					}));
				});
	
				// Libraries always save their XML data: the PDF and PNG
				// branches below export the current diagram, which would
				// replace the library contents
				if (this instanceof LocalLibrary)
				{
					doSave(this.getData());
				}
				else if (this.isPdfFile())
				{
					var p = this.ui.getPdfFileProperties(this.ui.fileNode);

					this.ui.getEmbeddedPdf(function(data)
					{
						doSave(data, 'binary');
					}, error, p.notes);
				}
				else if (!/(\.png)$/i.test(this.fileObject.name))
				{
					doSave(this.getData());
				}
				else
				{
					var p = this.ui.getPngFileProperties(this.ui.fileNode);

					this.ui.getEmbeddedPng(function(data)
					{
						doSave(atob(data), 'binary');
					}, error, null, p.scale, p.border);
				}
			});
			
			try
			{
				if (this.fileObject == null)
				{
					var lastDir = localStorage.getItem('.lastSaveDir');
					var isLibrary = this instanceof LocalLibrary;
					var name = this.ui.normalizeFilename(this.getTitle(),
						(isLibrary) ? 'xml' : null);
					var ext = null;

					if (name != null)
					{
						var idx = name.lastIndexOf('.');

						if (idx > 0)
						{
							ext = name.substring(idx + 1);
						}
					}

					var path = await requestSync({
						action: 'showSaveDialog',
						defaultPath: (lastDir || (await requestSync('getDocumentsFolder'))) + '/' + name,
						filters: (isLibrary) ? this.ui.createLibraryFileSystemFilters() :
							this.ui.createFileSystemFilters(ext)
					});

					if (path != null)
					{
						localStorage.setItem('.lastSaveDir', await requestSync({action: 'dirname', path: path}));
						this.fileObject = new Object();
						this.fileObject.path = path;
						this.fileObject.name = path.replace(/^.*[\\\/]/, '');
						this.fileObject.type = 'utf-8';
						this.title = this.fileObject.name;
						this.addToRecent();
						fn(mxUtils.bind(this, function()
						{
							if (EditorUi.enableDrafts)
							{
								this.removeDraft(true);
							}
						}));

						// Updates format panel to show autosave option
						var editor = this.ui.editor;
						editor.setAutosave(editor.autosave);
					}
					else
					{
						this.ui.spinner.stop();

						if (cancel != null)
						{
							cancel();
						}
					}
				}
				else
				{
					fn();
				}
			}
			catch (e)
			{
				error(e);
			}
		}
		else if (cancel != null)
		{
			//Another save is already in progress (eg. autosave), this save request is dropped
			cancel();
		}
	};


	var origAddConflictStatus = LocalFile.prototype.addConflictStatus;

	LocalFile.prototype.addConflictStatus = function(message, fn, latestFile)
	{
		if (Editor.desktopAutoSync && this.ui.editor.autosave)
		{
			fn();
		}
		else
		{
			origAddConflictStatus.apply(this, arguments);
		}
	};

	LocalFile.prototype.addToRecent = function()
	{
		if (this.fileObject == null) return;

		var title = this.fileObject.path;
				
		if (title.length > 100)
		{
			title = '...' + title.substr(title.length - 97);
		}

		this.ui.addRecent({id: this.fileObject.path, title: title});
	};

	LocalFile.prototype.saveAs = async function(title, success, error, cancel)
	{
		try
		{
			var lastDir = (this.fileObject != null && this.fileObject.path != null) ?
				await requestSync({action: 'dirname', path: this.fileObject.path}) :
				localStorage.getItem('.lastSaveDir');
			var isLibrary = this instanceof LocalLibrary;
			var name = this.ui.normalizeFilename(this.getTitle(),
				(isLibrary) ? 'xml' : null);
			var ext = null;

			if (name != null)
			{
				var idx = name.lastIndexOf('.');

				if (idx > 0)
				{
					ext = name.substring(idx + 1);
				}
			}

			var path = await requestSync({
				action: 'showSaveDialog',
				defaultPath: (lastDir || (await requestSync('getDocumentsFolder'))) + '/' + name,
				filters: (isLibrary) ? this.ui.createLibraryFileSystemFilters() :
					this.ui.createFileSystemFilters(ext)
			});

			if (path != null)
			{
				localStorage.setItem('.lastSaveDir', await requestSync({action: 'dirname', path: path}));
				this.fileObject = new Object();
				this.fileObject.path = path;
				this.fileObject.name = path.replace(/^.*[\\\/]/, '');
				this.fileObject.type = 'utf-8';
				this.title = this.fileObject.name;
				this.addToRecent();
				this.setEditable(true); //In case original file is read only
				this.save(false, mxUtils.bind(this, function()
				{
					this.ui.watchFile(this);
					success();
				}), error, null, true);
			}
			else if (cancel != null)
			{
				cancel();
			}
		}
		catch (e)
		{
			error(e);
		}
	};

	// The web LocalLibrary.saveAs calls saveFile with the web signature
	// (title, revision, ...), which hits the signature safeguard in the
	// desktop saveFile above, so the desktop saveAs is used instead
	LocalLibrary.prototype.saveAs = LocalFile.prototype.saveAs;

	// LocalLibrary extends the pre-wrapper LocalFile, so without these it
	// inherits the web save/saveFile: the web save calls saveAs, and the
	// desktop saveAs above ends with save, which reopens the save dialog
	// forever without ever writing the file [drawio-desktop#2518]
	LocalLibrary.prototype.save = LocalFile.prototype.save;
	LocalLibrary.prototype.saveFile = LocalFile.prototype.saveFile;

	LocalFile.prototype.saveDraft = function(data)
	{
		// Save draft only if file is not saved (prevents creating draft file after actual file is saved)
		if (!this.isModified()) return;

		if (this.fileObject == null)
		{
			//Use indexed db for unsaved files
			DrawioFile.prototype.saveDraft.apply(this, arguments);
		}
		else
		{
			EditorUi.debug('LocalFile.saveDraft', [this],
				'fileObject', [this.fileObject]);
			
			electron.request({
				action: 'saveDraft',
				fileObject: this.fileObject,
				data: (data != null) ? data : this.ui.getFileData()
			}, mxUtils.bind(this, function(draftFileName)
			{
				this.fileObject.draftFileName = draftFileName;
			}), mxUtils.bind(this, function(msg, e)
			{
				//TODO Currently ignored, maybe we should retry?
			}));
		}
	};

	LocalFile.prototype.removeDraft = async function(ignoreFileObject)
	{
		try
		{
			if (ignoreFileObject || this.fileObject == null)
			{
				//Use indexed db for unsaved files
				DrawioFile.prototype.removeDraft.apply(this, arguments);
			}
			else if (this.fileObject.draftFileName != null)
			{
				EditorUi.debug('LocalFile.removeDraft', [this],
					'draftFileName', [this.fileObject.draftFileName]);
				
				await requestSync({action: 'deleteFile', file: this.fileObject.draftFileName});
			}
		}
		catch (e)
		{
			// ignore
		}
	};

	LocalLibrary.prototype.addToRecent = function()
	{
		// do nothing
	};
	
	/**
	 * Loads the given file handle as a local file.
	 */
	App.prototype.createFileSystemFilters = function(defaultExt)
	{
		var ext = [];
		
		for (var i = 0; i < this.editor.diagramFileTypes.length; i++)
		{
			var obj = {name: mxResources.get(this.editor.diagramFileTypes[i].description) +
				' (.' + this.editor.diagramFileTypes[i].extension + ')',
				extensions: [this.editor.diagramFileTypes[i].extension]};
			
			if (this.editor.diagramFileTypes[i].extension == defaultExt)
			{
				ext.splice(0, 0, obj);
			}
			else
			{
				ext.push(obj);
			}
		}

		return ext;
	};

	/**
	 * Returns the save dialog filters for library files.
	 */
	App.prototype.createLibraryFileSystemFilters = function()
	{
		var filters = [];

		for (var i = 0; i < this.editor.libraryFileTypes.length; i++)
		{
			filters.push({name: this.editor.libraryFileTypes[i].description,
				extensions: this.editor.libraryFileTypes[i].extensions});
		}

		return filters;
	};

	/**
	 * Loads the given file handle as a local file.
	 */
	App.prototype.saveFile = function(forceDialog, success, error, cancel)
	{
		var file = this.getCurrentFile();

		if (file != null)
		{
			if (!forceDialog && file.getTitle() != null)
			{
				file.save(true, mxUtils.bind(this, function()
				{
					if (EditorUi.enableDrafts)
					{
						file.removeDraft();
					}

					file.handleFileSuccess(true);

					if (success != null)
					{
						success();
					}
				}), mxUtils.bind(this, function(err)
				{
					file.handleFileError(err, true);

					if (error != null)
					{
						error(err);
					}
				}), null, null, cancel);
			}
			else
			{
				let oldFileObject = file.fileObject;

				file.saveAs(null, mxUtils.bind(this, function()
				{
					if (EditorUi.enableDrafts)
					{
						//Workaround to delete the correct draft as the file object is updated in place
						let curFileObject = file.fileObject;
						file.fileObject = oldFileObject;
						file.removeDraft();
						file.fileObject = curFileObject;
					}

					file.handleFileSuccess(true);

					if (success != null)
					{
						success();
					}
				}), mxUtils.bind(this, function(err)
				{
					file.handleFileError(err, true);

					if (error != null)
					{
						error(err);
					}
				}), cancel);
			}
		}
	};
	
	/**
	 * Translates this point by the given vector.
	 */
	App.prototype.saveLibrary = function(name, images, file, mode, noSpin, noReload, fn)
	{
		mode = (mode != null) ? mode : this.mode;
		noSpin = (noSpin != null) ? noSpin : false;
		noReload = (noReload != null) ? noReload : false;
		var xml = this.createLibraryDataFromImages(images);
		
		var error = mxUtils.bind(this, function(resp)
		{
			this.spinner.stop();
			
			if (fn != null)
			{
				fn();
			}
			
			// Null means cancel by user and is ignored
			if (resp != null)
			{
				this.handleError(resp, mxResources.get('errorSavingFile'));
			}
		});
	
		// Handles special case for local libraries
		if (file == null)
		{
			file = new LocalLibrary(this, xml, name);
		}
		
		if (noSpin || this.spinner.spin(document.body, mxResources.get('saving')))
		{
			file.setData(xml);
			
			var doSave = mxUtils.bind(this, function()
			{
				file.save(true, mxUtils.bind(this, function(resp)
				{
					this.spinner.stop();
					this.hideDialog(true);
					
					if (!noReload)
					{
						this.libraryLoaded(file, images)
					}
					
					if (fn != null)
					{
						fn();
					}
				}), error);
			});
			
			if (name != file.getTitle())
			{
				var oldHash = file.getHash();
				
				file.rename(name, mxUtils.bind(this, function(resp)
				{
					// Change hash in stored settings
					if (file.constructor != LocalLibrary && oldHash != file.getHash())
					{
						mxSettings.removeCustomLibrary(oldHash);
						mxSettings.addCustomLibrary(file.getHash());
					}
	
					// Workaround for library files changing hash so
					// the old library cannot be removed from the
					// sidebar using the updated file in libraryLoaded
					this.removeLibrarySidebar(oldHash);
	
					doSave();
				}), error)
			}
			else
			{
				doSave();
			}
		}
	};
	
	App.prototype.checkForUpdates = function()
	{
		electron.sendMessage('checkForUpdates');
	};
	
	App.prototype.toggleSpellCheck = function()
	{
		electron.sendMessage('toggleSpellCheck');
	};

	App.prototype.toggleStoreBkp = function()
	{
		electron.sendMessage('toggleStoreBkp');
	};
	
	App.prototype.toggleGoogleFonts = function()
	{
		electron.sendMessage('toggleGoogleFonts');
	};

	App.prototype.openDevTools = function()
	{
		electron.sendMessage('openDevTools');
	};
		
	App.prototype.desktopZoomIn = function()
	{
		electron.sendMessage('zoomIn');
	};

	App.prototype.desktopZoomOut = function()
	{
		electron.sendMessage('zoomOut');
	};

	App.prototype.desktopResetZoom = function()
	{
		electron.sendMessage('resetZoom');
	};

	/**
	 * Copies the given cells and XML to the clipboard as an embedded image.
	 */
	EditorUi.prototype.writeImageToClipboard = async function(dataUrl, w, h, type, success, error)
	{
		try
		{
			await requestSync({
				action: 'clipboardAction', 
				method: 'writeImage',
				data: {dataUrl: dataUrl, w: w, h: h}
			});

			if (success != null)
			{
				success();
			}
		}
		catch (e)
		{
			if (error != null)
			{
				error(e);
			}
		}
	};

	/**
	 * Updates action states depending on the selection.
	 */
	var editorUiUpdateActionStates = EditorUi.prototype.updateActionStates;
	EditorUi.prototype.updateActionStates = function()
	{
		editorUiUpdateActionStates.apply(this, arguments);

		var file = this.getCurrentFile();
		var syncEnabled = file != null && file.fileObject != null;
		this.actions.get('synchronize').setEnabled(syncEnabled);
	};
	
	EditorUi.prototype.saveLocalFile = function(data, filename, mimeType, base64Encoded, format, allowBrowser)
	{
		this.saveData(filename, format, data, mimeType, base64Encoded);
	};
	
	EditorUi.prototype.saveRequest = function(filename, format, fn, data, base64Encoded, mimeType)
	{
		var xhr = fn(filename, '1');
		
		if (xhr != null && this.spinner.spin(document.body, mxResources.get('saving')))
		{
			xhr.send(mxUtils.bind(this, function()
			{
				this.spinner.stop();
				
				if (xhr.getStatus() >= 200 && xhr.getStatus() <= 299)
				{
					this.saveData(filename, format, xhr.getText(), mimeType, true);
				}
				else
				{
					this.handleError({message: mxResources.get('errorSavingFile')});
				}
			}), mxUtils.bind(this, function(resp)
			{
				this.spinner.stop();
				this.handleError(resp);
			}));
		}
	};

	function mxElectronRequest(reqType, reqObj)
	{
		this.reqType = reqType;
		this.reqObj = reqObj;
	};

	//Extends mxXmlRequest
	mxUtils.extend(mxElectronRequest, mxXmlRequest);
	
	mxElectronRequest.prototype.send = function(callback, error)
	{
		electron.sendMessage(this.reqType, this.reqObj);
		
		electron.listenOnce(this.reqType + '-success', (data) => 
		{
			this.response = data;
			callback();
			electron.sendMessage(this.reqType + '-finalize');
		})

		electron.listenOnce(this.reqType + '-error', (err) => 
		{
			this.hasError = true;
			error(err);
			electron.sendMessage(this.reqType + '-finalize');
		})
	};
	
	mxElectronRequest.prototype.getStatus = function()
	{
		return this.hasError? 500 : 200; 
	}
	
	mxElectronRequest.prototype.getText = function()
	{
		return this.response;
	}
	
	// Direct export to pdf
	EditorUi.prototype.createDownloadRequest = function(filename, format, ignoreSelection, base64,
		transparent, currentPage, scale, border, grid, includeXml, pageRange, w, h, crop, margin,
		fit, sheetsAcross, sheetsDown, shadows, icons)
	{
		var params = this.downloadRequestBuilder(filename, format, ignoreSelection, base64,
			transparent, currentPage, scale, border, grid, includeXml, pageRange, w, h, crop,
			margin, fit, sheetsAcross, sheetsDown, shadows, icons);

		return new mxElectronRequest('export', params);
	};

	// Renders all pages to PDF with the diagram XML embedded via the local
	// export pipeline, mirroring getEmbeddedPng for PNG files. The optional
	// icons argument adds notes as sticky note annotations.
	EditorUi.prototype.getEmbeddedPdf = function(success, error, icons)
	{
		var req = this.createDownloadRequest(null, 'pdf', true, '0',
			null, false, null, null, false, true, null, null, null,
			null, null, null, null, null, null, icons);

		req.send(function()
		{
			try
			{
				var data = req.getText();

				// The main process replies with the raw PDF bytes
				if (typeof data !== 'string')
				{
					var bytes = (data instanceof ArrayBuffer) ? new Uint8Array(data) : data;
					var result = [];

					for (var i = 0; i < bytes.length; i += 65536)
					{
						result.push(String.fromCharCode.apply(null, bytes.subarray(i, i + 65536)));
					}

					data = result.join('');
				}

				success(data);
			}
			catch (e)
			{
				if (error != null)
				{
					error(e);
				}
			}
		}, error);
	};
	
	var origSetAutosave = Editor.prototype.setAutosave;

	Editor.prototype.setAutosave = function(value)
	{
		autoSaveEnabled = value;
		return origSetAutosave.apply(this, arguments);
	}

	//Export Dialog Pdf case
	var origExportFile = ExportDialog.exportFile;
	
	ExportDialog.exportFile = function(editorUi, name, format, bg, s, b, dpi)
	{
		var graph = editorUi.editor.graph;
		
		if (format == 'xml' || format == 'svg')
		{
			return origExportFile.apply(this, arguments);
		}
		else
		{
			var data = editorUi.getFileData(true, null, null, null, null, true);
    		var bounds = graph.getGraphBounds();
			var w = Math.floor(bounds.width * s / graph.view.scale);
			var h = Math.floor(bounds.height * s / graph.view.scale);
			
			editorUi.hideDialog();
			
			if ((format == 'png' || format == 'jpg' || format == 'jpeg') &&
				editorUi.editor.isExportToCanvas())
			{
				if (format == 'png')
				{
					editorUi.exportImage(s, bg == null || bg == 'none', true,
				   		false, false, b, true, false, null, null, dpi);
				}
				else 
				{
					editorUi.exportImage(s, false, true, false,
						false, b, true, false, 'jpeg');
				}
			}
			else 
			{
				var extras = {globalVars: graph.getExportVariables()};
				
				if (Graph.translateDiagram)
				{
					extras.diagramLanguage = Graph.diagramLanguage;
				}

				editorUi.saveRequest(name, format,
					function(newTitle, base64)
					{
						return new mxElectronRequest('export', {
							format: format,
							xml: data,
							bg: (bg != null) ? bg : mxConstants.NONE,
							filename: (newTitle != null) ? newTitle : null,
							w: w,
							h: h,
							border: b,
							base64: (base64 || '0'),
							extras: JSON.stringify(extras),
							dpi: dpi > 0? dpi : null
						}); 
					});
			}
		}
	};
	
	EditorUi.prototype.saveData = async function(filename, format, data, mimeType, base64Encoded)
	{
		var resume = (this.spinner != null && this.spinner.pause != null) ? this.spinner.pause() : function() {};
		var file = this.getCurrentFile();
		// Defaults to the folder of the current file like saveAs [jgraph/drawio-desktop#2132]
		var lastDir = (file != null && file.fileObject != null && file.fileObject.path != null) ?
			await requestSync({action: 'dirname', path: file.fileObject.path}) :
			localStorage.getItem('.lastExpDir');
		
		// Spinner.stop is asynchronous so we must invoke save dialog asynchronously
		// to give the spinner some time to stop spinning
		window.setTimeout(mxUtils.bind(this, async function()
		{
			var dlgConfig = {
				action: 'showSaveDialog',
				defaultPath: (lastDir || (await requestSync('getDocumentsFolder'))) + '/' + filename
			};
			var filters = null;
			
			switch (format)
			{
				case 'xmlpng':
				case 'png':
					filters = [
				          { name: 'PNG Images', extensions: ['png'] }
				       ];
				break;
				case 'jpg':
				case 'jpeg':
					filters = [
				          { name: 'JPEG Images', extensions: ['jpg', 'jpeg'] }
				       ];
				break;
				case 'svg':
					filters = [
				          { name: 'SVG Images', extensions: ['svg'] }
				       ];
				break;
				case 'pdf':
					filters = [
				          { name: 'PDF Documents', extensions: ['pdf'] }
				       ];
				break;
				case 'vsdx':
					filters = [
				          { name: 'VSDX Documents', extensions: ['vsdx'] }
				       ];
				break;
				case 'html':
					filters = [
				          { name: 'HTML Documents', extensions: ['html'] }
				       ];
				break;
				case 'xml':
					filters = [
				          { name: 'XML Documents', extensions: ['xml'] }
				       ];
				break;
				case 'txt':
					filters = [
				          { name: 'Plain Text', extensions: ['txt'] }
				       ];
				break;
			};
			
			dlgConfig['filters'] = filters;
			//showSaveDialog
			var path = await requestSync(dlgConfig);

	        if (path != null)
	        {
	        	localStorage.setItem('.lastExpDir', await requestSync({action: 'dirname', path: path}));

	        	if (data == null || data.length == 0)
				{
					this.handleError({message: mxResources.get('errorSavingFile')});
				}
				else
				{
					resume();
					
					electron.request({
						action: 'writeFile',
						path: path,
						data: data,
						enc: (base64Encoded) ? 'base64' : 'utf-8'
					}, mxUtils.bind(this, function ()
				    {
						this.spinner.stop();
		        	}), mxUtils.bind(this, function (e)
				    {
						this.spinner.stop();
						this.handleError(e, mxResources.get('errorSavingFile'));
		        	}));
				}
			}
		}), 50);
	};

	EditorUi.prototype.addBeforeUnloadListener = function() {};
	
	EditorUi.prototype.loadDesktopLib = function(libPath, success, error)
	{
		this.readGraphFile(mxUtils.bind(this, function(fileEntry, data, stat)
		{
			try
			{
				// Must not load the library here: the caller (App.loadLibraries)
				// waits for all libraries and loads them in the stored order,
				// an immediate load here would insert them in the random order
				// in which the file reads complete
				success(new DesktopLibrary(this, data, fileEntry));
			}
			catch (e)
			{
				error(e);
			}
		}), error, libPath);
	};

	// Returns the filesystem path for URLs that point to local files
	// (file:// URLs, drive, UNC and absolute paths), null otherwise
	Editor.getLocalFilePath = function(url)
	{
		if (url != null && url.substring(0, 7) == 'file://')
		{
			var path = decodeURIComponent(url.substring(7).split(/[?#]/)[0]);

			// Removes leading slash before Windows drive letters (file:///C:/...)
			return (/^\/[a-zA-Z]:/.test(path)) ? path.substring(1) : path;
		}
		else if (url != null && /^([a-zA-Z]:[\\\/]|[\\\/])/.test(url))
		{
			return url;
		}

		return null;
	};

	// Reads URLs that point to local files via the main process so libraries
	// and templates configured with local paths or file:// URLs work in the
	// desktop app [jgraph/drawio-desktop#1278]
	var editorLoadUrl = Editor.prototype.loadUrl;

	Editor.prototype.loadUrl = function(url, success, error, forceBinary, retry, dataUriPrefix, noBinary, headers)
	{
		try
		{
			var filename = Editor.getLocalFilePath(url);

			if (filename == null)
			{
				editorLoadUrl.apply(this, arguments);
			}
			else
			{
				var binary = !noBinary && (forceBinary || /(\.png)($|\?)/i.test(url) ||
					/(\.jpe?g)($|\?)/i.test(url) || /(\.gif)($|\?)/i.test(url) ||
					/(\.pdf)($|\?)/i.test(url));

				electron.request({action: 'readFile', filename: filename,
					encoding: (binary) ? 'base64' : 'utf-8'}, function(data)
				{
					if (success != null)
					{
						if (binary)
						{
							data = ((dataUriPrefix != null) ? dataUriPrefix :
								'data:image/png;base64,') + data;
						}

						success(data);
					}
				}, function(msg)
				{
					if (error != null)
					{
						error({message: (msg != null) ? msg :
							mxResources.get('fileNotFound')});
					}
				});
			}
		}
		catch (e)
		{
			if (error != null)
			{
				error(e);
			}
		}
	};
})();
