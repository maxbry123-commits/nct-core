import type { PresetBase } from "@/src/preset/preset"
import { registryConfigSchema } from "@/src/schema"
import { z } from "zod"

export const REGISTRY_URL =
  process.env.REGISTRY_URL ?? "https://ui.shadcn.com/r"

export const SHADCN_URL = REGISTRY_URL.replace(/\/r\/?$/, "")

export const FALLBACK_STYLE = "new-york-v4"

export const BASE_COLORS = [
  {
    name: "neutral",
    label: "Neutral",
  },
  {
    name: "zinc",
    label: "Zinc",
  },
  {
    name: "stone",
    label: "Stone",
  },
  {
    name: "mauve",
    label: "Mauve",
  },
  {
    name: "olive",
    label: "Olive",
  },
  {
    name: "mist",
    label: "Mist",
  },
  {
    name: "taupe",
    label: "Taupe",
  },
] as const

// Built-in registries that are always available and cannot be overridden
export const BUILTIN_REGISTRIES: z.infer<typeof registryConfigSchema> = {
  "@shadcn": `${REGISTRY_URL}/styles/{style}/{name}.json`,
}

export const BUILTIN_MODULES = new Set([
  [
    // Node.js built-in modules
    // From https://github.com/sindresorhus/builtin-modules.
    "node:assert",
    "assert",
    "node:assert/strict",
    "assert/strict",
    "node:async_hooks",
    "async_hooks",
    "node:buffer",
    "buffer",
    "node:child_process",
    "child_process",
    "node:cluster",
    "cluster",
    "node:console",
    "console",
    "node:constants",
    "constants",
    "node:crypto",
    "crypto",
    "node:dgram",
    "dgram",
    "node:diagnostics_channel",
    "diagnostics_channel",
    "node:dns",
    "dns",
    "node:dns/promises",
    "dns/promises",
    "node:domain",
    "domain",
    "node:events",
    "events",
    "node:fs",
    "fs",
    "node:fs/promises",
    "fs/promises",
    "node:http",
    "http",
    "node:http2",
    "http2",
    "node:https",
    "https",
    "node:inspector",
    "inspector",
    "node:inspector/promises",
    "inspector/promises",
    "node:module",
    "module",
    "node:net",
    "net",
    "node:os",
    "os",
    "node:path",
    "path",
    "node:path/posix",
    "path/posix",
    "node:path/win32",
    "path/win32",
    "node:perf_hooks",
    "perf_hooks",
    "node:process",
    "process",
    "node:querystring",
    "querystring",
    "node:quic",
    "node:readline",
    "readline",
    "node:readline/promises",
    "readline/promises",
    "node:repl",
    "repl",
    "node:sea",
    "node:sqlite",
    "node:stream",
    "stream",
    "node:stream/consumers",
    "stream/consumers",
    "node:stream/promises",
    "stream/promises",
    "node:stream/web",
    "stream/web",
    "node:string_decoder",
    "string_decoder",
    "node:test",
    "node:test/reporters",
    "node:timers",
    "timers",
    "node:timers/promises",
    "timers/promises",
    "node:tls",
    "tls",
    "node:trace_events",
    "trace_events",
    "node:tty",
    "tty",
    "node:url",
    "url",
    "node:util",
    "util",
    "node:util/types",
    "util/types",
    "node:v8",
    "v8",
    "node:vm",
    "vm",
    "node:wasi",
    "wasi",
    "node:worker_threads",
    "worker_threads",
    "node:zlib",
    "zlib",

    // Bun built-in modules.
    "bun",
    "bun:test",
    "bun:sqlite",
    "bun:ffi",
    "bun:jsc",
    "bun:internal",
  ],
])

type DeprecatedComponent = {
  name: string
  deprecatedBy: string
  message: string
  availableIn?: PresetBase[]
}

export const DEPRECATED_COMPONENTS: DeprecatedComponent[] = [
  {
    name: "toast",
    deprecatedBy: "sonner",
    message:
      "The toast component is only available for Base UI projects. Use the sonner component instead.",
    availableIn: ["base"],
  },
  {
    name: "toaster",
    deprecatedBy: "sonner",
    message:
      "The toaster component is deprecated. Use the sonner component instead.",
  },
]

export const COMPONENTS_HIDDEN_FROM_SELECTION: {
  name: string
  hiddenIn: PresetBase[]
}[] = [
  {
    name: "sonner",
    hiddenIn: ["base"],
  },
]
