export enum ChangeType {
  NEW = 'NEW',
  SOURCE_CODE = 'SOURCE_CODE',
  DEPENDENCY = 'DEPENDENCY',
  ASPECTS = 'ASPECTS',
  API = 'API',
  NONE = 'NONE',
}
