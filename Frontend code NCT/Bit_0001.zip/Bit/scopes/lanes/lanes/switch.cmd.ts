import chalk from 'chalk';
import type { MergeStrategy } from '@teambit/component.modules.merge-helper';
import {
  applyVersionReport,
  installationErrorOutput,
  compilationErrorOutput,
} from '@teambit/component.modules.merge-helper';
import type { Command, CommandOptions } from '@teambit/cli';
import { formatItem, formatSection, formatSuccessSummary, formatDetailsHint, joinSections } from '@teambit/cli';
import { COMPONENT_PATTERN_HELP } from '@teambit/legacy.constants';
import type { LanesMain } from './lanes.main.runtime';

export class SwitchCmd implements Command {
  name = 'switch <lane>';
  description = `switch to the specified lane`;
  extendedDescription = ``;
  private = true;
  group = 'collaborate';
  alias = '';
  arguments = [
    {
      name: 'lane',
      description: 'lane-name or lane-id (if lane is not local) to switch to',
    },
  ];
  options = [
    ['h', 'head', 'DEPRECATED. this is currently the default behavior'],
    [
      '',
      'skip-fetch',
      "don't fetch the latest from the remote; switch to the lane/main state already in the local scope",
    ],
    [
      'r',
      'auto-merge-resolve <merge-strategy>',
      'merge local changes with the checked out version. strategy should be "theirs", "ours" or "manual"',
    ],
    ['', 'force-ours', 'do not merge, preserve local files as is'],
    ['', 'force-theirs', 'do not merge, just overwrite with incoming files'],
    ['a', 'get-all', 'DEPRECATED. this is currently the default behavior'],
    ['', 'workspace-only', 'checkout only the components in the workspace to the selected lane'],
    ['x', 'skip-dependency-installation', 'do not install dependencies of the imported components'],
    [
      'p',
      'pattern <component-pattern>',
      `switch only the lane components matching the specified component-pattern. only works when the workspace is empty\n
${COMPONENT_PATTERN_HELP}`,
    ],
    [
      'n',
      'alias <string>',
      "relevant when the specified lane is a remote lane. create a local alias for the lane (doesn't affect the lane's name on the remote)",
    ],
    ['', 'verbose', 'display detailed information about components that legitimately were not switched'],
    ['j', 'json', 'return the output as JSON'],
    ['', 'branch', 'create and checkout a new git branch named after the lane'],
  ] as CommandOptions;
  loader = true;

  constructor(private lanes: LanesMain) {}

  async report(
    [lane]: [string],
    {
      head,
      skipFetch = false,
      alias,
      autoMergeResolve,
      forceOurs,
      forceTheirs,
      getAll = false,
      workspaceOnly = false,
      skipDependencyInstallation = false,
      pattern,
      verbose,
      json = false,
      branch = false,
    }: {
      head?: boolean;
      skipFetch?: boolean;
      alias?: string;
      autoMergeResolve?: MergeStrategy;
      forceOurs?: boolean;
      forceTheirs?: boolean;
      getAll?: boolean;
      workspaceOnly?: boolean;
      skipDependencyInstallation?: boolean;
      override?: boolean;
      pattern?: string;
      verbose?: boolean;
      json?: boolean;
      branch?: boolean;
    }
  ) {
    const switchResult = await this.lanes.switchLanes(lane, {
      skipFetch,
      alias,
      merge: autoMergeResolve,
      forceOurs,
      forceTheirs,
      workspaceOnly,
      pattern,
      skipDependencyInstallation,
      branch,
    });
    const { components, failedComponents, installationError, compilationError, gitBranchWarning } = switchResult;

    if (getAll) {
      this.lanes.logger.consoleWarning('the --get-all flag is deprecated and currently the default behavior');
    }
    if (head) {
      this.lanes.logger.consoleWarning('the --head flag is deprecated and currently the default behavior');
    }
    if (json) {
      return JSON.stringify({ components, failedComponents }, null, 4);
    }
    const skippedComponents = failedComponents ?? [];
    const hasSkippedComponents = skippedComponents.length > 0 && !verbose;

    const getFailureOutputMinimal = () => {
      if (!hasSkippedComponents) return '';
      return formatDetailsHint(`full list of ${skippedComponents.length} skipped component(s)`);
    };
    const getFailureOutputDetailed = () => {
      if (!skippedComponents.length) return '';
      const items = skippedComponents.map((failedComponent) =>
        formatItem(`${chalk.bold(failedComponent.id.toString())} - ${failedComponent.unchangedMessage}`)
      );
      return formatSection('switch skipped', '', items);
    };
    const getSuccessfulOutput = () => {
      const laneSwitched = formatSuccessSummary(`successfully set "${chalk.bold(lane)}" as the active lane`);
      if (!components || !components.length) return `No components have been changed.\n${laneSwitched}`;
      const target = skipFetch ? `local head of lane ${lane}` : `head of lane ${lane}`;
      const title = `successfully switched ${components.length} components to the ${target}`;
      return [formatSuccessSummary(title), applyVersionReport(components, true, false), laneSwitched]
        .filter(Boolean)
        .join('\n');
    };

    const getGitBranchWarningOutput = () => {
      return gitBranchWarning ? chalk.yellow(`Warning: ${gitBranchWarning}`) : '';
    };

    const buildOutput = (failureOutput: string) =>
      joinSections([
        failureOutput,
        getSuccessfulOutput(),
        getGitBranchWarningOutput(),
        installationErrorOutput(installationError),
        compilationErrorOutput(compilationError),
      ]);

    if (!hasSkippedComponents) {
      return buildOutput(getFailureOutputDetailed());
    }

    const data = buildOutput(getFailureOutputMinimal());
    const details = buildOutput(getFailureOutputDetailed());
    return { data, code: 0, details };
  }
}
