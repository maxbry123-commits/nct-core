import type { Command, CommandOptions } from '@teambit/cli';
import type { WorkspaceDependencyLifecycleType } from '@teambit/dependency-resolver';
import type { Logger } from '@teambit/logger';
import chalk from 'chalk';
import type { Workspace } from '@teambit/workspace';
import { OutsideWorkspaceError } from '@teambit/workspace';
import type { InstallMain, WorkspaceInstallOptions } from './install.main.runtime';
import { extractPackageName, isValidPackageName } from './package-name-utils';

type InstallCmdOptions = {
  type: WorkspaceDependencyLifecycleType;
  skipDedupe: boolean;
  skipImport: boolean;
  skipCompile: boolean;
  skipWriteConfigFiles: boolean;
  update: boolean;
  updateExisting: boolean;
  savePrefix: string;
  addMissingDeps: boolean;
  skipUnavailable: boolean;
  addMissingPeers: boolean;
  noOptional: boolean;
  recurringInstall: boolean;
  lockfileOnly: boolean;
  allowScripts?: string;
  disallowScripts?: string;
};

type FormatOutputArgs = {
  numOfComps: string;
  startTime: number;
  endTime: number;
  oldNonLoadedEnvs: string[];
  recurringInstall: boolean;
};

const recurringInstallFlagName = 'recurring-install';

export default class InstallCmd implements Command {
  name = 'install [packages...]';
  description = 'install workspace dependencies';
  extendedDescription = `installs workspace dependencies and prepares the workspace for development.
when packages are specified, adds them to workspace.jsonc policy and installs. when no packages specified, installs existing dependencies.
automatically imports components, compiles components, links to node_modules, and writes config files.`;
  helpUrl = 'reference/dependencies/dependency-installation';
  arguments = [{ name: 'packages...', description: 'a list of packages to install (separated by spaces)' }];
  alias = 'in';
  group = 'dependencies';
  options = [
    ['t', 'type [lifecycleType]', '"runtime" (default) or "peer" (dev is not a valid option)'],
    ['u', 'update', 'update all dependencies to latest version according to their semver range'],
    [
      '',
      'update-existing',
      'DEPRECATED (not needed anymore, it is the default now). update existing dependencies version and types',
    ],
    ['', 'save-prefix [savePrefix]', 'set the prefix to use when adding dependency to workspace.jsonc'],
    ['', 'skip-dedupe', 'do not dedupe dependencies on installation'],
    ['', 'skip-import', 'do not import bit objects post installation'],
    ['', 'skip-compile', 'do not compile components'],
    ['', 'skip-write-config-files', 'do not write config files (such as eslint, tsconfig, prettier, etc...)'],
    ['a', 'add-missing-deps', 'install all missing dependencies'],
    ['', 'skip-unavailable', 'when adding missing dependencies, skip those that are not found in the registry'],
    ['', 'add-missing-peers', 'install all missing peer dependencies'],
    [
      '',
      recurringInstallFlagName,
      'automatically run install again if there are non loaded old envs in your workspace',
    ],
    ['', 'no-optional [noOptional]', 'do not install optional dependencies (works with pnpm only)'],
    ['', 'lockfile-only', 'dependencies are not written to node_modules. Only the lockfile is updated'],
    [
      '',
      'allow-scripts [pkgNames]',
      'a comma separated list of package names that are allowed to run installation scripts',
    ],
    [
      '',
      'disallow-scripts [pkgNames]',
      'a comma separated list of package names that are NOT allowed to run installation scripts',
    ],
  ] as CommandOptions;

  constructor(
    private install: InstallMain,
    /**
     * workspace extension.
     */
    private workspace: Workspace,

    /**
     * logger extension.
     */
    private logger: Logger
  ) {}

  async report([packages = []]: [string[]], options: InstallCmdOptions) {
    const startTime = Date.now();
    if (!this.workspace) throw new OutsideWorkspaceError();
    if (options.updateExisting) {
      this.logger.consoleWarning(
        `--update-existing is deprecated, please omit it. "bit install" will update existing dependencies by default`
      );
    }

    const validPackages = await Promise.all(
      packages.map(async (pkg) => {
        const pkgName = extractPackageName(pkg);
        if (isValidPackageName(pkgName)) {
          return pkg;
        }
        // if this is a component-id, find the package name and use it instead.
        try {
          // Check if it's not a package name (doesn't start with @)
          if (!pkgName.startsWith('@')) {
            // Try to resolve it as a component ID
            const componentId = await this.workspace.resolveComponentId(pkg);
            // Get the package name for this component
            const component = await this.workspace.get(componentId);
            const componentPackageName = this.workspace.componentPackageName(component);
            return componentPackageName;
          }
        } catch {
          // If component resolution fails, fall through to original error
        }
        throw new Error(`the package name "${pkgName}" is invalid. please provide a valid package name.`);
      })
    );
    this.logger.console(`Resolving component dependencies for workspace: '${chalk.cyan(this.workspace.name)}'`);
    const installOpts: WorkspaceInstallOptions = {
      lifecycleType: options.addMissingPeers ? 'peer' : options.type,
      dedupe: !options.skipDedupe,
      import: !options.skipImport,
      updateExisting: true,
      savePrefix: options.savePrefix,
      addMissingDeps: options.addMissingDeps,
      skipUnavailable: options.skipUnavailable,
      addMissingPeers: options.addMissingPeers,
      compile: !options.skipCompile,
      includeOptionalDeps: !options.noOptional,
      writeConfigFiles: !options.skipWriteConfigFiles,
      updateAll: options.update,
      recurringInstall: options.recurringInstall,
      lockfileOnly: options.lockfileOnly,
      showExternalPackageManagerPrompt: true,
      allowScripts: this._parseAllowScriptsFlags(options.allowScripts, options.disallowScripts),
    };
    const components = await this.install.install(validPackages, installOpts);
    const endTime = Date.now();
    const oldNonLoadedEnvs = this.install.getOldNonLoadedEnvs();
    return formatOutput({
      startTime,
      endTime,
      numOfComps: components.toArray().length.toString(),
      recurringInstall: options[recurringInstallFlagName],
      oldNonLoadedEnvs,
    });
  }

  private _parseAllowScriptsFlags(
    allowScriptsFlag?: string,
    disallowScriptsFlag?: string
  ): Record<string, boolean> | undefined {
    if (!allowScriptsFlag && !disallowScriptsFlag) return undefined;
    const allowScripts: Record<string, boolean> = {};
    if (allowScriptsFlag) {
      for (const pkgName of this._parseCommaSeparatedPkgList(allowScriptsFlag)) {
        allowScripts[pkgName] = true;
      }
    }
    if (disallowScriptsFlag) {
      for (const pkgName of this._parseCommaSeparatedPkgList(disallowScriptsFlag)) {
        allowScripts[pkgName] = false;
      }
    }
    return allowScripts;
  }

  private *_parseCommaSeparatedPkgList(pkgList: string): IterableIterator<string> {
    for (const pkgName of pkgList.split(',')) {
      const trimmed = pkgName.trim();
      if (trimmed) {
        yield trimmed;
      }
    }
  }
}

function calculateTime(startTime: number, endTime: number) {
  const diff = endTime - startTime;
  return diff / 1000;
}

function formatOutput({
  numOfComps,
  endTime,
  startTime,
  recurringInstall,
  oldNonLoadedEnvs,
}: FormatOutputArgs): string {
  const executionTime = calculateTime(startTime, endTime);
  const summary = chalk.green(
    `Successfully installed dependencies and compiled ${chalk.cyan(numOfComps)} component(s) in ${chalk.cyan(
      executionTime.toString()
    )} seconds`
  );
  const anotherInstallRequiredOutput = getAnotherInstallRequiredOutput(recurringInstall, oldNonLoadedEnvs);
  return anotherInstallRequiredOutput ? `\n${anotherInstallRequiredOutput}\n\n${summary}` : `\n${summary}`;
}

export function getAnotherInstallRequiredOutput(recurringInstall = false, oldNonLoadedEnvs: string[] = []): string {
  if (!oldNonLoadedEnvs.length) return '';
  const oldNonLoadedEnvsStr = oldNonLoadedEnvs.join(', ');
  const firstPart = `Bit was not able to install all dependencies. Please run "${chalk.cyan('bit install')}" again `;
  const flag = chalk.cyan(`--${recurringInstallFlagName}`);
  const suggestRecurringInstall = recurringInstall ? '' : `(or use the "${flag}" option next time).`;
  const envsStr = `The following environments need to add support for "dependency policy" to fix the warning: ${chalk.cyan(
    oldNonLoadedEnvsStr
  )}`;
  const docsLink = `Read more about how to fix this issue in: https://bit.dev/blog/using-a-static-dependency-policy-in-a-legacy-env-lihfbt9b`;

  const msg = `${firstPart}${suggestRecurringInstall}\n${envsStr}\n${docsLink}`;
  return chalk.yellow(msg);
}
