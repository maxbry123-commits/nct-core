export const foo = 'hi';
