/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {ActionButton} from '../../src/button/ActionButton';

import AlignCenter from '@spectrum-icons/workflow/AlignCenter';
import AlignLeft from '@spectrum-icons/workflow/AlignLeft';
import AlignRight from '@spectrum-icons/workflow/AlignRight';
import Blower from '@spectrum-icons/workflow/Blower';
import Book from '@spectrum-icons/workflow/Book';
import Copy from '@spectrum-icons/workflow/Copy';
import Cut from '@spectrum-icons/workflow/Cut';
import {Item} from 'react-stately/Item';
import {Keyboard} from '../../src/text/Keyboard';
import {Menu} from '../../src/menu/Menu';
import {MenuTrigger, SpectrumMenuTriggerProps} from '../../src/menu/MenuTrigger';
import {Meta, StoryObj} from '@storybook/react';
import Paste from '@spectrum-icons/workflow/Paste';
import React, {JSX} from 'react';
import {Section} from 'react-stately/Section';
import {Text} from '../../src/text/Text';

const meta: Meta<SpectrumMenuTriggerProps> = {
  title: 'MenuTrigger',
  component: MenuTrigger,
  parameters: {
    chromaticProvider: {
      colorSchemes: ['light'],
      locales: ['en-US'],
      scales: ['medium'],
      disableAnimations: true,
      express: false
    },
    // chromatic needs a bit more time than disableAnimations allows
    chromatic: {pauseAnimationAtEnd: true}
  },
  decorators: [
    Story => (
      <div style={{display: 'flex', width: 'auto', margin: '250px 0'}}>
        <Story />
      </div>
    )
  ]
};

export default meta;

let iconMap = {
  AlignCenter,
  AlignLeft,
  AlignRight,
  Blower,
  Book,
  Copy,
  Cut,
  Paste
};

let hardModeProgrammatic = [
  {
    name: 'Section 1',
    children: [
      {name: 'Copy', icon: 'Copy', shortcut: '⌘C'},
      {name: 'Cut', icon: 'Cut', shortcut: '⌘X'},
      {name: 'Paste', icon: 'Paste', shortcut: '⌘V'}
    ]
  },
  {
    name: 'Section 2',
    children: [
      {name: 'Puppy', icon: 'AlignLeft', shortcut: '⌘P'},
      {name: 'Doggo', icon: 'AlignCenter', shortcut: '⌘D'},
      {name: 'Floof', icon: 'AlignRight', shortcut: '⌘F'},
      {
        name: 'hasChildren',
        children: [
          {name: 'Thailand', icon: 'Blower', shortcut: '⌘T'},
          {name: 'Germany', icon: 'Book', shortcut: '⌘G'}
        ]
      }
    ]
  }
];

let flatMenu = [{name: 'One'}, {name: 'Two'}, {name: 'Three'}, {name: 'Four'}, {name: 'Five'}];

let withSection = [
  {name: 'Animals', children: [{name: 'Aardvark'}, {name: 'Kangaroo'}, {name: 'Snake'}]},
  {
    name: 'People',
    children: [
      {name: 'Danni'},
      {name: 'Devon'},
      {name: 'Ross', children: [{name: 'Tests', children: [{name: 'blah'}]}]}
    ]
  }
];

let withArabic = [
  {name: 'نسخ', icon: 'Copy', shortcut: '⌘C'},
  {name: 'قص', icon: 'Cut', shortcut: '⌘X'},
  {name: 'لصق', icon: 'Paste', shortcut: '⌘V'}
];

const Template = (args: SpectrumMenuTriggerProps): JSX.Element => (
  <MenuTrigger {...args} isOpen>
    <ActionButton>Menu Button</ActionButton>
    <Menu
      items={flatMenu}
      disabledKeys={['One', 'Three']}
      selectedKeys={['Two', 'Five']}
      selectionMode="multiple">
      {item => <Item key={item.name}>{item.name}</Item>}
    </Menu>
  </MenuTrigger>
);

const TemplateWithSections = (args: SpectrumMenuTriggerProps): JSX.Element => (
  <MenuTrigger {...args} isOpen>
    <ActionButton>Menu Button</ActionButton>
    <Menu
      items={withSection}
      disabledKeys={['Snake', 'Ross']}
      selectedKeys={['Aardvark', 'Devon']}
      selectionMode="multiple">
      {(item: any) => (
        <Section key={item.name} items={item.children} title={item.name}>
          {(item: any) => (
            <Item key={item.name} childItems={item.children}>
              {item.name}
            </Item>
          )}
        </Section>
      )}
    </Menu>
  </MenuTrigger>
);

const customMenuItem = (item): JSX.Element => {
  let Icon = iconMap[item.icon];
  return (
    <Item childItems={item.children} textValue={item.name} key={item.name}>
      {item.icon && <Icon />}
      <Text>{item.name}</Text>
      {item.shortcut && <Keyboard>{item.shortcut}</Keyboard>}
    </Item>
  );
};

const TemplateWithIcons = (args: SpectrumMenuTriggerProps): JSX.Element => (
  <MenuTrigger {...args} isOpen>
    <ActionButton>Menu Button</ActionButton>
    <Menu
      items={hardModeProgrammatic}
      disabledKeys={['Cut', 'Doggo']}
      selectedKeys={['Floof', 'Copy']}
      selectionMode="multiple">
      {item => (
        <Section key={item.name} items={item.children} title={item.name}>
          {item => customMenuItem(item)}
        </Section>
      )}
    </Menu>
  </MenuTrigger>
);

const TemplateArabicWithIcons = (args: SpectrumMenuTriggerProps): JSX.Element => (
  <MenuTrigger {...args} isOpen>
    <ActionButton>Menu Button</ActionButton>
    <Menu items={withArabic}>{item => customMenuItem(item)}</Menu>
  </MenuTrigger>
);

export type MenuTriggerStory = StoryObj<typeof Template>;

export const Default: MenuTriggerStory = {
  render: args => <Template {...args} />,
  name: 'flat list'
};

export const WithSections: MenuTriggerStory = {
  render: args => <TemplateWithSections {...args} />,
  name: 'with sections'
};

export const Complex: MenuTriggerStory = {
  render: args => <TemplateWithIcons {...args} />,
  name: 'complex items'
};

export const AlignEnd: MenuTriggerStory = {
  render: args => <Template {...args} />,
  name: 'align="end"',
  args: {align: 'end'}
};

export const DirectionTop: MenuTriggerStory = {
  render: args => <Template {...args} />,
  name: 'direction="top"',
  args: {direction: 'top'}
};

export const DirectionBottom: MenuTriggerStory = {
  render: args => <Template {...args} />,
  name: 'direction="bottom"',
  args: {direction: 'bottom'}
};

export const DirectionStart: MenuTriggerStory = {
  render: args => <Template {...args} />,
  name: 'direction="start"',
  args: {direction: 'start'}
};

export const DirectionStartEnd: MenuTriggerStory = {
  render: args => <Template {...args} />,
  name: 'direction="start", align="end"',
  args: {direction: 'start', align: 'end'}
};

export const DirectionEnd: MenuTriggerStory = {
  render: args => <Template {...args} />,
  name: 'direction="end"',
  args: {direction: 'end'}
};

export const DirectionEndEnd: MenuTriggerStory = {
  render: args => <Template {...args} />,
  name: 'direction="end" align="end"',
  args: {direction: 'end', align: 'end'}
};

export const DirectionLeft: MenuTriggerStory = {
  render: args => <Template {...args} />,
  name: 'direction="left"',
  args: {direction: 'left'}
};

export const DirectionLeftEnd: MenuTriggerStory = {
  render: args => <Template {...args} />,
  name: 'direction="left", align="end"',
  args: {direction: 'left', align: 'end'}
};

export const DirectionRight: MenuTriggerStory = {
  render: args => <Template {...args} />,
  name: 'direction="right"',
  args: {direction: 'right'}
};

export const DirectionRightEnd: MenuTriggerStory = {
  render: args => <Template {...args} />,
  name: 'direction="right", align="end"',
  args: {direction: 'right', align: 'end'}
};

export const ArabicComplex: MenuTriggerStory = {
  render: args => <TemplateArabicWithIcons {...args} />,
  name: 'Arabic complex items'
};
