/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {AriaBaseButtonProps, ButtonProps, useButton} from 'react-aria/useButton';

import {classNames} from '../utils/classNames';
import {ClearSlots, SlotProvider, useSlotProps} from '../utils/Slots';
import CornerTriangle from '@spectrum-icons/ui/CornerTriangle';
import {FocusableRef, StyleProps} from '@react-types/shared';
import {FocusRing} from 'react-aria/FocusRing';
import {mergeProps} from 'react-aria/mergeProps';
import React from 'react';
import styles from '@adobe/spectrum-css-temp/components/button/vars.css';
import {Text} from '../text/Text';
import {useFocusableRef} from '../utils/useDOMRef';
import {useHover} from 'react-aria/useHover';
import {useProviderProps} from '../provider/Provider';
import {useStyleProps} from '../utils/styleProps';

export interface SpectrumActionButtonProps
  extends AriaBaseButtonProps, Omit<ButtonProps, 'onClick'>, StyleProps {
  /**
   * Whether the button should be displayed with a [quiet
   * style](https://spectrum.adobe.com/page/action-button/#Quiet).
   */
  isQuiet?: boolean;
  /** The static color style to apply. Useful when the button appears over a color background. */
  staticColor?: 'white' | 'black';
}

/**
 * ActionButtons allow users to perform an action. They’re used for similar, task-based options
 * within a workflow, and are ideal for interfaces where buttons aren’t meant to draw a lot of
 * attention.
 */
export const ActionButton = React.forwardRef(function ActionButton(
  props: SpectrumActionButtonProps,
  ref: FocusableRef<HTMLButtonElement>
) {
  props = useProviderProps(props);
  props = useSlotProps(props, 'actionButton');
  let textProps = useSlotProps(
    {UNSAFE_className: classNames(styles, 'spectrum-ActionButton-label')},
    'text'
  );

  let {
    isQuiet,
    isDisabled,
    staticColor,
    children,
    autoFocus,
    // @ts-ignore (private)
    holdAffordance,
    // @ts-ignore (private)
    hideButtonText,
    ...otherProps
  } = props;

  let domRef = useFocusableRef(ref);
  let {buttonProps, isPressed} = useButton(props, domRef);
  let {hoverProps, isHovered} = useHover({isDisabled});
  let {styleProps} = useStyleProps(otherProps);
  let isTextOnly = React.Children.toArray(props.children).every(c => !React.isValidElement(c));

  return (
    <FocusRing focusRingClass={classNames(styles, 'focus-ring')} autoFocus={autoFocus}>
      <button
        {...styleProps}
        {...mergeProps(buttonProps, hoverProps)}
        ref={domRef}
        className={classNames(
          styles,
          'spectrum-ActionButton',
          {
            'spectrum-ActionButton--quiet': isQuiet,
            'spectrum-ActionButton--staticColor': !!staticColor,
            'spectrum-ActionButton--staticWhite': staticColor === 'white',
            'spectrum-ActionButton--staticBlack': staticColor === 'black',
            'is-active': isPressed,
            'is-disabled': isDisabled,
            'is-hovered': isHovered
          },
          styleProps.className
        )}>
        {holdAffordance && (
          <CornerTriangle UNSAFE_className={classNames(styles, 'spectrum-ActionButton-hold')} />
        )}
        <ClearSlots>
          <SlotProvider
            slots={{
              icon: {
                size: 'S',
                UNSAFE_className: classNames(styles, 'spectrum-Icon', {
                  'spectrum-ActionGroup-itemIcon': hideButtonText
                })
              },
              text: {
                ...textProps
              }
            }}>
            {typeof children === 'string' || isTextOnly ? <Text>{children}</Text> : children}
          </SlotProvider>
        </ClearSlots>
      </button>
    </FocusRing>
  );
});
