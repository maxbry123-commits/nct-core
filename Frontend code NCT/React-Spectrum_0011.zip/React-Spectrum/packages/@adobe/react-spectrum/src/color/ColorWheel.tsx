/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {AriaColorWheelProps, useColorWheel} from 'react-aria/useColorWheel';

import {classNames} from '../utils/classNames';
import {ColorThumb} from './ColorThumb';
import {ColorWheelContext} from 'react-aria-components/ColorWheel';
import {dimensionValue, useStyleProps} from '../utils/styleProps';
import {DimensionValue, FocusableRef, StyleProps} from '@react-types/shared';
import React, {useCallback, useRef, useState} from 'react';
import styles from '@adobe/spectrum-css-temp/components/colorwheel/vars.css';
import {useColorWheelState} from 'react-stately/useColorWheelState';
import {useContextProps} from 'react-aria-components/slots';
import {useFocusableRef} from '../utils/useDOMRef';
import {useFocusRing} from 'react-aria/useFocusRing';
import {useLayoutEffect} from 'react-aria/private/utils/useLayoutEffect';
import {useProviderProps} from '../provider/Provider';
import {useResizeObserver} from 'react-aria/private/utils/useResizeObserver';

export interface SpectrumColorWheelProps
  extends AriaColorWheelProps, Omit<StyleProps, 'width' | 'height'> {
  /** The outer diameter of the ColorWheel. */
  size?: DimensionValue;
}

const WHEEL_THICKNESS = 24;

/**
 * ColorWheels allow users to adjust the hue of an HSL or HSB color value on a circular track.
 */
export const ColorWheel = React.forwardRef(function ColorWheel(
  props: SpectrumColorWheelProps,
  ref: FocusableRef<HTMLDivElement>
) {
  props = useProviderProps(props);
  let inputRef = useRef(null);
  let containerRef = useFocusableRef(ref, inputRef);
  [props, containerRef] = useContextProps(props, containerRef, ColorWheelContext);

  let {isDisabled} = props;
  let size = props.size && dimensionValue(props.size);
  let {styleProps} = useStyleProps(props);

  let [wheelRadius, setWheelRadius] = useState<number>(0);
  let [wheelThickness, setWheelThickness] = useState(WHEEL_THICKNESS);

  // oxlint-disable-next-line react/react-compiler
  let resizeHandler = useCallback(() => {
    if (containerRef.current) {
      setWheelRadius(containerRef.current.offsetWidth / 2);
      let thickness = window
        .getComputedStyle(containerRef.current)
        .getPropertyValue('--spectrum-colorwheel-track-thickness');
      if (thickness) {
        setWheelThickness(parseInt(thickness, 10));
      }
    }
  }, [containerRef, setWheelRadius, setWheelThickness]);

  useLayoutEffect(() => {
    // the size observer's fallback to the window resize event doesn't fire on mount
    if (wheelRadius === 0) {
      resizeHandler();
    }
  }, [wheelRadius, resizeHandler]);

  useResizeObserver({
    ref: containerRef,
    onResize: resizeHandler
  });

  let state = useColorWheelState(props);

  let {trackProps, inputProps, thumbProps} = useColorWheel(
    {
      ...props,
      innerRadius: wheelRadius - wheelThickness,
      outerRadius: wheelRadius
    },
    state,
    inputRef
  );

  let {focusProps, isFocusVisible} = useFocusRing();

  return (
    <div
      className={classNames(
        styles,
        'spectrum-ColorWheel',
        {
          'is-disabled': isDisabled
        },
        styleProps.className
      )}
      ref={containerRef}
      style={{
        ...styleProps.style,
        // Workaround around https://github.com/adobe/spectrum-css/issues/1032
        width: size,
        height: size
      }}>
      <div {...trackProps} className={classNames(styles, 'spectrum-ColorWheel-gradient')} />
      <ColorThumb
        value={state.getDisplayColor()}
        isFocused={isFocusVisible}
        isDisabled={isDisabled}
        isDragging={state.isDragging}
        containerRef={containerRef}
        className={classNames(styles, 'spectrum-ColorWheel-handle')}
        {...thumbProps}>
        <input
          {...focusProps}
          className={classNames(styles, 'spectrum-ColorWheel-slider')}
          {...inputProps}
          ref={inputRef}
        />
      </ColorThumb>
    </div>
  );
});
