/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import AlertMedium from '@spectrum-icons/ui/AlertMedium';
import {AriaLabelingProps, DOMProps, DOMRef, StyleProps} from '@react-types/shared';
import {Button, SpectrumButtonProps} from '../button/Button';
import {ButtonGroup} from '../buttongroup/ButtonGroup';
import {chain} from 'react-aria/chain';
import {classNames} from '../utils/classNames';
import {Content} from '../view/Content';
import {Dialog} from './Dialog';
import {DialogContext, DialogContextValue} from './context';
import {Divider} from '../divider/Divider';
import {filterDOMProps} from 'react-aria/filterDOMProps';
import {Heading} from '../text/Heading';
import intlMessages from '../../intl/dialog/*.json';
import React, {forwardRef, ReactNode, useContext} from 'react';
import styles from '@adobe/spectrum-css-temp/components/dialog/vars.css';
import {useLocalizedStringFormatter} from 'react-aria/useLocalizedStringFormatter';
import {useStyleProps} from '../utils/styleProps';

export interface SpectrumAlertDialogProps extends AriaLabelingProps, DOMProps, StyleProps {
  /** The [visual style](https://spectrum.adobe.com/page/alert-dialog/#Options) of the AlertDialog. */
  variant?: 'confirmation' | 'information' | 'destructive' | 'error' | 'warning';
  /** The title of the AlertDialog. */
  title: string;
  /** The contents of the AlertDialog. */
  children: ReactNode;
  /** The label to display within the cancel button. */
  cancelLabel?: string;
  /** The label to display within the confirm button. */
  primaryActionLabel: string;
  /** The label to display within the secondary button. */
  secondaryActionLabel?: string;
  /** Whether the primary button is disabled. */
  isPrimaryActionDisabled?: boolean;
  /** Whether the secondary button is disabled. */
  isSecondaryActionDisabled?: boolean;
  /** Handler that is called when the cancel button is pressed. */
  onCancel?: () => void;
  /** Handler that is called when the primary button is pressed. */
  onPrimaryAction?: () => void;
  /** Handler that is called when the secondary button is pressed. */
  onSecondaryAction?: () => void;
  /** Button to focus by default when the dialog opens. */
  autoFocusButton?: 'cancel' | 'primary' | 'secondary';
  // allowsKeyboardConfirmation?: boolean, // triggers primary action
}

/**
 * AlertDialogs are a specific type of Dialog. They display important information that users need to
 * acknowledge.
 */
export const AlertDialog = forwardRef(function AlertDialog(
  props: SpectrumAlertDialogProps,
  ref: DOMRef
) {
  let {onClose = () => {}} = useContext(DialogContext) || ({} as DialogContextValue);

  let {
    variant,
    children,
    primaryActionLabel,
    secondaryActionLabel,
    cancelLabel,
    autoFocusButton,
    title,
    isPrimaryActionDisabled,
    isSecondaryActionDisabled,
    onCancel = () => {},
    onPrimaryAction = () => {},
    onSecondaryAction = () => {},
    ...otherProps
  } = props;
  let {styleProps} = useStyleProps(otherProps);
  let stringFormatter = useLocalizedStringFormatter(intlMessages, '@react-spectrum/dialog');

  let confirmVariant: SpectrumButtonProps['variant'] = 'primary';
  if (variant) {
    if (variant === 'confirmation') {
      confirmVariant = 'cta';
    } else if (variant === 'destructive') {
      confirmVariant = 'negative';
    }
  }

  return (
    <Dialog
      UNSAFE_style={styleProps.style}
      UNSAFE_className={classNames(
        styles,
        {[`spectrum-Dialog--${variant}`]: variant},
        styleProps.className
      )}
      isHidden={styleProps.hidden}
      size="M"
      role="alertdialog"
      ref={ref}
      {...filterDOMProps(props, {labelable: true})}>
      <Heading>{title}</Heading>
      {(variant === 'error' || variant === 'warning') && (
        <AlertMedium slot="typeIcon" aria-label={stringFormatter.format('alert')} />
      )}
      <Divider />
      <Content>{children}</Content>
      <ButtonGroup align="end">
        {cancelLabel && (
          <Button
            variant="secondary"
            onPress={() => chain(onClose(), onCancel())}
            autoFocus={autoFocusButton === 'cancel'}
            data-testid="rsp-AlertDialog-cancelButton">
            {cancelLabel}
          </Button>
        )}
        {secondaryActionLabel && (
          <Button
            variant="secondary"
            onPress={() => chain(onClose(), onSecondaryAction())}
            isDisabled={isSecondaryActionDisabled}
            autoFocus={autoFocusButton === 'secondary'}
            data-testid="rsp-AlertDialog-secondaryButton">
            {secondaryActionLabel}
          </Button>
        )}
        <Button
          variant={confirmVariant}
          onPress={() => chain(onClose(), onPrimaryAction())}
          isDisabled={isPrimaryActionDisabled}
          autoFocus={autoFocusButton === 'primary'}
          data-testid="rsp-AlertDialog-confirmButton">
          {primaryActionLabel}
        </Button>
      </ButtonGroup>
    </Dialog>
  );
});
