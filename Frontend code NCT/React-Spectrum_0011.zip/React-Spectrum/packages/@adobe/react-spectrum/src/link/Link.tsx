/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {AriaLinkProps, useLink} from 'react-aria/useLink';

import {classNames} from '../utils/classNames';
import {FocusRing} from 'react-aria/FocusRing';
import {getWrappedElement} from '../utils/getWrappedElement';
import {mergeProps} from 'react-aria/mergeProps';
import {mergeRefs} from 'react-aria/mergeRefs';
import React, {ForwardedRef, JSX, MutableRefObject, ReactNode, useRef} from 'react';
import {StyleProps} from '@react-types/shared';
import styles from '@adobe/spectrum-css-temp/components/link/vars.css';
import {useHover} from 'react-aria/useHover';
import {useProviderProps} from '../provider/Provider';
import {useSlotProps} from '../utils/Slots';
import {useStyleProps} from '../utils/styleProps';

export interface SpectrumLinkProps extends Omit<AriaLinkProps, 'onClick'>, StyleProps {
  /** The content to display in the link. */
  children: ReactNode;
  /**
   * The [visual style](https://spectrum.adobe.com/page/link/#Options) of the link.
   *
   * @default 'primary'
   */
  variant?: 'primary' | 'secondary' | 'overBackground';
  /** Whether the link should be displayed with a quiet style. */
  isQuiet?: boolean;
}

let isOldReact = parseInt(React.version, 10) <= 18;
/**
 * Links allow users to navigate to a different location.
 * They can be presented inline inside a paragraph or as standalone text.
 */
export function Link(props: SpectrumLinkProps): JSX.Element {
  props = useProviderProps(props);
  props = useSlotProps(props, 'link');
  let {
    variant = 'primary',
    isQuiet,
    children,
    // @ts-ignore
    href
  } = props;
  let {styleProps} = useStyleProps(props);
  let {hoverProps, isHovered} = useHover({});

  let ref = useRef(null);
  let {linkProps} = useLink(
    {
      ...props,
      elementType: !href && typeof children === 'string' ? 'span' : 'a'
    },
    ref
  );

  let domProps = {
    ...styleProps,
    ...mergeProps(linkProps, hoverProps),
    ref,
    className: classNames(
      styles,
      'spectrum-Link',
      {
        'spectrum-Link--quiet': isQuiet,
        [`spectrum-Link--${variant}`]: variant,
        'is-hovered': isHovered
      },
      styleProps.className
    )
  };

  let link: JSX.Element;
  if (href) {
    link = <a {...domProps}>{children}</a>;
  } else {
    // Backward compatibility.
    let wrappedChild = getWrappedElement(children);
    let mergedRef: MutableRefObject<any> | ForwardedRef<any> = ref;
    if (isOldReact) {
      // @ts-ignore
      // oxlint-disable-next-line react/react-compiler
      mergedRef = mergeRefs(ref, wrappedChild.ref);
    } else {
      // @ts-ignore
      // oxlint-disable-next-line react/react-compiler
      mergedRef = mergeRefs(ref, wrappedChild.props.ref);
    }
    link = React.cloneElement(wrappedChild, {
      // oxlint-disable-next-line react/react-compiler
      ...mergeProps(wrappedChild.props, domProps),
      // @ts-ignore https://github.com/facebook/react/issues/8873
      ref: mergedRef
    });
  }

  return <FocusRing focusRingClass={classNames(styles, 'focus-ring')}>{link}</FocusRing>;
}
