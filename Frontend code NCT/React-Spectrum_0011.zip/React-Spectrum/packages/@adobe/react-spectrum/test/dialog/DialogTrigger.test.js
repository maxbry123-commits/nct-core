/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {
  act,
  fireEvent,
  pointerMap,
  render,
  simulateDesktop,
  simulateMobile,
  User,
  waitFor,
  within
} from '@react-spectrum/test-utils-internal';
import {ActionButton} from '../../src/button/ActionButton';
import {Button} from '../../src/button/Button';
import {ButtonGroup} from '../../src/buttongroup/ButtonGroup';
import {Content} from '../../src/view/Content';
import {Dialog} from '../../src/dialog/Dialog';
import {DialogTrigger} from '../../src/dialog/DialogTrigger';
import {Item} from 'react-stately/Item';
import {Menu} from '../../src/menu/Menu';
import {MenuTrigger} from '../../src/menu/MenuTrigger';
import {Provider} from '../../src/provider/Provider';
import React from 'react';
import {TextField} from '../../src/textfield/TextField';
import {defaultTheme as theme} from '../../src/theme-default/defaultTheme';
import {UNSAFE_PortalProvider} from 'react-aria/PortalProvider';
import userEvent from '@testing-library/user-event';

describe('DialogTrigger', function () {
  let warnMock;
  let user;
  let testUtilUser = new User({advanceTimer: jest.advanceTimersByTime});

  beforeAll(() => {
    user = userEvent.setup({delay: null, pointerMap});
    jest.useFakeTimers();
  });

  beforeEach(() => {
    simulateDesktop();
    if (process.env.STRICT_MODE) {
      warnMock = jest.spyOn(global.console, 'warn').mockImplementation();
    }
  });

  afterEach(() => {
    // Ensure we close any dialogs before unmounting to avoid warning.
    let dialog = document.querySelector('[role="dialog"]');
    if (dialog) {
      fireEvent.keyDown(dialog, {key: 'Escape'});
      fireEvent.keyUp(dialog, {key: 'Escape'});
      act(() => {
        jest.runAllTimers();
      });
    }

    if (process.env.STRICT_MODE && warnMock.mock.calls.length > 0) {
      expect(warnMock).toHaveBeenCalledTimes(1);
      expect(warnMock).toHaveBeenCalledWith(
        'A DialogTrigger unmounted while open. This is likely due to being placed within a trigger that unmounts or inside a conditional. Consider using a DialogContainer instead.'
      );
      warnMock.mockRestore();
    }
  });

  it('should trigger a modal by default', async function () {
    let {queryByRole, getByRole, getByTestId} = render(
      <Provider theme={theme}>
        <DialogTrigger>
          <ActionButton>Trigger</ActionButton>
          <Dialog aria-label="Test dialog">contents</Dialog>
        </DialogTrigger>
      </Provider>
    );

    expect(queryByRole('dialog')).toBeNull();

    let button = getByRole('button');
    let dialogTester = testUtilUser.createTester('Dialog', {root: button, overlayType: 'modal'});
    await dialogTester.open();
    let dialog = dialogTester.getDialog();
    expect(dialog).toBeVisible();

    let modal = getByTestId('modal');
    expect(modal).toBeVisible();
  });

  it('should trigger a tray', async function () {
    let {getByRole, queryByRole, getByTestId} = render(
      <Provider theme={theme}>
        <DialogTrigger type="tray">
          <ActionButton>Trigger</ActionButton>
          <Dialog aria-label="Test dialog">contents</Dialog>
        </DialogTrigger>
      </Provider>
    );

    expect(queryByRole('dialog')).toBeNull();

    let button = getByRole('button');
    await user.click(button);

    act(() => {
      jest.runAllTimers();
    });

    let dialog = getByRole('dialog');
    expect(dialog).toBeVisible();

    let tray = getByTestId('tray');
    expect(tray).toBeVisible();
  });

  it('should trigger a popover', async function () {
    let {getByRole, queryByRole, getByTestId} = render(
      <Provider theme={theme}>
        <DialogTrigger type="popover">
          <ActionButton>Trigger</ActionButton>
          <Dialog aria-label="Test dialog">contents</Dialog>
        </DialogTrigger>
      </Provider>
    );

    expect(queryByRole('dialog')).toBeNull();

    let button = getByRole('button');
    let dialogTester = testUtilUser.createTester('Dialog', {root: button, overlayType: 'popover'});
    await dialogTester.open();
    let dialog = dialogTester.getDialog();
    expect(dialog).toBeVisible();

    let popover = getByTestId('popover');
    expect(popover).toBeVisible();
    expect(popover).toHaveAttribute('style');
  });

  it('popovers should be closeable', async function () {
    let {getByRole, getByText, queryByRole} = render(
      <Provider theme={theme}>
        <DialogTrigger type="popover">
          <ActionButton>Trigger</ActionButton>
          {close => (
            <Dialog aria-label="Test dialog">
              contents
              <ButtonGroup>
                <Button variant="secondary" onPress={close}>
                  Cancel
                </Button>
              </ButtonGroup>
            </Dialog>
          )}
        </DialogTrigger>
      </Provider>
    );

    let triggerButton = getByRole('button');
    await user.click(triggerButton);

    act(() => {
      jest.runAllTimers();
    });

    let dialog = getByRole('dialog');
    expect(dialog).toBeVisible();

    let cancelButton = getByText('Cancel');
    await user.click(cancelButton);

    act(() => {
      jest.runAllTimers();
    });

    dialog = queryByRole('dialog');
    expect(dialog).toBeNull();
  });

  it('should trigger a modal instead of a popover on mobile', async function () {
    simulateMobile();
    let {getByRole, queryByRole, getByTestId} = render(
      <Provider theme={theme}>
        <DialogTrigger type="popover">
          <ActionButton>Trigger</ActionButton>
          <Dialog aria-label="Test dialog">contents</Dialog>
        </DialogTrigger>
      </Provider>
    );

    expect(queryByRole('dialog')).toBeNull();

    let button = getByRole('button');
    await user.click(button);

    act(() => {
      jest.runAllTimers();
    });

    let dialog = getByRole('dialog');
    expect(dialog).toBeVisible();

    let modal = getByTestId('modal');
    expect(modal).toBeVisible();
  });

  it('should trigger a tray instead of a popover on mobile if mobileType="tray"', async function () {
    simulateMobile();
    let {getByRole, queryByRole, getByTestId} = render(
      <Provider theme={theme}>
        <DialogTrigger type="popover" mobileType="tray">
          <ActionButton>Trigger</ActionButton>
          <Dialog aria-label="Test dialog">contents</Dialog>
        </DialogTrigger>
      </Provider>
    );

    expect(queryByRole('dialog')).toBeNull();

    let button = getByRole('button');
    await user.click(button);

    act(() => {
      jest.runAllTimers();
    });

    let dialog = getByRole('dialog');
    expect(dialog).toBeVisible();

    let tray = getByTestId('tray');
    expect(tray).toBeVisible();
  });

  it.each(['modal', 'popover', 'tray'])(
    'contains focus within the dialog when rendered as a %s',
    async function (type) {
      let {getByRole, getByTestId} = render(
        <Provider theme={theme}>
          <DialogTrigger type={type}>
            <ActionButton>Trigger</ActionButton>
            <Dialog aria-label="Test dialog">
              <input data-testid="input1" />
              <input data-testid="input2" />
            </Dialog>
          </DialogTrigger>
        </Provider>
      );

      let button = getByRole('button');
      await user.click(button);

      act(() => {
        jest.runAllTimers();
      });

      let dialog = getByRole('dialog');
      let input1 = getByTestId('input1');
      let input2 = getByTestId('input2');
      expect(document.activeElement).toBe(dialog);

      fireEvent.keyDown(document.activeElement, {key: 'Tab'});
      expect(document.activeElement).toBe(input1);

      fireEvent.keyDown(document.activeElement, {key: 'Tab'});
      expect(document.activeElement).toBe(input2);

      fireEvent.keyDown(document.activeElement, {key: 'Tab'});
      expect(document.activeElement).toBe(input1);
    }
  );

  it('should restore focus to the trigger when the dialog is closed', async function () {
    let {getByRole} = render(
      <Provider theme={theme}>
        <DialogTrigger>
          <ActionButton>Trigger</ActionButton>
          <Dialog aria-label="Test dialog">contents</Dialog>
        </DialogTrigger>
      </Provider>
    );

    let button = getByRole('button');
    let dialogTester = testUtilUser.createTester('Dialog', {root: button, overlayType: 'modal'});
    await dialogTester.open();
    let dialog = dialogTester.getDialog();
    expect(document.activeElement).toBe(dialog);
    await dialogTester.close();
    // now that it's been unmounted, run the raf callback
    act(() => {
      jest.runAllTimers();
    });
    expect(document.activeElement).toBe(button);
  });

  it('should restore focus to the trigger when the dialog is closed from a hidden dismiss button', async function () {
    let {getByRole, getAllByRole} = render(
      <Provider theme={theme}>
        <DialogTrigger type="popover">
          <ActionButton>Trigger</ActionButton>
          <Dialog aria-label="Test dialog">contents</Dialog>
        </DialogTrigger>
      </Provider>
    );

    let button = getByRole('button');
    await user.click(button);

    act(() => {
      jest.runAllTimers();
    });

    let dialog = getByRole('dialog');

    await waitFor(() => {
      expect(dialog).toBeVisible();
    }); // wait for animation

    expect(document.activeElement).toBe(dialog);

    let dismiss = getAllByRole('button')[0];
    await user.click(dismiss);

    act(() => {
      jest.runAllTimers();
    });

    await waitFor(() => {
      expect(dialog).not.toBeInTheDocument();
    }); // wait for animation

    // now that it's been unmounted, run the raf callback
    act(() => {
      jest.runAllTimers();
    });

    expect(document.activeElement).toBe(button);
  });

  it('popovers should be closeable by clicking their trigger while they are open', async function () {
    let onOpenChange = jest.fn();
    let {getByRole} = render(
      <Provider theme={theme}>
        <DialogTrigger onOpenChange={onOpenChange} type="popover">
          <ActionButton>Trigger</ActionButton>
          <Dialog aria-label="Test dialog">contents</Dialog>
        </DialogTrigger>
      </Provider>
    );

    let button = getByRole('button');
    await user.click(button);

    act(() => {
      jest.runAllTimers();
    });

    let dialog = getByRole('dialog');

    await waitFor(() => {
      expect(dialog).toBeVisible();
    }); // wait for animation

    expect(document.activeElement).toBe(dialog);
    expect(onOpenChange).toHaveBeenCalledTimes(1);

    await user.click(button);

    act(() => {
      jest.runAllTimers();
    });

    await waitFor(() => {
      expect(dialog).not.toBeInTheDocument();
    }); // wait for animation

    // now that it's been unmounted, run the raf callback
    act(() => {
      jest.runAllTimers();
    });

    expect(document.activeElement).toBe(button);
    expect(onOpenChange).toHaveBeenCalledTimes(2);
  });

  it('should set aria-hidden on parent providers on mount and remove on unmount', async function () {
    let rootProviderRef = React.createRef();
    let {getByRole} = render(
      <Provider theme={theme} ref={rootProviderRef}>
        <DialogTrigger>
          <ActionButton>Trigger</ActionButton>
          <Dialog aria-label="Test dialog">contents</Dialog>
        </DialogTrigger>
      </Provider>
    );

    expect(
      rootProviderRef.current.UNSAFE_getDOMNode().closest('[aria-hidden=true]')
    ).not.toBeInTheDocument();

    let button = getByRole('button');
    await user.click(button);

    act(() => {
      jest.runAllTimers();
    });

    await waitFor(() => {
      expect(getByRole('dialog')).toBeVisible();
    }); // wait for animation

    expect(
      rootProviderRef.current.UNSAFE_getDOMNode().closest('[aria-hidden=true]')
    ).toBeInTheDocument();

    let dialog = getByRole('dialog');
    fireEvent.keyDown(dialog, {key: 'Escape'});
    fireEvent.keyUp(dialog, {key: 'Escape'});

    act(() => {
      jest.runAllTimers();
    });
    await waitFor(() => {
      expect(dialog).not.toBeInTheDocument();
    }); // wait for animation

    expect(
      rootProviderRef.current.UNSAFE_getDOMNode().closest('[aria-hidden=true]')
    ).not.toBeInTheDocument();
  });

  it('can be controlled', async function () {
    function Test({isOpen, onOpenChange}) {
      return (
        <Provider theme={theme}>
          <DialogTrigger isOpen={isOpen} onOpenChange={onOpenChange}>
            <ActionButton>Trigger</ActionButton>
            <Dialog aria-label="Test dialog">contents</Dialog>
          </DialogTrigger>
        </Provider>
      );
    }

    let onOpenChange = jest.fn();
    let {getByRole, queryByRole, rerender} = render(
      <Test isOpen={false} onOpenChange={onOpenChange} />
    );

    expect(queryByRole('dialog')).toBeNull();

    let button = getByRole('button');
    await user.click(button);

    act(() => {
      jest.runAllTimers();
    });

    expect(queryByRole('dialog')).toBeNull();
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(true);

    rerender(<Test isOpen onOpenChange={onOpenChange} />);

    act(() => {
      jest.runAllTimers();
    });
    let dialog = getByRole('dialog');
    await waitFor(() => {
      expect(dialog).toBeVisible();
    }); // wait for animation

    fireEvent.keyDown(dialog, {key: 'Escape'});
    fireEvent.keyUp(dialog, {key: 'Escape'});

    act(() => {
      jest.runAllTimers();
    });
    expect(dialog).toBeVisible();
    expect(onOpenChange).toHaveBeenCalledTimes(2);
    expect(onOpenChange).toHaveBeenCalledWith(false);

    rerender(<Test isOpen={false} onOpenChange={onOpenChange} />);

    act(() => {
      jest.runAllTimers();
    });
    await waitFor(() => {
      expect(dialog).not.toBeInTheDocument();
    }); // wait for animation
  });

  it('can be uncontrolled with defaultOpen', async function () {
    function Test({defaultOpen, onOpenChange}) {
      return (
        <Provider theme={theme}>
          <DialogTrigger defaultOpen={defaultOpen} onOpenChange={onOpenChange}>
            <ActionButton>Trigger</ActionButton>
            <Dialog aria-label="Test dialog">contents</Dialog>
          </DialogTrigger>
        </Provider>
      );
    }

    let onOpenChange = jest.fn();
    let {getByRole} = render(<Test defaultOpen onOpenChange={onOpenChange} />);

    act(() => {
      jest.runAllTimers();
    });

    let dialog = getByRole('dialog');
    await waitFor(() => {
      expect(dialog).toBeVisible();
    }); // wait for animation

    fireEvent.keyDown(dialog, {key: 'Escape'});
    fireEvent.keyUp(dialog, {key: 'Escape'});

    act(() => {
      jest.runAllTimers();
    });
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);

    await waitFor(() => {
      expect(dialog).not.toBeInTheDocument();
    }); // wait for animation
  });

  it('can be closed by buttons the user adds', async function () {
    function Test({defaultOpen, onOpenChange}) {
      return (
        <Provider theme={theme}>
          <DialogTrigger defaultOpen={defaultOpen} onOpenChange={onOpenChange}>
            <ActionButton>Trigger</ActionButton>
            {close => (
              <Dialog aria-label="Test dialog">
                contents
                <Button variant="primary" data-testid="closebtn" onPress={close}>
                  Close
                </Button>
              </Dialog>
            )}
          </DialogTrigger>
        </Provider>
      );
    }

    let onOpenChange = jest.fn();
    let {getByRole, getByTestId} = render(<Test defaultOpen onOpenChange={onOpenChange} />);

    act(() => {
      jest.runAllTimers();
    });

    let dialog = getByRole('dialog');
    let closeBtn = getByTestId('closebtn');
    await waitFor(() => {
      expect(dialog).toBeVisible();
    }); // wait for animation

    await user.click(closeBtn);
    expect(dialog).toBeVisible();
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);

    act(() => {
      jest.runAllTimers();
    });

    await waitFor(() => {
      expect(dialog).not.toBeInTheDocument();
    }); // wait for animation
  });

  it('can be closed by dismiss button in dialog', async function () {
    function Test({defaultOpen, onOpenChange}) {
      return (
        <Provider theme={theme}>
          <DialogTrigger isDismissable defaultOpen={defaultOpen} onOpenChange={onOpenChange}>
            <ActionButton>Trigger</ActionButton>
            <Dialog aria-label="Test dialog">contents</Dialog>
          </DialogTrigger>
        </Provider>
      );
    }

    let onOpenChange = jest.fn();
    let {getByRole, getByLabelText} = render(<Test defaultOpen onOpenChange={onOpenChange} />);

    act(() => {
      jest.runAllTimers();
    });

    let dialog = getByRole('dialog');
    await waitFor(() => {
      expect(dialog).toBeVisible();
    }); // wait for animation

    let closeButton = getByLabelText('Dismiss');
    await user.click(closeButton);
    expect(dialog).toBeVisible();
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);

    act(() => {
      jest.runAllTimers();
    });

    await waitFor(() => {
      expect(dialog).not.toBeInTheDocument();
    }); // wait for animation
  });

  it('dismissable modals can be closed by clicking outside the dialog', async function () {
    function Test({defaultOpen, onOpenChange}) {
      return (
        <Provider theme={theme}>
          <DialogTrigger
            type="modal"
            isDismissable
            defaultOpen={defaultOpen}
            onOpenChange={onOpenChange}>
            <ActionButton>Trigger</ActionButton>
            <Dialog aria-label="Test dialog">contents</Dialog>
          </DialogTrigger>
        </Provider>
      );
    }

    let onOpenChange = jest.fn();
    let {getByRole} = render(<Test defaultOpen onOpenChange={onOpenChange} />);

    act(() => {
      jest.runAllTimers();
    });

    let dialog = getByRole('dialog');
    await waitFor(() => {
      expect(dialog).toBeVisible();
    }); // wait for animation

    await user.click(document.body);
    expect(dialog).toBeVisible();
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);

    act(() => {
      jest.runAllTimers();
    });

    await waitFor(() => {
      expect(dialog).not.toBeInTheDocument();
    }); // wait for animation
  });

  it('non dismissable modals cannot be closed by clicking outside the dialog', async function () {
    function Test({defaultOpen, onOpenChange}) {
      return (
        <Provider theme={theme}>
          <DialogTrigger type="modal" defaultOpen={defaultOpen} onOpenChange={onOpenChange}>
            <ActionButton>Trigger</ActionButton>
            <Dialog aria-label="Test dialog">contents</Dialog>
          </DialogTrigger>
        </Provider>
      );
    }

    let onOpenChange = jest.fn();
    let {getByRole} = render(<Test defaultOpen onOpenChange={onOpenChange} />);

    act(() => {
      jest.runAllTimers();
    });

    let dialog = getByRole('dialog');
    await waitFor(() => {
      expect(dialog).toBeVisible();
    }); // wait for animation

    await user.click(document.body);
    act(() => {
      jest.runAllTimers();
    });
    expect(dialog).toBeVisible();
    expect(onOpenChange).toHaveBeenCalledTimes(0);
  });

  it('mobile type modals should be closable by clicking outside the modal', async function () {
    simulateMobile();
    function Test({defaultOpen, onOpenChange}) {
      return (
        <Provider theme={theme}>
          <DialogTrigger
            type="popover"
            mobileType="modal"
            defaultOpen={defaultOpen}
            onOpenChange={onOpenChange}>
            <ActionButton>Trigger</ActionButton>
            <Dialog aria-label="Test dialog">contents</Dialog>
          </DialogTrigger>
        </Provider>
      );
    }

    let onOpenChange = jest.fn();
    let {getByTestId} = render(<Test defaultOpen onOpenChange={onOpenChange} />);

    act(() => {
      jest.runAllTimers();
    });

    let modal = getByTestId('modal');
    await waitFor(() => {
      expect(modal).toBeVisible();
    }); // wait for animation

    await user.click(document.body);
    expect(modal).toBeVisible();
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);

    act(() => {
      jest.runAllTimers();
    });

    await waitFor(() => {
      expect(modal).not.toBeInTheDocument();
    }); // wait for animation
  });

  it('non-modals can be closed by clicking outside the dialog regardless of isDismissable', async function () {
    function Test({defaultOpen, onOpenChange}) {
      return (
        <Provider theme={theme}>
          <DialogTrigger
            type="popover"
            defaultOpen={defaultOpen}
            onOpenChange={onOpenChange}
            isDismissable={false}>
            <ActionButton>Trigger</ActionButton>
            <Dialog aria-label="Test dialog">contents</Dialog>
          </DialogTrigger>
        </Provider>
      );
    }

    let onOpenChange = jest.fn();
    let {getByRole} = render(<Test defaultOpen onOpenChange={onOpenChange} />);

    act(() => {
      jest.runAllTimers();
    });

    let dialog = getByRole('dialog');
    expect(dialog).toBeVisible();
    await waitFor(() => {
      expect(dialog).toBeVisible();
    }); // wait for animation
    await user.click(document.body);
    expect(dialog).toBeVisible();
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    expect(onOpenChange).toHaveBeenCalledWith(false);

    act(() => {
      jest.runAllTimers();
    });

    await waitFor(() => {
      expect(dialog).not.toBeInTheDocument();
    }); // wait for animation
  });

  it('disable closing dialog via escape key', async function () {
    let {queryByRole, getByRole} = render(
      <Provider theme={theme}>
        <DialogTrigger isKeyboardDismissDisabled>
          <ActionButton>Trigger</ActionButton>
          {close => (
            <Dialog aria-label="Test dialog">
              <ActionButton onPress={close}>Close</ActionButton>
            </Dialog>
          )}
        </DialogTrigger>
      </Provider>
    );

    let button = getByRole('button');
    await user.click(button);

    act(() => {
      jest.runAllTimers();
    });

    let dialog = getByRole('dialog');

    await waitFor(() => {
      expect(dialog).toBeVisible();
    }); // wait for animation

    expect(document.activeElement).toBe(dialog);

    fireEvent.keyDown(dialog, {key: 'Escape'});
    fireEvent.keyUp(dialog, {key: 'Escape'});

    act(() => {
      jest.runAllTimers();
    });

    await waitFor(() => {
      expect(dialog).toBeInTheDocument();
    }); // wait for animation

    expect(document.activeElement).toBe(dialog);

    // Close the dialog by clicking the button inside
    button = within(dialog).getByRole('button');
    await user.click(button);
    act(() => {
      jest.runAllTimers();
    });

    expect(queryByRole('dialog')).toBeNull();
  });

  it('should warn when unmounting a dialog trigger while a modal is open', async function () {
    using warn = jest.spyOn(console, 'warn').mockImplementation(() => {});
    let {getByRole, queryByRole} = render(
      <Provider theme={theme}>
        <MenuTrigger>
          <ActionButton>Trigger</ActionButton>
          <Menu>
            <DialogTrigger isKeyboardDismissDisabled>
              <Item>Open menu</Item>
              <Dialog aria-label="Test dialog">Content body</Dialog>
            </DialogTrigger>
          </Menu>
        </MenuTrigger>
      </Provider>
    );

    let button = getByRole('button');

    await user.click(button);
    act(() => {
      jest.runAllTimers();
    });

    let menu = getByRole('menu');
    let menuitem = within(menu).getByRole('menuitem');

    await user.click(menuitem);
    act(() => {
      jest.runAllTimers();
    });

    expect(queryByRole('menu')).toBeNull();
    expect(queryByRole('menuitem')).toBeNull();
    expect(queryByRole('dialog')).toBeNull();

    expect(warn).toHaveBeenCalledTimes(1);
    expect(warn).toHaveBeenCalledWith(
      'A DialogTrigger unmounted while open. This is likely due to being placed within a trigger that unmounts or inside a conditional. Consider using a DialogContainer instead.'
    );
  });

  it('should not try to restore focus to the outer dialog when the inner dialog opens', async () => {
    let {getByRole} = render(
      <Provider theme={theme}>
        <TextField id="document-input" aria-label="document input" />
        <DialogTrigger>
          <ActionButton id="outer-trigger">Trigger</ActionButton>
          <Dialog aria-label="Test dialog" id="outer-dialog">
            <Content>
              <TextField id="outer-input" aria-label="outer input" autoFocus />
              <DialogTrigger>
                <ActionButton id="inner-trigger">Trigger</ActionButton>
                <Dialog aria-label="Test dialog" id="inner-dialog">
                  <Content>
                    <TextField id="inner-input" aria-label="outer input" autoFocus />
                  </Content>
                </Dialog>
              </DialogTrigger>
            </Content>
          </Dialog>
        </DialogTrigger>
      </Provider>
    );
    let button = getByRole('button');
    await user.click(button);

    act(() => {
      jest.runAllTimers();
    });

    let outerDialog = getByRole('dialog');

    await waitFor(() => {
      expect(outerDialog).toBeVisible();
    }); // wait for animation
    let outerButton = getByRole('button');
    let outerInput = getByRole('textbox');

    expect(document.activeElement).toBe(outerInput);
    await user.click(outerButton);

    act(() => {
      jest.runAllTimers();
    });

    let innerDialog = getByRole('dialog');

    await waitFor(() => {
      expect(innerDialog).toBeVisible();
    }); // wait for animation

    let innerInput = getByRole('textbox');

    expect(document.activeElement).toBe(innerInput);

    await user.click(document.body);

    act(() => {
      jest.runAllTimers();
    });

    expect(document.activeElement).toBe(innerInput);

    let outsideInput = document.getElementById('document-input');
    act(() => {
      outsideInput.focus();
    });
    act(() => {
      jest.runAllTimers();
    });
    expect(document.activeElement).toBe(innerInput);
  });

  it('input in nested popover should be interactive with a click', async () => {
    let {getByRole, getByText, getByLabelText} = render(
      <Provider theme={theme}>
        <TextField id="document-input" aria-label="document input" />
        <DialogTrigger type="popover">
          <ActionButton id="outer-trigger">Trigger1</ActionButton>
          <Dialog aria-label="Test dialog" id="outer-dialog">
            <Content>
              <TextField id="outer-input" aria-label="outer input" />
              <DialogTrigger type="popover">
                <ActionButton id="inner-trigger">Trigger2</ActionButton>
                <Dialog aria-label="Test dialog" id="inner-dialog">
                  <Content>
                    <TextField id="inner-input" label="inner input" />
                  </Content>
                </Dialog>
              </DialogTrigger>
            </Content>
          </Dialog>
        </DialogTrigger>
      </Provider>
    );
    let button = getByRole('button');
    await user.click(button);

    act(() => {
      jest.runAllTimers();
    });

    let outerDialog = getByRole('dialog');

    await waitFor(() => {
      expect(outerDialog).toBeVisible();
    }); // wait for animation
    let outerButton = getByText('Trigger2');

    await user.click(outerButton);

    act(() => {
      jest.runAllTimers();
    });

    let innerDialog = getByRole('dialog');

    await waitFor(() => {
      expect(innerDialog).toBeVisible();
    }); // wait for animation

    let innerInput = getByLabelText('inner input');
    expect(getByLabelText('inner input')).toBeVisible();
    await user.click(innerInput);

    expect(document.activeElement).toBe(innerInput);
  });

  describe('portalContainer', () => {
    function InfoDialog(props) {
      let {container} = props;
      return (
        <Provider theme={theme}>
          <UNSAFE_PortalProvider getContainer={() => container.current}>
            <DialogTrigger type={props.type}>
              <ActionButton>Trigger</ActionButton>
              <Dialog aria-label="Test dialog">contents</Dialog>
            </DialogTrigger>
          </UNSAFE_PortalProvider>
        </Provider>
      );
    }
    function App(props) {
      let container = React.useRef(null);
      return (
        <>
          <InfoDialog type={props.type} container={container} />
          <div ref={container} data-testid="custom-container" />
        </>
      );
    }

    it('should render the dialog in the portal container', async () => {
      let {getByRole, getByTestId} = render(<App />);

      let button = getByRole('button');
      await user.click(button);

      expect(getByRole('dialog').closest('[data-testid="custom-container"]')).toBe(
        getByTestId('custom-container')
      );
    });

    it('should render the tray in the portal container', async () => {
      let {getByRole, getByTestId} = render(<App type="tray" />);

      let button = getByRole('button');
      await user.click(button);

      expect(getByRole('dialog').closest('[data-testid="custom-container"]')).toBe(
        getByTestId('custom-container')
      );
    });

    it('should render the popover in the portal container', async () => {
      let {getByRole, getByTestId} = render(<App type="popover" />);

      let button = getByRole('button');
      await user.click(button);

      expect(getByRole('dialog').closest('[data-testid="custom-container"]')).toBe(
        getByTestId('custom-container')
      );
    });
  });
});
