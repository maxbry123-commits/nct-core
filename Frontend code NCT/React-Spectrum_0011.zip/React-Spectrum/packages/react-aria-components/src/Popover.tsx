/*
 * Copyright 2022 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {
  AriaLabelingProps,
  forwardRefType,
  GlobalDOMAttributes,
  RefObject
} from '@react-types/shared';
import {AriaPopoverProps, usePopover} from 'react-aria/usePopover';
import {
  ClassNameOrFunction,
  ContextValue,
  dom,
  RenderProps,
  SlotProps,
  useContextProps,
  useRenderProps
} from './utils';
import {DismissButton, Overlay} from 'react-aria/Overlay';
import {filterDOMProps} from 'react-aria/filterDOMProps';
import {focusSafely} from 'react-aria/private/interactions/focusSafely';
import {getInteractionModality} from 'react-aria/private/interactions/useFocusVisible';
import {isFocusWithin} from 'react-aria/private/utils/shadowdom/DOMFunctions';
import {mergeProps} from 'react-aria/mergeProps';
import {OverlayArrowContext} from './OverlayArrow';
import {
  OverlayTriggerProps,
  OverlayTriggerState,
  useOverlayTriggerState
} from 'react-stately/useOverlayTriggerState';
import {OverlayTriggerStateContext} from './Dialog';
import {PlacementAxis, PositionProps} from 'react-aria/useOverlayPosition';
import React, {
  Context,
  createContext,
  ForwardedRef,
  forwardRef,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState
} from 'react';
import {useEnterAnimation, useExitAnimation} from 'react-aria/private/utils/animation';
import {useIsHidden} from 'react-aria/private/collections/Hidden';
import {useLayoutEffect} from 'react-aria/private/utils/useLayoutEffect';
import {useLocale} from 'react-aria/I18nProvider';
import {useResizeObserver} from 'react-aria/private/utils/useResizeObserver';

export interface PopoverProps
  extends
    Omit<PositionProps, 'isOpen'>,
    Omit<AriaPopoverProps, 'popoverRef' | 'triggerRef' | 'groupRef' | 'offset' | 'arrowSize'>,
    OverlayTriggerProps,
    RenderProps<PopoverRenderProps>,
    SlotProps,
    AriaLabelingProps,
    GlobalDOMAttributes<HTMLDivElement> {
  /**
   * The CSS [className](https://developer.mozilla.org/en-US/docs/Web/API/Element/className) for the
   * element. A function may be provided to compute the class based on component state.
   *
   * @default 'react-aria-Popover'
   */
  className?: ClassNameOrFunction<PopoverRenderProps>;
  /**
   * The name of the component that triggered the popover. This is reflected on the element
   * as the `data-trigger` attribute, and can be used to provide specific
   * styles for the popover depending on which element triggered it.
   */
  trigger?: string;
  /**
   * The ref for the element which the popover positions itself with respect to.
   *
   * When used within a trigger component such as DialogTrigger, MenuTrigger, Select, etc.,
   * this is set automatically. It is only required when used standalone.
   */
  triggerRef?: RefObject<Element | null>;
  /**
   * Whether the popover is currently performing an entry animation.
   */
  isEntering?: boolean;
  /**
   * Whether the popover is currently performing an exit animation.
   */
  isExiting?: boolean;
  /**
   * Whether the popover should appear and disappear without an entry or exit animation. This is
   * used by components such as PreviewTrigger to skip animations when quickly swapping between
   * overlays.
   */
  shouldSkipAnimation?: boolean;
  /**
   * The container element in which the overlay portal will be placed. This may have unknown
   * behavior depending on where it is portalled to.
   *
   * @deprecated - Use a parent UNSAFE_PortalProvider to set your portal container instead.
   * @default document.body
   */
  UNSTABLE_portalContainer?: Element;
  /**
   * The additional offset applied along the main axis between the element and its
   * anchor element.
   *
   * @default 8
   */
  offset?: number;
}

export interface PopoverRenderProps {
  /**
   * The name of the component that triggered the popover, e.g. "DialogTrigger" or "ComboBox".
   *
   * @selector [data-trigger="..."]
   */
  trigger: string | null;
  /**
   * The placement of the popover relative to the trigger.
   *
   * @selector [data-placement="left | right | top | bottom"]
   */
  placement: PlacementAxis | null;
  /**
   * Whether the popover is currently entering. Use this to apply animations.
   *
   * @selector [data-entering]
   */
  isEntering: boolean;
  /**
   * Whether the popover is currently exiting. Use this to apply animations.
   *
   * @selector [data-exiting]
   */
  isExiting: boolean;
}

interface PopoverContextValue extends PopoverProps {
  id?: string;
  /** Contexts to clear. */
  clearContexts?: Context<any>[];
}

export const PopoverContext = createContext<ContextValue<PopoverContextValue, HTMLElement>>(null);

// Stores a ref for the portal container for a group of popovers (e.g. submenus).
const PopoverGroupContext = createContext<RefObject<Element | null> | null>(null);

/**
 * A popover is an overlay element positioned relative to a trigger.
 */
export const Popover = /*#__PURE__*/ (forwardRef as forwardRefType)(function Popover(
  props: PopoverProps,
  ref: ForwardedRef<HTMLElement>
) {
  [props, ref] = useContextProps(props, ref, PopoverContext);
  let contextState = useContext(OverlayTriggerStateContext);
  let localState = useOverlayTriggerState(props);
  let state =
    props.isOpen != null || props.defaultOpen != null || !contextState ? localState : contextState;
  // Skip the automatic exit animation when closing instantly (e.g. swapping between previews
  // during warmup). An explicitly provided isExiting prop still takes precedence.
  let exitAnimation = useExitAnimation(ref, state.isOpen);
  let isExiting = props.isExiting || (!props.shouldSkipAnimation && exitAnimation) || false;
  let isHidden = useIsHidden();
  let {direction} = useLocale();

  // If we are in a hidden tree, we still need to preserve our children.
  if (isHidden) {
    let children = props.children;
    if (typeof children === 'function') {
      children = children({
        trigger: props.trigger || null,
        placement: 'bottom',
        isEntering: false,
        isExiting: false,
        defaultChildren: null
      });
    }

    return <>{children}</>;
  }

  if (state && !state.isOpen && !isExiting) {
    return null;
  }

  return (
    <PopoverInner
      {...props}
      triggerRef={props.triggerRef!}
      state={state}
      popoverRef={ref}
      isExiting={isExiting}
      dir={direction}
    />
  );
});

interface PopoverInnerProps extends AriaPopoverProps, RenderProps<PopoverRenderProps>, SlotProps {
  state: OverlayTriggerState;
  isEntering?: boolean;
  isExiting: boolean;
  shouldSkipAnimation?: boolean;
  UNSTABLE_portalContainer?: Element;
  trigger?: string;
  dir?: 'ltr' | 'rtl';
  clearContexts?: Context<any>[];
  id?: string;
}

function PopoverInner({
  state,
  isExiting,
  UNSTABLE_portalContainer,
  clearContexts,
  ...props
}: PopoverInnerProps) {
  // Calculate the arrow size internally (and remove props.arrowSize from PopoverProps)
  // Referenced from: packages/@react-spectrum/tooltip/src/TooltipTrigger.tsx
  let arrowRef = useRef<HTMLDivElement>(null);
  let containerRef = useRef<HTMLDivElement | null>(null);
  let groupCtx = useContext(PopoverGroupContext);
  let isSubPopover = groupCtx && props.trigger === 'SubmenuTrigger';

  let {popoverProps, underlayProps, arrowProps, placement, triggerAnchorPoint} = usePopover(
    {
      ...props,
      offset: props.offset ?? 8,
      arrowRef,
      // If this is a submenu/subdialog, use the root popover's container
      // to detect outside interaction and add aria-hidden.
      groupRef: isSubPopover ? groupCtx! : containerRef
    },
    state
  );

  let ref = props.popoverRef as RefObject<HTMLDivElement | null>;
  // Skip the automatic entry animation when opening instantly (e.g. swapping between previews
  // during warmup). An explicitly provided isEntering prop still takes precedence.
  let enterAnimation = useEnterAnimation(ref, !!placement);
  // oxlint-disable-next-line react/react-compiler
  let isEntering = props.isEntering || (!props.shouldSkipAnimation && enterAnimation) || false;
  // oxlint-disable-next-line react/react-compiler
  let renderProps = useRenderProps({
    // oxlint-disable-next-line react/react-compiler
    ...props,
    defaultClassName: 'react-aria-Popover',
    // oxlint-disable-next-line react/react-compiler
    values: {
      // oxlint-disable-next-line react/react-compiler
      trigger: props.trigger || null,
      placement,
      // oxlint-disable-next-line react/react-compiler
      isEntering,
      isExiting
    }
  });

  // Automatically render Popover with role=dialog except when isNonModal is true,
  // or a dialog is already nested inside the popover.
  let shouldBeDialog =
    // oxlint-disable-next-line react/react-compiler
    !props.isNonModal || props.trigger === 'SubmenuTrigger' || props.trigger === 'PreviewTrigger';
  // oxlint-disable-next-line react/react-compiler
  let [isDialog, setDialog] = useState(props.trigger === 'PreviewTrigger');
  useLayoutEffect(() => {
    if (ref.current) {
      setDialog(shouldBeDialog && !ref.current.querySelector('[role=dialog]'));
    }
  }, [ref, shouldBeDialog]);

  // Focus the popover itself on mount, unless a child element is already focused.
  // Skip this for submenus since hovering a submenutrigger should keep focus on the trigger
  // oxlint-disable react/react-compiler
  useEffect(() => {
    if (
      isDialog &&
      props.trigger !== 'PreviewTrigger' &&
      (props.trigger !== 'SubmenuTrigger' || getInteractionModality() !== 'pointer') &&
      ref.current &&
      !isFocusWithin(ref.current)
    ) {
      focusSafely(ref.current);
    }
  }, [isDialog, ref, props.trigger]);
  // oxlint-enable react/react-compiler

  let children = useMemo(() => {
    let children = renderProps.children;
    if (clearContexts) {
      for (let Context of clearContexts) {
        children = <Context.Provider value={null}>{children}</Context.Provider>;
      }
    }
    return children;
  }, [renderProps.children, clearContexts]);

  let [triggerWidth, setTriggerWidth] = useState<string | null>(null);
  // oxlint-disable-next-line react/react-compiler
  let onResize = useCallback(() => {
    if (props.triggerRef.current) {
      setTriggerWidth(props.triggerRef.current.getBoundingClientRect().width + 'px');
    }
  }, [props.triggerRef]);

  useLayoutEffect(onResize, [onResize]);
  // oxlint-disable-next-line react/react-compiler
  useResizeObserver({
    // oxlint-disable-next-line react/react-compiler
    ref: renderProps.style?.['--trigger-width'] ? undefined : props.triggerRef,
    onResize: onResize
  });

  let style = {
    ...popoverProps.style,
    '--trigger-anchor-point': triggerAnchorPoint
      ? `${triggerAnchorPoint.x}px ${triggerAnchorPoint.y}px`
      : undefined,
    ...renderProps.style,
    '--trigger-width': renderProps.style?.['--trigger-width'] || triggerWidth
  };

  // oxlint-disable react/react-compiler
  let overlay = (
    <dom.div
      {...mergeProps(filterDOMProps(props, {global: true}), popoverProps)}
      {...renderProps}
      id={isDialog ? props.id : undefined}
      role={isDialog ? 'dialog' : undefined}
      tabIndex={isDialog ? -1 : undefined}
      aria-label={props['aria-label']}
      aria-labelledby={props['aria-labelledby']}
      ref={ref}
      slot={props.slot || undefined}
      style={style}
      dir={props.dir}
      data-trigger={props.trigger}
      data-placement={placement}
      data-entering={isEntering || undefined}
      data-exiting={isExiting || undefined}>
      {/* oxlint-disable-next-line react/react-compiler */}
      {!props.isNonModal && <DismissButton onDismiss={state.close} />}
      <OverlayArrowContext.Provider value={{...arrowProps, placement, ref: arrowRef}}>
        {children}
      </OverlayArrowContext.Provider>
      <DismissButton onDismiss={state.close} />
    </dom.div>
  );
  // oxlint-enable react/react-compiler

  // If this is a root popover, render an extra div to act as the portal container for submenus/subdialogs.
  if (!isSubPopover) {
    // oxlint-disable react/react-compiler
    return (
      <Overlay
        {...props}
        shouldContainFocus={isDialog && props.trigger !== 'PreviewTrigger'}
        isExiting={isExiting}
        portalContainer={UNSTABLE_portalContainer}>
        {/* oxlint-disable-next-line react/react-compiler */}
        {!props.isNonModal && state.isOpen && (
          <div data-testid="underlay" {...underlayProps} style={{position: 'fixed', inset: 0}} />
        )}
        <div ref={containerRef} style={{display: 'contents'}}>
          <PopoverGroupContext.Provider value={containerRef}>
            {overlay}
          </PopoverGroupContext.Provider>
        </div>
      </Overlay>
    );
    // oxlint-enable react/react-compiler
  }

  // Submenus/subdialogs are mounted into the root popover's container.
  // oxlint-disable react/react-compiler
  return (
    <Overlay
      {...props}
      shouldContainFocus={isDialog && props.trigger !== 'PreviewTrigger'}
      isExiting={isExiting}
      portalContainer={UNSTABLE_portalContainer ?? groupCtx?.current ?? undefined}>
      {overlay}
    </Overlay>
  );
  // oxlint-enable react/react-compiler
}
