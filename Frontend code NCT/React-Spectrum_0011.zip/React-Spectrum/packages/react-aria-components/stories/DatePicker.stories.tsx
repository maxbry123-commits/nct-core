/*
 * Copyright 2022 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {action} from 'storybook/actions';
import {Button} from '../src/Button';
import {Calendar, CalendarCell, CalendarGrid, RangeCalendar} from '../src/Calendar';
import clsx from 'clsx';
import {DateInput, DateSegment} from '../src/DateField';
import {DatePicker, DateRangePicker} from '../src/DatePicker';
import {Dialog} from '../src/Dialog';
import {Form} from '../src/Form';
import {Group} from '../src/Group';
import {Heading} from '../src/Heading';
import {Input} from '../src/Input';
import {Label} from '../src/Label';
import {Meta, StoryFn} from '@storybook/react';
import {parseAbsoluteToLocal} from '@internationalized/date';
import {Popover} from '../src/Popover';
import React from 'react';
import styles from '../example/index.css';
import {TextField} from '../src/TextField';
import './styles.css';

export default {
  title: 'React Aria Components/DatePicker',
  component: DatePicker,
  argTypes: {
    onChange: {
      table: {
        disable: true
      }
    },
    granularity: {
      control: 'select',
      options: ['day', 'hour', 'minute', 'second']
    },
    isRequired: {
      control: 'boolean'
    },
    isInvalid: {
      control: 'boolean'
    },
    isDisabled: {
      control: 'boolean'
    },
    isReadOnly: {
      control: 'boolean'
    },
    validationBehavior: {
      control: 'select',
      options: ['native', 'aria']
    }
  }
} as Meta<typeof DatePicker>;

export type DatePickerStory = StoryFn<typeof DatePicker>;
export type DateRangePickerStory = StoryFn<typeof DateRangePicker>;

export const DatePickerExample: DatePickerStory = args => (
  <DatePicker data-testid="date-picker-example" {...args}>
    <Label style={{display: 'block'}}>Date</Label>
    <Group style={{display: 'inline-flex'}}>
      <DateInput className={styles.field}>
        {segment => (
          <DateSegment
            segment={segment}
            className={clsx(styles.segment, {[styles.placeholder]: segment.isPlaceholder})}
          />
        )}
      </DateInput>
      <Button>🗓</Button>
    </Group>
    <Popover
      placement="bottom start"
      style={{
        background: 'Canvas',
        color: 'CanvasText',
        border: '1px solid gray',
        padding: 20
      }}>
      <Dialog>
        <Calendar style={{width: 220}}>
          <div style={{display: 'flex', alignItems: 'center'}}>
            <Button slot="previous">&lt;</Button>
            <Heading style={{flex: 1, textAlign: 'center'}} />
            <Button slot="next">&gt;</Button>
          </div>
          <CalendarGrid style={{width: '100%'}}>
            {date => (
              <CalendarCell
                date={date}
                style={({isSelected, isOutsideMonth}) => ({
                  display: isOutsideMonth ? 'none' : '',
                  textAlign: 'center',
                  cursor: 'default',
                  background: isSelected ? 'blue' : ''
                })}
              />
            )}
          </CalendarGrid>
        </Calendar>
      </Dialog>
    </Popover>
  </DatePicker>
);

export const DatePickerTriggerWidthExample: DatePickerStory = args => (
  <DatePicker data-testid="date-picker-example" {...args}>
    <Label style={{display: 'block'}}>Date</Label>
    <Group style={{display: 'inline-flex', width: 300}}>
      <DateInput className={styles.field} style={{flex: 1}}>
        {segment => (
          <DateSegment
            segment={segment}
            className={clsx(styles.segment, {[styles.placeholder]: segment.isPlaceholder})}
          />
        )}
      </DateInput>
      <Button>🗓</Button>
    </Group>
    <Popover
      placement="bottom start"
      style={{
        background: 'Canvas',
        color: 'CanvasText',
        border: '1px solid gray',
        padding: 20,
        boxSizing: 'border-box',
        width: 'var(--trigger-width)'
      }}>
      <Dialog>
        <Calendar>
          <div style={{display: 'flex', alignItems: 'center'}}>
            <Button slot="previous">&lt;</Button>
            <Heading style={{flex: 1, textAlign: 'center'}} />
            <Button slot="next">&gt;</Button>
          </div>
          <CalendarGrid style={{width: '100%'}}>
            {date => (
              <CalendarCell
                date={date}
                style={({isSelected, isOutsideMonth}) => ({
                  display: isOutsideMonth ? 'none' : '',
                  textAlign: 'center',
                  cursor: 'default',
                  background: isSelected ? 'blue' : ''
                })}
              />
            )}
          </CalendarGrid>
        </Calendar>
      </Dialog>
    </Popover>
  </DatePicker>
);

export const DateRangePickerExample: DateRangePickerStory = args => (
  <DateRangePicker data-testid="date-range-picker-example" {...args}>
    <Label style={{display: 'block'}}>Date</Label>
    <Group style={{display: 'inline-flex'}}>
      <div className={styles.field}>
        <DateInput
          data-testid="date-range-picker-date-input"
          slot="start"
          style={{display: 'inline'}}>
          {segment => (
            <DateSegment
              segment={segment}
              className={clsx(styles.segment, {[styles.placeholder]: segment.isPlaceholder})}
            />
          )}
        </DateInput>
        <span aria-hidden="true" style={{padding: '0 4px'}}>
          –
        </span>
        <DateInput slot="end" style={{display: 'inline'}}>
          {segment => (
            <DateSegment
              segment={segment}
              className={clsx(styles.segment, {[styles.placeholder]: segment.isPlaceholder})}
            />
          )}
        </DateInput>
      </div>
      <Button>🗓</Button>
    </Group>
    <Popover
      placement="bottom start"
      style={{
        background: 'Canvas',
        color: 'CanvasText',
        border: '1px solid gray',
        padding: 20
      }}>
      <Dialog>
        <RangeCalendar style={{width: 220}}>
          <div style={{display: 'flex', alignItems: 'center'}}>
            <Button slot="previous">&lt;</Button>
            <Heading style={{flex: 1, textAlign: 'center'}} />
            <Button slot="next">&gt;</Button>
          </div>
          <CalendarGrid style={{width: '100%'}}>
            {date => (
              <CalendarCell
                date={date}
                style={({isSelected, isOutsideMonth}) => ({
                  display: isOutsideMonth ? 'none' : '',
                  textAlign: 'center',
                  cursor: 'default',
                  background: isSelected ? 'blue' : ''
                })}
              />
            )}
          </CalendarGrid>
        </RangeCalendar>
      </Dialog>
    </Popover>
  </DateRangePicker>
);

export const DateRangePickerTriggerWidthExample: DateRangePickerStory = args => (
  <DateRangePicker data-testid="date-range-picker-example" {...args}>
    <Label style={{display: 'block'}}>Date</Label>
    <Group style={{display: 'inline-flex', width: 300}}>
      <div className={styles.field} style={{flex: 1}}>
        <DateInput
          data-testid="date-range-picker-date-input"
          slot="start"
          style={{display: 'inline'}}>
          {segment => (
            <DateSegment
              segment={segment}
              className={clsx(styles.segment, {[styles.placeholder]: segment.isPlaceholder})}
            />
          )}
        </DateInput>
        <span aria-hidden="true" style={{padding: '0 4px'}}>
          –
        </span>
        <DateInput slot="end" style={{display: 'inline'}}>
          {segment => (
            <DateSegment
              segment={segment}
              className={clsx(styles.segment, {[styles.placeholder]: segment.isPlaceholder})}
            />
          )}
        </DateInput>
      </div>
      <Button>🗓</Button>
    </Group>
    <Popover
      placement="bottom start"
      style={{
        background: 'Canvas',
        color: 'CanvasText',
        border: '1px solid gray',
        padding: 20,
        boxSizing: 'border-box',
        width: 'var(--trigger-width)'
      }}>
      <Dialog>
        <RangeCalendar>
          <div style={{display: 'flex', alignItems: 'center'}}>
            <Button slot="previous">&lt;</Button>
            <Heading style={{flex: 1, textAlign: 'center'}} />
            <Button slot="next">&gt;</Button>
          </div>
          <CalendarGrid style={{width: '100%'}}>
            {date => (
              <CalendarCell
                date={date}
                style={({isSelected, isOutsideMonth}) => ({
                  display: isOutsideMonth ? 'none' : '',
                  textAlign: 'center',
                  cursor: 'default',
                  background: isSelected ? 'blue' : ''
                })}
              />
            )}
          </CalendarGrid>
        </RangeCalendar>
      </Dialog>
    </Popover>
  </DateRangePicker>
);

export const DatePickerAutofill = props => (
  <Form
    onSubmit={e => {
      action('onSubmit')(Object.fromEntries(new FormData(e.target as HTMLFormElement).entries()));
      e.preventDefault();
    }}>
    <TextField>
      <Label>Name</Label>
      <Input name="firstName" type="name" id="name" autoComplete="name" />
    </TextField>
    <DatePicker
      data-testid="date-picker-example"
      name="bday"
      autoComplete="bday"
      defaultValue={parseAbsoluteToLocal('2021-04-07T18:45:22Z')}
      {...props}>
      <Label style={{display: 'block'}}>Date</Label>
      <Group style={{display: 'inline-flex'}}>
        <DateInput className={styles.field}>
          {segment => (
            <DateSegment
              segment={segment}
              className={clsx(styles.segment, {[styles.placeholder]: segment.isPlaceholder})}
            />
          )}
        </DateInput>
        <Button>🗓</Button>
      </Group>
      <Popover
        placement="bottom start"
        style={{
          background: 'Canvas',
          color: 'CanvasText',
          border: '1px solid gray',
          padding: 20
        }}>
        <Dialog>
          <Calendar style={{width: 220}}>
            <div style={{display: 'flex', alignItems: 'center'}}>
              <Button slot="previous">&lt;</Button>
              <Heading style={{flex: 1, textAlign: 'center'}} />
              <Button slot="next">&gt;</Button>
            </div>
            <CalendarGrid style={{width: '100%'}}>
              {date => (
                <CalendarCell
                  date={date}
                  style={({isSelected, isOutsideMonth}) => ({
                    display: isOutsideMonth ? 'none' : '',
                    textAlign: 'center',
                    cursor: 'default',
                    background: isSelected ? 'blue' : ''
                  })}
                />
              )}
            </CalendarGrid>
          </Calendar>
        </Dialog>
      </Popover>
    </DatePicker>
    <Button type="submit">Submit</Button>
  </Form>
);
