/*
 * Copyright 2022 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {action} from 'storybook/actions';
import {Button} from '../src/Button';
import {Checkbox, CheckboxGroup, CheckboxProps} from '../src/Checkbox';
import {classNames} from '@adobe/react-spectrum/private/utils/classNames';
import {Collection} from 'react-aria/Collection';
import {ComboBox} from '../src/ComboBox';
import {Dialog, DialogTrigger} from '../src/Dialog';
import {DropIndicator, useDragAndDrop} from '../src/useDragAndDrop';
import {GridLayout} from '../src/GridLayout';
import {
  GridList,
  GridListHeader,
  GridListItem,
  GridListItemProps,
  GridListLoadMoreItem,
  GridListProps,
  GridListSection
} from '../src/GridList';
import {Heading} from '../src/Heading';
import {Input} from '../src/Input';
import {Key} from '@react-types/shared';
import {ListBox} from '../src/ListBox';
import {ListLayout, Size, WaterfallLayout} from 'react-stately/useVirtualizerState';
import {LoadingSpinner, MyListBoxItem} from './utils';
import {LoadingState} from '@react-types/shared';
import {Menu, MenuItem, MenuTrigger} from '../src/Menu';
import {Meta, StoryFn, StoryObj} from '@storybook/react';
import {Modal, ModalOverlay, ModalOverlayProps} from '../src/Modal';
import {Popover} from '../src/Popover';
import React, {JSX, useState} from 'react';
import styles from '../example/index.css';
import {Tag, TagGroup, TagList} from '../src/TagGroup';
import {Text} from '../src/Text';
import {TextField} from '../src/TextField';
import {Toolbar} from '../src/Toolbar';
import {useAsyncList} from 'react-stately/useAsyncList';
import {useListData} from 'react-stately/useListData';
import {Virtualizer} from '../src/Virtualizer';
import './styles.css';
import {Radio, RadioGroup} from '../src/RadioGroup';

export default {
  title: 'React Aria Components/GridList',
  component: GridList,
  excludeStories: ['MyGridListItem']
} as Meta<typeof GridList>;

export type GridListStory = StoryFn<typeof GridList>;

export const GridListExample: GridListStory = args => {
  let isHorizontalStack = args.orientation === 'horizontal' && args.layout !== 'grid';
  return (
    <GridList
      {...args}
      className={styles.menu}
      aria-label="test gridlist"
      style={{
        width: isHorizontalStack ? undefined : 300,
        height: isHorizontalStack ? undefined : 300,
        display: isHorizontalStack ? 'flex' : 'grid',
        gridTemplate: args.layout === 'grid' ? 'repeat(3, 1fr) / repeat(3, 1fr)' : 'auto / 1fr',
        gridAutoFlow: args.orientation === 'horizontal' ? 'column' : 'row'
      }}>
      <MyGridListItem textValue="1,1">
        1,1 <Button>Actions</Button>
      </MyGridListItem>
      <MyGridListItem textValue="1,2">
        1,2 <Button>Actions</Button>
      </MyGridListItem>
      <MyGridListItem textValue="1,3">
        1,3 <Button>Actions</Button>
      </MyGridListItem>
      <MyGridListItem textValue="2,1">
        2,1 <Button>Actions</Button>
      </MyGridListItem>
      <MyGridListItem textValue="2,2">
        2,2 <Button>Actions</Button>
      </MyGridListItem>
      <MyGridListItem textValue="2,3">
        2,3 <Button>Actions</Button>
      </MyGridListItem>
      <MyGridListItem textValue="3,1">
        3,1 <Button>Actions</Button>
      </MyGridListItem>
      <MyGridListItem textValue="3,2">
        3,2 <Button>Actions</Button>
      </MyGridListItem>
      <MyGridListItem textValue="3,3">
        3,3 <Button>Actions</Button>
      </MyGridListItem>
    </GridList>
  );
};

export const MyGridListItem = (props: GridListItemProps) => {
  return (
    <GridListItem
      {...props}
      style={{display: 'flex', alignItems: 'center', gap: 8}}
      className={({isFocused, isSelected, isHovered}) =>
        classNames(styles, 'item', {
          focused: isFocused,
          selected: isSelected,
          hovered: isHovered
        })
      }>
      {({selectionMode, allowsDragging}) => (
        <>
          {allowsDragging && <Button slot="drag">≡</Button>}
          {selectionMode !== 'none' ? <MyCheckbox slot="selection" /> : null}
          {props.children as any}
        </>
      )}
    </GridListItem>
  );
};

GridListExample.story = {
  args: {
    layout: 'stack',
    orientation: 'vertical',
    escapeKeyBehavior: 'clearSelection',
    shouldSelectOnPressUp: false,
    disallowTypeAhead: false
  },
  argTypes: {
    layout: {
      control: 'radio',
      options: ['stack', 'grid']
    },
    orientation: {
      control: 'radio',
      options: ['vertical', 'horizontal']
    },
    keyboardNavigationBehavior: {
      control: 'radio',
      options: ['arrow', 'tab']
    },
    selectionMode: {
      control: 'radio',
      options: ['none', 'single', 'multiple']
    },
    selectionBehavior: {
      control: 'radio',
      options: ['toggle', 'replace']
    },
    escapeKeyBehavior: {
      control: 'radio',
      options: ['clearSelection', 'none']
    }
  }
};

const DraggableGridListRender = (args: GridListProps<any>) => {
  let list = useListData({
    initialItems: [
      {id: '1', name: 'Item 1'},
      {id: '2', name: 'Item 2'},
      {id: '3', name: 'Item 3'},
      {id: '4', name: 'Item 4'},
      {id: '5', name: 'Item 5'}
    ]
  });

  let {dragAndDropHooks} = useDragAndDrop({
    getItems: keys => [...keys].map(key => ({'text/plain': list.getItem(key)?.name ?? ''})),
    onReorder(e) {
      if (e.target.dropPosition === 'before') {
        list.moveBefore(e.target.key, e.keys);
      } else if (e.target.dropPosition === 'after') {
        list.moveAfter(e.target.key, e.keys);
      }
    }
  });

  let isHorizontal = args.orientation === 'horizontal';

  return (
    <GridList
      className={styles.menu}
      disabledKeys={['3']}
      aria-label="draggable gridlist"
      orientation={args.orientation}
      selectionMode="multiple"
      dragAndDropHooks={dragAndDropHooks}
      items={list.items}
      style={{
        display: 'flex',
        flexDirection: isHorizontal ? 'row' : 'column',
        width: isHorizontal ? undefined : 300
      }}>
      {item => <MyGridListItem>{item.name}</MyGridListItem>}
    </GridList>
  );
};

export const DraggableGridListExample: StoryObj<typeof DraggableGridListRender> = {
  render: args => <DraggableGridListRender {...args} />,
  args: {
    orientation: 'vertical'
  },
  argTypes: {
    orientation: {
      control: 'radio',
      options: ['vertical', 'horizontal']
    }
  }
};

const MyCheckbox = ({children, ...props}: CheckboxProps) => {
  return (
    <Checkbox {...props}>
      {({isIndeterminate}) => (
        <>
          <div className="checkbox">
            <svg viewBox="0 0 18 18" aria-hidden="true">
              {isIndeterminate ? (
                <rect x={1} y={7.5} width={15} height={3} />
              ) : (
                <polyline points="1 9 7 14 15 4" />
              )}
            </svg>
          </div>
          {children}
        </>
      )}
    </Checkbox>
  );
};

export const GridListSectionExample = args => (
  <GridList
    {...args}
    className={styles.menu}
    aria-label="test gridlist"
    style={{
      width: 400,
      height: 400
    }}>
    <GridListSection>
      <GridListHeader>Section 1</GridListHeader>
      <MyGridListItem>
        1,1 <Button>Actions</Button>
      </MyGridListItem>
      <MyGridListItem>
        1,2 <Button>Actions</Button>
      </MyGridListItem>
      <MyGridListItem>
        1,3 <Button>Actions</Button>
      </MyGridListItem>
    </GridListSection>
    <GridListSection>
      <GridListHeader>Section 2</GridListHeader>
      <MyGridListItem>
        2,1 <Button>Actions</Button>
      </MyGridListItem>
      <MyGridListItem>
        2,2 <Button>Actions</Button>
      </MyGridListItem>
      <MyGridListItem>
        2,3 <Button>Actions</Button>
      </MyGridListItem>
    </GridListSection>
    <GridListSection>
      <GridListHeader>Section 3</GridListHeader>
      <MyGridListItem>
        3,1 <Button>Actions</Button>
      </MyGridListItem>
      <MyGridListItem>
        3,2 <Button>Actions</Button>
      </MyGridListItem>
      <MyGridListItem>
        3,3 <Button>Actions</Button>
      </MyGridListItem>
    </GridListSection>
  </GridList>
);

GridListSectionExample.story = {
  args: {
    layout: 'stack',
    escapeKeyBehavior: 'clearSelection',
    shouldSelectOnPressUp: false
  },
  argTypes: {
    layout: {
      control: 'radio',
      options: ['stack', 'grid']
    },
    keyboardNavigationBehavior: {
      control: 'radio',
      options: ['arrow', 'tab']
    },
    selectionMode: {
      control: 'radio',
      options: ['none', 'single', 'multiple']
    },
    selectionBehavior: {
      control: 'radio',
      options: ['toggle', 'replace']
    },
    escapeKeyBehavior: {
      control: 'radio',
      options: ['clearSelection', 'none']
    }
  }
};

export function VirtualizedGridListSection() {
  let sections: {
    id: string;
    name: string;
    children: {id: string; name: string}[];
  }[] = [];
  for (let s = 0; s < 10; s++) {
    let items: {id: string; name: string}[] = [];
    for (let i = 0; i < 3; i++) {
      items.push({id: `item_${s}_${i}`, name: `Section ${s}, Item ${i}`});
    }
    sections.push({
      id: `section_${s}`,
      name: `Section ${s}`,
      children: items
    });
  }

  return (
    <Virtualizer
      layout={ListLayout}
      layoutOptions={{
        rowHeight: 25
      }}>
      <GridList
        className={styles.menu}
        // selectionMode="multiple"
        style={{height: 400}}
        aria-label="virtualized with grid section"
        items={sections}>
        <Collection items={sections}>
          {section => (
            <GridListSection>
              <GridListHeader>{section.name}</GridListHeader>
              <Collection items={section.children}>
                {item => <MyGridListItem>{item.name}</MyGridListItem>}
              </Collection>
            </GridListSection>
          )}
        </Collection>
      </GridList>
    </Virtualizer>
  );
}

const VirtualizedGridListRender = (args: GridListProps<any> & {isLoading: boolean}) => {
  let items: {id: number; name: string}[] = [];
  for (let i = 0; i < 10000; i++) {
    items.push({id: i, name: `Item ${i}`});
  }

  let list = useListData({
    initialItems: items
  });

  let {dragAndDropHooks} = useDragAndDrop({
    getItems: keys => {
      return [...keys].map(key => ({
        'text/plain': list.getItem(key)?.name ?? ''
      }));
    },
    onReorder(e) {
      if (e.target.dropPosition === 'before') {
        list.moveBefore(e.target.key, e.keys);
      } else if (e.target.dropPosition === 'after') {
        list.moveAfter(e.target.key, e.keys);
      }
    },
    renderDropIndicator(target) {
      return (
        <DropIndicator
          target={target}
          style={({isDropTarget}) => ({
            width: '100%',
            height: '100%',
            background: isDropTarget ? 'blue' : 'transparent'
          })}
        />
      );
    }
  });

  return (
    <Virtualizer
      layout={ListLayout}
      layoutOptions={{
        rowHeight: 25
      }}>
      <GridList
        className={styles.menu}
        selectionMode="multiple"
        dragAndDropHooks={dragAndDropHooks}
        style={{height: 400}}
        aria-label="virtualized gridlist"
        items={list.items}>
        <Collection items={list.items}>
          {item => <MyGridListItem>{item.name}</MyGridListItem>}
        </Collection>
        <MyGridListLoaderIndicator isLoading={args.isLoading} />
      </GridList>
    </Virtualizer>
  );
};

export const VirtualizedGridList: StoryObj<typeof VirtualizedGridListRender> = {
  render: args => <VirtualizedGridListRender {...args} />,
  args: {
    isLoading: false
  }
};

interface VirtualizedGridListGridProps {
  minItemSizeWidth?: number;
  maxItemSizeWidth?: number;
  maxColumns?: number;
  minHorizontalSpace?: number;
  maxHorizontalSpace?: number;
}

export let VirtualizedGridListGrid: StoryFn<VirtualizedGridListGridProps> = args => {
  const {
    minItemSizeWidth = 40,
    maxItemSizeWidth = 65,
    maxColumns = Infinity,
    minHorizontalSpace = 0,
    maxHorizontalSpace = Infinity
  } = args;
  let items: {id: number; name: string}[] = [];
  for (let i = 0; i < 10000; i++) {
    items.push({id: i, name: `Item ${i}`});
  }

  return (
    <Virtualizer
      layout={GridLayout}
      layoutOptions={{
        minItemSize: new Size(minItemSizeWidth, 40),
        maxItemSize: new Size(maxItemSizeWidth, 40),
        minSpace: new Size(minHorizontalSpace, 18),
        maxColumns,
        maxHorizontalSpace
      }}>
      <GridList
        className={styles.menu}
        layout="grid"
        style={{height: 400, width: 400}}
        aria-label="virtualized listbox"
        items={items}>
        {item => <MyGridListItem>{item.name}</MyGridListItem>}
      </GridList>
    </Virtualizer>
  );
};

VirtualizedGridListGrid.story = {
  args: {
    minItemSizeWidth: 40,
    maxItemSizeWidth: 65,
    maxColumns: undefined,
    minHorizontalSpace: 0,
    maxHorizontalSpace: undefined
  },
  argTypes: {
    minItemSizeWidth: {
      control: 'number',
      description: 'The minimum width of each item in the grid list',
      defaultValue: 40
    },
    maxItemSizeWidth: {
      control: 'number',
      description: 'Maximum width of each item in the grid list.',
      defaultValue: 65
    },
    maxColumns: {
      control: 'number',
      description: 'Maximum number of columns in the grid list.',
      defaultValue: undefined
    },
    minHorizontalSpace: {
      control: 'number',
      description: 'Minimum horizontal space between grid items.',
      defaultValue: 0
    },
    maxHorizontalSpace: {
      control: 'number',
      description: 'Maximum horizontal space between grid items.',
      defaultValue: undefined
    }
  }
};

function VirtualizedGridDnD() {
  let initialItems: {id: number; name: string}[] = [];
  for (let i = 0; i < 50; i++) {
    initialItems.push({id: i, name: `Item ${i}`});
  }
  let list = useListData({initialItems});

  let {dragAndDropHooks} = useDragAndDrop({
    getItems: keys => [...keys].map(key => ({'text/plain': list.getItem(key)?.name ?? ''})),
    onReorder(e) {
      if (e.target.dropPosition === 'before') {
        list.moveBefore(e.target.key, e.keys);
      } else if (e.target.dropPosition === 'after') {
        list.moveAfter(e.target.key, e.keys);
      }
    },
    renderDropIndicator(target) {
      return (
        <DropIndicator
          target={target}
          style={({isDropTarget}) => ({
            width: '100%',
            height: '100%',
            background: isDropTarget ? 'red' : 'transparent'
          })}
        />
      );
    }
  });

  return (
    <Virtualizer
      layout={GridLayout}
      layoutOptions={{
        minItemSize: new Size(120, 120),
        maxItemSize: new Size(120, 120),
        minSpace: new Size(20, 20),
        dropIndicatorThickness: 4
      }}>
      <GridList
        className={styles.menu}
        layout="grid"
        selectionMode="multiple"
        dragAndDropHooks={dragAndDropHooks}
        style={{height: 500, width: 600, border: '1px solid gray'}}
        aria-label="grid layout dnd"
        items={list.items}>
        {item => (
          <GridListItem
            textValue={item.name}
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              border: '1px solid blue',
              background: 'white'
            }}>
            {item.name}
          </GridListItem>
        )}
      </GridList>
    </Virtualizer>
  );
}

export let VirtualizedGridDrag: StoryObj<typeof VirtualizedGridDnD> = {
  render: () => <VirtualizedGridDnD />,
  parameters: {
    description: {
      data: 'test rtl and ltr dnd, the drop indicators should be positioned properly'
    }
  }
};

let renderEmptyState = ({isLoading}) => {
  return (
    <div style={{height: 30, width: '100%'}}>
      {isLoading ? (
        <LoadingSpinner style={{height: 20, width: 20, transform: 'translate(-50%, -50%)'}} />
      ) : (
        'No results'
      )}
    </div>
  );
};

interface Character {
  name: string;
  height: number;
  mass: number;
  birth_year: number;
}

const MyGridListLoaderIndicator = props => {
  return (
    <GridListLoadMoreItem
      style={{
        height: 30,
        width: '100%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}
      {...props}>
      <LoadingSpinner style={{height: 20, width: 20, position: 'unset'}} />
    </GridListLoadMoreItem>
  );
};

function AsyncGridListRender(props: {delay: number}): JSX.Element {
  let list = useAsyncList<Character>({
    async load({signal, cursor, filterText}) {
      if (cursor) {
        cursor = cursor.replace(/^http:\/\//i, 'https://');
      }

      await new Promise(resolve => setTimeout(resolve, props.delay));
      let res = await fetch(cursor || `https://swapi.py4e.com/api/people/?search=${filterText}`, {
        signal
      });
      let json = await res.json();

      return {
        items: json.results,
        cursor: json.next
      };
    }
  });

  return (
    <GridList
      className={styles.menu}
      style={{height: 200}}
      aria-label="async gridlist"
      renderEmptyState={() => renderEmptyState({isLoading: list.isLoading})}>
      <Collection items={list.items}>
        {(item: Character) => <MyGridListItem id={item.name}>{item.name}</MyGridListItem>}
      </Collection>
      <MyGridListLoaderIndicator
        isLoading={list.loadingState === 'loadingMore'}
        onLoadMore={list.loadMore}
      />
    </GridList>
  );
}

export let AsyncGridList: StoryObj<typeof AsyncGridListRender> = {
  render: args => <AsyncGridListRender {...args} />,
  args: {
    delay: 50
  }
};

function AsyncGridListVirtualizedRender(props: {delay: number}): JSX.Element {
  let list = useAsyncList<Character>({
    async load({signal, cursor, filterText}) {
      if (cursor) {
        cursor = cursor.replace(/^http:\/\//i, 'https://');
      }

      await new Promise(resolve => setTimeout(resolve, props.delay));
      let res = await fetch(cursor || `https://swapi.py4e.com/api/people/?search=${filterText}`, {
        signal
      });
      let json = await res.json();
      return {
        items: json.results,
        cursor: json.next
      };
    }
  });

  return (
    <Virtualizer
      layout={ListLayout}
      layoutOptions={{
        rowHeight: 25,
        loaderHeight: 30
      }}>
      <GridList
        className={styles.menu}
        style={{height: 200}}
        aria-label="async virtualized gridlist"
        renderEmptyState={() => renderEmptyState({isLoading: list.isLoading})}>
        <Collection items={list.items}>
          {item => <MyGridListItem id={item.name}>{item.name}</MyGridListItem>}
        </Collection>
        <MyGridListLoaderIndicator
          isLoading={list.loadingState === 'loadingMore'}
          onLoadMore={list.loadMore}
        />
      </GridList>
    </Virtualizer>
  );
}

export let AsyncGridListVirtualized: StoryObj<typeof AsyncGridListVirtualizedRender> = {
  render: args => <AsyncGridListVirtualizedRender {...args} />,
  args: {
    delay: 50
  }
};

export let TagGroupInsideGridList: GridListStory = () => {
  return (
    <GridList
      className={styles.menu}
      aria-label="Grid list with tag group"
      keyboardNavigationBehavior="tab"
      style={{
        width: 300,
        height: 300
      }}>
      <MyGridListItem textValue="Tags">
        1,1
        <TagGroup aria-label="Tag group 1" onRemove={action('onRemove')}>
          <TagList style={{display: 'flex', gap: 10}}>
            <Tag key="1">
              Tag 1<Button slot="remove">X</Button>
            </Tag>
            <Tag key="2">
              Tag 2<Button slot="remove">X</Button>
            </Tag>
            <Tag key="3">
              Tag 3<Button slot="remove">X</Button>
            </Tag>
          </TagList>
        </TagGroup>
        <TagGroup aria-label="Tag group 2" onRemove={action('onRemove')}>
          <TagList style={{display: 'flex', gap: 10}}>
            <Tag key="1">
              Tag 1<Button slot="remove">X</Button>
            </Tag>
            <Tag key="2">
              Tag 2<Button slot="remove">X</Button>
            </Tag>
            <Tag key="3">
              Tag 3<Button slot="remove">X</Button>
            </Tag>
          </TagList>
        </TagGroup>
      </MyGridListItem>
      <MyGridListItem>
        1,2 <Button>Actions</Button>
      </MyGridListItem>
      <MyGridListItem>
        1,3
        <TagGroup aria-label="Tag group">
          <TagList style={{display: 'flex', gap: 10}}>
            <Tag key="1">Tag 1</Tag>
            <Tag key="2">Tag 2</Tag>
            <Tag key="3">Tag 3</Tag>
          </TagList>
        </TagGroup>
      </MyGridListItem>
    </GridList>
  );
};

const GridListDropdown = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<Set<Key>>(new Set([]));

  const handleSelectionChange = e => {
    setSelectedItem(e);
    setIsOpen(false);
  };

  return (
    <DialogTrigger isOpen={isOpen} onOpenChange={setIsOpen}>
      <Button>Open GridList Options</Button>
      <Popover>
        <div>
          <GridList
            className={styles.menu}
            selectedKeys={selectedItem}
            aria-label="Favorite pokemon"
            selectionMode="single"
            onSelectionChange={handleSelectionChange}
            shouldSelectOnPressUp
            autoFocus>
            <MyGridListItem textValue="Charizard">
              Option 1 <Button>A</Button>
            </MyGridListItem>
            <MyGridListItem textValue="Blastoise">
              Option 2 <Button>B</Button>
            </MyGridListItem>
            <MyGridListItem textValue="Venusaur">
              Option 3 <Button>C</Button>
            </MyGridListItem>
            <MyGridListItem textValue="Pikachu">
              Option 4 <Button>D</Button>
            </MyGridListItem>
          </GridList>
        </div>
      </Popover>
    </DialogTrigger>
  );
};

function GridListInModalPickerRender(props: ModalOverlayProps): JSX.Element {
  const [mainModalOpen, setMainModalOpen] = useState(true);
  return (
    <>
      <Button onPress={() => setMainModalOpen(true)}>Open Modal</Button>
      <ModalOverlay
        {...props}
        isOpen={mainModalOpen}
        onOpenChange={setMainModalOpen}
        isDismissable
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          background: 'rgba(0,0,0,0.5)'
        }}>
        <Modal>
          <Dialog>
            <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                padding: 8,
                background: '#ccc',
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%,-50%)',
                width: 'max-content',
                height: 'max-content'
              }}>
              <Heading slot="title">Open the GridList Picker</Heading>
              <GridListDropdown />
            </div>
          </Dialog>
        </Modal>
      </ModalOverlay>
    </>
  );
}

export let GridListInModalPicker: StoryObj<typeof GridListInModalPickerRender> = {
  render: args => <GridListInModalPickerRender {...args} />,
  parameters: {
    docs: {
      description: {
        component:
          'Selecting an option from the grid list over the backdrop should not result in the modal closing.'
      }
    }
  }
};

type Item = {
  id: number;
  user: {
    name: string;
    profile_image: {small: string};
  };
  urls: {regular: string};
  description: string;
  alt_description: string;
  width: number;
  height: number;
};

interface AsyncGridListGridVirtualizedRenderProps {
  delay: number;
  layout: 'grid' | 'waterfall';
  loaderHeight: number;
  loadingState: LoadingState;
}

function AsyncGridListGridVirtualizedRender(props: AsyncGridListGridVirtualizedRenderProps) {
  const list = useAsyncList<Item, number | null>({
    async load({cursor, items, signal}) {
      const page = cursor || 1;
      await new Promise(resolve => setTimeout(resolve, props.delay));
      const res = await fetch(
        `https://api.unsplash.com/topics/nature/photos?page=${page}&per_page=30&client_id=AJuU-FPh11hn7RuumUllp4ppT8kgiLS7LtOHp_sp4nc`,
        {signal}
      );
      let nextItems = await res.json();
      // Filter duplicates which might be returned by the API.
      const existingKeys = new Set(items.map(i => i.id));
      nextItems = nextItems.filter(
        i => !existingKeys.has(i.id) && (i.description || i.alt_description)
      );
      return {cursor: nextItems.length ? page + 1 : null, items: nextItems};
    }
  });
  const layout = props.layout === 'waterfall' ? WaterfallLayout : GridLayout;
  const loadingState = props.loadingState === 'idle' ? list.loadingState : props.loadingState;

  return (
    <Virtualizer
      layout={layout}
      layoutOptions={{
        loaderHeight: props.loaderHeight,
        maxItemSize: new Size(140, 140),
        minItemSize: new Size(100, 100),
        minSpace: new Size(6, 6)
      }}>
      <GridList
        aria-label="async virtualized gridlist"
        className={styles.menu}
        layout="grid"
        renderEmptyState={() => renderEmptyState({isLoading: list.isLoading})}
        style={{height: 400, width: 400}}>
        <Collection items={list.items}>
          {item => (
            <GridListItem
              style={{display: 'flex', flexDirection: 'column'}}
              textValue={item.description || item.alt_description}>
              <img
                alt=""
                width={item.width}
                height={item.height}
                src={item.urls.regular}
                style={{height: 200, objectFit: 'cover', width: '100%'}}
              />
              <Text slot="description">By {item.user.name}</Text>
            </GridListItem>
          )}
        </Collection>
        <MyGridListLoaderIndicator
          isLoading={loadingState === 'loadingMore'}
          onLoadMore={loadingState === 'idle' ? list.loadMore : undefined}
        />
      </GridList>
    </Virtualizer>
  );
}

export const AsyncGridListGridVirtualized: StoryObj<typeof AsyncGridListGridVirtualizedRender> = {
  render: AsyncGridListGridVirtualizedRender,
  args: {
    delay: 50,
    layout: 'grid',
    loaderHeight: 30,
    loadingState: 'idle'
  },
  argTypes: {
    delay: {
      control: 'number'
    },
    layout: {
      control: 'select',
      options: ['grid', 'waterfall']
    },
    loaderHeight: {
      control: 'number'
    },
    loadingState: {
      control: 'select',
      options: ['idle', 'loadingMore']
    }
  }
};

let comboboxEmptyState = () => {
  return <div style={{height: 30, width: '100%'}}>No results</div>;
};

type GridListWithTextfieldArgs = GridListProps<any> & {autoFocusChildren?: boolean};

const GridListWithTextfieldRender = (args: GridListWithTextfieldArgs) => {
  let isHorizontalStack = args.orientation === 'horizontal' && args.layout !== 'grid';
  let {autoFocusChildren, keyboardNavigationBehavior, ...otherArgs} = args;

  let focusMode =
    autoFocusChildren && keyboardNavigationBehavior === 'tab'
      ? 'child'
      : (undefined as 'child' | undefined);
  let allowsArrowNavigation =
    autoFocusChildren && keyboardNavigationBehavior === 'tab' ? true : undefined;

  return (
    <div style={{display: 'flex', flexDirection: 'column'}}>
      <input aria-label="input before gridlist" />
      <GridList
        className={styles.menu}
        aria-label="gridlist with textfield"
        keyboardNavigationBehavior={keyboardNavigationBehavior}
        style={{
          width: isHorizontalStack ? undefined : 400,
          height: isHorizontalStack ? undefined : 400,
          display: isHorizontalStack ? 'flex' : 'grid',
          gridTemplate: args.layout === 'grid' ? 'repeat(3, 1fr) / repeat(3, 1fr)' : 'auto / 1fr',
          gridAutoFlow: args.orientation === 'horizontal' ? 'column' : 'row'
        }}
        {...otherArgs}>
        <MyGridListItem textValue="Rac TextField" focusMode={focusMode}>
          RAC TextField
          <TextField aria-label="Name">
            <Input />
          </TextField>
        </MyGridListItem>
        <MyGridListItem textValue="Rac input" focusMode={focusMode}>
          Raw input <input aria-label="Raw text input" style={{marginLeft: 4}} />
        </MyGridListItem>
        <MyGridListItem textValue="TextField + Button" focusMode={focusMode}>
          TextField + Button
          <TextField aria-label="Search">
            <Input />
          </TextField>{' '}
          <Button>Go</Button>
        </MyGridListItem>
        <MyGridListItem textValue="Combobox" focusMode={focusMode}>
          ComboBox
          <ComboBox aria-label="combobox" allowsEmptyCollection>
            <div style={{display: 'flex'}}>
              <Input />
              <Button>
                <span aria-hidden="true" style={{padding: '0 2px'}}>
                  ▼
                </span>
              </Button>
            </div>
            <Popover>
              <ListBox
                renderEmptyState={comboboxEmptyState}
                data-testid="combo-box-list-box"
                className={styles.menu}
                style={{width: 'var(--trigger-width)'}}>
                <MyListBoxItem>Foo</MyListBoxItem>
                <MyListBoxItem>Bar</MyListBoxItem>
                <MyListBoxItem>Baz</MyListBoxItem>
                <MyListBoxItem href="http://google.com">Google</MyListBoxItem>
              </ListBox>
            </Popover>
          </ComboBox>
        </MyGridListItem>
        <MyGridListItem textValue="Toolbar" focusMode={focusMode}>
          Toolbar
          <Toolbar aria-label="Text formatting" style={{gap: 4}}>
            <Button onPress={action('Bold press')}>Bold</Button>
            <Button onPress={action('Italics press')}>Italic</Button>
            <Button onPress={action('Underline press')}>Underline</Button>
          </Toolbar>
        </MyGridListItem>
        <MyGridListItem
          textValue="Menu"
          focusMode={focusMode}
          allowsArrowNavigation={allowsArrowNavigation}>
          Menu
          {/* TODO: hitting escape to close the menu, returns focus to the row.
          Tabbing back from the external input also focuses the trggerbutton rather than the row. Tabbing back into the textfield row focuses the row  */}
          <MenuTrigger>
            <Button aria-label="Options">▾</Button>
            <Popover>
              <Menu className={styles.menu}>
                <MenuItem>Cut</MenuItem>
                <MenuItem>Copy</MenuItem>
                <MenuItem>Paste</MenuItem>
              </Menu>
            </Popover>
          </MenuTrigger>
        </MyGridListItem>
        <MyGridListItem textValue="Radiogroup" focusMode={focusMode}>
          RadioGroup
          <RadioGroup
            aria-label="Radiogroup"
            className={styles.radiogroup}
            style={{flexDirection: 'row'}}>
            <Radio className={styles.radio} value="dogs" data-testid="radio-dog">
              Dog
            </Radio>
            <Radio className={styles.radio} value="cats">
              Cat
            </Radio>
            <Radio className={styles.radio} value="dragon">
              Dragon
            </Radio>
          </RadioGroup>
        </MyGridListItem>
        <MyGridListItem textValue="Checkboxgroup" focusMode={focusMode}>
          CheckboxGroup
          <CheckboxGroup aria-label="Checkboxgroup" style={{display: 'flex', flexDirection: 'row'}}>
            <Checkbox value="soccer">
              <div className="checkbox" aria-hidden="true">
                <svg viewBox="0 0 18 18">
                  <polyline points="1 9 7 14 15 4" />
                </svg>
              </div>
              Soccer
            </Checkbox>
            <Checkbox value="baseball">
              <div className="checkbox" aria-hidden="true">
                <svg viewBox="0 0 18 18">
                  <polyline points="1 9 7 14 15 4" />
                </svg>
              </div>
              Baseball
            </Checkbox>
            <Checkbox value="basketball">
              <div className="checkbox" aria-hidden="true">
                <svg viewBox="0 0 18 18">
                  <polyline points="1 9 7 14 15 4" />
                </svg>
              </div>
              Basketball
            </Checkbox>
          </CheckboxGroup>
        </MyGridListItem>
      </GridList>
      <input aria-label="input after gridlist" />
    </div>
  );
};

export const GridListWithTextfield: StoryObj<typeof GridListWithTextfieldRender> = {
  render: args => <GridListWithTextfieldRender {...args} />,
  args: {
    layout: 'stack',
    orientation: 'vertical',
    escapeKeyBehavior: 'clearSelection',
    keyboardNavigationBehavior: 'tab'
  },
  argTypes: {
    layout: {
      control: 'radio',
      options: ['stack', 'grid']
    },
    orientation: {
      control: 'radio',
      options: ['vertical', 'horizontal']
    },
    keyboardNavigationBehavior: {
      control: 'radio',
      options: ['arrow', 'tab']
    },
    autoFocusChildren: {
      control: 'boolean'
    },
    selectionMode: {
      control: 'radio',
      options: ['none', 'single', 'multiple']
    },
    selectionBehavior: {
      control: 'radio',
      options: ['toggle', 'replace']
    },
    escapeKeyBehavior: {
      control: 'radio',
      options: ['clearSelection', 'none']
    }
  },
  parameters: {
    description: {
      data: 'Note that toggling autoFocusChildren will make each row automatically focus its children. For the row with a menu, allowsArrowNavigation is also applied so that arrow keys can be used to move focus between rows still'
    }
  }
};

function VirtualizedDisplayNoneToggleRender() {
  let [visible, setVisible] = useState(true);

  return (
    <div>
      <Button onPress={() => setVisible(v => !v)} style={{marginBottom: 8}}>
        {visible ? 'Hide' : 'Show'}
      </Button>
      <div style={{display: visible ? undefined : 'none'}}>
        <VirtualizedGridDnD />
      </div>
    </div>
  );
}

export const VirtualizedDisplayNoneToggle: StoryObj = {
  render: VirtualizedDisplayNoneToggleRender,
  parameters: {
    description: {
      data: 'toggling hide and show should not cause the items to disappear'
    }
  }
};
