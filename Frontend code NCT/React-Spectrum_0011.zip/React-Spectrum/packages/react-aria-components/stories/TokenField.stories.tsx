/*
 * Copyright 2026 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {Meta, StoryFn} from '@storybook/react';
import React, {useMemo, useRef, useState} from 'react';
import './styles.global.css';
import {Autocomplete} from 'react-aria-components/Autocomplete';
import {ChevronDown} from 'lucide-react';
import {Collection, ComboBox} from 'react-aria-components';
import {ComboBoxItem, ComboBoxListBox} from 'vanilla-starter/ComboBox';
import {FieldButton, Label} from 'vanilla-starter/Form';
import {Header, Menu, MenuItem, MenuSection} from 'vanilla-starter/Menu';
import {Key} from '@react-types/shared';
import {Popover} from 'vanilla-starter/Popover';
import 'vanilla-starter/TagGroup.css';
import {Text} from 'react-aria-components/Text';
import {Token, TokenField, TokenInput} from '../src/TokenField';
import {tokenFieldPositionToDOMRange} from 'react-aria/useTokenField';
import {type TokenFieldSegment, TokenFieldValue} from 'react-stately/useTokenFieldState';
import 'vanilla-starter/TagGroup.css';

export default {
  title: 'React Aria Components/TokenField',
  component: TokenField,
  tags: ['autodocs']
} as Meta<typeof TokenField>;

export type TokenFieldStory = StoryFn<typeof TokenField>;

class TokenizingFieldValue extends TokenFieldValue {
  tokenRegex: RegExp;

  constructor(tokens: TokenFieldSegment[], tokenRegex: RegExp) {
    super(tokens);
    this.tokenRegex = tokenRegex;
  }

  static tokenize(text: string, tokenRegex: RegExp): TokenFieldValue {
    let list = new this([], tokenRegex);
    let segments = list.tokenize(text);
    return new this(segments, tokenRegex);
  }

  createFieldValue(segments: TokenFieldSegment[]): this {
    let Constructor = this.constructor as new (
      tokens: TokenFieldSegment[],
      tokenRegex: RegExp
    ) => this;
    return new Constructor(segments, this.tokenRegex);
  }

  tokenize(text: string): TokenFieldSegment[] {
    if (text.length === 0) {
      return [{type: 'text', text}];
    }

    let tokenRegex = this.tokenRegex;
    tokenRegex.lastIndex = 0;

    let match: RegExpExecArray | null = null;
    let start = 0;
    let segments: TokenFieldSegment[] = [];
    while ((match = tokenRegex.exec(text))) {
      if (match.index > start) {
        segments.push({type: 'text', text: text.slice(start, match.index)});
      }
      segments.push({type: 'token', text: match[0]});
      start = match.index + match[0].length;
    }

    if (start < text.length) {
      segments.push({type: 'text', text: text.slice(start)});
    }

    return segments;
  }
}

export const AutoTokenize: TokenFieldStory = () => {
  return (
    <TokenField
      allowsNewlines
      defaultValue={TokenizingFieldValue.tokenize(
        'This example automatically tokenizes #hashtags and @usernames in the text.',
        /(?<=\s|^)[#@]\S+(?=\s)/g
      )}>
      <Label>Message</Label>
      <TokenInput>{segment => <Token>{segment.text}</Token>}</TokenInput>
      <Text slot="description">Type #hashtags or @usernames to create tokens.</Text>
    </TokenField>
  );
};

export const Template: TokenFieldStory = () => {
  return (
    <TokenField
      allowsNewlines
      defaultValue={TokenizingFieldValue.tokenize(
        "Hello {{firstName}}, it's nice to meet you!",
        /(?<=\s|^)\{\{.+?\}\}/g
      )}>
      <Label>Message</Label>
      <TokenInput>{segment => <Token>{segment.text}</Token>}</TokenInput>
    </TokenField>
  );
};

const usernames = [
  {username: 'alexmiller'},
  {username: 'sarahjones'},
  {username: 'davidkim'},
  {username: 'emmawatson'},
  {username: 'oliverliu'},
  {username: 'ellagreen'},
  {username: 'lucasbrown'},
  {username: 'amandarivera'},
  {username: 'masonlee'},
  {username: 'nataliasmith'},
  {username: 'benjamintaylor'},
  {username: 'zoewilson'},
  {username: 'henrywalker'},
  {username: 'madelineyoung'},
  {username: 'noahscott'},
  {username: 'lucygonzalez'},
  {username: 'jacobmartin'},
  {username: 'averymoore'},
  {username: 'loganmurphy'},
  {username: 'miahernandez'},
  {username: 'danieladair'},
  {username: 'sofiacox'},
  {username: 'jackharris'},
  {username: 'chloebaker'},
  {username: 'liamrodriguez'}
];
const slashCommands = [
  {
    command: 'gif',
    description: 'Insert a GIF'
  },
  {
    command: 'todo',
    description: 'Add a todo list item'
  },
  {
    command: 'mention',
    description: 'Mention a user with @username'
  },
  {
    command: 'date',
    description: 'Insert the current date'
  },
  {
    command: 'quote',
    description: 'Insert a quote block'
  }
];

type Item = {username: string} | {command: string; description: string};

export const WithAutocomplete: TokenFieldStory = () => {
  let inputRef = useRef(null);
  let [value, setValue] = useState(
    new TokenFieldValue([
      {type: 'text', text: 'This example has autocomplete for '},
      {type: 'token', text: '@usernames'},
      {type: 'text', text: ' and '},
      {type: 'token', text: '/commands'}
    ])
  );

  let [filterAnchor, filterValue] = useMemo(() => {
    let filterAnchor = value.findText(
      value.caretPosition,
      TokenFieldValue.Direction.Backward,
      /(?<=^|\s)[@/]/
    );
    if (filterAnchor != null) {
      let filterValue = value.slice(filterAnchor, value.caretPosition).toString();
      return [filterAnchor, filterValue];
    }
    return [null, null];
  }, [value]);

  let items: Item[] = [];
  if (filterValue != null && filterValue.startsWith('/')) {
    items = slashCommands.filter(item => item.command.includes(filterValue.slice(1)));
  } else if (filterValue != null && filterValue.startsWith('@')) {
    items = usernames.filter(item => item.username.includes(filterValue.slice(1)));
  }

  return (
    <Autocomplete>
      <TokenField value={value} onChange={setValue}>
        <Label>Message</Label>
        <TokenInput ref={inputRef}>{segment => <Token>{segment.text}</Token>}</TokenInput>
      </TokenField>
      <Popover
        triggerRef={inputRef}
        isOpen={filterAnchor != null && items.length > 0}
        isNonModal
        hideArrow
        placement="bottom start"
        trigger="MenuTrigger"
        getTargetRect={target => {
          return tokenFieldPositionToDOMRange(target, filterAnchor!).getBoundingClientRect();
        }}>
        <Menu items={items} dependencies={[filterAnchor]}>
          {item => (
            <MenuItem
              id={'username' in item ? item.username : item.command}
              onAction={() => {
                setValue(value =>
                  value.replaceRangeWithSegments(
                    filterAnchor!,
                    value.caretPosition,
                    [
                      {
                        type: 'token',
                        text: 'username' in item ? '@' + item.username : item.command
                      },
                      {type: 'text', text: ' '}
                    ],
                    false // Don't coalesce in undo/redo history.
                  )
                );
              }}>
              <Text slot="label">{'username' in item ? item.username : item.command}</Text>
              {'description' in item ? <Text slot="description">{item.description}</Text> : null}
            </MenuItem>
          )}
        </Menu>
      </Popover>
    </Autocomplete>
  );
};

class TagFieldValue extends TokenFieldValue {
  tokenize(text: string): TokenFieldSegment[] {
    let parts = text.split(/[, \n]/);

    let segments: TokenFieldSegment[] = parts.map((part, i) => {
      if (i === parts.length - 1 || part.length === 0) {
        return {type: 'text', text: part};
      }
      return {type: 'token', text: part};
    });

    if (parts.at(-1)?.length === 0) {
      segments.pop();
    }
    return segments;
  }

  toString(): string {
    return this.segments.map(seg => seg.text).join(', ');
  }
}

export const TagField: TokenFieldStory = () => {
  return (
    <TokenField
      allowsNewlines
      defaultValue={
        new TagFieldValue([
          {type: 'token', text: 'Architecture'},
          {type: 'token', text: 'Design'},
          {type: 'token', text: 'Development'},
          {type: 'token', text: 'Marketing'},
          {type: 'token', text: 'Sales'}
        ])
      }>
      <Label>Categories</Label>
      <TokenInput>{segment => <Token>{segment.text}</Token>}</TokenInput>
    </TokenField>
  );
};

export const Search: TokenFieldStory = () => {
  let inputRef = useRef(null);
  let [value, setValue] = useState(
    new TokenFieldValue([{type: 'token', text: 'From: Alice Smith'}])
  );

  let last = value.segments.at(-1);
  let filterText = last?.type === 'text' ? last.text : null;
  let suggestions: {name: string; items: string[]}[] = [];
  if (filterText != null) {
    let users = usernames
      .filter(item => item.username.includes(filterText))
      .map(u => u.username)
      .slice(0, 5);
    if (users.length > 0) {
      if (
        !value.segments.some(
          segment => segment.type === 'token' && segment.text.startsWith('From: ')
        )
      ) {
        suggestions.push({
          name: 'From',
          items: users
        });
      }

      suggestions.push({
        name: 'To',
        items: users
      });
    }

    suggestions.push({
      name: 'Subject',
      items: [filterText]
    });
  }

  return (
    <Autocomplete>
      <TokenField value={value} onChange={setValue} role="searchbox">
        <Label>Search</Label>
        <TokenInput ref={inputRef}>{segment => <Token>{segment.text}</Token>}</TokenInput>
      </TokenField>
      <Popover
        triggerRef={inputRef}
        isOpen={suggestions.length > 0}
        isNonModal
        hideArrow
        placement="bottom start"
        style={{width: 'var(--trigger-width)'}}
        trigger="MenuTrigger">
        <Menu items={suggestions}>
          {section => (
            <MenuSection>
              <Header>{section.name}</Header>
              <Collection items={section.items}>
                {item => (
                  <MenuItem
                    id={section.name + '-' + item}
                    onAction={() => {
                      setValue(value =>
                        value.replaceRangeWithSegments(
                          {index: value.caretPosition.index, offset: 0},
                          value.caretPosition,
                          [{type: 'token', text: section.name + ': ' + item}],
                          false
                        )
                      );
                    }}>
                    {item}
                  </MenuItem>
                )}
              </Collection>
            </MenuSection>
          )}
        </Menu>
      </Popover>
    </Autocomplete>
  );
};

class ComboBoxTokenFieldValue extends TokenFieldValue<Key> {
  getSelectedKeys(): Key[] {
    return this.segments.filter(seg => seg.type === 'token').map(seg => seg.value!);
  }

  getInputValue(): string {
    let segment = this.segments[this.caretPosition.index];
    return segment?.type === 'text' ? segment.text : '';
  }

  setSelectedKeys(keys: Key[]): ComboBoxTokenFieldValue {
    let selectedKeys = this.getSelectedKeys();
    let added: Key[] = [];
    for (let key of keys) {
      if (!selectedKeys.includes(key)) {
        added.push(key);
      }
    }
    let removed = new Set();
    for (let key of selectedKeys) {
      if (!keys.includes(key)) {
        removed.add(key);
      }
    }

    let value = this;
    for (let key of removed) {
      let index = value.segments.findIndex(seg => seg.type === 'token' && seg.value! === key);
      value = value.replaceRangeWithSegments(
        {index: index, offset: 0},
        {index: index, offset: value.segments[index]?.text.length ?? 0},
        [],
        false
      );
    }

    if (added.length > 0) {
      // TODO: if the user selects multiple existing segments and then selects a value from the menu,
      // should we replace the selected segments?
      let segment = value.segments[value.caretPosition.index];
      value = value.replaceRangeWithSegments(
        {index: value.caretPosition.index, offset: 0},
        // If caret is in a text segment, replace the text segment with the new token. Otherwise, insert it.
        segment?.type === 'text'
          ? {
              index: value.caretPosition.index,
              offset: value.segments[value.caretPosition.index]?.text.length ?? 0
            }
          : {index: value.caretPosition.index, offset: 0},
        added.map(value => {
          // TODO: add a way to lookup a custom text value
          return {type: 'token', text: String(value), value: value};
        }),
        false
      );
    }

    return value;
  }
}

export const ComboBoxExample: TokenFieldStory = () => {
  let [value, setValue] = useState(new ComboBoxTokenFieldValue([]));

  return (
    <ComboBox
      selectionMode="multiple"
      style={{width: 500}}
      value={value.getSelectedKeys()}
      inputValue={value.getInputValue()}
      onChange={keys => setValue(value.setSelectedKeys(keys))}>
      <Label>Users</Label>
      <div className="combobox-field">
        <TokenField value={value} onChange={setValue}>
          <TokenInput style={{paddingInlineEnd: 36}}>
            {segment => <Token>{segment.text}</Token>}
          </TokenInput>
        </TokenField>
        <FieldButton>
          <ChevronDown />
        </FieldButton>
      </div>
      <Popover hideArrow className="combobox-popover">
        <ComboBoxListBox items={usernames}>
          {state => <ComboBoxItem id={state.username}>{state.username}</ComboBoxItem>}
        </ComboBoxListBox>
      </Popover>
    </ComboBox>
  );
};
