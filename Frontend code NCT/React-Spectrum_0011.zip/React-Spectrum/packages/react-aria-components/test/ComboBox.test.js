/*
 * Copyright 2022 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {act} from '@testing-library/react';
import {Button} from '../src/Button';
import {ComboBox, ComboBoxContext, ComboBoxValue} from '../src/ComboBox';
import {Dialog} from '../src/Dialog';
import {FieldError} from '../src/FieldError';
import {fireEvent, pointerMap, render, within} from '@react-spectrum/test-utils-internal';
import {Form} from '../src/Form';
import {Header} from '../src/Header';
import {Input} from '../src/Input';
import {Label} from '../src/Label';
import {ListBox, ListBoxItem, ListBoxLoadMoreItem, ListBoxSection} from '../src/ListBox';
import {ListLayout} from 'react-stately/useVirtualizerState';
import {Popover} from '../src/Popover';
import React, {useState} from 'react';
import {Text} from '../src/Text';
import {User} from '@react-aria/test-utils';
import userEvent from '@testing-library/user-event';
import {Virtualizer} from '../src/Virtualizer';

let renderEmptyState = () => {
  return <div>No results</div>;
};

let TestComboBox = props => (
  <ComboBox name="test-combobox" defaultInputValue="C" data-foo="bar" {...props}>
    <Label>Favorite Animal</Label>
    <Input />
    <Button />
    {props.selectionMode === 'multiple' && <ComboBoxValue placeholder="No items selected" />}
    <Text slot="description">Description</Text>
    <Text slot="errorMessage">Error</Text>
    <Popover>
      <ListBox renderEmptyState={renderEmptyState}>
        <ListBoxItem id="1">Cat</ListBoxItem>
        <ListBoxItem id="2">Dog</ListBoxItem>
        <ListBoxItem id="3">Kangaroo</ListBoxItem>
        <ListBoxLoadMoreItem>loading</ListBoxLoadMoreItem>
      </ListBox>
    </Popover>
  </ComboBox>
);

describe('ComboBox', () => {
  let user;
  let testUtilUser = new User();
  beforeAll(() => {
    jest.useFakeTimers();
    user = userEvent.setup({delay: null, pointerMap});
  });

  afterEach(() => {
    jest.clearAllMocks();
    act(() => jest.runAllTimers());
  });

  it('provides slots', async () => {
    let {getByRole} = render(<TestComboBox />);

    let input = getByRole('combobox');
    expect(input).toHaveValue('C');

    let combobox = input.closest('.react-aria-ComboBox');
    expect(combobox).toHaveAttribute('data-foo', 'bar');

    expect(input).toHaveAttribute('aria-labelledby');
    let label = document.getElementById(input.getAttribute('aria-labelledby').split(' ')[0]);
    expect(label).toHaveAttribute('class', 'react-aria-Label');
    expect(label).toHaveTextContent('Favorite Animal');

    expect(input).toHaveAttribute('aria-describedby');
    expect(
      input
        .getAttribute('aria-describedby')
        .split(' ')
        .map(id => document.getElementById(id).textContent)
        .join(' ')
    ).toBe('Description Error');

    let button = getByRole('button');
    await user.click(button);

    let listbox = getByRole('listbox');
    expect(listbox).toHaveAttribute('class', 'react-aria-ListBox');
    expect(listbox.closest('.react-aria-Popover')).toBeInTheDocument();
    expect(listbox.closest('.react-aria-Popover')).toHaveAttribute('data-trigger', 'ComboBox');

    let options = within(listbox).getAllByRole('option');
    expect(options).toHaveLength(3);

    await user.click(options[1]);
    expect(input).toHaveValue('Dog');
  });

  it('should support slot', () => {
    let {getByRole} = render(
      <ComboBoxContext.Provider value={{slots: {test: {'aria-label': 'test'}}}}>
        <TestComboBox slot="test" />
      </ComboBoxContext.Provider>
    );

    let combobox = getByRole('combobox');
    expect(combobox.closest('.react-aria-ComboBox')).toHaveAttribute('slot', 'test');
    expect(combobox).toHaveAttribute('aria-label', 'test');
  });

  it('should support custom render function', () => {
    let {getByRole} = render(
      <TestComboBox render={props => <div {...props} data-custom="true" />} />
    );
    let field = getByRole('combobox').closest('.react-aria-ComboBox');
    expect(field).toHaveAttribute('data-custom', 'true');
  });

  it('should apply isPressed state to button when expanded', async () => {
    let {getByRole} = render(<TestComboBox />);
    let button = getByRole('button');

    expect(button).not.toHaveAttribute('data-pressed');
    await user.click(button);
    expect(button).toHaveAttribute('data-pressed');
  });

  it('should support filtering sections', async () => {
    let tree = render(
      <ComboBox>
        <Label>Preferred fruit or vegetable</Label>
        <Input />
        <Button />
        <Popover>
          <ListBox>
            <ListBoxSection>
              <Header>Fruit</Header>
              <ListBoxItem id="Apple">Apple</ListBoxItem>
              <ListBoxItem id="Banana">Banana</ListBoxItem>
            </ListBoxSection>
            <ListBoxSection>
              <Header>Vegetable</Header>
              <ListBoxItem id="Cabbage">Cabbage</ListBoxItem>
              <ListBoxItem id="Broccoli">Broccoli</ListBoxItem>
            </ListBoxSection>
          </ListBox>
        </Popover>
      </ComboBox>
    );

    let comboboxTester = testUtilUser.createTester('ComboBox', {root: tree.container});
    act(() => {
      comboboxTester.getCombobox().focus();
    });
    await user.keyboard('p');

    let groups = comboboxTester.getSections();
    expect(groups).toHaveLength(1);
    expect(groups[0]).toHaveAttribute('aria-labelledby');
    expect(document.getElementById(groups[0].getAttribute('aria-labelledby'))).toHaveTextContent(
      'Fruit'
    );

    let options = within(groups[0]).getAllByRole('option');
    expect(options).toHaveLength(1);
  });

  it('should support undefined defaultFilter', async () => {
    let tree = render(
      <ComboBox defaultFilter={undefined}>
        <Label>Preferred fruit or vegetable</Label>
        <Input />
        <Button />
        <Popover>
          <ListBox>
            <ListBoxSection>
              <Header>Fruit</Header>
              <ListBoxItem id="Apple">Apple</ListBoxItem>
              <ListBoxItem id="Banana">Banana</ListBoxItem>
            </ListBoxSection>
            <ListBoxSection>
              <Header>Vegetable</Header>
              <ListBoxItem id="Cabbage">Cabbage</ListBoxItem>
              <ListBoxItem id="Broccoli">Broccoli</ListBoxItem>
            </ListBoxSection>
          </ListBox>
        </Popover>
      </ComboBox>
    );

    let comboboxTester = testUtilUser.createTester('ComboBox', {root: tree.container});
    act(() => {
      comboboxTester.getCombobox().focus();
    });
    await user.keyboard('p');

    let groups = comboboxTester.getSections();
    expect(groups).toHaveLength(1);
    expect(groups[0]).toHaveAttribute('aria-labelledby');
    expect(document.getElementById(groups[0].getAttribute('aria-labelledby'))).toHaveTextContent(
      'Fruit'
    );

    let options = within(groups[0]).getAllByRole('option');
    expect(options).toHaveLength(1);
  });

  it('should support dynamic collections', async () => {
    let defaultItems = [
      {id: 1, name: 'Cat'},
      {id: 2, name: 'Dog'},
      {id: 3, name: 'Kangaroo'}
    ];
    let tree = render(
      <ComboBox defaultItems={defaultItems}>
        <Label>Favorite Animal</Label>
        <Input />
        <Button />
        <Text slot="description">Description</Text>
        <Text slot="errorMessage">Error</Text>
        <Popover>
          <ListBox>{item => <ListBoxItem>{item.name}</ListBoxItem>}</ListBox>
        </Popover>
      </ComboBox>
    );

    let comboboxTester = testUtilUser.createTester('ComboBox', {root: tree.container});
    act(() => {
      comboboxTester.getCombobox().focus();
    });
    await user.keyboard('c');
    let options = comboboxTester.getOptions();
    expect(options).toHaveLength(1);
  });

  it('should support render props', async () => {
    let {getByRole} = render(
      <ComboBox>
        {({isOpen}) => (
          <>
            <Label>Favorite Animal</Label>
            <Input />
            <Button>{isOpen ? 'close' : 'open'}</Button>
            <Popover>
              <ListBox>
                <ListBoxItem>Cat</ListBoxItem>
                <ListBoxItem>Dog</ListBoxItem>
                <ListBoxItem>Kangaroo</ListBoxItem>
              </ListBox>
            </Popover>
          </>
        )}
      </ComboBox>
    );

    let button = getByRole('button');
    expect(button).toHaveTextContent('open');

    await user.click(button);
    expect(button).toHaveTextContent('close');
  });

  it('should support formValue', () => {
    let {getByRole, rerender} = render(<TestComboBox name="test" value="2" />);
    let input = getByRole('combobox');
    expect(input).not.toHaveAttribute('name');
    expect(input).toHaveValue('Dog');
    let hiddenInput = document.querySelector('input[type=hidden]');
    expect(hiddenInput).toHaveAttribute('name', 'test');
    expect(hiddenInput).toHaveValue('2');

    rerender(<TestComboBox name="test" formValue="text" value="2" />);
    expect(input).toHaveAttribute('name', 'test');
    expect(document.querySelector('input[type=hidden]')).toBeNull();
  });

  it('should support selecting an option via keyboard', async () => {
    let onSelectionChange = jest.fn();
    let tree = render(
      <ComboBox onSelectionChange={onSelectionChange}>
        <Label>Favorite Animal</Label>
        <Input />
        <Button />
        <Popover>
          <ListBox>
            <ListBoxItem id="1">Cat</ListBoxItem>
            <ListBoxItem id="2">Dog</ListBoxItem>
            <ListBoxItem id="3">Kangaroo</ListBoxItem>
          </ListBox>
        </Popover>
      </ComboBox>
    );
    let comboboxTester = testUtilUser.createTester('ComboBox', {
      root: tree.container,
      interactionType: 'keyboard'
    });

    await comboboxTester.toggleOptionSelection({option: 'Dog'});
    expect(onSelectionChange).toHaveBeenCalledWith('2');
    expect(comboboxTester.getCombobox()).toHaveValue('Dog');
    expect(comboboxTester.getListbox()).toBeNull();
  });

  it.each(['click', 'tab'])(
    'should not fire extra onSelectionChange calls after focus moves away in fully controlled mode via %s',
    async focusMove => {
      let onSelectionChange = jest.fn();
      let keyToText = {
        1: 'Cat',
        2: 'Dog',
        3: 'Kangaroo'
      };

      function ControlledComboBox() {
        let [selectedKey, setSelectedKey] = useState(null);
        let [inputValue, setInputValue] = useState('');

        return (
          <>
            <ComboBox
              value={selectedKey}
              inputValue={inputValue}
              onChange={key => {
                onSelectionChange(key);
                setSelectedKey(key);
                setInputValue(key != null ? keyToText[key] : '');
              }}
              onInputChange={setInputValue}>
              <Label>Favorite Animal</Label>
              <Input />
              <Button />
              <Popover>
                <ListBox>
                  <ListBoxItem id="1">Cat</ListBoxItem>
                  <ListBoxItem id="2">Dog</ListBoxItem>
                  <ListBoxItem id="3">Kangaroo</ListBoxItem>
                </ListBox>
              </Popover>
            </ComboBox>
            <button type="button">Next</button>
          </>
        );
      }

      let tree = render(<ControlledComboBox />);
      let comboboxTester = testUtilUser.createTester('ComboBox', {root: tree.container});

      await comboboxTester.toggleOptionSelection({option: 'Dog'});
      expect(onSelectionChange).toHaveBeenCalledTimes(1);

      if (focusMove === 'click') {
        await user.click(tree.getByRole('button', {name: 'Next'}));
      } else {
        act(() => {
          comboboxTester.getCombobox().focus();
        });
        await user.tab();
      }

      expect(onSelectionChange).toHaveBeenCalledTimes(1);
    }
  );

  it('should support form reset', async () => {
    const tree = render(
      <form>
        <ComboBox defaultValue="2" name="combobox">
          <Label>Favorite Animal</Label>
          <Input />
          <Button />
          <FieldError />
          <Popover>
            <ListBox>
              <ListBoxItem id="1">Cat</ListBoxItem>
              <ListBoxItem id="2">Dog</ListBoxItem>
              <ListBoxItem id="3">Kangaroo</ListBoxItem>
            </ListBox>
          </Popover>
        </ComboBox>
        <input type="reset" />
      </form>
    );

    const comboboxTester = testUtilUser.createTester('ComboBox', {root: tree.container});
    const combobox = comboboxTester.getCombobox();

    expect(combobox).toHaveValue('Dog');
    await comboboxTester.open();

    const options = comboboxTester.getOptions();
    await user.click(options[0]);
    expect(combobox).toHaveValue('Cat');

    await user.click(document.querySelector('input[type="reset"]'));
    expect(combobox).toHaveValue('Dog');
    expect(document.querySelector('input[name=combobox]')).toHaveValue('2');
  });

  it('should render data- attributes on outer element', () => {
    let {getAllByTestId} = render(<TestComboBox data-testid="combo-box" />);
    let outerEl = getAllByTestId('combo-box');
    expect(outerEl).toHaveLength(1);
    expect(outerEl[0]).toHaveClass('react-aria-ComboBox');
  });

  it('should support validation errors', async () => {
    let tree = render(
      <form data-testid="form">
        <ComboBox isRequired>
          <Label>Favorite Animal</Label>
          <Input />
          <Button />
          <FieldError />
          <Popover>
            <ListBox>
              <ListBoxItem id="1">Cat</ListBoxItem>
              <ListBoxItem id="2">Dog</ListBoxItem>
              <ListBoxItem id="3">Kangaroo</ListBoxItem>
            </ListBox>
          </Popover>
        </ComboBox>
      </form>
    );

    let comboboxTester = testUtilUser.createTester('ComboBox', {root: tree.container});
    let combobox = comboboxTester.getCombobox();

    expect(combobox).toHaveAttribute('required');
    expect(combobox).not.toHaveAttribute('aria-required');
    expect(combobox).not.toHaveAttribute('aria-describedby');
    expect(combobox.validity.valid).toBe(false);
    expect(combobox).not.toHaveAttribute('data-invalid');

    act(() => {
      tree.getByTestId('form').checkValidity();
    });

    expect(document.activeElement).toBe(combobox);
    expect(combobox).toHaveAttribute('aria-describedby');
    expect(document.getElementById(combobox.getAttribute('aria-describedby'))).toHaveTextContent(
      'Constraints not satisfied'
    );
    let comboboxWrapper = combobox.closest('.react-aria-ComboBox');
    expect(comboboxWrapper).toHaveAttribute('data-invalid');

    act(() => {
      comboboxTester.getCombobox().focus();
    });
    await user.keyboard('C');

    let options = comboboxTester.getOptions();
    await user.click(options[0]);

    expect(combobox).toHaveAttribute('aria-describedby');
    expect(combobox.validity.valid).toBe(true);

    await user.tab();
    expect(combobox).not.toHaveAttribute('aria-describedby');
    expect(combobox).not.toHaveAttribute('data-invalid');
  });

  it('should close on scroll', async () => {
    let {getByRole} = render(<TestComboBox />);

    let button = getByRole('button');
    await user.click(button);
    let listbox = getByRole('listbox');
    expect(listbox).toBeInTheDocument();
    fireEvent.scroll(document.body);
    expect(listbox).not.toBeInTheDocument();
  });

  it('should not close on input scrolling for cursor placement', async () => {
    let {getByRole} = render(<TestComboBox />);

    let input = getByRole('combobox');
    let button = getByRole('button');
    await user.click(button);
    let listbox = getByRole('listbox');
    expect(listbox).toBeInTheDocument();
    expect(input).toHaveFocus();
    fireEvent.scroll(input); // simulate what happens when the text is long and overflows
    expect(listbox).toBeInTheDocument();
  });

  it('should not open the menu when isReadOnly', async () => {
    let {getByRole, queryByRole} = render(<TestComboBox isReadOnly menuTrigger="focus" />);

    let input = getByRole('combobox');
    await user.click(input);

    expect(queryByRole('listbox')).not.toBeInTheDocument();
  });

  it('should support virtualizer', async () => {
    let items = [];
    for (let i = 0; i < 50; i++) {
      items.push({id: i, name: 'Item ' + i});
    }

    jest.restoreAllMocks(); // don't mock scrollTop for this test
    jest.spyOn(window.HTMLElement.prototype, 'clientWidth', 'get').mockImplementation(() => 100);
    jest.spyOn(window.HTMLElement.prototype, 'clientHeight', 'get').mockImplementation(() => 100);

    let tree = render(
      <ComboBox>
        <Label style={{display: 'block'}}>Test</Label>
        <div style={{display: 'flex'}}>
          <Input />
          <Button>
            <span aria-hidden="true" style={{padding: '0 2px'}}>
              ▼
            </span>
          </Button>
        </div>
        <Popover>
          <Virtualizer layout={ListLayout} layoutOptions={{rowHeight: 25}}>
            <ListBox items={items}>{item => <ListBoxItem>{item.name}</ListBoxItem>}</ListBox>
          </Virtualizer>
        </Popover>
      </ComboBox>
    );

    let comboboxTester = testUtilUser.createTester('ComboBox', {root: tree.container});
    expect(comboboxTester.getListbox()).toBeFalsy();
    comboboxTester.setInteractionType('mouse');
    await comboboxTester.open();

    expect(comboboxTester.getOptions()).toHaveLength(7);
  });

  it('should clear contexts inside popover', async () => {
    let tree = render(
      <ComboBox>
        <Label>Preferred fruit or vegetable</Label>
        <Input />
        <Button />
        <Popover data-testid="popover">
          <Label>Hello</Label>
          <Button>Yo</Button>
          <Input />
          <Text>hi</Text>
          <ListBox>
            <ListBoxItem id="cat">Cat</ListBoxItem>
            <ListBoxItem id="dog">Dog</ListBoxItem>
            <ListBoxItem id="kangaroo">Kangaroo</ListBoxItem>
          </ListBox>
        </Popover>
      </ComboBox>
    );

    let selectTester = testUtilUser.createTester('Select', {root: tree.container});

    await selectTester.open();

    let popover = await tree.getByTestId('popover');
    let label = popover.querySelector('.react-aria-Label');
    expect(label).not.toHaveAttribute('for');

    let button = popover.querySelector('.react-aria-Button');
    expect(button).not.toHaveAttribute('aria-expanded');

    let input = popover.querySelector('.react-aria-Input');
    expect(input).not.toHaveAttribute('role');

    let text = popover.querySelector('.react-aria-Text');
    expect(text).not.toHaveAttribute('id');
  });

  it('should support form prop', () => {
    let {getByRole} = render(<TestComboBox form="test" />);
    let input = getByRole('combobox');
    expect(input).toHaveAttribute('form', 'test');
  });

  it('should render empty state even when there is a loader provided and allowsEmptyCollection is true', async () => {
    let tree = render(<TestComboBox allowsEmptyCollection />);

    let comboboxTester = testUtilUser.createTester('ComboBox', {root: tree.container});
    act(() => {
      comboboxTester.getCombobox().focus();
    });
    await user.keyboard('p');

    let options = comboboxTester.getOptions();
    expect(options).toHaveLength(1);
    expect(comboboxTester.getListbox()).toBeTruthy();
    expect(options[0]).toHaveTextContent('No results');
  });

  it.each(['keyboard', 'mouse'])('should support onAction with %s', async interactionType => {
    let onAction = jest.fn();
    function WithCreateOption() {
      let [inputValue, setInputValue] = useState('');

      return (
        <ComboBox allowsEmptyCollection inputValue={inputValue} onInputChange={setInputValue}>
          <Label style={{display: 'block'}}>Favorite Animal</Label>
          <div style={{display: 'flex'}}>
            <Input />
            <Button>
              <span aria-hidden="true" style={{padding: '0 2px'}}>
                ▼
              </span>
            </Button>
          </div>
          <Popover placement="bottom end">
            <ListBox>
              {inputValue.length > 0 && (
                <ListBoxItem onAction={onAction}>{`Create "${inputValue}"`}</ListBoxItem>
              )}
              <ListBoxItem>Aardvark</ListBoxItem>
              <ListBoxItem>Cat</ListBoxItem>
              <ListBoxItem>Dog</ListBoxItem>
              <ListBoxItem>Kangaroo</ListBoxItem>
              <ListBoxItem>Panda</ListBoxItem>
              <ListBoxItem>Snake</ListBoxItem>
            </ListBox>
          </Popover>
        </ComboBox>
      );
    }

    let tree = render(<WithCreateOption />);
    let comboboxTester = testUtilUser.createTester('ComboBox', {root: tree.container});
    act(() => {
      comboboxTester.getCombobox().focus();
    });

    await user.keyboard('L');

    let options = comboboxTester.getOptions();
    expect(options).toHaveLength(1);
    expect(options[0]).toHaveTextContent('Create "L"');

    if (interactionType === 'keyboard') {
      await user.keyboard('{ArrowDown}{Enter}');
    } else {
      await user.click(options[0]);
    }
    expect(onAction).toHaveBeenCalledTimes(1);
    expect(comboboxTester.getCombobox()).toHaveValue('');

    // Repeat with an option selected.
    await comboboxTester.toggleOptionSelection({option: 'Cat'});

    await user.keyboard('s');

    options = comboboxTester.getOptions();
    expect(options).toHaveLength(1);
    expect(options[0]).toHaveTextContent('Create "Cats"');

    if (interactionType === 'keyboard') {
      await user.keyboard('{ArrowDown}{Enter}');
    } else {
      await user.click(options[0]);
    }
    expect(onAction).toHaveBeenCalledTimes(2);
    expect(comboboxTester.getCombobox()).toHaveValue('Cat');
  });

  it('should not close the combobox when clicking on a section header', async () => {
    let tree = render(
      <ComboBox>
        <Label>Preferred fruit or vegetable</Label>
        <Input />
        <Button />
        <Popover>
          <ListBox>
            <ListBoxSection>
              <Header>Fruit</Header>
              <ListBoxItem id="Apple">Apple</ListBoxItem>
              <ListBoxItem id="Banana">Banana</ListBoxItem>
            </ListBoxSection>
            <ListBoxSection>
              <Header>Vegetable</Header>
              <ListBoxItem id="Cabbage">Cabbage</ListBoxItem>
              <ListBoxItem id="Broccoli">Broccoli</ListBoxItem>
            </ListBoxSection>
          </ListBox>
        </Popover>
      </ComboBox>
    );

    let comboboxTester = testUtilUser.createTester('ComboBox', {root: tree.container});
    let button = tree.getByRole('button');

    // Open the combobox
    await user.click(button);
    act(() => {
      jest.runAllTimers();
    });

    // Verify the listbox is open
    let listbox = tree.getByRole('listbox');
    expect(listbox).toBeInTheDocument();
    expect(listbox).toBeVisible();

    // Find and click on a section header
    let fruitHeader = tree.getByText('Fruit');
    expect(fruitHeader).toBeInTheDocument();

    await user.click(fruitHeader);
    act(() => {
      jest.runAllTimers();
    });

    // Verify the listbox is still open
    listbox = tree.getByRole('listbox');
    expect(listbox).toBeInTheDocument();
    expect(listbox).toBeVisible();

    // Verify we can still interact with options
    let options = comboboxTester.getOptions();
    expect(options.length).toBeGreaterThan(0);

    // Click an option
    await user.click(options[0]);
    act(() => {
      jest.runAllTimers();
    });

    // Verify the combobox is closed and the value is updated
    expect(tree.queryByRole('listbox')).toBeNull();
    expect(comboboxTester.getCombobox()).toHaveValue('Apple');
  });

  it('should support multiple selection', async () => {
    let onChange = jest.fn();
    let {container, getByTestId} = render(
      <Form data-testid="form">
        <TestComboBox
          name="combobox"
          selectionMode="multiple"
          defaultInputValue=""
          onChange={onChange}
        />
        <input type="reset" />
      </Form>
    );
    let comboboxTester = testUtilUser.createTester('ComboBox', {root: container});
    let value = container.querySelector('.react-aria-ComboBoxValue');

    expect(value).toHaveTextContent('No items selected');
    expect(comboboxTester.getCombobox().getAttribute('aria-describedby')).toContain(value.id);

    expect(comboboxTester.getCombobox()).toHaveValue('');
    await comboboxTester.open();

    let listbox = comboboxTester.getListbox();
    expect(listbox).toHaveAttribute('aria-multiselectable', 'true');

    let options = comboboxTester.getOptions();
    expect(options).toHaveLength(3);

    await comboboxTester.toggleOptionSelection({option: options[0]});
    expect(options[0]).toHaveAttribute('aria-selected', 'true');
    expect(comboboxTester.getCombobox()).toHaveValue('');
    expect(comboboxTester.getListbox()).toBeInTheDocument();
    expect(value).toHaveTextContent('Cat');
    await comboboxTester.toggleOptionSelection({option: options[1]});
    expect(options[1]).toHaveAttribute('aria-selected', 'true');
    expect(comboboxTester.getCombobox()).toHaveValue('');
    expect(comboboxTester.getListbox()).toBeInTheDocument();
    expect(value).toHaveTextContent('Cat and Dog');
    await comboboxTester.close();

    expect(onChange).toHaveBeenCalledTimes(2);
    expect(onChange).toHaveBeenLastCalledWith(['1', '2']);

    let formData = new FormData(getByTestId('form'));
    expect(formData.getAll('combobox')).toEqual(['1', '2']);

    await user.click(document.querySelector('input[type="reset"]'));
    expect(comboboxTester.getCombobox()).toHaveValue('');
    formData = new FormData(getByTestId('form'));
    expect(formData.getAll('combobox')).toEqual(['']);
  });

  it('should support deselection if multiple selection is enabled', async () => {
    let onChange = jest.fn();
    let {container} = render(
      <TestComboBox
        name="combobox"
        selectionMode="multiple"
        defaultInputValue=""
        onChange={onChange}
      />
    );
    let comboboxTester = testUtilUser.createTester('ComboBox', {root: container});

    await comboboxTester.toggleOptionSelection({option: 'Cat'});
    await comboboxTester.toggleOptionSelection({option: 'Dog'});
    expect(comboboxTester.getOptions()[0]).toHaveAttribute('aria-selected', 'true');
    expect(comboboxTester.getOptions()[1]).toHaveAttribute('aria-selected', 'true');
    expect(onChange).toHaveBeenLastCalledWith(['1', '2']);

    await comboboxTester.toggleOptionSelection({option: 'Cat'});
    expect(comboboxTester.getOptions()[0]).toHaveAttribute('aria-selected', 'false');
    expect(comboboxTester.getOptions()[1]).toHaveAttribute('aria-selected', 'true');
    expect(onChange).toHaveBeenLastCalledWith(['2']);

    await comboboxTester.toggleOptionSelection({option: 'Dog'});
    expect(comboboxTester.getOptions()[0]).toHaveAttribute('aria-selected', 'false');
    expect(comboboxTester.getOptions()[1]).toHaveAttribute('aria-selected', 'false');
    expect(onChange).toHaveBeenLastCalledWith([]);

    await comboboxTester.close();
  });

  it('should support controlled multi-selection', async () => {
    let {container} = render(
      <TestComboBox selectionMode="multiple" defaultInputValue={undefined} value={['2', '3']} />
    );

    let comboboxTester = testUtilUser.createTester('ComboBox', {root: container});
    expect(comboboxTester.getCombobox()).toHaveValue('');
    await comboboxTester.open();

    let options = comboboxTester.getOptions();
    expect(options[0]).toHaveAttribute('aria-selected', 'false');
    expect(options[1]).toHaveAttribute('aria-selected', 'true');
    expect(options[2]).toHaveAttribute('aria-selected', 'true');
  });

  it('should support controlled multi-selection with both inputValue and value controlled', async () => {
    let onChange = jest.fn();
    let onInputChange = jest.fn();
    let {container} = render(
      <TestComboBox
        selectionMode="multiple"
        defaultInputValue={undefined}
        inputValue="C"
        onInputChange={onInputChange}
        value={['2', '3']}
        onChange={onChange}
      />
    );

    let comboboxTester = testUtilUser.createTester('ComboBox', {root: container});
    let combobox = comboboxTester.getCombobox();
    expect(combobox).toHaveValue('C');
    await comboboxTester.open();

    await user.keyboard('a');

    act(() => {
      jest.runAllTimers();
    });

    expect(combobox).toHaveValue('C');
    expect(onInputChange).toHaveBeenCalledTimes(1);
    expect(onInputChange).toHaveBeenCalledWith('Ca');
    expect(onChange).not.toHaveBeenCalled();

    await user.keyboard('{Enter}');

    expect(combobox).toHaveValue('C');
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(['3']);
  });

  it('should support multi-select with custom value', async () => {
    // allowsCustomValue doesn't really make sense to use with multi-selection, but test it anyway.
    let {container} = render(<TestComboBox selectionMode="multiple" allowsCustomValue />);
    let comboboxTester = testUtilUser.createTester('ComboBox', {root: container});

    await user.tab();
    await user.keyboard('Test');
    expect(comboboxTester.getCombobox()).toHaveValue('Test');

    await user.tab();
    expect(comboboxTester.getCombobox()).toHaveValue('Test');
  });

  it.each(['{Escape}', '{Enter}', '{Tab}'])(
    'should preserve multi-select value with custom input on %s',
    async key => {
      let {container, queryByRole} = render(
        <TestComboBox
          selectionMode="multiple"
          allowsCustomValue
          defaultValue={['1', '2']}
          defaultInputValue=""
        />
      );
      let comboboxTester = testUtilUser.createTester('ComboBox', {root: container});
      let value = container.querySelector('.react-aria-ComboBoxValue');

      expect(value).toHaveTextContent('Cat and Dog');

      await user.tab();
      await user.keyboard('Den');
      expect(comboboxTester.getCombobox()).toHaveValue('Den');

      await user.keyboard(key);

      expect(queryByRole('listbox')).toBeNull();
      expect(comboboxTester.getCombobox()).toHaveValue('Den');
      expect(value).toHaveTextContent('Cat and Dog');
    }
  );

  it('should allow the user to deselect items with keyboard when multiselect (uncontrolled)', async () => {
    let onChange = jest.fn();
    let {container} = render(
      <TestComboBox defaultValue={['1', '2']} selectionMode="multiple" onChange={onChange} />
    );

    let comboboxTester = testUtilUser.createTester('ComboBox', {root: container});
    await comboboxTester.open();

    await user.keyboard('{Enter}');
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenLastCalledWith(['2']);

    await user.keyboard('{ArrowDown}{Enter}');
    expect(onChange).toHaveBeenCalledTimes(2);
    expect(onChange).toHaveBeenLastCalledWith([]);
  });

  it('should allow the user to deselect items with keyboard when multiselect (controlled)', async () => {
    let onChange = jest.fn();
    let {container} = render(
      <TestComboBox value={['1', '2']} selectionMode="multiple" onChange={onChange} />
    );

    let comboboxTester = testUtilUser.createTester('ComboBox', {root: container});
    await comboboxTester.open();

    await user.keyboard('{Enter}');
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenLastCalledWith(['2']);

    await user.keyboard('{ArrowDown}{Enter}');
    expect(onChange).toHaveBeenCalledTimes(2);
    expect(onChange).toHaveBeenLastCalledWith(['1']);
  });

  it('should support isRequired with multiple selection', async () => {
    let {container, getByTestId} = render(
      <Form data-testid="form">
        <ComboBox name="combobox" selectionMode="multiple" isRequired>
          <Label>Favorite Animal</Label>
          <Input />
          <Button />
          <FieldError />
          <Popover>
            <ListBox>
              <ListBoxItem id="1">Cat</ListBoxItem>
              <ListBoxItem id="2">Dog</ListBoxItem>
              <ListBoxItem id="3">Kangaroo</ListBoxItem>
            </ListBox>
          </Popover>
        </ComboBox>
      </Form>
    );
    let comboboxTester = testUtilUser.createTester('ComboBox', {root: container});
    let combobox = comboboxTester.getCombobox();

    expect(combobox).toHaveAttribute('required');
    expect(combobox.validity.valid).toBe(false);

    act(() => {
      getByTestId('form').checkValidity();
    });
    expect(combobox).toHaveAttribute('aria-describedby');
    expect(container.querySelector('.react-aria-ComboBox')).toHaveAttribute('data-invalid');

    await comboboxTester.open();
    let options = comboboxTester.getOptions();
    await user.click(options[0]);

    act(() => combobox.blur());
    expect(combobox).not.toHaveAttribute('required');
    expect(combobox.validity.valid).toBe(true);
    expect(container.querySelector('.react-aria-ComboBox')).not.toHaveAttribute('data-invalid');

    let hiddenInputs = container.querySelectorAll('input[type="hidden"]');
    expect(hiddenInputs).toHaveLength(1);
    expect(hiddenInputs[0]).toHaveAttribute('name', 'combobox');
    expect(hiddenInputs[0]).toHaveAttribute('value', '1');

    await comboboxTester.open();
    options = comboboxTester.getOptions();
    await user.click(options[0]);
    act(() => combobox.blur());
    expect(combobox).toHaveAttribute('required');
    expect(combobox.validity.valid).toBe(false);
    expect(combobox).toHaveAttribute('aria-describedby');

    hiddenInputs = container.querySelectorAll('input[type="hidden"]');
    expect(hiddenInputs).toHaveLength(1);
    expect(hiddenInputs[0]).toHaveAttribute('name', 'combobox');
    expect(hiddenInputs[0]).toHaveAttribute('value', '');
  });

  it('should not close the combobox when clicking on the input', async () => {
    let onOpenChange = jest.fn();
    let {container, getByRole} = render(<TestComboBox onOpenChange={onOpenChange} />);
    let comboboxTester = testUtilUser.createTester('ComboBox', {root: container});
    await comboboxTester.open();
    act(() => {
      jest.runAllTimers();
    });
    expect(comboboxTester.getListbox()).toBeVisible();
    expect(comboboxTester.getCombobox()).toHaveFocus();
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    onOpenChange.mockClear();

    await user.click(getByRole('combobox'));
    act(() => {
      jest.runAllTimers();
    });
    expect(comboboxTester.getListbox()).toBeVisible();
    expect(comboboxTester.getCombobox()).toHaveFocus();
    expect(onOpenChange).toHaveBeenCalledTimes(0);
  });

  it('should close the combobox when clicking on the button, and it should reopen if clicked again', async () => {
    let onOpenChange = jest.fn();
    let {container, getByRole, getAllByRole} = render(<TestComboBox onOpenChange={onOpenChange} />);
    let comboboxTester = testUtilUser.createTester('ComboBox', {root: container});
    await comboboxTester.open();
    act(() => {
      jest.runAllTimers();
    });
    expect(comboboxTester.getListbox()).toBeVisible();
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    onOpenChange.mockClear();

    await user.click(getAllByRole('button', {hidden: true})[0]);
    act(() => {
      jest.runAllTimers();
    });
    expect(comboboxTester.getListbox()).toBeNull();
    expect(comboboxTester.getCombobox()).toHaveFocus();
    expect(onOpenChange).toHaveBeenCalledTimes(1);
    onOpenChange.mockClear();

    await user.click(getByRole('button'));
    act(() => {
      jest.runAllTimers();
    });
    expect(comboboxTester.getListbox()).toBeVisible();
    expect(comboboxTester.getCombobox()).toHaveFocus();
    expect(onOpenChange).toHaveBeenCalledTimes(1);
  });

  it('should support read-only state', async () => {
    let {getByRole, rerender} = render(<TestComboBox />);

    let input = getByRole('combobox');

    expect(input.closest('.react-aria-ComboBox')).not.toHaveAttribute('data-readonly');
    rerender(<TestComboBox isReadOnly />);
    expect(input.closest('.react-aria-ComboBox')).toHaveAttribute('data-readonly');
  });

  it('should not throw when rendered inside a Dialog with a Text errorMessage slot', () => {
    render(
      <Dialog aria-label="Dialog">
        <TestComboBox isInvalid />
      </Dialog>
    );
  });

  it('should not throw when rendered inside an alertdialog with a Text errorMessage slot', () => {
    render(
      <Dialog role="alertdialog" aria-label="Dialog">
        <TestComboBox isInvalid />
      </Dialog>
    );
  });
});
