/*
 * Copyright 2022 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {
  act,
  installPointerEvent,
  pointerMap,
  render,
  within
} from '@react-spectrum/test-utils-internal';
import {CalendarDate} from '@internationalized/date';
import {DateField, DateFieldContext, DateInput, DateSegment} from '../src/DateField';
import {FieldError} from '../src/FieldError';
import {I18nProvider} from 'react-aria/I18nProvider';
import {Label} from '../src/Label';
import React from 'react';
import {Text} from '../src/Text';
import userEvent from '@testing-library/user-event';

describe('DateField', () => {
  installPointerEvent();

  let user;
  beforeAll(() => {
    user = userEvent.setup({delay: null, pointerMap});
  });

  it('provides slots', () => {
    let {getByRole, getAllByRole} = render(
      <DateField data-foo="bar">
        <Label>Birth date</Label>
        <DateInput data-bar="foo">
          {segment => <DateSegment segment={segment} data-test="test" />}
        </DateInput>
        <Text slot="description">Description</Text>
        <Text slot="errorMessage">Error</Text>
      </DateField>
    );

    let input = getByRole('group');
    expect(input).toHaveTextContent('mm/dd/yyyy');
    expect(input).toHaveAttribute('class', 'react-aria-DateInput');
    expect(input).toHaveAttribute('data-bar', 'foo');

    expect(input.closest('.react-aria-DateField')).toHaveAttribute('data-foo', 'bar');

    expect(input).toHaveAttribute('aria-labelledby');
    let label = document.getElementById(input.getAttribute('aria-labelledby'));
    expect(label).toHaveAttribute('class', 'react-aria-Label');
    expect(label).toHaveTextContent('Birth date');

    expect(input).toHaveAttribute('aria-describedby');
    expect(
      input
        .getAttribute('aria-describedby')
        .split(' ')
        .map(id => document.getElementById(id).textContent)
        .join(' ')
    ).toBe('Description Error');

    for (let segment of getAllByRole('spinbutton')) {
      expect(segment).toHaveAttribute('class', 'react-aria-DateSegment');
      expect(segment).toHaveAttribute('data-placeholder', 'true');
      expect(segment).toHaveAttribute('data-type');
      expect(segment).toHaveAttribute('data-test', 'test');
      expect(segment).not.toHaveAttribute('data-readonly');
    }

    for (let literal of [...input.children].filter(
      child => child.getAttribute('data-type') === 'literal'
    )) {
      expect(literal).not.toHaveAttribute('data-readonly');
    }
  });

  it('supports custom class names', () => {
    let {getByRole, getAllByRole} = render(
      <DateField className="date-field">
        <Label>Birth date</Label>
        <DateInput className="date-input">
          {segment => (
            <DateSegment
              segment={segment}
              className={({isPlaceholder}) => `segment ${isPlaceholder ? 'placeholder' : ''}`}
            />
          )}
        </DateInput>
      </DateField>
    );

    let input = getByRole('group');
    expect(input).toHaveAttribute('class', 'date-input');
    expect(input.closest('.date-field')).toBeInTheDocument();

    for (let segment of getAllByRole('spinbutton')) {
      expect(segment).toHaveAttribute('class', 'segment placeholder');
    }
  });

  it('should support slot', () => {
    let {getByRole} = render(
      <DateFieldContext.Provider value={{slots: {test: {'aria-label': 'test'}}}}>
        <DateField slot="test">
          <DateInput>{segment => <DateSegment segment={segment} />}</DateInput>
        </DateField>
      </DateFieldContext.Provider>
    );

    let group = getByRole('group');
    expect(group.closest('.react-aria-DateField')).toHaveAttribute('slot', 'test');
    expect(group).toHaveAttribute('aria-label', 'test');
  });

  it('should support custom render function', () => {
    let {getByRole, getAllByRole} = render(
      <DateField render={props => <div {...props} data-custom="true" />}>
        <Label render={props => <span {...props} data-custom="true" />}>Birth date</Label>
        <DateInput className="date-input" render={props => <div {...props} data-custom="true" />}>
          {segment => (
            <DateSegment
              segment={segment}
              render={props => <span {...props} data-custom="true" />}
            />
          )}
        </DateInput>
      </DateField>
    );
    let input = getByRole('group');
    expect(input).toHaveAttribute('data-custom', 'true');
    expect(input.closest('.react-aria-DateField')).toHaveAttribute('data-custom', 'true');
    expect(input.previousElementSibling).toHaveAttribute('data-custom', 'true');

    for (let segment of getAllByRole('spinbutton')) {
      expect(segment).toHaveAttribute('data-custom', 'true');
    }
  });

  it('should support hover state', async () => {
    let hoverStartSpy = jest.fn();
    let hoverChangeSpy = jest.fn();
    let hoverEndSpy = jest.fn();
    let {getByRole} = render(
      <DateField>
        <Label>Birth date</Label>
        <DateInput className={({isHovered}) => (isHovered ? 'hover' : '')}>
          {segment => (
            <DateSegment
              segment={segment}
              className={({isHovered}) => (isHovered ? 'hover' : '')}
              onHoverStart={hoverStartSpy}
              onHoverChange={hoverChangeSpy}
              onHoverEnd={hoverEndSpy}
            />
          )}
        </DateInput>
      </DateField>
    );
    let group = getByRole('group');

    expect(group).not.toHaveAttribute('data-hovered');
    expect(group).not.toHaveClass('hover');

    await user.hover(group);
    expect(group).toHaveAttribute('data-hovered', 'true');
    expect(group).toHaveClass('hover');

    await user.unhover(group);
    expect(group).not.toHaveAttribute('data-hovered');
    expect(group).not.toHaveClass('hover');

    let segments = within(group).getAllByRole('spinbutton');
    await user.hover(segments[0]);
    expect(segments[0]).toHaveAttribute('data-hovered', 'true');
    expect(segments[0]).toHaveClass('hover');
    expect(hoverStartSpy).toHaveBeenCalledTimes(1);
    expect(hoverChangeSpy).toHaveBeenCalledTimes(1);

    await user.unhover(segments[0]);
    expect(segments[0]).not.toHaveAttribute('data-hovered', 'true');
    expect(segments[0]).not.toHaveClass('hover');
    expect(hoverEndSpy).toHaveBeenCalledTimes(1);
    expect(hoverChangeSpy).toHaveBeenCalledTimes(2);
  });

  it('should support focus visible state', async () => {
    let {getByRole} = render(
      <DateField>
        <Label>Birth date</Label>
        <DateInput className={({isFocusVisible}) => (isFocusVisible ? 'focus' : '')}>
          {segment => (
            <DateSegment
              segment={segment}
              className={({isFocusVisible}) => (isFocusVisible ? 'focus' : '')}
            />
          )}
        </DateInput>
      </DateField>
    );
    let group = getByRole('group');

    expect(group).not.toHaveAttribute('data-focus-visible');
    expect(group).not.toHaveClass('focus');

    await user.tab();
    expect(document.activeElement).toBe(within(group).getAllByRole('spinbutton')[0]);
    expect(group).toHaveAttribute('data-focus-visible', 'true');
    expect(group).toHaveClass('focus');

    let segments = within(group).getAllByRole('spinbutton');
    expect(segments[0]).toHaveAttribute('data-focus-visible', 'true');
    expect(segments[0]).toHaveClass('focus');

    await user.tab({shift: true});
    expect(group).not.toHaveAttribute('data-focus-visible');
    expect(group).not.toHaveClass('focus');
    expect(segments[0]).not.toHaveAttribute('data-focus-visible', 'true');
    expect(segments[0]).not.toHaveClass('focus');
  });

  it('should support disabled state', () => {
    let {getByRole, getAllByRole} = render(
      <DateField isDisabled>
        <Label>Birth date</Label>
        <DateInput className={({isDisabled}) => (isDisabled ? 'disabled' : '')}>
          {segment => <DateSegment segment={segment} />}
        </DateInput>
      </DateField>
    );
    let group = getByRole('group');
    expect(group).toHaveAttribute('data-disabled');
    expect(group).toHaveClass('disabled');

    for (let segment of getAllByRole('spinbutton')) {
      expect(segment).not.toHaveAttribute('data-readonly');
      expect(segment).toHaveAttribute('data-disabled');
    }
    for (let literal of [...group.children].filter(
      child => child.getAttribute('data-type') === 'literal'
    )) {
      expect(literal).not.toHaveAttribute('data-readonly');
      expect(literal).toHaveAttribute('data-disabled');
    }
  });

  it('should support readonly with disabled state', () => {
    let {getByRole, getAllByRole} = render(
      <DateField isReadOnly isDisabled>
        <Label>Birth date</Label>
        <DateInput>{segment => <DateSegment segment={segment} />}</DateInput>
      </DateField>
    );

    let group = getByRole('group');
    expect(group).toHaveAttribute('data-readonly');
    expect(group).toHaveAttribute('data-disabled');

    for (let segment of getAllByRole('spinbutton')) {
      expect(segment).toHaveAttribute('data-readonly');
      expect(segment).toHaveAttribute('data-disabled');
    }
    for (let literal of [...group.children].filter(
      child => child.getAttribute('data-type') === 'literal'
    )) {
      expect(literal).toHaveAttribute('data-readonly');
      expect(literal).toHaveAttribute('data-disabled');
    }
  });

  it('should support readonly state', () => {
    let {getByRole, getAllByRole} = render(
      <DateField isReadOnly>
        <Label>Birth date</Label>
        <DateInput>{segment => <DateSegment segment={segment} />}</DateInput>
      </DateField>
    );

    let group = getByRole('group');
    expect(group).toHaveAttribute('data-readonly');
    expect(group).not.toHaveAttribute('data-disabled');
    expect(group).not.toHaveClass('disabled');

    for (let segment of getAllByRole('spinbutton')) {
      expect(segment).toHaveAttribute('data-readonly');
      expect(segment).not.toHaveAttribute('data-disabled');
    }
    for (let literal of [...group.children].filter(
      child => child.getAttribute('data-type') === 'literal'
    )) {
      expect(literal).toHaveAttribute('data-readonly');
      expect(literal).not.toHaveAttribute('data-disabled');
    }
  });

  it('should support render props', () => {
    let {getByRole} = render(
      <DateField
        minValue={new CalendarDate(2023, 1, 1)}
        defaultValue={new CalendarDate(2020, 2, 3)}
        validationBehavior="aria">
        {({isInvalid}) => (
          <>
            <Label>Birth date</Label>
            <DateInput data-validation-state={isInvalid ? 'invalid' : null}>
              {segment => <DateSegment segment={segment} />}
            </DateInput>
          </>
        )}
      </DateField>
    );
    let group = getByRole('group');
    expect(group).toHaveAttribute('data-validation-state', 'invalid');
  });

  it('should support disabled render prop', () => {
    let {getByRole} = render(
      <DateField isDisabled>
        {({isDisabled}) => (
          <>
            <Label>Birth date</Label>
            <DateInput data-disabled-state={isDisabled ? 'disabled' : null}>
              {segment => <DateSegment segment={segment} />}
            </DateInput>
          </>
        )}
      </DateField>
    );
    let group = getByRole('group');
    expect(group).toHaveAttribute('data-disabled-state', 'disabled');
  });

  it('should support required render prop', () => {
    let {getByRole} = render(
      <DateField isRequired>
        {({isRequired}) => (
          <>
            <Label>Birth date</Label>
            <DateInput data-required-state={isRequired ? 'required' : null}>
              {segment => <DateSegment segment={segment} />}
            </DateInput>
          </>
        )}
      </DateField>
    );
    let group = getByRole('group');
    expect(group).toHaveAttribute('data-required-state', 'required');
  });

  it('should support required state', () => {
    let {getByRole, rerender} = render(
      <DateField>
        <Label>Birth date</Label>
        <DateInput>{segment => <DateSegment segment={segment} />}</DateInput>
      </DateField>
    );
    let group = getByRole('group');
    expect(group.closest('.react-aria-DateField')).not.toHaveAttribute('data-required');
    rerender(
      <DateField isRequired>
        <Label>Birth date</Label>
        <DateInput>{segment => <DateSegment segment={segment} />}</DateInput>
      </DateField>
    );
    expect(group.closest('.react-aria-DateField')).toHaveAttribute('data-required');
  });

  it('should support form value', () => {
    render(
      <DateField name="birthday" form="test" value={new CalendarDate(2020, 2, 3)}>
        <Label>Birth date</Label>
        <DateInput>{segment => <DateSegment segment={segment} />}</DateInput>
      </DateField>
    );
    let input = document.querySelector('input[name=birthday]');
    expect(input).toHaveValue('2020-02-03');
    expect(input).toHaveAttribute('form', 'test');
  });

  it('should render data- attributes only on the outer element', () => {
    let {getAllByTestId} = render(
      <DateField data-testid="date-field">
        <Label>Birth Date</Label>
        <DateInput>{segment => <DateSegment segment={segment} />}</DateInput>
      </DateField>
    );
    let outerEl = getAllByTestId('date-field');
    expect(outerEl).toHaveLength(1);
    expect(outerEl[0]).toHaveClass('react-aria-DateField');
  });

  it('supports validation errors', async () => {
    let {getByRole, getByTestId} = render(
      <form data-testid="form">
        <DateField name="date" isRequired>
          <Label>Birth Date</Label>
          <DateInput>{segment => <DateSegment segment={segment} />}</DateInput>
          <FieldError />
        </DateField>
      </form>
    );

    let group = getByRole('group');
    let input = document.querySelector('input[name=date]');
    expect(input).toHaveAttribute('required');
    expect(input.validity.valid).toBe(false);
    expect(group).not.toHaveAttribute('aria-describedby');
    expect(group).not.toHaveAttribute('data-invalid');

    act(() => {
      getByTestId('form').checkValidity();
    });

    expect(group).toHaveAttribute('aria-describedby');
    let getDescription = () =>
      group
        .getAttribute('aria-describedby')
        .split(' ')
        .map(d => document.getElementById(d).textContent)
        .join(' ');
    expect(getDescription()).toContain('Constraints not satisfied');
    expect(group).toHaveAttribute('data-invalid');
    expect(document.activeElement).toBe(within(group).getAllByRole('spinbutton')[0]);

    await user.keyboard('[ArrowUp][Tab][ArrowUp][Tab][ArrowUp]');

    expect(getDescription()).toContain('Constraints not satisfied');
    expect(input.validity.valid).toBe(true);

    await user.tab();
    expect(getDescription()).not.toContain('Constraints not satisfied');
    expect(group).not.toHaveAttribute('data-invalid');
  });

  it('should use controlled validation first', async () => {
    let {getByRole, getByTestId} = render(
      <form data-testid="form">
        <DateField name="date" isRequired isInvalid={false}>
          <Label>Birth Date</Label>
          <DateInput>{segment => <DateSegment segment={segment} />}</DateInput>
          <FieldError />
        </DateField>
      </form>
    );

    let group = getByRole('group');
    let input = document.querySelector('input[name=date]');
    expect(input).toHaveAttribute('required');
    expect(input.validity.valid).toBe(false);
    expect(group).not.toHaveAttribute('aria-describedby');
    expect(group).not.toHaveAttribute('data-invalid');

    act(() => {
      getByTestId('form').checkValidity();
    });

    expect(input.validity.valid).toBe(false);
    expect(group).not.toHaveAttribute('aria-describedby');
    expect(group).not.toHaveAttribute('data-invalid');
  });

  it('should focus previous segment when backspacing on an empty date segment', async () => {
    let {getAllByRole} = render(
      <DateField defaultValue={new CalendarDate(2024, 12, 31)}>
        <Label>Birth date</Label>
        <DateInput>{segment => <DateSegment segment={segment} />}</DateInput>
      </DateField>
    );

    let segments = getAllByRole('spinbutton');
    await user.click(segments[2]);
    expect(document.activeElement).toBe(segments[2]);

    // Press backspace to delete '2024'
    for (let i = 0; i < 4; i++) {
      await user.keyboard('{backspace}');
    }
    expect(document.activeElement).toBe(segments[2]);
    await user.keyboard('{backspace}');
    expect(document.activeElement).toBe(segments[1]);

    // Press backspace to delete '31'
    for (let i = 0; i < 2; i++) {
      await user.keyboard('{backspace}');
    }
    expect(document.activeElement).toBe(segments[1]);
    await user.keyboard('{backspace}');
    expect(document.activeElement).toBe(segments[0]);
  });

  it('should support repeat keydown events when holding backspace across empty segments', async () => {
    // Backspace on an empty (placeholder) segment moves focus to the previous segment.
    let {getAllByRole} = render(
      <DateField>
        <Label>Birth date</Label>
        <DateInput>{segment => <DateSegment segment={segment} />}</DateInput>
      </DateField>
    );

    let segments = getAllByRole('spinbutton');
    await user.click(segments[2]);
    await user.keyboard('{Backspace>2/}');

    expect(document.activeElement).toBe(segments[0]);
  });

  it('should support repeat keydown events when holding an arrow key to navigate segments', async () => {
    // ArrowLeft/ArrowRight move between segments
    let {getAllByRole} = render(
      <DateField defaultValue={new CalendarDate(2024, 12, 31)}>
        <Label>Birth date</Label>
        <DateInput>{segment => <DateSegment segment={segment} />}</DateInput>
      </DateField>
    );

    let segments = getAllByRole('spinbutton');
    await user.click(segments[0]);
    await user.keyboard('{ArrowRight>2/}');

    expect(document.activeElement).toBe(segments[2]);
  });

  it('should do nothing when pressing enter', async () => {
    let {getAllByRole} = render(
      <DateField defaultValue={new CalendarDate(2024, 12, 31)}>
        <Label>Birth date</Label>
        <DateInput>{segment => <DateSegment segment={segment} />}</DateInput>
      </DateField>
    );

    let segments = getAllByRole('spinbutton');
    await user.click(segments[2]);
    expect(segments[2]).toHaveFocus();
    await user.keyboard('{Enter}');
    expect(segments[2]).toHaveFocus();
  });

  it('does not crash on unknown segment types', async () => {
    let {getByRole} = render(
      <I18nProvider locale="zh-CN-u-ca-chinese">
        <DateField defaultValue={new CalendarDate(2024, 12, 31)}>
          <Label>Birth date</Label>
          <DateInput>{segment => <DateSegment segment={segment} />}</DateInput>
        </DateField>
      </I18nProvider>
    );

    let segments = Array.from(getByRole('group').querySelectorAll('.react-aria-DateSegment'));
    let segmentTypes = segments.map(s => s.getAttribute('data-type'));
    expect(segmentTypes).toEqual(['year', 'literal', 'month', 'day']);
  });

  it('should support autofill', async () => {
    let {getByRole} = render(
      <DateField>
        <Label>Birth date</Label>
        <DateInput>{segment => <DateSegment segment={segment} />}</DateInput>
      </DateField>
    );

    let hiddenDateInput = document.querySelector('input[type=date]');
    await user.type(hiddenDateInput, '2000-05-30');
    let input = getByRole('group');
    expect(input).toHaveTextContent('5/30/2000');
  });

  it('should reset to placeholders when deleting a partially filled DateField', async () => {
    let {getAllByRole} = render(
      <DateField>
        <Label>Date</Label>
        <DateInput>{segment => <DateSegment segment={segment} />}</DateInput>
      </DateField>
    );

    let segements = getAllByRole('spinbutton');
    let monthSegment = segements[0];
    expect(monthSegment).toHaveTextContent('mm');
    await user.click(monthSegment);
    expect(monthSegment).toHaveFocus();
    await user.keyboard('11');
    expect(monthSegment).toHaveTextContent('11');

    await user.click(monthSegment);
    await user.keyboard('{backspace}');
    await user.keyboard('{backspace}');
    expect(monthSegment).toHaveTextContent('mm');
    expect(segements[1]).toHaveTextContent('dd');
    expect(segements[2]).toHaveTextContent('yyyy');
  });

  // Regression test for #10259: in Firefox a stale selection anchor can remain inside a segment
  // after focus moves away, and the selectionchange handler would collapse onto it, stealing focus.
  it('does not collapse the selection onto a segment while another element is focused', () => {
    let {getByRole} = render(
      <>
        <button>sibling</button>
        <DateField defaultValue={new CalendarDate(2020, 2, 3)}>
          <Label>Date</Label>
          <DateInput>{segment => <DateSegment segment={segment} />}</DateInput>
        </DateField>
      </>
    );

    let button = getByRole('button');
    let segment = within(getByRole('group')).getAllByRole('spinbutton').at(-1);
    act(() => button.focus());
    expect(document.activeElement).toBe(button);

    let collapse = jest.fn();
    jest.spyOn(window, 'getSelection').mockReturnValue({anchorNode: segment.firstChild, collapse});
    act(() => {
      document.dispatchEvent(new Event('selectionchange'));
    });

    expect(collapse).not.toHaveBeenCalled();
    jest.restoreAllMocks();
  });
});
