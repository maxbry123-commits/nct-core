import {getChildNodes, getFirstItem, getLastItem} from '../collections/getChildNodes';
import {GridNode, IGridCollection} from './GridCollection';
import {Key} from '@react-types/shared';
import {MultipleSelectionState} from '../selection/types';
import {
  MultipleSelectionStateProps,
  useMultipleSelectionState
} from '../selection/useMultipleSelectionState';
import {SelectionManager} from '../selection/SelectionManager';
import {useEffect, useMemo, useRef} from 'react';

export interface GridState<T, C extends IGridCollection<T>> {
  collection: C;
  /** A set of keys for rows that are disabled. */
  disabledKeys: Set<Key>;
  /** A selection manager to read and update row selection state. */
  selectionManager: SelectionManager;
  /**
   * Whether keyboard navigation is disabled, such as when the arrow keys should be handled by a
   * component within a cell.
   */
  isKeyboardNavigationDisabled: boolean;
}

export interface GridStateOptions<
  T,
  C extends IGridCollection<T>
> extends MultipleSelectionStateProps {
  collection: C;
  disabledKeys?: Iterable<Key>;
  focusMode?: 'row' | 'cell';
  /** @private - Do not use unless you know what you're doing. */
  UNSAFE_selectionState?: MultipleSelectionState;
}

/**
 * Provides state management for a grid component. Handles row selection and focusing a grid cell's
 * focusable child if applicable.
 */
export function useGridState<T extends object, C extends IGridCollection<T>>(
  props: GridStateOptions<T, C>
): GridState<T, C> {
  let {collection, focusMode} = props;
  // oxlint-disable-next-line react/react-compiler, react-hooks/rules-of-hooks
  let selectionState = props.UNSAFE_selectionState || useMultipleSelectionState(props);
  let disabledKeys = useMemo(
    () => (props.disabledKeys ? new Set(props.disabledKeys) : new Set<Key>()),
    [props.disabledKeys]
  );

  let setFocusedKey = selectionState.setFocusedKey;
  // oxlint-disable-next-line react/react-compiler
  selectionState.setFocusedKey = (key, child) => {
    // If focusMode is cell and an item is focused, focus a child cell instead.
    if (focusMode === 'cell' && key != null) {
      let item = collection.getItem(key);
      if (item?.type === 'item') {
        let children = getChildNodes(item, collection);
        if (child === 'last') {
          key = getLastItem(children)?.key ?? null;
        } else {
          key = getFirstItem(children)?.key ?? null;
        }
      }
    }

    setFocusedKey(key, child);
  };

  let selectionManager = useMemo(
    () => new SelectionManager(collection, selectionState),
    [collection, selectionState]
  );

  // Reset focused key if that item is deleted from the collection.
  const cachedCollection = useRef<C | null>(null);
  useEffect(() => {
    if (
      selectionState.focusedKey != null &&
      cachedCollection.current &&
      !collection.getItem(selectionState.focusedKey)
    ) {
      const node = cachedCollection.current.getItem(selectionState.focusedKey);
      const parentNode =
        node?.parentKey != null &&
        (node.type === 'cell' || node.type === 'rowheader' || node.type === 'column')
          ? cachedCollection.current.getItem(node.parentKey)
          : node;
      if (!parentNode) {
        selectionState.setFocusedKey(null);
        return;
      }
      const cachedRows = cachedCollection.current.rows;
      const rows = collection.rows;
      const diff = cachedRows.length - rows.length;
      let index = Math.min(
        diff > 1 ? Math.max(parentNode.index - diff + 1, 0) : parentNode.index,
        rows.length - 1
      );
      let newRow: GridNode<T> | null = null;
      // Find the nearest focusable row at or after the deleted position...
      for (let i = Math.max(0, index); i < rows.length; i++) {
        if (!selectionManager.isDisabled(rows[i].key) && rows[i].type !== 'headerrow') {
          newRow = rows[i];
          break;
        }
      }
      // ...otherwise the nearest focusable row before it. (Mirrors useListState's
      // getKeyAfter/getKeyBefore walk.)
      if (newRow === null) {
        for (let i = index - 1; i >= 0; i--) {
          if (!selectionManager.isDisabled(rows[i].key) && rows[i].type !== 'headerrow') {
            newRow = rows[i];
            break;
          }
        }
      }
      if (newRow) {
        const childNodes = newRow.hasChildNodes ? [...getChildNodes(newRow, collection)] : [];
        const keyToFocus =
          newRow.hasChildNodes && parentNode !== node && node && node.index < childNodes.length
            ? childNodes[node.index].key
            : newRow.key;
        selectionState.setFocusedKey(keyToFocus);
      } else {
        selectionState.setFocusedKey(null);
      }
    }
    cachedCollection.current = collection;
  }, [collection, selectionManager, selectionState, selectionState.focusedKey]);

  return {
    collection,
    disabledKeys,
    isKeyboardNavigationDisabled: false,
    selectionManager
  };
}
