// @ts-check

/** @type {import('@yarnpkg/types')} */
const {defineConfig} = require('@yarnpkg/types');
/**
 * @typedef {import('@yarnpkg/types').Yarn.Constraints.Workspace} Workspace
 *
 * @typedef {import('@yarnpkg/types').Yarn.Constraints.Dependency} Dependency
 */

/**
 * This rule will enforce that a workspace MUST depend on the same version of
 * a dependency as the one used by the other workspaces.
 *
 * @param {Context} context
 */
function enforceConsistentDependenciesAcrossTheProject({Yarn}) {
  // enforce react/react-dom version
  for (const dependency of Yarn.dependencies()) {
    if (dependency.type === 'peerDependencies') {
      if (dependency.ident === 'react' || dependency.ident === 'react-dom') {
        if (dependency.workspace.ident === 'storybook-react-parcel') {
          continue;
        }
        if (dependency.workspace.ident === 'storybook-builder-parcel') {
          dependency.update('*');
        } else if (
          dependency.workspace.ident === '@react-spectrum/s2' ||
          dependency.workspace.ident === '@react-spectrum/s2-icon-builder' ||
          dependency.workspace.ident === '@react-spectrum/ai'
        ) {
          dependency.update('^19.0.0-rc.1');
        } else if (dependency.workspace.ident === '@react-spectrum/codemods') {
          dependency.update('^18.0.0 || ^19.0.0-rc.1');
        } else {
          dependency.update('^16.8.0 || ^17.0.0-rc.1 || ^18.0.0 || ^19.0.0-rc.1');
        }
      }
    }

    // for (const otherDependency of Yarn.dependencies({ident: dependency.ident})) {
    //   if (otherDependency.type === `peerDependencies`)
    //     continue;
    //
    //   // useful, however, i haven't quite made it relaxed enough
    //   // dependency.update(otherDependency.range);
    // }
  }

  // enforce swc helpers version, spectrum-css-temp, and where they are placed in the package.json
  for (const workspace of Yarn.workspaces()) {
    if (
      isPublishing(workspace) &&
      // should these be included in the requirement?
      workspace.ident !== '@adobe/react-spectrum' &&
      workspace.ident !== 'react-aria' &&
      workspace.ident !== 'react-stately' &&
      workspace.ident !== '@internationalized/string-compiler' &&
      workspace.ident !== 'tailwindcss-react-aria-components' &&
      workspace.ident !== '@react-spectrum/s2' &&
      workspace.ident !== '@react-spectrum/ai' &&
      workspace.manifest.rsp?.type !== 'cli'
    ) {
      workspace.set('dependencies.@swc/helpers', '^0.5.0');
      // these should not be in dependencies, but should be in dev or peer
      // can't change the error message, but the package knows if it even needs it
      if (!workspace.ident.startsWith('@react-spectrum/test-utils-internal')) {
        workspace.set('dependencies.@react-spectrum/test-utils');
        workspace.set('dependencies.react');
        workspace.set('dependencies.react-dom');
      }
    }
  }
}

/** @param {Context} context */
function enforceNonPrivateDependencies({Yarn}) {
  // enforce that public packages do not depend on private packages
  for (const workspace of Yarn.workspaces()) {
    if (workspace.manifest.private) {
      for (const dependency of Yarn.dependencies({ident: workspace.ident})) {
        if (dependency.type !== 'devDependencies' && !dependency.workspace.manifest.private) {
          dependency.workspace.set('private', true);
          workspace.set('private', false);
        }
      }
    }
  }
}

/** @param {Context} context */
function enforceNoCircularDependencies({Yarn}) {
  // enforce that there are no circular dependencies between our packages
  function addDep(workspace, seen = new Set()) {
    if (seen.has(workspace.ident)) {
      let arr = [...seen];
      let index = arr.indexOf(workspace.ident);
      // ok for pkg to depend on itself
      if (arr.slice(index).length > 1) {
        // better to error the constraints early for this for a more meaningful error message
        throw new Error(
          `Circular dependency detected: ${arr.slice(index).join(' -> ')} -> ${workspace.ident}`
        );
      } else {
        return;
      }
    }

    seen.add(workspace.ident);

    for (let d of Yarn.dependencies({ident: workspace.ident})) {
      if (d.type === 'peerDependencies') {
        continue;
      }
      addDep(d.workspace, seen);
    }

    seen.delete(workspace.ident);
  }

  for (const workspace of Yarn.workspaces()) {
    addDep(workspace);
  }
}

/** @param {Dependency} dependency */
function isOurPackage(dependency) {
  let name = dependency.ident;
  return (
    name.includes('@react-spectrum') ||
    name.includes('@react-aria') ||
    name.includes('@react-stately') ||
    name.includes('@react-types') ||
    name.includes('@internationalized') ||
    name.includes('@spectrum-icons') ||
    name.startsWith('react-aria-components') ||
    name.startsWith('tailwindcss-react-aria-components') ||
    name.startsWith('react-aria') ||
    name.startsWith('react-stately')
  );
}

/** @param {Context} context */
function enforceWorkspaceDependencies({Yarn}) {
  for (const dependency of Yarn.dependencies()) {
    if (dependency.type === 'peerDependencies') {
      continue;
    }

    for (const otherDependency of Yarn.dependencies({ident: dependency.ident})) {
      if (otherDependency.type === 'peerDependencies') {
        continue;
      }

      if (isOurPackage(dependency)) {
        // change back to workspaces:^ when we're ready for yarn to handle versioning
        // don't check for consistency on our own packages because they can individually version and we don't bump EVERY package because of one change
        // dependency.update(otherDependency.range);
      }
    }
  }

  // This finds all the peer dependencies and checks that everything up the
  // workspace tree has the same peer dependency.
  let seen = new Map();
  for (const dependency of Yarn.dependencies()) {
    if (dependency.type === 'peerDependencies') {
      for (const workspace of Yarn.workspaces()) {
        if (
          // must check in manifest because yarn is reporting all peer in workspace.pkg.dependencies
          // and doesn't differentiate between peer and dependencies
          workspace.manifest.dependencies?.[dependency.workspace?.ident] &&
          !workspace.manifest.peerDependencies?.[dependency.ident] &&
          !workspace.manifest.dependencies?.[dependency.ident]
        ) {
          // eslint-disable-next-line max-depth
          if (seen.has(workspace.ident) && !seen.get(workspace.ident).includes(dependency.ident)) {
            seen.get(workspace.ident).push(dependency.ident);
            workspace.set('peerDependencies', {
              ...workspace.manifest.peerDependencies,
              [dependency.ident]: dependency.range
            });
          } else if (!seen.has(workspace.ident) && workspace.ident !== dependency.ident) {
            seen.set(workspace.ident, [dependency.ident]);
            workspace.set('peerDependencies', {
              ...workspace.manifest.peerDependencies,
              [dependency.ident]: dependency.range
            });
          }
        }
      }
    }
  }
}

/** @param {Workspace} workspace */
function isPublishing(workspace) {
  let name = workspace.ident;
  // should allowlist instead? workspace.manifest.private?
  return (
    !name.includes('@react-types') &&
    !name.includes('@spectrum-icons') &&
    !name.includes('@react-aria/example-theme') &&
    !name.includes('@react-spectrum/style-macro-s1') &&
    !name.includes('@react-spectrum/docs') &&
    !name.includes('@react-spectrum/s2-docs') &&
    !name.includes('parcel') &&
    !name.includes('@adobe/spectrum-css-temp') &&
    !name.includes('css-module-types') &&
    !name.includes('eslint') &&
    !name.includes('optimize-locales-plugin') &&
    name !== 'react-spectrum-monorepo'
  );
}

/** @param {Context} context */
function enforcePublishing({Yarn}) {
  // make sure fields required for publishing have been set
  for (const workspace of Yarn.workspaces()) {
    let name = workspace.ident;
    if (
      isPublishing(workspace) ||
      (workspace.manifest.rsp?.type === 'cli' && !workspace.manifest.private)
    ) {
      if (name.startsWith('@react-spectrum')) {
        workspace.set('license', 'Apache-2.0');
      }
      if (!workspace.manifest.private) {
        workspace.set('publishConfig', {access: 'public'});
      }
      workspace.set('repository', {
        type: 'git',
        url: name.startsWith('@internationalized/date')
          ? 'https://github.com/adobe/react-spectrum/tree/main/packages/@internationalized/date'
          : 'https://github.com/adobe/react-spectrum'
      });
    }
  }
}

/** @param {Context} context */
function enforceExports({Yarn}) {
  // make sure build fields are correctly set
  for (const workspace of Yarn.workspaces()) {
    let name = workspace.ident;
    if (isPublishing(workspace) && workspace.manifest.rsp?.type !== 'cli') {
      // better to do in enforceCSS? it doesn't match the set of packages handled
      if (name !== 'react-aria-components') {
        if (
          name.includes('@react-spectrum') ||
          name.includes('@adobe/react-spectrum') ||
          name.includes('@react-aria/visually-hidden')
        ) {
          workspace.set('sideEffects', ['*.css']);
        } else {
          workspace.set('sideEffects', false);
        }
      }
    }
  }
}

function enforceDevMirroringPeerDependencies({Yarn}) {
  for (const workspace of Yarn.workspaces()) {
    const peers = workspace.manifest.peerDependencies;
    if (!peers) {
      continue;
    }
    if (peers.react) {
      workspace.set('devDependencies.react', peers.react);
    }
    if (peers['react-dom']) {
      workspace.set('devDependencies.react-dom', peers['react-dom']);
    }
  }
}

module.exports = defineConfig({
  constraints: async ctx => {
    enforceWorkspaceDependencies(ctx);
    enforceConsistentDependenciesAcrossTheProject(ctx);
    enforcePublishing(ctx);
    enforceExports(ctx);
    enforceNonPrivateDependencies(ctx);
    enforceNoCircularDependencies(ctx);
    enforceDevMirroringPeerDependencies(ctx);
  }
});
