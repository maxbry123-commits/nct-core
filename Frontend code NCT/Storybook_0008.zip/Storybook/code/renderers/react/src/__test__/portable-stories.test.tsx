// @vitest-environment happy-dom
import { cleanup, render, screen } from '@testing-library/react';
import { afterEach, beforeAll, describe, expect, it, vi } from 'vitest';

import React from 'react';

import type { Meta } from '@storybook/react';

import { expectTypeOf } from 'expect-type';
import { addons, useEffect } from 'storybook/preview-api';

import { composeStories, composeStory, setProjectAnnotations } from '../index.ts';
import type { Button } from './Button.tsx';
import * as ButtonStories from './Button.stories.tsx';
import * as ComponentWithErrorStories from './ComponentWithError.stories.tsx';

const HooksStory = composeStory(ButtonStories.HooksStory, ButtonStories.default);

const projectAnnotations = setProjectAnnotations([]);

// example with composeStories, returns an object with all stories composed with args/decorators
const { CSF3Primary, LoaderStory, MountInPlayFunction, MountInPlayFunctionThrow } =
  composeStories(ButtonStories);
const { ThrowsError } = composeStories(ComponentWithErrorStories);

beforeAll(async () => {
  await projectAnnotations.beforeAll?.();
});

afterEach(() => {
  cleanup();
});

// example with composeStory, returns a single story composed with args/decorators
const Secondary = composeStory(ButtonStories.CSF2Secondary, ButtonStories.default);
describe('renders', () => {
  it('renders primary button', () => {
    render(<CSF3Primary>Hello world</CSF3Primary>);
    const buttonElement = screen.getByText(/Hello world/i);
    expect(buttonElement).not.toBeNull();
  });

  it('reuses args from composed story', () => {
    render(<Secondary />);
    const buttonElement = screen.getByRole('button');
    expect(buttonElement.textContent).toEqual(Secondary.args.children);
  });

  it('onclick handler is called', async () => {
    const onClickSpy = vi.fn();
    render(<Secondary onClick={onClickSpy} />);
    const buttonElement = screen.getByRole('button');
    buttonElement.click();
    expect(onClickSpy).toHaveBeenCalled();
  });

  it('reuses args from composeStories', () => {
    const { getByText } = render(<CSF3Primary />);
    const buttonElement = getByText(/foo/i);
    expect(buttonElement).not.toBeNull();
  });

  it('should throw error when rendering a component with a render error', async () => {
    await expect(ThrowsError.run()).rejects.toThrowError('Error in render');
  });

  it('should render component mounted in play function', async () => {
    await MountInPlayFunction.run();

    expect(screen.getByTestId('spy-data').textContent).toEqual('mockFn return value');
    expect(screen.getByTestId('loaded-data').textContent).toEqual('loaded data');
  });

  it('should throw an error in play function', async () => {
    await expect(MountInPlayFunctionThrow.run()).rejects.toThrowError('Error thrown in play');
  });

  it('should call and compose loaders data', async () => {
    await LoaderStory.load();
    const { getByTestId } = render(<LoaderStory />);
    expect(getByTestId('spy-data').textContent).toEqual('mockFn return value');
    expect(getByTestId('loaded-data').textContent).toEqual('loaded data');
    // spy assertions happen in the play function and should work
    await LoaderStory.run!();
  });
});

describe('projectAnnotations', () => {
  it('renders with default projectAnnotations', () => {
    setProjectAnnotations([
      {
        parameters: { injected: true },
        initialGlobals: { locale: 'en' },
      },
    ]);
    const WithEnglishText = composeStory(ButtonStories.CSF2StoryWithLocale, ButtonStories.default);
    const { getByText } = render(<WithEnglishText />);
    const buttonElement = getByText('Hello!');
    expect(buttonElement).not.toBeNull();
    expect(WithEnglishText.parameters?.injected).toBe(true);
  });

  it('renders with custom projectAnnotations via composeStory params', () => {
    const WithPortugueseText = composeStory(
      ButtonStories.CSF2StoryWithLocale,
      ButtonStories.default,
      {
        initialGlobals: { locale: 'pt' },
      }
    );
    const { getByText } = render(<WithPortugueseText />);
    const buttonElement = getByText('Olá!');
    expect(buttonElement).not.toBeNull();
  });

  it('has action arg from argTypes when addon-actions annotations are added', () => {
    const Story = composeStory(ButtonStories.WithActionArgType, ButtonStories.default);
    expect(Story.args.someActionArg).toHaveProperty('isAction', true);
  });
});

describe('CSF3', () => {
  it('renders with inferred globalRender', () => {
    const Primary = composeStory(ButtonStories.CSF3Button, ButtonStories.default);

    render(<Primary>Hello world</Primary>);
    const buttonElement = screen.getByText(/Hello world/i);
    expect(buttonElement).not.toBeNull();
  });

  it('renders with custom render function', () => {
    const Primary = composeStory(ButtonStories.CSF3ButtonWithRender, ButtonStories.default);

    render(<Primary />);
    expect(screen.getByTestId('custom-render')).not.toBeNull();
  });

  it('renders with play function without canvas element', async () => {
    const CSF3InputFieldFilled = composeStory(
      ButtonStories.CSF3InputFieldFilled,
      ButtonStories.default
    );
    await CSF3InputFieldFilled.run();

    const input = screen.getByTestId('input') as HTMLInputElement;
    expect(input.value).toEqual('Hello world!');
  });

  it('renders with play function with canvas element', async () => {
    const CSF3InputFieldFilled = composeStory(
      ButtonStories.CSF3InputFieldFilled,
      ButtonStories.default
    );

    const div = document.createElement('div');
    document.body.appendChild(div);

    await CSF3InputFieldFilled.run({ canvasElement: div });

    const input = screen.getByTestId('input') as HTMLInputElement;
    expect(input.value).toEqual('Hello world!');

    document.body.removeChild(div);
  });

  it('renders with hooks', async () => {
    await HooksStory.run();

    const input = screen.getByTestId('input') as HTMLInputElement;
    expect(input.value).toEqual('Hello world!');
  });
});

// common in addons that need to communicate between manager and preview
it('should pass with decorators that need addons channel', () => {
  const PrimaryWithChannels = composeStory(ButtonStories.CSF3Primary, ButtonStories.default, {
    decorators: [
      (StoryFn: any) => {
        addons.getChannel();
        return StoryFn();
      },
    ],
  });
  render(<PrimaryWithChannels>Hello world</PrimaryWithChannels>);
  const buttonElement = screen.getByText(/Hello world/i);
  expect(buttonElement).not.toBeNull();
});

// Regression: preview-api `useEffect` (the hook addon-themes' withThemeByDataAttribute uses, not
// React's) registered by a decorator must run under portable stories, so theme/direction side
// effects actually apply to the DOM before the play function / a11y check observe it.
it('flushes preview-api useEffect side-effects from decorators after run', async () => {
  const WithThemeEffect = composeStory(ButtonStories.CSF3Primary, ButtonStories.default, {
    decorators: [
      (StoryFn: any) => {
        useEffect(() => {
          document.documentElement.setAttribute('data-theme', 'dark');
          return () => document.documentElement.removeAttribute('data-theme');
        }, []);
        return StoryFn();
      },
    ],
  });

  try {
    expect(document.documentElement.getAttribute('data-theme')).toBeNull();
    await WithThemeEffect.run();
    expect(document.documentElement.getAttribute('data-theme')).toBe('dark');
  } finally {
    document.documentElement.removeAttribute('data-theme');
  }
});

describe('ComposeStories types', () => {
  // this file tests Typescript types that's why there are no assertions
  it('Should support typescript operators', () => {
    type ComposeStoriesParam = Parameters<typeof composeStories>[0];

    expectTypeOf({
      ...ButtonStories,
      default: ButtonStories.default as Meta<typeof Button>,
    }).toMatchTypeOf<ComposeStoriesParam>();

    expectTypeOf({
      ...ButtonStories,
      default: ButtonStories.default satisfies Meta<typeof Button>,
    }).toMatchTypeOf<ComposeStoriesParam>();
  });
});

const testCases = Object.values(composeStories(ButtonStories)).map(
  (Story) => [Story.storyName, Story] as [string, typeof Story]
);
it.each(testCases)('Renders %s story', async (_storyName, Story) => {
  if (_storyName === 'CSF2StoryWithLocale' || _storyName === 'MountInPlayFunctionThrow') {
    return;
  }
  await Story.run();
  expect(document.body).toMatchSnapshot();
});
