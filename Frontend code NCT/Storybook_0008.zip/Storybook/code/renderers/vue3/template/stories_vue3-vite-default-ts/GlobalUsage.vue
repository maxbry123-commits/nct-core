<template>
  <global-button />
</template>
