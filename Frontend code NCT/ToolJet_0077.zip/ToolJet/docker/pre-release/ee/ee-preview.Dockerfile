FROM node:22.15.1 AS builder
# Fix for JS heap limit allocation issue
ENV NODE_OPTIONS="--max-old-space-size=4096"

# Build nsjail for Python sandboxing
RUN apt-get update && apt-get install -y --no-install-recommends \
    autoconf \
    bison \
    flex \
    gcc \
    g++ \
    libprotobuf-dev \
    libnl-route-3-dev \
    libtool \
    make \
    pkg-config \
    protobuf-compiler \
    && rm -rf /var/lib/apt/lists/*

WORKDIR /build-nsjail
RUN git clone --depth 1 --branch 3.4 https://github.com/google/nsjail.git && \
    cd nsjail && \
    make && \
    strip nsjail

# Build Python runtime with pre-installed packages
RUN apt-get update && apt-get install -y --no-install-recommends \
    python3 \
    python3-venv \
    python3-pip \
    build-essential \
    && rm -rf /var/lib/apt/lists/*

RUN python3 -m venv /opt/python-runtime

RUN /opt/python-runtime/bin/pip install --no-cache-dir --upgrade pip setuptools wheel && \
    /opt/python-runtime/bin/pip install --no-cache-dir \
    numpy==1.26.4 \
    pandas==2.2.1 \
    requests==2.31.0 \
    httpx==0.27.0 \
    python-dateutil==2.9.0 \
    pytz==2024.1 \
    pydantic==2.6.4 \
    typing-extensions==4.10.0

RUN mkdir -p /app
WORKDIR /app

# Set GitHub token, branch and repository URL as build arguments
ARG CUSTOM_GITHUB_TOKEN
ARG BRANCH_NAME
ARG REPO_URL=https://github.com/ToolJet/ToolJet.git

# Clone and checkout the frontend repository
RUN git config --global url."https://x-access-token:${CUSTOM_GITHUB_TOKEN}@github.com/".insteadOf "https://github.com/"

RUN git config --global http.version HTTP/1.1
RUN git config --global http.postBuffer 524288000
RUN git clone ${REPO_URL} .

# The branch name needs to be changed the branch with modularisation in CE repo
RUN if git show-ref --verify --quiet refs/heads/${BRANCH_NAME} || \
       git ls-remote --exit-code --heads origin ${BRANCH_NAME}; then \
      git checkout ${BRANCH_NAME}; \
    else \
      echo "Branch ${BRANCH_NAME} not found, falling back to main"; \
      git checkout main; \
    fi

# Handle submodules - try normal submodule update first, if it fails clone directly from base repo
RUN if git submodule update --init --recursive; then \
  echo "Submodules initialized successfully"; \
  # Checkout the same branch in submodules if it exists, otherwise fallback to main
  git submodule foreach " \
    if git show-ref --verify --quiet refs/heads/${BRANCH_NAME} || \
       git ls-remote --exit-code --heads origin ${BRANCH_NAME}; then \
      git checkout ${BRANCH_NAME}; \
    else \
      echo 'Branch ${BRANCH_NAME} not found in submodule \$name, falling back to main'; \
      git checkout main; \
    fi"; \
else \
  echo "Submodule update failed, likely a forked repo. Cloning EE submodules directly from base repo."; \
  # Clone frontend/ee submodule directly
  if [ ! -d "frontend/ee" ]; then \
    mkdir -p frontend/ee; \
    git clone https://x-access-token:${CUSTOM_GITHUB_TOKEN}@github.com/ToolJet/ee-frontend.git frontend/ee; \
  fi; \
  # Clone server/ee submodule directly  
  if [ ! -d "server/ee" ]; then \
    mkdir -p server/ee; \
    git clone https://x-access-token:${CUSTOM_GITHUB_TOKEN}@github.com/ToolJet/ee-server.git server/ee; \
  fi; \
  # Checkout the same branch in EE submodules if it exists, otherwise fallback to main
  cd frontend/ee && \
  if git show-ref --verify --quiet refs/heads/${BRANCH_NAME} || \
     git ls-remote --exit-code --heads origin ${BRANCH_NAME}; then \
    git checkout ${BRANCH_NAME}; \
  else \
    echo "Branch ${BRANCH_NAME} not found in frontend/ee, falling back to main"; \
    git checkout main; \
  fi && \
  cd ../../server/ee && \
  if git show-ref --verify --quiet refs/heads/${BRANCH_NAME} || \
     git ls-remote --exit-code --heads origin ${BRANCH_NAME}; then \
    git checkout ${BRANCH_NAME}; \
  else \
    echo "Branch ${BRANCH_NAME} not found in server/ee, falling back to main"; \
    git checkout main; \
  fi && \
  cd ../..; \
fi

# Scripts for building
COPY ./package.json ./package.json

# Build plugins
COPY ./plugins/package.json ./plugins/package-lock.json ./plugins/
# Pin ibm_db's clidriver to a build linked against glibc <=2.14, since the runtime
# stage is bullseye (glibc 2.31) and the latest clidriver requires glibc 2.32+
ENV IBM_DB_INSTALLER_URL=https://public.dhe.ibm.com/ibmdl/export/pub/software/data/db2/drivers/odbc_cli/v11.5.9
RUN npm --prefix plugins install
COPY ./plugins/ ./plugins/
RUN NODE_ENV=production npm --prefix plugins run build
RUN npm --prefix plugins prune --production

ENV TOOLJET_EDITION=ee

# Build frontend
COPY ./frontend/package.json ./frontend/package-lock.json ./frontend/
RUN npm --prefix frontend install
COPY ./frontend/ ./frontend/
RUN npm --prefix frontend run build --production
RUN npm --prefix frontend prune --production

ENV NODE_ENV=production
ENV TOOLJET_EDITION=ee

# Build server
COPY ./server/package.json ./server/package-lock.json ./server/
RUN npm --prefix server install
COPY ./server/ ./server/
RUN npm install -g @nestjs/cli
RUN npm install -g copyfiles
RUN npm --prefix server run build

FROM node:22.15.1-bullseye

RUN apt-get update -yq \
    && apt-get install curl gnupg zip -yq \
    && apt-get install -yq build-essential \
    && apt-get clean -y

# copy postgrest executable
COPY --from=postgrest/postgrest:v12.2.0 /bin/postgrest /bin

ENV NODE_ENV=production
ENV TOOLJET_EDITION=ee
ENV NODE_OPTIONS="--max-old-space-size=4096"
# Install Redis 7.x from official Redis repository for BullMQ compatibility
RUN curl -fsSL https://packages.redis.io/gpg | gpg --dearmor -o /usr/share/keyrings/redis-archive-keyring.gpg \
    && echo "deb [signed-by=/usr/share/keyrings/redis-archive-keyring.gpg] https://packages.redis.io/deb bullseye main" | tee /etc/apt/sources.list.d/redis.list \
    && apt-get update && apt-get install -y freetds-dev libaio1 libxml2 wget supervisor redis-server libprotobuf23 libnl-route-3-200 python3 python3-pip

# Install Instantclient Basic Light Oracle and Dependencies
WORKDIR /opt/oracle
RUN wget https://tooljet-plugins-production.s3.us-east-2.amazonaws.com/marketplace-assets/oracledb/instantclients/instantclient-basiclite-linuxx64.zip && \
    wget https://tooljet-plugins-production.s3.us-east-2.amazonaws.com/marketplace-assets/oracledb/instantclients/instantclient-basiclite-linux.x64-11.2.0.4.0.zip && \
    unzip instantclient-basiclite-linuxx64.zip && rm -f instantclient-basiclite-linuxx64.zip && \
    unzip instantclient-basiclite-linux.x64-11.2.0.4.0.zip && rm -f instantclient-basiclite-linux.x64-11.2.0.4.0.zip && \
    cd /opt/oracle/instantclient_21_10 && rm -f *jdbc* *occi* *mysql* *mql1* *ipc1* *jar uidrvci genezi adrci && \
    cd /opt/oracle/instantclient_11_2 && rm -f *jdbc* *occi* *mysql* *mql1* *ipc1* *jar uidrvci genezi adrci && \
    echo /opt/oracle/instantclient* > /etc/ld.so.conf.d/oracle-instantclient.conf && ldconfig
# Set the Instant Client library paths
ENV LD_LIBRARY_PATH="/opt/oracle/instantclient_11_2:/opt/oracle/instantclient_21_10:${LD_LIBRARY_PATH}"

# Copy nsjail and Python runtime from builder
COPY --from=builder /build-nsjail/nsjail/nsjail /usr/local/bin/nsjail
RUN chmod 755 /usr/local/bin/nsjail

COPY --from=builder /opt/python-runtime /opt/python-runtime

# Create nsjail config directory and Python execution temp directory
RUN mkdir -p /etc/nsjail /tmp/python-exec && chmod 1777 /tmp/python-exec

WORKDIR /

# copy npm scripts
COPY --from=builder /app/package.json ./app/package.json
# copy plugins dependencies
COPY --from=builder /app/plugins/dist ./app/plugins/dist
COPY --from=builder /app/plugins/client.js ./app/plugins/client.js
COPY --from=builder /app/plugins/node_modules ./app/plugins/node_modules
COPY --from=builder /app/plugins/packages/common ./app/plugins/packages/common
COPY --from=builder /app/plugins/package.json ./app/plugins/package.json
# copy frontend build
COPY --from=builder /app/frontend/build ./app/frontend/build
# copy server build
COPY --from=builder /app/server/package.json ./app/server/package.json
COPY --from=builder /app/server/.version ./app/server/.version
COPY --from=builder /app/server/ee/keys ./app/server/ee/keys
COPY --from=builder /app/server/node_modules ./app/server/node_modules
COPY --from=builder /app/server/templates ./app/server/templates
COPY --from=builder /app/server/scripts ./app/server/scripts
COPY --from=builder /app/server/dist ./app/server/dist
# Copy nsjail configuration for Python sandboxing
COPY --from=builder /app/server/ee/workflows/nsjail/python-execution.cfg /etc/nsjail/python-execution.cfg

WORKDIR /app

# Install PostgreSQL
USER root
RUN wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | apt-key add -
RUN echo "deb http://apt.postgresql.org/pub/repos/apt/ bullseye-pgdg main" | tee /etc/apt/sources.list.d/pgdg.list
RUN apt update && apt -y install postgresql-13 postgresql-client-13 supervisor --fix-missing


# Explicitly create PG main directory with correct ownership
RUN mkdir -p /var/lib/postgresql/13/main && \
    chown -R postgres:postgres /var/lib/postgresql

RUN mkdir -p /var/log/supervisor /var/run/postgresql && \
    chown -R postgres:postgres /var/run/postgresql /var/log/supervisor

# Remove existing data and create directory with proper ownership
RUN rm -rf /var/lib/postgresql/13/main && \
    mkdir -p /var/lib/postgresql/13/main && \
    chown -R postgres:postgres /var/lib/postgresql

# Initialize PostgreSQL
RUN su - postgres -c "/usr/lib/postgresql/13/bin/initdb -D /var/lib/postgresql/13/main"

# Configure Redis for BullMQ
RUN mkdir -p /etc/redis /var/lib/redis /var/log/redis && \
    chown -R redis:redis /var/lib/redis /var/log/redis && \
    chmod 755 /var/lib/redis /var/log/redis

# Copy Redis configuration
COPY ./docker/LTS/ee/redis.conf /etc/redis/redis.conf
RUN chown redis:redis /etc/redis/redis.conf && \
    chmod 644 /etc/redis/redis.conf

# Configure Supervisor to manage PostgREST and ToolJet
# Note: PostgreSQL and Redis are started directly in preview.sh
RUN echo "[supervisord] \n" \
    "nodaemon=true \n" \
    "user=root \n" \
    "\n" \
    "[program:postgrest] \n" \
    "command=/bin/postgrest \n" \
    "autostart=true \n" \
    "autorestart=true \n" \
    "stderr_logfile=/dev/stdout \n" \
    "stderr_logfile_maxbytes=0 \n" \
    "stdout_logfile=/dev/stdout \n" \
    "stdout_logfile_maxbytes=0 \n" \
    "\n" \
    "[program:tooljet] \n" \
    "user=root \n" \
    "command=/bin/bash -c '/app/server/scripts/boot.sh' \n" \
    "autostart=true \n" \
    "autorestart=true \n" \
    "stderr_logfile=/dev/stdout \n" \
    "stderr_logfile_maxbytes=0 \n" \
    "stdout_logfile=/dev/stdout \n" \
    "stdout_logfile_maxbytes=0 \n" | sed 's/ //' > /etc/supervisor/conf.d/supervisord.conf

# ENV defaults
ENV TOOLJET_HOST=http://localhost \
    PORT=80 \
    NODE_ENV=production \
    LOCKBOX_MASTER_KEY=replace_with_lockbox_master_key \
    SECRET_KEY_BASE=replace_with_secret_key_base \
    PG_DB=tooljet_production \
    PG_USER=postgres \
    PG_PASS=postgres \
    PG_HOST=localhost \
    ENABLE_TOOLJET_DB=true \
    TOOLJET_DB_HOST=localhost \
    TOOLJET_DB_USER=postgres \
    TOOLJET_DB_PASS=postgres \
    TOOLJET_DB=tooljet_db \
    PGRST_HOST=http://localhost:3000 \
    PGRST_DB_URI=postgres://postgres:postgres@localhost/tooljet_db \
    PGRST_JWT_SECRET=r9iMKoe5CRMgvJBBtp4HrqN7QiPpUToj \
    PGRST_DB_PRE_CONFIG=postgrest.pre_config \
    REDIS_HOST=localhost \
    REDIS_PORT=6379 \
    REDIS_DB=0 \
    REDIS_TLS_ENABLED=false \
    ORM_LOGGING=true \
    DEPLOYMENT_PLATFORM=docker:local \
    HOME=/home/appuser \
    TERM=xterm


RUN chmod +x ./server/scripts/preview.sh
# Set the entrypoint
ENTRYPOINT ["./server/scripts/preview.sh"]
