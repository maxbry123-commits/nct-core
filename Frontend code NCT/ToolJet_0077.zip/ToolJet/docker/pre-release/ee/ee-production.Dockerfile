FROM node:22.15.1 AS builder

# Fix for JS heap limit allocation issue
ENV NODE_OPTIONS="--max-old-space-size=4096"

RUN npm i -g npm@10.9.2 && npm cache clean --force

# Build nsjail for Python sandboxing
RUN apt-get update && apt-get install -y --no-install-recommends \
    autoconf \
    bison \
    flex \
    gcc \
    g++ \
    libprotobuf-dev \
    libnl-route-3-dev \
    libtool \
    make \
    pkg-config \
    protobuf-compiler \
    && rm -rf /var/lib/apt/lists/*

WORKDIR /build-nsjail
RUN git clone --depth 1 --branch 3.4 https://github.com/google/nsjail.git && \
    cd nsjail && \
    make && \
    strip nsjail

# Build Python runtime with pre-installed packages
RUN apt-get update && apt-get install -y --no-install-recommends \
    python3.11 \
    python3.11-venv \
    python3-pip \
    build-essential \
    && rm -rf /var/lib/apt/lists/*

# Create isolated Python environment
RUN python3.11 -m venv /opt/python-runtime

# Upgrade pip and install common packages
RUN /opt/python-runtime/bin/pip install --no-cache-dir --upgrade pip setuptools wheel && \
    /opt/python-runtime/bin/pip install --no-cache-dir \
    numpy==1.26.4 \
    pandas==2.2.1 \
    requests==2.31.0 \
    httpx==0.27.0 \
    python-dateutil==2.9.0 \
    pytz==2024.1 \
    pydantic==2.6.4 \
    typing-extensions==4.10.0

RUN mkdir -p /app
WORKDIR /app

# Set GitHub token and branch as build arguments
ARG CUSTOM_GITHUB_TOKEN
ARG BRANCH_NAME

# Clone and checkout the frontend repository
RUN git config --global url."https://x-access-token:${CUSTOM_GITHUB_TOKEN}@github.com/".insteadOf "https://github.com/"

RUN git config --global http.version HTTP/1.1
RUN git config --global http.postBuffer 524288000
RUN git clone https://github.com/ToolJet/ToolJet.git .

# The branch name needs to be changed the branch with modularisation in CE repo
RUN git checkout ${BRANCH_NAME}

RUN git submodule update --init --recursive

# Checkout the same branch in submodules if it exists, otherwise fallback to main
RUN git submodule foreach " \
  if git show-ref --verify --quiet refs/heads/${BRANCH_NAME} || \
     git ls-remote --exit-code --heads origin ${BRANCH_NAME}; then \
    git checkout ${BRANCH_NAME}; \
  else \
    echo 'Branch ${BRANCH_NAME} not found in submodule \$name, falling back to main'; \
    git checkout main; \
  fi"

# Scripts for building
COPY ./package.json ./package.json

# Build plugins
COPY ./plugins/package.json ./plugins/package-lock.json ./plugins/
RUN npm --prefix plugins install
COPY ./plugins/ ./plugins/
RUN NODE_ENV=production npm --prefix plugins run build
RUN npm --prefix plugins prune --production 

ENV TOOLJET_EDITION=ee

# Build frontend
COPY ./frontend/package.json ./frontend/package-lock.json ./frontend/
RUN npm --prefix frontend install
COPY ./frontend/ ./frontend/
RUN npm --prefix frontend run build --production && npm --prefix frontend prune --production

ENV NODE_ENV=production
ENV TOOLJET_EDITION=ee

# Build server
COPY ./server/package.json ./server/package-lock.json ./server/
RUN npm --prefix server ci --omit=dev
COPY ./server/ ./server/
RUN npm install -g @nestjs/cli && npm install -g copyfiles
RUN npm --prefix server run build && npm prune --production --prefix server

# Install dependencies for PostgREST, curl, tar, etc.
RUN apt-get update && apt-get install -y \
    curl ca-certificates tar \
    && rm -rf /var/lib/apt/lists/*

ENV POSTGREST_VERSION=v12.2.0

RUN curl -fSL --retry 3 --retry-delay 5 -o postgrest.tar.xz "https://github.com/PostgREST/postgrest/releases/download/${POSTGREST_VERSION}/postgrest-${POSTGREST_VERSION}-linux-static-x64.tar.xz" && \
    tar -xf postgrest.tar.xz && \
    mv postgrest /postgrest && \
    rm postgrest.tar.xz && \
    chmod +x /postgrest

FROM debian:12-slim

RUN apt-get update && \
    apt-get install -y --no-install-recommends \
    curl \
    wget \
    gnupg \
    unzip \
    ca-certificates \
    xz-utils \
    tar \
    postgresql-client \
    redis \
    libaio1 \
    libxml2 \
    git \
    openssh-client \
    freetds-dev \
    python3.11 \
    python3.11-venv \
    libprotobuf32 \
    libnl-route-3-200 \
    procps \
    libcap2-bin \
    && apt-get upgrade -y -o Dpkg::Options::="--force-confold" \
    && apt-get autoremove -y \
    && apt-get clean && rm -rf /var/lib/apt/lists/*


RUN curl -O https://nodejs.org/dist/v22.15.1/node-v22.15.1-linux-x64.tar.xz \
    && tar -xf node-v22.15.1-linux-x64.tar.xz \
    && mv node-v22.15.1-linux-x64 /usr/local/lib/nodejs \
    && echo 'export PATH="/usr/local/lib/nodejs/bin:$PATH"' >> /etc/profile.d/nodejs.sh \
    && /bin/bash -c "source /etc/profile.d/nodejs.sh" \
    && rm node-v22.15.1-linux-x64.tar.xz
ENV PATH=/usr/local/lib/nodejs/bin:/opt/python-runtime/bin:$PATH

ENV NODE_ENV=production
ENV TOOLJET_EDITION=ee
ENV NODE_OPTIONS="--max-old-space-size=4096"


# Install Instantclient Basic Light Oracle and Dependencies
WORKDIR /opt/oracle

RUN wget https://tooljet-plugins-production.s3.us-east-2.amazonaws.com/marketplace-assets/oracledb/instantclients/instantclient-basiclite-linuxx64.zip && \
    wget https://tooljet-plugins-production.s3.us-east-2.amazonaws.com/marketplace-assets/oracledb/instantclients/instantclient-basiclite-linux.x64-11.2.0.4.0.zip && \
    unzip instantclient-basiclite-linuxx64.zip && rm -f instantclient-basiclite-linuxx64.zip && \
    unzip instantclient-basiclite-linux.x64-11.2.0.4.0.zip && rm -f instantclient-basiclite-linux.x64-11.2.0.4.0.zip && \
    cd /opt/oracle/instantclient_21_10 && rm -f *jdbc* *occi* *mysql* *mql1* *ipc1* *jar uidrvci genezi adrci && \
    cd /opt/oracle/instantclient_11_2 && rm -f *jdbc* *occi* *mysql* *mql1* *ipc1* *jar uidrvci genezi adrci && \
    echo /opt/oracle/instantclient* > /etc/ld.so.conf.d/oracle-instantclient.conf && ldconfig
# Set the Instant Client library paths
ENV LD_LIBRARY_PATH="/opt/oracle/instantclient_11_2:/opt/oracle/instantclient_21_10:${LD_LIBRARY_PATH}"

RUN rm -f *.zip *.key && apt-get clean && rm -rf /var/lib/apt/lists/*

WORKDIR /

RUN mkdir -p /app

RUN useradd --create-home --home-dir /home/appuser appuser

# Copy nsjail and Python runtime from builder
COPY --from=builder /build-nsjail/nsjail/nsjail /usr/local/bin/nsjail
RUN chmod 4755 /usr/local/bin/nsjail

# Copy Python runtime with pre-installed packages
COPY --from=builder /opt/python-runtime /opt/python-runtime

# Copy nsjail configuration file
RUN mkdir -p /etc/nsjail
COPY --from=builder /app/server/ee/workflows/nsjail/python-execution.cfg /etc/nsjail/python-execution.cfg

# Create Python execution directories
RUN mkdir -p \
    /tmp/python-execution \
    /tmp/python-bundles \
    && chmod 1777 /tmp/python-execution \
    && chmod 1777 /tmp/python-bundles

# Use the PostgREST binary from the builder stage
COPY --from=builder --chown=appuser:0 /postgrest /usr/local/bin/postgrest

RUN mv /usr/local/bin/postgrest /usr/local/bin/postgrest-original && \
    echo '#!/bin/bash\nexec /usr/local/bin/postgrest-original "$@" 2>&1 | sed "s/^/[PostgREST] /"' > /usr/local/bin/postgrest && \
    chmod +x /usr/local/bin/postgrest


# Copy application with ownership set directly to avoid chown -R
COPY --from=builder --chown=appuser:0 /app/package.json ./app/package.json
COPY --from=builder --chown=appuser:0 /app/plugins/dist ./app/plugins/dist
COPY --from=builder --chown=appuser:0 /app/plugins/client.js ./app/plugins/client.js
COPY --from=builder --chown=appuser:0 /app/plugins/node_modules ./app/plugins/node_modules
COPY --from=builder --chown=appuser:0 /app/plugins/packages/common ./app/plugins/packages/common
COPY --from=builder --chown=appuser:0 /app/plugins/package.json ./app/plugins/package.json
COPY --from=builder --chown=appuser:0 /app/frontend/build ./app/frontend/build
COPY --from=builder --chown=appuser:0 /app/server/package.json ./app/server/package.json
COPY --from=builder --chown=appuser:0 /app/server/.version ./app/server/.version
COPY --from=builder --chown=appuser:0 /app/server/ee/keys ./app/server/ee/keys
COPY --from=builder --chown=appuser:0 /app/server/node_modules ./app/server/node_modules
COPY --from=builder --chown=appuser:0 /app/server/templates ./app/server/templates
COPY --from=builder --chown=appuser:0 /app/server/scripts ./app/server/scripts
COPY --from=builder --chown=appuser:0 /app/server/dist ./app/server/dist
COPY --from=builder --chown=appuser:0 /app/server/ee/ai/assets ./app/server/ee/ai/assets
COPY ./docker/pre-release/ee/ee-entrypoint.sh ./app/server/ee-entrypoint.sh

# Set group write permissions for frontend build files to support RedHat arbitrary user assignment
RUN chmod -R g+w /app/frontend/build

# Create directory /home/appuser and set ownership to appuser
RUN mkdir -p /home/appuser \
    && chown -R appuser:0 /home/appuser \
    && chmod g+s /home/appuser \
    && chmod -R g=u /home/appuser \
    && npm cache clean --force

# Create gitsync directory with proper permissions for RedHat/OpenShift arbitrary UID support
RUN mkdir -p /app/server/tooljet/gitsync \
      && chown -R appuser:0 /app/server/tooljet \
      && chmod -R 2770 /app/server/tooljet/gitsync

# Create rsyslog directory for audit logs with proper permissions
RUN mkdir -p /home/appuser/rsyslog \
    && chown -R appuser:0 /home/appuser/rsyslog \
    && chmod g+s /home/appuser/rsyslog \
    && chmod -R g=u /home/appuser/rsyslog

# Create directory /tmp/.npm/npm-cache/ and set ownership to appuser
RUN mkdir -p /tmp/.npm/npm-cache/ \
    && chown -R appuser:0 /tmp/.npm/npm-cache/ \
    && chmod g+s /tmp/.npm/npm-cache/ \
    && chmod -R g=u /tmp/.npm/npm-cache \
    && npm cache clean --force

# Set npm cache directory globally
RUN npm config set cache /tmp/.npm/npm-cache/ --global
ENV npm_config_cache /tmp/.npm/npm-cache/

# Create directory /tmp/.npm/npm-cache/_logs and set ownership to appuser
RUN mkdir -p /tmp/.npm/npm-cache/_logs \
    && chown -R appuser:0 /tmp/.npm/npm-cache/_logs \
    && chmod g+s /tmp/.npm/npm-cache/_logs \
    && chmod -R g=u /tmp/.npm/npm-cache/_logs

# Create Redis data, log, and configuration directories
RUN mkdir -p /var/lib/redis /var/log/redis /etc/redis \
    && chown -R appuser:0 /var/lib/redis /var/log/redis /etc/redis \
    && chmod g+s /var/lib/redis /var/log/redis /etc/redis \
    && chmod -R g=u /var/lib/redis /var/log/redis /etc/redis

ENV HOME=/home/appuser
# Switch back to appuser
USER appuser
WORKDIR /app

RUN npm install --prefix server --no-save dotenv@10.0.0 joi@17.4.1 && npm cache clean --force

ENTRYPOINT ["./server/ee-entrypoint.sh"]
