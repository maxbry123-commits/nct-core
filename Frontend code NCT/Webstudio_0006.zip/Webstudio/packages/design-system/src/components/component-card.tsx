/**
 * Implementation of the "Component Card" component from:
 * https://www.figma.com/file/sfCE7iLS0k25qCxiifQNLE/%F0%9F%93%9A-Webstudio-Library?node-id=2608-8921
 */

import {
  forwardRef,
  type ComponentProps,
  type JSX,
  type ReactNode,
} from "react";
import { css, theme, type CSS } from "../stitches.config";
import { textVariants } from "./text";
import { Tooltip } from "./tooltip";
import { cssVar } from "../css-var";

const cardStyle = css({
  boxSizing: "border-box",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  textAlign: "center",
  padding: theme.spacing[3],
  aspectRatio: "1",
  border: `1px solid`,
  borderColor: cssVar("--border-default"),
  borderRadius: theme.borderRadius[4],
  outline: "none",
  userSelect: "none",
  color: cssVar("--foreground-primary"),
  cursor: "grab",
  background: cssVar("--background-primary"),
  "&:hover, &[data-state=hover]": {
    background: cssVar("--overlay-interaction-hover"),
  },
  "&[data-state=disabled]": {
    background: cssVar("--background-primary"),
    color: cssVar("--foreground-disabled"),
  },
  "&:focus-visible, &[data-state=selected]": {
    borderColor: cssVar("--border-focus"),
  },
  "& svg": {
    flexGrow: 0,
    marginTop: theme.spacing[7],
    width: 22,
    height: 22,
  },
});

const textContainerStyle = css({
  display: "flex",
  flexDirection: "column",
  justifyContent: "center",
  flexGrow: 1,
  width: "100%",
});

const textStyle = css(textVariants.small, {
  display: "-webkit-box",
  WebkitLineClamp: 2,
  WebkitBoxOrient: "vertical",
  overflow: "hidden",
  textOverflow: "ellipsis",
});

type ComponentCardProps = {
  label: ReactNode;
  description?: string;
  icon: JSX.Element;
  state?: "hover" | "disabled" | "selected";
  disableTooltip?: boolean;
  css?: CSS;
} & ComponentProps<"div">;

export const ComponentCard = forwardRef<HTMLDivElement, ComponentCardProps>(
  (
    {
      icon,
      label,
      className,
      css,
      state,
      description,
      disableTooltip,
      ...props
    },
    ref
  ) => {
    return (
      <Tooltip
        disableHoverableContent
        open={disableTooltip ? false : undefined}
        content={description ?? label}
        css={{ maxWidth: theme.spacing[28] }}
      >
        <div
          className={cardStyle({ className, css })}
          ref={ref}
          data-state={state}
          {...props}
        >
          {icon}

          <div className={textContainerStyle()}>
            <div className={textStyle()}>{label}</div>
          </div>
        </div>
      </Tooltip>
    );
  }
);

ComponentCard.displayName = "ComponentCard";
