import { executeExpression } from "./expression";
import {
  isPageDraft,
  type Folder,
  type Page,
  type PageTemplate,
  type Pages,
} from "./schema/pages";
import { isPathnamePattern } from "./url-pattern";

export const ROOT_FOLDER_ID = "root";

/**
 * Narrows Page | PageTemplate to Page.
 * Templates have no `path` field; pages always do.
 */
export const isPage = (page: Page | PageTemplate | undefined): page is Page =>
  page !== undefined && "path" in page;

/**
 * Narrows Page | PageTemplate to PageTemplate.
 */
export const isPageTemplate = (
  page: Page | PageTemplate | undefined
): page is PageTemplate & { path?: never } =>
  page !== undefined && !("path" in page);

/**
 * Returns true if folder is the root folder.
 */
export const isRootFolder = ({ id }: { id: Folder["id"] }) =>
  id === ROOT_FOLDER_ID;

export const getPageById = (
  pages: Pages,
  pageId: Page["id"]
): Page | undefined => {
  return pages.pages.get(pageId);
};

export const getFolderById = (
  pages: Pages,
  folderId: Folder["id"]
): Folder | undefined => {
  return pages.folders.get(folderId);
};

export const getAllPages = (pages: Pages): Page[] => {
  return Array.from(pages.pages.values());
};

export const getPublishablePages = (pages: Pages): Page[] =>
  getAllPages(pages).filter((page) => isPageDraft(page) === false);

export const getAllFolders = (pages: Pages): Folder[] => {
  return Array.from(pages.folders.values());
};

export const getHomePage = (pages: Pages): Page => {
  const homePage = getPageById(pages, pages.homePageId);
  if (homePage === undefined) {
    throw new Error(`Home page "${pages.homePageId}" was not found.`);
  }
  return homePage;
};

/**
 * Find a page by id or path. Pass { includeTemplates: true } to also search
 * pageTemplates (builder-only call sites: canvas awareness, selected-page
 * computation). Without the flag the return type is `Page | undefined` so
 * existing call sites are unaffected.
 */
export function findPageByIdOrPath(
  idOrPath: string,
  pages: Pages,
  options: { includeTemplates: true }
): Page | PageTemplate | undefined;
export function findPageByIdOrPath(
  idOrPath: string,
  pages: Pages,
  options?: { includeTemplates?: false }
): Page | undefined;
export function findPageByIdOrPath(
  idOrPath: string,
  pages: Pages,
  options: { includeTemplates?: boolean } = {}
): Page | PageTemplate | undefined {
  if (idOrPath === "" || idOrPath === "/" || idOrPath === pages.homePageId) {
    return getHomePage(pages);
  }
  const found = getAllPages(pages).find(
    (page) => page.id === idOrPath || getPagePath(page.id, pages) === idOrPath
  );
  if (found) {
    return found;
  }
  if (options.includeTemplates) {
    return pages.pageTemplates?.get(idOrPath);
  }
}

/**
 * Find a folder that has has that id in the children.
 */
export const findParentFolderByChildId = (
  id: Folder["id"] | Page["id"],
  folders: Iterable<Folder> | Map<Folder["id"], Folder>
): Folder | undefined => {
  const folderList = folders instanceof Map ? folders.values() : folders;
  for (const folder of folderList) {
    if (folder.children.includes(id)) {
      return folder;
    }
  }
};

/**
 * Get a path from all folder slugs from root to the current folder or page.
 */
export const getPagePath = (id: Folder["id"] | Page["id"], pages: Pages) => {
  const foldersMap = new Map<Folder["id"], Folder>();
  const childParentMap = new Map<Folder["id"] | Page["id"], Folder["id"]>();
  for (const folder of getAllFolders(pages)) {
    foldersMap.set(folder.id, folder);
    for (const childId of folder.children) {
      childParentMap.set(childId, folder.id);
    }
  }

  const paths = [];
  let currentId: undefined | string = id;

  // In case id is a page id
  const allPages = getAllPages(pages);
  for (const page of allPages) {
    if (page.id === id) {
      paths.push(page.path);
      currentId = childParentMap.get(page.id);
      break;
    }
  }

  while (currentId) {
    const folder = foldersMap.get(currentId);
    if (folder === undefined) {
      break;
    }
    paths.push(folder.slug);
    currentId = childParentMap.get(currentId);
  }

  return paths.reverse().join("/").replace(/\/+/g, "/");
};

/** Checks page-level sitemap settings independently of its concrete path. */
export const isPageEligibleForSitemap = (page: Page) =>
  (page.meta.documentType ?? "html") === "html" &&
  // A dynamic expression cannot be evaluated without its resource data, so it
  // remains eligible just as it did for static sitemap generation.
  executeExpression(page.meta.excludePageFromSearch) !== true;

export const getStaticSiteMapXml = (pages: Pages, updatedAt: string) => {
  const allPages = getPublishablePages(pages);
  return allPages
    .filter(isPageEligibleForSitemap)
    .filter((page) => false === isPathnamePattern(page.path))
    .map((page) => ({
      path: getPagePath(page.id, pages),
      lastModified: updatedAt.split("T")[0],
    }));
};
