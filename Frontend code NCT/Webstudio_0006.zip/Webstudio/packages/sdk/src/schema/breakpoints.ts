import { z } from "zod";

const breakpointId = z.string();

export const breakpoint = z
  .object({
    id: breakpointId,
    label: z.string(),
    minWidth: z.number().optional(),
    maxWidth: z.number().optional(),
    condition: z.string().optional(),
  })
  .transform((data) => {
    // Normalize empty condition strings to undefined
    if (data.condition !== undefined && data.condition.trim() === "") {
      return { ...data, condition: undefined };
    }
    return data;
  })
  .refine(({ minWidth, maxWidth, condition }) => {
    // If condition is set, minWidth and maxWidth should not be set
    if (condition !== undefined) {
      return minWidth === undefined && maxWidth === undefined;
    }
    // When both min and max width are defined, min must be less than max
    if (minWidth !== undefined && maxWidth !== undefined) {
      return minWidth < maxWidth;
    }
    return true;
  }, "Width-based (minWidth/maxWidth) and condition are mutually exclusive, and minWidth must be less than maxWidth");

export type Breakpoint = z.infer<typeof breakpoint>;

export const breakpoints = z.map(breakpointId, breakpoint);

export type Breakpoints = z.infer<typeof breakpoints>;

export const initialBreakpoints: Array<Breakpoint> = [
  { id: "placeholder", label: "Base" },
  { id: "placeholder", label: "Tablet", maxWidth: 991 },
  { id: "placeholder", label: "Mobile landscape", maxWidth: 767 },
  { id: "placeholder", label: "Mobile portrait", maxWidth: 479 },
];
