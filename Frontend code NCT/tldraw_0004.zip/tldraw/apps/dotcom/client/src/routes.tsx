import { captureException } from '@sentry/react'
import { THUMBNAIL_RENDER_PATH } from '@tldraw/dotcom-shared'
import { TLRemoteSyncError, TLSyncErrorCloseEventReason } from '@tldraw/sync-core'
import { Suspense, lazy, useEffect } from 'react'
import { Helmet } from 'react-helmet-async'
import { Outlet, Route, createRoutesFromElements, redirect, useRouteError } from 'react-router-dom'
import { ErrorPage } from './components/ErrorPage/ErrorPage'
import { notFound } from './pages/not-found'
import { ROUTES, routes } from './routeDefs'
import { TlaNotFoundError } from './tla/utils/notFoundError'

const LoginRedirectPage = lazy(() => import('./components/LoginRedirectPage/LoginRedirectPage'))

interface CreateAppRouterOptions {
	includeDevRoutes?: boolean
}

function getDefaultIncludeDevRoutes() {
	// @ts-ignore this is provided by Vite
	return import.meta.env.DEV
}

export function createAppRouter({
	includeDevRoutes = getDefaultIncludeDevRoutes(),
}: CreateAppRouterOptions = {}) {
	return createRoutesFromElements(
		<Route
			ErrorBoundary={() => {
				const error = useRouteError()
				useEffect(() => {
					captureException(error)
				}, [error])

				let header = 'Something went wrong'
				let para1 =
					'Please try refreshing the page. Still having trouble? Let us know at hello@tldraw.com.'
				if (error instanceof TLRemoteSyncError) {
					switch (error.reason) {
						case TLSyncErrorCloseEventReason.NOT_FOUND: {
							header = 'Not found'
							para1 = 'The file you are looking for does not exist.'
							break
						}
						case TLSyncErrorCloseEventReason.NOT_AUTHENTICATED: {
							return (
								<Suspense>
									<LoginRedirectPage />
								</Suspense>
							)
						}
						case TLSyncErrorCloseEventReason.FORBIDDEN: {
							header = 'Invite only'
							para1 = `You don't have permission to view this room.`
							break
						}
						case TLSyncErrorCloseEventReason.RATE_LIMITED: {
							header = 'Rate limited'
							para1 = `Please slow down.`
							break
						}
					}
				}
				if (error instanceof TlaNotFoundError) {
					return notFound()
				}

				return (
					<ErrorPage
						messages={{
							header,
							para1,
						}}
					/>
				)
			}}
		>
			{includeDevRoutes && (
				<>
					<Route
						path="/dev/reset-local-state"
						lazy={() => import('./pages/dev-reset-local-state')}
					/>
					<Route
						path="/dev/browser-run-thumbnail"
						lazy={() => import('./pages/dev-browser-run-thumbnail')}
					/>
				</>
			)}
			<Route lazy={() => import('./tla/providers/TlaRootProviders')}>
				<Route path={ROUTES.tlaRoot} lazy={() => import('./tla/pages/local')} />
				<Route element={<NoIndex />}>
					<Route path={ROUTES.tlaNew} lazy={() => import('./pages/tla-new')} />
					<Route path={ROUTES.tlaOptIn} loader={() => redirect(routes.tlaRoot())} />
					<Route path={ROUTES.tlaLocalFile} lazy={() => import('./tla/pages/local-file')} />
					<Route
						path={ROUTES.tlaLocalFileIndex}
						lazy={() => import('./tla/pages/local-file-index')}
					/>
					{/* File view */}
					<Route path={ROUTES.tlaFile} lazy={() => import('./tla/pages/file')} />
					<Route lazy={() => import('./tla/providers/RequireTldrawStaff')}>
						<Route path={ROUTES.tlaFileHistory} lazy={() => import('./tla/pages/file-history')} />
						<Route
							path={ROUTES.tlaFileHistorySnapshot}
							lazy={() => import('./tla/pages/file-history-snapshot')}
						/>
						<Route
							path={ROUTES.tlaLegacyRoomHistory}
							lazy={() => import('./tla/pages/legacy-history')}
						/>
						<Route
							path={ROUTES.tlaLegacyRoomHistorySnapshot}
							lazy={() => import('./tla/pages/legacy-history-snapshot')}
						/>
					</Route>

					<Route path={ROUTES.tlaPublish} lazy={() => import('./tla/pages/publish')} />
					<Route path={ROUTES.tlaImport} lazy={() => import('./tla/pages/import')} />
					<Route path={ROUTES.tlaInvite} lazy={() => import('./tla/pages/invite')} />
					{/* Legacy room */}
					<Route path={ROUTES.tlaLegacyRoom} lazy={() => import('./tla/pages/legacy-room')} />
					{/* Legacy readonly */}
					<Route
						path={ROUTES.tlaLegacyReadonly}
						lazy={() => import('./tla/pages/legacy-readonly')}
					/>
					<Route
						path={ROUTES.tlaLegacyReadonlyOld}
						lazy={() => import('./tla/pages/legacy-readonly-old')}
					/>
					{/* Legacy snapshot */}
					<Route
						path={ROUTES.tlaLegacySnapshot}
						lazy={() => import('./tla/pages/legacy-snapshot')}
					/>
					{/* Views that require login */}
					<Route lazy={() => import('./tla/providers/RequireSignedInUser')}></Route>
					{/* Two explicit routes, not one optional segment: the Vercel rewrite derived from
					    a trailing optional param drops the optionality and 404s bare /admin */}
					<Route path="/admin" lazy={() => import('./pages/admin')} />
					<Route path="/admin/:section" lazy={() => import('./pages/admin')} />
				</Route>
			</Route>
			<Route path="/__debug-tail" lazy={() => import('./tla/pages/worker-debug-tail')} />
			{/* Renders a board for Browser Run thumbnail capture from a signed render token */}
			<Route path={THUMBNAIL_RENDER_PATH} lazy={() => import('./pages/thumbnail-render')} />
			<Route path="*" lazy={() => import('./pages/not-found')} />
		</Route>
	)
}

export const router = createAppRouter()

function NoIndex() {
	return (
		<>
			<Helmet>
				<meta name="robots" content="noindex, noimageindex, nofollow" />
			</Helmet>
			<Outlet />
		</>
	)
}
