import { memo, useCallback, useEffect } from 'react'
import { tlmenus, useMaybeEditor } from 'tldraw'
import { useActiveWorkspaceId } from '../../hooks/useActiveWorkspaceId'
import { useIsCommentingEnabled } from '../../hooks/useIsCommentingEnabled'
import { useTldrFileDrop } from '../../hooks/useTldrFileDrop'
import { useTldrawAppUiEvents } from '../../utils/app-ui-events'
import {
	getIsSidebarOpen,
	toggleSidebar,
	updateLocalSessionState,
	useIsSidebarOpen,
	useIsSidebarOpenMobile,
} from '../../utils/local-session-state'
import { TlaSidebarCreateFileButton } from './components/TlaSidebarCreateFileButton'
import { TlaSidebarDotDevLink } from './components/TlaSidebarDotDevLink'
import { TlaSidebarFeedbackButton } from './components/TlaSidebarFeedbackButton'
import { TlaSidebarNotificationsButton } from './components/TlaSidebarNotificationsButton'
import { TlaSidebarRecentFiles } from './components/TlaSidebarRecentFiles'
import { TlaUserSettingsMenu } from './components/TlaSidebarUserSettingsMenu'
import { TlaSidebarWorkspaceActions } from './components/TlaSidebarWorkspaceActions'
import { TlaSidebarWorkspaceLink } from './components/TlaSidebarWorkspaceLink'
import { TlaSidebarWorkspaceSwitcher } from './components/TlaSidebarWorkspaceSwitcher'
import styles from './sidebar.module.css'

export const TlaSidebar = memo(function TlaSidebar() {
	const isSidebarOpen = useIsSidebarOpen()
	const isSidebarOpenMobile = useIsSidebarOpenMobile()
	const trackEvent = useTldrawAppUiEvents()
	const editor = useMaybeEditor()

	useEffect(() => {
		function handleKeyDown(e: KeyboardEvent) {
			if (e.key === '\\' && (e.ctrlKey || e.metaKey)) {
				toggleSidebar()
				trackEvent('sidebar-toggle', {
					value: getIsSidebarOpen(),
					source: 'sidebar',
				})
			}
		}
		window.addEventListener('keydown', handleKeyDown)
		return () => {
			window.removeEventListener('keydown', handleKeyDown)
		}
	}, [trackEvent])

	const handleOverlayClick = useCallback(() => {
		// The sidebar only hides (CSS transform), it doesn't unmount, so its portaled menus
		// (workspace switcher, file/user menus) would otherwise stay open over the canvas once the
		// sidebar is closed. Close them — scoped to this editor's menus plus the global switcher id.
		// The scope matters: open SDK dialogs register in the same tlmenus registry under the 'tla'
		// context, and an arg-less clearOpenMenus() would evict them while they stay mounted, leaving
		// the editor's menu-gated behavior (canvas click-capture, shortcuts, clipboard guards)
		// thinking nothing is open.
		if (editor) tlmenus.clearOpenMenus(editor.contextId)
		tlmenus.deleteOpenMenu('sidebar-workspace-switcher')
		updateLocalSessionState(() => ({ isSidebarOpenMobile: false }))
	}, [editor])

	const { onDrop, onDragOver, onDragEnter, onDragLeave } = useTldrFileDrop()

	const activeWorkspaceId = useActiveWorkspaceId()
	const commentingEnabled = useIsCommentingEnabled()

	return (
		<nav aria-hidden={!isSidebarOpen} style={{ visibility: isSidebarOpen ? 'visible' : 'hidden' }}>
			<button
				className={styles.sidebarOverlayMobile}
				data-visiblemobile={isSidebarOpenMobile}
				data-testid="tla-sidebar-overlay-mobile"
				onClick={handleOverlayClick}
			/>
			<div
				className={styles.sidebar}
				data-visible={isSidebarOpen}
				data-visiblemobile={isSidebarOpenMobile}
				data-testid="tla-sidebar"
				onDropCapture={onDrop}
				onDragOver={onDragOver}
				onDragEnter={onDragEnter}
				onDragLeave={onDragLeave}
			>
				<div className={styles.sidebarTopRow}>
					<TlaSidebarWorkspaceLink />
					<div style={{ display: 'flex', alignItems: 'center' }}>
						{commentingEnabled && <TlaSidebarNotificationsButton />}
						<TlaSidebarCreateFileButton />
					</div>
				</div>
				{/* The workspace switcher is fixed; only the file list below it scrolls. */}
				<TlaSidebarWorkspaceSwitcher />
				<div className={styles.sidebarDivider} />
				<TlaSidebarWorkspaceActions workspaceId={activeWorkspaceId} />
				<div className={styles.sidebarDivider} />
				<div className={styles.sidebarContent} data-sidebar-scroll-container>
					<div className={styles.sidebarContentInner}>
						<TlaSidebarRecentFiles />
					</div>
				</div>
				<div className={styles.sidebarBottomArea}>
					<div className={styles.sidebarDivider} />
					<TlaSidebarDotDevLink />
					<TlaSidebarFeedbackButton />
					<div className={styles.sidebarBottomRow}>
						<TlaUserSettingsMenu />
					</div>
				</div>
			</div>
		</nav>
	)
})
